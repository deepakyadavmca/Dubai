﻿using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models.ContentPortal;
using Google.Api.Gax;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Clients
{
    public interface IFirebaseClient
    {
        Task<T> GetUserAsync<T>(string uId) where T: class;
        Task<List<UserRecord>> GetUsersAsync(Roles role);
        Task<T> UpdateUserAsync<T>(UserRecordArgs userRecord) where T : class;
        Task<T> CreateUserAsync<T>(UserRecordArgs userRecord, Roles role) where T : class;
        Task<bool> DeleteUserAsync(string uId);
        Task<bool> SetClaims(string uId, IReadOnlyDictionary<string, object> claims);
        Task<string> GeneratePasswordReset(string email);

        Task<T> GetUserByEmail<T>(string email) where T : class;
    }
}
