﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Clients
{
    public class UserInfo
    {
        public string DisplayName { get; set; }
        public IReadOnlyDictionary<string, object> CustomClaims { get; set; }
        public string Email { get; set; }
        public string UId { get; set; }
        public string PhoneNumber { get; set; }
    }
}
