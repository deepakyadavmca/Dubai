﻿using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models.ContentPortal;
using Google.Api.Gax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;

namespace Wexer.Content.Portal.Clients
{
    public class FirebaseClient : IFirebaseClient
    {
        private readonly FirebaseAuth _auth;
        private readonly ILogger _logger;
        public FirebaseClient(ILoggerFactory loggerFactory)
        {
            _auth = FirebaseAuth.DefaultInstance;
            _logger = loggerFactory.GetLoggerForClass(this);
        }


        public async Task<T> CreateUserAsync<T>(UserRecordArgs userRecord, Roles role) where T : class
        {
            try
            {
                var createUserResponse = await _auth.CreateUserAsync(userRecord).ConfigureAwait(false);
                if (createUserResponse != null)
                {
                    UserInfo user = new UserInfo();
                    user.DisplayName = createUserResponse.DisplayName;
                    user.UId = createUserResponse.Uid;
                    user.Email = createUserResponse.Email;

                    return user as T;
                }
                return null;
            }
            catch (Exception ex)
            {
                _logger.Warn("CreateUserAsync failed", "warn", ex.ToString());
                return null;
            }
        }

        public async Task<bool> DeleteUserAsync(string uId)
        {
            try
            {
                var deleteUser = _auth.DeleteUserAsync(uId);
                await Task.WhenAll(deleteUser).ConfigureAwait(false);
                return deleteUser.IsCompletedSuccessfully ? true : false;
            }
            catch (Exception e)
            {
                _logger.Warn("DeleteUserAsync failed", "warn", e.ToString());
                return false;
            }
        }

        public async Task<T> GetUserAsync<T>(string uId) where T : class
        {
            try
            {
                var user = await _auth.GetUserAsync(uId).ConfigureAwait(false);
                UserInfo userInfo = new UserInfo();
                userInfo.CustomClaims = user.CustomClaims;
                userInfo.UId = user.Uid;
                userInfo.DisplayName = user.DisplayName;
                userInfo.Email = user.Email;
                return userInfo as T;
            }
            catch (Exception ex)
            {
                _logger.Warn("GetUserAsync failed", "warn", ex.ToString());
                return null;
            }
        }

        public async Task<List<UserRecord>> GetUsersAsync(Roles role)
        {
            List<UserRecord> users = new List<UserRecord>();
            try
            {
                var pagedEnumerable = _auth.ListUsersAsync(null);
                var responses = pagedEnumerable.AsRawResponses().GetEnumerator();
                while (await responses.MoveNext())
                {
                    ExportedUserRecords response = responses.Current;
                    foreach (ExportedUserRecord user in response.Users)
                    {
                        users.Add(user);
                    }
                }
                if(users != null && users.Count > 0)
                {
                    users = users.Where(t =>
                                    t.CustomClaims.ContainsKey("role")
                                    && t.CustomClaims.GetValueOrDefault("role").ToString().Equals(Convert.ToInt32(role).ToString()))
                                    .ToList();
                }
            }
            catch(Exception e)
            {
                _logger.Warn("GetUsersAsync failed", "warn", e.ToString());
                return null;
            }
            return users;
        }

        public async Task<T> UpdateUserAsync<T>(UserRecordArgs userRecord) where T : class
        {
            try
            {
                if(userRecord != null && userRecord.Disabled)
                {
                    await _auth.RevokeRefreshTokensAsync(userRecord.Uid).ConfigureAwait(false);
                }
                
                var updateUserReponse = await _auth.UpdateUserAsync(userRecord).ConfigureAwait(false);

                return updateUserReponse as T;
            }
            catch (Exception ex)
            {
                _logger.Warn("UpdateUserAsync failed", "warn", ex.ToString());
                return null;
            }
        }

        public async Task<bool> SetClaims(string uId, IReadOnlyDictionary<string, object> claims)
        {
            bool flag;
            try
            {
                await _auth.SetCustomUserClaimsAsync(uId, claims).ConfigureAwait(false);
                flag = true;
            }
            catch (Exception ex)
            {
                _logger.Warn("SetClaims failed", "warn", ex.ToString());
                flag = false;
            }
            return flag;
        }

        public async Task<string> GeneratePasswordReset(string email)
        {
            try
            {
                var link = await _auth.GeneratePasswordResetLinkAsync(email).ConfigureAwait(false);
                if (!string.IsNullOrEmpty(link))
                {
                    return link;
                }
                return null;
            }
            catch (Exception e)
            {
                _logger.Warn("GeneratePasswordReset failed", "warn", e.ToString());
                return null;
            }
        }

        public async Task<T> GetUserByEmail<T>(string email) where T : class
        {
            try
            {
                var user = await _auth.GetUserByEmailAsync(email.ToLowerInvariant().Trim()).ConfigureAwait(false);
                UserInfo userInfo = new UserInfo();
                userInfo.CustomClaims = user.CustomClaims;
                userInfo.UId = user.Uid;
                userInfo.DisplayName = user.DisplayName;
                userInfo.Email = user.Email;
                return userInfo as T;
            }
            catch(FirebaseAuthException ex)
            {
                return null;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
