﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using Microsoft.Extensions.Configuration;

namespace Wexer.Content.Portal.Worker
{
    /// <summary>
    /// This class reads values from local configuration file appsettings.json.
    /// Please change the configuration using your account information. For more information, see
    /// https://docs.microsoft.com/azure/media-services/latest/access-api-cli-how-to. For security
    /// reasons, do not check in the configuration file to source control.
    /// </summary>
    public class ConfigWrapper
    {
        private readonly IConfiguration _config;

        public ConfigWrapper(IConfiguration config)
        {
            _config = config;
        }

        public string ServiceBusConnectionString
        {
            get { return _config["ServiceBusConnectionString"]; }
        }

        public string BlobContentConnectionString
        {
            get { return _config["BlobContentConnectionString"]; }
        }

        public string FileStoreBlobConnectionString
        {
            get { return _config["FileStoreBlobConnectionString"]; }
        }

        public string LogglyAccountId
        {
            get { return _config["LogglyAccountId"]; }
        }

        public string LogglyUrl
        {
            get { return _config["LogglyUrl"]; }
        }

        public string LogglyTags
        {
            get { return _config["LogglyTags"]; }
        }

        public string LogglyLevels
        {
            get { return _config["LogglyLevels"]; }
        }

        public string AzureMediaServiceTenantDomain
        {
            get { return _config["AzureMediaServiceTenantDomain"]; }
        }

        public string AzureMediaServiceClientId
        {
            get { return _config["AzureMediaServiceClientId"]; }
        }

        public string AzureMediaServiceClientSecret
        {
            get { return _config["AzureMediaServiceClientSecret"]; }
        }

        //public string AzureMediaServiceApiUrl
        //{
        //    get { return _config["AzureMediaServiceApiUrl"]; }
        //}

        public string AzureMediaServiceSubscriptionId
        {
            get { return _config["AzureMediaServiceSubscriptionId"]; }

        }

        public string AzureMediaServiceResourceGroup
        {
            get { return _config["AzureMediaServiceResourceGroup"]; }

        }

        public string AzureMediaServiceAccountName
        {
            get { return _config["AzureMediaServiceAccountName"]; }

        }

        public string BlobUserConnectionString
        {
            get { return _config["BlobUserConnectionString"]; }
        }

        public string TableConnectionString
        {
            get { return _config["TableConnectionString"]; }
        }

        public string PlatformAdminBaseUrl
        {
            get { return _config["PlatformAdminBaseUrl"]; }
        }

        public string SqlTableContentConnectionString
        {
            get { return _config["SqlTableContentConnectionString"]; }
        }

        public string PlatformBaseUrl
        {
            get { return _config["PlatformBaseUrl"]; }
        }
        public string CdnUrl
        {
            get { return _config["CdnUrl"]; }
        }
        public string MediaServiceConnectionString
        {
            get { return _config["MediaServiceConnectionString"]; }
        }
        public string PortalBaseUrl
        {
            get { return _config["PortalBaseUrl"]; }
        }
        public string BaseAddressV2
        {
            get { return _config["JWPlayerConfiguration:BaseAddressV2"]; }
        }
        public string BaseAddressDelivery
        {
            get { return _config["JWPlayerConfiguration:BaseAddressDelivery"]; }
        }
        public bool IsSandbox
        {
            get { return Convert.ToBoolean(_config["JWPlayerConfiguration:IsSandbox"]); }
        }
        public string SiteId
        {
            get { return _config["JWPlayerConfiguration:SiteId"]; }
        }
        public string APISecret
        {
            get { return _config["JWPlayerConfiguration:APISecret"]; }
        }
    }
}
