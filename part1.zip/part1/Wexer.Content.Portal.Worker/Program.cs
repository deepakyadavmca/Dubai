﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using Wexer.Content.Portal.Command.Common;
using Microsoft.Azure.ServiceBus.InteropExtensions;
using Microsoft.Extensions.DependencyInjection;
using Wexer.Content.Portal.Command.Core;
using Microsoft.Extensions.Configuration;
using System.IO;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.EntityTransforms;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.CommandHandlers.Media;
using Wexer.Content.Portal.Repositories.MediaService;
using Newtonsoft.Json;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Rest.Azure.Authentication;
using Microsoft.Azure.Management.Media;
using Wexer.Content.Portal.CommandHandlers.Titles;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.UserService;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.CommandHandlers.Tenant;
using Wexer.Content.Portal.CommandHandlers.Channel;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Repositories.Database.Models;
using Microsoft.EntityFrameworkCore;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.UserService.SignupService;
using Wexer.Content.Portal.EventService;
using System.Net.Http;
using Wexer.Content.Portal.CommandHandlers.Events;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;
using Wexer.Content.Portal.Repositories.JWPlayer;

namespace Wexer.Content.Portal.Worker
{
    class Program
    {
        // Connection String for the namespace can be obtained from the Azure portal under the 
        // 'Shared Access policies' section.
        // The name of your queue
        const string QueueName = "contentportal-commands";
        const string BackgroundQueueName = "contentportal-background-commands";
        const string IntensiveQueueName = "intensive-commands";
        // QueueClient is thread-safe. Recommended that you cache 
        // rather than recreating it on every request
        ////private QueueClient _queueClient;
        ////private QueueClient _backgroundQueueClient;
        ////private QueueClient _intensiveQueueClient;
        ////private CommandEnvelopeQueue _queue;
        ////private CommandEnvelopeQueue _backgroundQueue;
        ////private CommandEnvelopeQueue _intensiveQueue;

        //const string ServiceBusConnectionString = "<your_connection_string>";

        static IQueueClient queueClient;
        static IQueueClient backgroundQueueClient;

        static ICommandDispatcher _commandDispatcher;

        static void Main(string[] args)
        {
            var environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_WORKER_ENVIRONMENT");
            var config = new ConfigWrapper(new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", false)
               .AddJsonFile($"appsettings.{environmentName}.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build());

            var modelTransformService = new ModelTransformService();
            var loggerfactory = new LogglyLoggerFactory(config.LogglyAccountId, config.LogglyUrl, config.LogglyTags, config.LogglyLevels);
            ClientCredential creds = new ClientCredential(config.AzureMediaServiceClientId, config.AzureMediaServiceClientSecret);
            var serviceClientCredentials = ApplicationTokenProvider.LoginSilentAsync(config.AzureMediaServiceTenantDomain, creds, ActiveDirectoryServiceSettings.Azure).Result;
            var mediaServiceClient = new AzureMediaServicesClient(serviceClientCredentials) { SubscriptionId = config.AzureMediaServiceSubscriptionId };

            var serviceProvider = new ServiceCollection()
           .AddHttpClient()
           .AddSingleton<ILoggerFactory>(loggerfactory)
           .AddSingleton<ICommandDispatcher, CommandDispatcher>()
           .AddSingleton<IBlobRepo>(new BlobRepo(config.BlobContentConnectionString, loggerfactory, modelTransformService))
           .AddSingleton<ITableRepo>(new TableRepo(config.TableConnectionString, loggerfactory, modelTransformService))
           .AddSingleton<IFileStoreRepo>(new FileStoreRepo(config.FileStoreBlobConnectionString, loggerfactory, null))
           .AddSingleton<IMediaServiceRepo>(new MediaServiceRepo(mediaServiceClient, config.AzureMediaServiceResourceGroup,
                                                config.AzureMediaServiceAccountName, loggerfactory, config.CdnUrl, config.MediaServiceConnectionString))
           .AddSingleton<IUserBlobRepo>(new UserBlobRepo(config.BlobUserConnectionString, loggerfactory, modelTransformService))
           .AddSingleton<ICmsStoreRepo>(new CmsStoreRepo(config.BlobContentConnectionString, loggerfactory, modelTransformService))
           .AddSingleton<IJWPlayerRepo>(new JWPlayerRepo(config.IsSandbox, config.SiteId, config.APISecret, config.BaseAddressV2, config.BaseAddressDelivery, loggerfactory, new BlobRepo(config.BlobContentConnectionString, loggerfactory, modelTransformService)))
           .AddSingleton<IUserService, UserService.UserService>()
           .AddSingleton<IFirebaseClient, FirebaseClient>()
           .AddSingleton<IUserSignupService, UserSignupService>()
           .AddSingleton<IProviderService, ProviderService.ProviderService>()
           .AddSingleton<IChannelService, ChannelService.ChannelService>()
           .AddSingleton<ITitleService, TitleService.TitleService>()
           .AddSingleton<IEventService, EventService.EventService>()
           .AddSingleton<ICommandBus>(new CommandBus(loggerfactory, new QueueClient(config.ServiceBusConnectionString, QueueName), new QueueClient(config.ServiceBusConnectionString, BackgroundQueueName)))
           .AddDbContext<ContentWriteStoreContext>(o => o.UseSqlServer(config.SqlTableContentConnectionString))
           .AddScoped<IContentWriteStoreRepo, ContentWriteStoreRepo>()
           .AddHttpClient()
           .BuildServiceProvider();

            _commandDispatcher = serviceProvider.GetService<ICommandDispatcher>();
            _commandDispatcher.Register(
                      new ICommandHandler[]
                      {
                          new MediaCommandHandler(serviceProvider.GetService<IBlobRepo>(), serviceProvider.GetService<IMediaServiceRepo>(), serviceProvider.GetService<ILoggerFactory>(), 
                                serviceProvider.GetService<IContentWriteStoreRepo>(), serviceProvider.GetService<ICmsStoreRepo>(), serviceProvider.GetService<ITitleService>(), serviceProvider.GetService<IEventService>(), config.PortalBaseUrl, serviceProvider.GetService<IJWPlayerRepo>(), serviceProvider.GetService<IProviderService>()),
                          new TitlesPublishCommandHandler(serviceProvider.GetService<ILoggerFactory>(), serviceProvider.GetService<IChannelService>(),
                                serviceProvider.GetService<IBlobRepo>(), serviceProvider.GetService<ITitleService>(), config.PlatformBaseUrl, config.PlatformAdminBaseUrl),
                          new TenantPublishCommandHandler(serviceProvider.GetService<ILoggerFactory>(), serviceProvider.GetService<IBlobRepo>(),
                                serviceProvider.GetService<ICmsStoreRepo>(), serviceProvider.GetService<ITitleService>(), serviceProvider.GetService<IChannelService>(),
                                    config.PlatformBaseUrl, config.PlatformAdminBaseUrl),
                          new TenantUnPublishCommandHandler(serviceProvider.GetService<ILoggerFactory>(), serviceProvider.GetService<IBlobRepo>(),
                                serviceProvider.GetService<ICmsStoreRepo>(), serviceProvider.GetService<ITitleService>(), serviceProvider.GetService<IChannelService>(),
                                    config.PlatformBaseUrl, config.PlatformAdminBaseUrl),

                          new ChannelPublishCommandHandler(serviceProvider.GetService<ITitleService>(), serviceProvider.GetService<ICmsStoreRepo>(), serviceProvider.GetService<ILoggerFactory>(), config.PlatformBaseUrl, config.PlatformAdminBaseUrl),
                          new ChannelUnPublishCommandHandler(serviceProvider.GetService<ICmsStoreRepo>(), serviceProvider.GetService<ILoggerFactory>(), serviceProvider.GetService<ITitleService>(), config.PlatformBaseUrl, config.PlatformAdminBaseUrl),
                          new TitlesDeleteCommandHandler(serviceProvider.GetService<ITitleService>(), serviceProvider.GetService<ILoggerFactory>(), serviceProvider.GetRequiredService<ICmsStoreRepo>(), config.PlatformBaseUrl, config.PlatformAdminBaseUrl),
                          new AutoPublishTitleCommandHandler(serviceProvider.GetService<IEventService>(), serviceProvider.GetService<ITitleService>(), serviceProvider.GetService<ILoggerFactory>(),
                                serviceProvider.GetRequiredService<ICmsStoreRepo>(), serviceProvider.GetRequiredService<IHttpClientFactory>(), config.PlatformBaseUrl, config.PlatformAdminBaseUrl, config.PortalBaseUrl),
                          new EventsValidateCommandHandler(serviceProvider.GetService<ILoggerFactory>(),serviceProvider.GetService<ICmsStoreRepo>(),serviceProvider.GetService<IBlobRepo>(), serviceProvider.GetService<IFileStoreRepo>()),
                          new EventsUploadCommandHandler(serviceProvider.GetService<ILoggerFactory>(),serviceProvider.GetService<ICmsStoreRepo>(),serviceProvider.GetService<IFileStoreRepo>(),serviceProvider.GetService<IBlobRepo>(),serviceProvider.GetService<IContentWriteStoreRepo>())
                      });

            queueClient = new QueueClient(config.ServiceBusConnectionString, QueueName);
            backgroundQueueClient = new QueueClient(config.ServiceBusConnectionString, BackgroundQueueName);

            Console.WriteLine("======================================================");
            Console.WriteLine("Press ENTER key to exit after receiving all the messages.");
            Console.WriteLine("======================================================");
            MainAsync().GetAwaiter().GetResult();
        }
        static async Task MainAsync()
        {
            // Register QueueClient's MessageHandler and receive messages in a loop
            RegisterOnMessageHandlerAndReceiveMessages();
            RegisterOnMessageHandlerAndReceiveMessagesForBackgroundQueueClient();
            //Console.ReadKey();

            //await queueClient.CloseAsync();
            while (true)
            {
                Thread.Sleep(1000);
            }
        }
        static void RegisterOnMessageHandlerAndReceiveMessages()
        {
            // Configure the MessageHandler Options in terms of exception handling, number of concurrent messages to deliver etc.
            var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                // Maximum number of Concurrent calls to the callback `ProcessMessagesAsync`, set to 1 for simplicity.
                // Set it according to how many messages the application wants to process in parallel.
                MaxConcurrentCalls = 1,

                // Indicates whether MessagePump should automatically complete the messages after returning from User Callback.
                // False below indicates the Complete will be handled by the User Callback as in `ProcessMessagesAsync` below.
                AutoComplete = false,
                MaxAutoRenewDuration = TimeSpan.FromSeconds(60)

            };

            // Register the function that will process messages
            queueClient.RegisterMessageHandler(ProcessMessagesAsync, messageHandlerOptions);
        }

        static void RegisterOnMessageHandlerAndReceiveMessagesForBackgroundQueueClient()
        {
            // Configure the MessageHandler Options in terms of exception handling, number of concurrent messages to deliver etc.
            var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                // Maximum number of Concurrent calls to the callback `ProcessMessagesAsync`, set to 1 for simplicity.
                // Set it according to how many messages the application wants to process in parallel.
                MaxConcurrentCalls = 5,
                AutoComplete = false
            };

            // Register the function that will process messages
            backgroundQueueClient.RegisterMessageHandler(ProcessMessagesAsyncForBackgroundQueueClient, messageHandlerOptions);
        }
        static async Task ProcessMessagesAsync(Message message, CancellationToken token)
        {
            var start = DateTime.UtcNow;
            var envelopeId = string.Empty;
            //var envelope1 = message.GetBody<CommandEnvelope>();
            var messageBody = Encoding.UTF8.GetString(message.Body);
            CommandEnvelope envelope = JsonConvert.DeserializeObject<CommandEnvelope>(messageBody);
            envelopeId = envelope.EnvelopeId;

            var commandType = _commandDispatcher.GetCommandTypeFor(envelope.CommandName); // get from route
            var payload = envelope.GetPayload(commandType);

            var commandResult = _commandDispatcher.ProcessMessageAsync(payload).Result;
            var timeTakenMs = DateTime.UtcNow.Subtract(start).TotalMilliseconds;

            var result = new
            {
                envelopeId = envelope.EnvelopeId,
                commandType = envelope.CommandName,
                // payload,
                timeTakenMs
            };
            if (commandResult)
            {
                Console.WriteLine($"Processed command : {result}");
            }
            else
            {
                Console.WriteLine($"Error Processed command : {result}");
            }
            // Process the message
            Console.WriteLine($"Received message: SequenceNumber:{message.SystemProperties.SequenceNumber} Body:{Encoding.UTF8.GetString(message.Body)}");

            // Complete the message so that it is not received again.
            // This can be done only if the queueClient is created in ReceiveMode.PeekLock mode (which is default).
            await queueClient.CompleteAsync(message.SystemProperties.LockToken);

            // Note: Use the cancellationToken passed as necessary to determine if the queueClient has already been closed.
            // If queueClient has already been Closed, you may chose to not call CompleteAsync() or AbandonAsync() etc. calls 
            // to avoid unnecessary exceptions.
        }

        static async Task ProcessMessagesAsyncForBackgroundQueueClient(Message message, CancellationToken token)
        {
            var start = DateTime.UtcNow;
            var envelopeId = string.Empty;
            //var envelope1 = message.GetBody<CommandEnvelope>();
            var messageBody = Encoding.UTF8.GetString(message.Body);
            CommandEnvelope envelope = JsonConvert.DeserializeObject<CommandEnvelope>(messageBody);
            envelopeId = envelope.EnvelopeId;

            var commandType = _commandDispatcher.GetCommandTypeFor(envelope.CommandName); // get from route
            var payload = envelope.GetPayload(commandType);

            // Complete the message so that it is not received again.
            // This can be done only if the queueClient is created in ReceiveMode.PeekLock mode (which is default).
            // completed msg as soon as it is recieved, since this is a long running task
            await backgroundQueueClient.CompleteAsync(message.SystemProperties.LockToken);

            var commandResult = _commandDispatcher.ProcessMessageAsync(payload).Result;
            var timeTakenMs = DateTime.UtcNow.Subtract(start).TotalMilliseconds;

            var result = new
            {
                envelopeId = envelope.EnvelopeId,
                commandType = envelope.CommandName,
                // payload,
                timeTakenMs
            };
            if (commandResult)
            {
                Console.WriteLine($"Processed background command : {result}");
            }
            else
            {
                Console.WriteLine($"Error Processed background command : {result}");
            }
            // Process the message
            Console.WriteLine($"Received message: background command SequenceNumber:{message.SystemProperties.SequenceNumber} Body:{Encoding.UTF8.GetString(message.Body)}");

            // Note: Use the cancellationToken passed as necessary to determine if the queueClient has already been closed.
            // If queueClient has already been Closed, you may chose to not call CompleteAsync() or AbandonAsync() etc. calls 
            // to avoid unnecessary exceptions.
        }

        static Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine($"Message handler encountered an exception {exceptionReceivedEventArgs.Exception}.");
            var context = exceptionReceivedEventArgs.ExceptionReceivedContext;
            Console.WriteLine("Exception context for troubleshooting:");
            Console.WriteLine($"- Endpoint: {context.Endpoint}");
            Console.WriteLine($"- Entity Path: {context.EntityPath}");
            Console.WriteLine($"- Executing Action: {context.Action}");
            return Task.CompletedTask;
        }


    }
}

