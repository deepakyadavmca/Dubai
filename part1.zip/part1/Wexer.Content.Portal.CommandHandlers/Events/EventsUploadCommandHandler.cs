﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Events;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.BackgroundTasks;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using System.Linq;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;
using System.IO;
using System.Text.Json;
using Wexer.Content.Portal.Models.Events;
using Wexer.Content.Portal.Repositories.Database.Models;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Models.ConsumerWeb;

namespace Wexer.Content.Portal.CommandHandlers.Events
{
    public class EventsUploadCommandHandler : ICommandHandler<EventsUploadCommand>
    {
        private readonly ILogger _logger;
        private readonly ICmsStoreRepo _cmsStoreRepo;
        private readonly IFileStoreRepo _fileStoreRepo;
        private readonly IBlobRepo _blobRepo;
        private readonly IContentWriteStoreRepo _db;

        public EventsUploadCommandHandler(ILoggerFactory loggerFactory, ICmsStoreRepo cmsStoreRepo,
            IFileStoreRepo fileStoreRepo, IBlobRepo blobRepo, IContentWriteStoreRepo contentWriteStoreRepo)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _cmsStoreRepo = cmsStoreRepo;
            _fileStoreRepo = fileStoreRepo;
            _blobRepo = blobRepo;
            _db = contentWriteStoreRepo;
        }

        public async Task HandleCommandAsync(EventsUploadCommand command)
        {
            _logger.Info($"EventsUploadCommandHandler > Events Upload Handler begin: {command.TaskId}");

            var backgroundTasks = _cmsStoreRepo.GetList<BackgroundTaskStatus>(command.TaskId);
            if (backgroundTasks == null || backgroundTasks.Count() <= 0)
            {
                _logger.Info("EventsValidateCommandHandler > EventsUploadCommand - Background Task Status doesn't exists for TaskId {0}", command.TaskId);
                return;
            }

            var processBackgroundTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsProcess.ToString()).FirstOrDefault();
            var validateBackgroundTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsValidate.ToString()).FirstOrDefault();

            List<EventData> failedItems = null;
            if (validateBackgroundTask != null && !string.IsNullOrEmpty(validateBackgroundTask.ErrorItems))
                failedItems = JsonSerializer.Deserialize<List<EventData>>(validateBackgroundTask.ErrorItems);

            var processedRecordCounter = 0;
            try
            {

                string fileBlobName = processBackgroundTask.FileBlobName;

                // If Action Marked cancel then we just delete the BackgroundTaskStatus record for this Task Id
                if (command.Action == BackgroundActionType.Cancel.ToString())
                {
                    // Deleting the blob because process has been marked as cancel
                    await _fileStoreRepo.DeleteAsync("ondemandevents", fileBlobName);

                    processBackgroundTask.Status = ProcessTaskStatus.Cancelled.ToString();
                    processBackgroundTask.EndedDateTimeUtc = DateTime.UtcNow;
                    await _cmsStoreRepo.StoreAsync<BackgroundTaskStatus>(processBackgroundTask);
                    return;
                }


                string tenantId = processBackgroundTask.TenantId;

                MemoryStream stream = new MemoryStream();
                await _fileStoreRepo.GetStreamAsync(stream, "ondemandevents", fileBlobName).ConfigureAwait(false);

                OnDemandEventData ondemandEvents = null;
                if (stream != null && stream.Length > 0)
                {
                    string s = Encoding.UTF8.GetString(stream.ToArray());
                    ondemandEvents = JsonSerializer.Deserialize<OnDemandEventData>(s);
                }

                if (ondemandEvents != null && ondemandEvents.Events != null && ondemandEvents.Events.Count > 0)
                {
                    var existingTenants = await Task.Run(() => _db.Read<TenantDetail>()).ConfigureAwait(false);
                    TenantDetail tenantDetails = null;
                    if (existingTenants != null && existingTenants.Data != null && existingTenants.Data.Any(x => x.Entity.TenantID == tenantId))
                        tenantDetails = existingTenants.Data.Where(x => x.Entity.TenantID == tenantId).Select(x => x.Entity).FirstOrDefault();

                    // Fetching the VirtualClasses or Titles based on Tenant Id
                    var titlesSet = await _blobRepo.GetSetAsync<VirtualClass>(tenantId).ConfigureAwait(false);

                    Dictionary<string, VirtualClass> titleDicSet = null;
                    if (titlesSet != null && titlesSet.Entity != null && titlesSet.Entity.Items != null)
                        titleDicSet = new Dictionary<string, VirtualClass>(titlesSet.Entity.Items.
                            Select(x => new KeyValuePair<string, VirtualClass>(x.Tag, x)));

                    var events = ondemandEvents.Events;
                    for (int i = 0; i < events.Count; i++)
                    {
                        var ondemandEvent = events[i];

                        if (failedItems != null && failedItems.Exists(x => x.EventName == ondemandEvent.EventName &&
                                                    x.VideoId == ondemandEvent.VideoId &&
                                                    x.SessionStart == ondemandEvent.SessionStart &&
                                                    x.SessionEnd == ondemandEvent.SessionEnd &&
                                                    x.SessionDuration == ondemandEvent.SessionDuration &&
                                                    x.UserHash == ondemandEvent.UserHash))
                            continue;

                        var dbEntity = new OnDemandTrackingEntity();

                        if (tenantDetails != null)
                        {
                            dbEntity.ClientId = tenantId;
                            dbEntity.ClientName = tenantDetails.Name;

                            titleDicSet.TryGetValue(ondemandEvent.VideoId, out VirtualClass videoDetail);
                            if (videoDetail != null)
                            {
                                _logger.Info(string.Format("Processing 'EventsCommand', class details found for the class tag: {0}.", ondemandEvent.VideoId));
                                dbEntity.Month = ondemandEvent.SessionStart.Value.Month;
                                dbEntity.Year = ondemandEvent.SessionStart.Value.Year;
                                dbEntity.PerformDate = ondemandEvent.SessionStart.Value;
                                dbEntity.PlayedDurationSecond = ondemandEvent.SessionDuration;
                                dbEntity.Id = Guid.NewGuid().ToString();
                                dbEntity.ActualDurationSecond = videoDetail.DurationSecond;
                                dbEntity.ContentId = ondemandEvent.VideoId;
                                dbEntity.ContentName = videoDetail.ClassName;
                                dbEntity.CountryId = null;
                                dbEntity.CountryName = null;
                                dbEntity.CreatedUtc = DateTime.UtcNow;
                                dbEntity.LastModifiedUtc = DateTime.UtcNow;
                                dbEntity.IsTrial = ondemandEvent.Billable == false ? true : false;
                                dbEntity.ProviderId = videoDetail.ProviderID;
                                dbEntity.ProviderName = videoDetail.Provider;
                                dbEntity.SubscriptionStartDate = null;
                                dbEntity.Source = WorkoutPerformChannel.API;
                                dbEntity.CustomerNumber = tenantDetails.CustomerNumber;
                                dbEntity.UserId = ondemandEvent.UserHash;
                                dbEntity.ExternalIdentifier = ondemandEvent.ExternalIdentifier;
                                if (tenantDetails.TenantID.ToLowerInvariant() == "innovatise"
                                    || tenantDetails.TenantID.ToLowerInvariant() == "optus")
                                {
                                    dbEntity.ContentOwner = "wexer";
                                }

                                _logger.Info(string.Format("Processing 'EventsCommand', updating ondemand tacking table for the Id: {0}, class tag: {1}, user: {2}.", dbEntity.Id, ondemandEvent.VideoId, ondemandEvent.UserHash));
                                _db.Upsert(dbEntity.Id, dbEntity);

                                processedRecordCounter += 1;

                            }
                            else
                            {
                                _logger.Info(string.Format("Processing 'EventsCommand', class details not found for the class tag: {0}.", ondemandEvent.VideoId));
                            }
                        }
                        else
                        {
                            _logger.Info(string.Format("Processing 'EventsCommand', tenant details not found for the tenant id: {0}.", tenantId));
                        }

                    }

                    processBackgroundTask.Status = ProcessTaskStatus.FileProcessed.ToString();
                    processBackgroundTask.EndedDateTimeUtc = DateTime.UtcNow;
                    processBackgroundTask.Result = JsonSerializer.Serialize(new BackgroundTaskProcessResult() { Total = ondemandEvents.Events.Count, Processed = processedRecordCounter });
                    await _cmsStoreRepo.StoreAsync<BackgroundTaskStatus>(processBackgroundTask);
                }
                else
                {
                    processBackgroundTask.Status = ProcessTaskStatus.Failed.ToString();
                    processBackgroundTask.ErrorCode = 400;
                    processBackgroundTask.ErrorMessage = "Events data is empty.";
                    processBackgroundTask.EndedDateTimeUtc = DateTime.UtcNow;
                    await _cmsStoreRepo.StoreAsync<BackgroundTaskStatus>(processBackgroundTask);
                }
            }
            catch (Exception ex)
            {
                _logger.Info("EventsValidateCommandHandler > EventsUploadCommand - Got error while processing events: error {0}", ex.StackTrace);
                processBackgroundTask.Status = ProcessTaskStatus.Failed.ToString();
                processBackgroundTask.ErrorCode = 500;
                processBackgroundTask.ErrorMessage = ex.Message;
                processBackgroundTask.EndedDateTimeUtc = DateTime.UtcNow;
                await _cmsStoreRepo.StoreAsync<BackgroundTaskStatus>(processBackgroundTask);
            }

        }
    }
}
