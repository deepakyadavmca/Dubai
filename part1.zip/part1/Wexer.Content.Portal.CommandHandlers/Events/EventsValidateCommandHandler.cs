﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Events;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.BackgroundTasks;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using System.Linq;
using Wexer.Content.Portal.Models.Events;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.VirtualClasses;
using System.Text.Json;
using System.IO;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;

namespace Wexer.Content.Portal.CommandHandlers.Events
{
    public class EventsValidateCommandHandler : ICommandHandler<EventsValidateCommand>
    {
        private readonly ILogger _logger;
        private readonly ICmsStoreRepo _cmsStoreRepo;
        private readonly IBlobRepo _blobRepo;
        private readonly IFileStoreRepo _fileStoreRepo;

        public EventsValidateCommandHandler(ILoggerFactory loggerFactory, ICmsStoreRepo cmsStoreRepo, IBlobRepo blobRepo, IFileStoreRepo fileStoreRepo)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _cmsStoreRepo = cmsStoreRepo;
            _blobRepo = blobRepo;
            _fileStoreRepo = fileStoreRepo;
        }

        public async Task HandleCommandAsync(EventsValidateCommand command)
        {
            _logger.Info($"EventsValidateCommandHandler > Events validate Handler begin: {command.TaskId}");

            var backgroundTasks = _cmsStoreRepo.GetList<BackgroundTaskStatus>(command.TaskId);
            if (backgroundTasks == null || backgroundTasks.Count() <= 0)
            {
                _logger.Info("EventsValidateCommandHandler > EventsValidateCommand - Background Task Status doesn't exists for TaskId {0}", command.TaskId);
                return;
            }
            
            var validateBackgroundTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsValidate.ToString()).FirstOrDefault();

            MemoryStream stream = new MemoryStream();
            await _fileStoreRepo.GetStreamAsync(stream, "ondemandevents", validateBackgroundTask.FileBlobName).ConfigureAwait(false);

            OnDemandEventData ondemandEvents = null;
            if (stream != null && stream.Length > 0)
            {
                string s = Encoding.UTF8.GetString(stream.ToArray());
                ondemandEvents = JsonSerializer.Deserialize<OnDemandEventData>(s);
            }

            if (ondemandEvents == null || ondemandEvents.Events == null ||
                ondemandEvents.Events.Count <= 0)
            {
                validateBackgroundTask.Status = ValidateTaskStatus.Rejected.ToString();
                validateBackgroundTask.ErrorCode = 400;
                validateBackgroundTask.ErrorMessage = "Ondemand events are empty.";
                validateBackgroundTask.EndedDateTimeUtc = DateTime.UtcNow;
                UpdateBackgroundTaskStatus(validateBackgroundTask);
                return;
            }

            string tenantId = validateBackgroundTask.TenantId;

            // Fetching the VirtualClasses or Titles based on Tenant Id
            var titlesSet = await _blobRepo.GetSetAsync<VirtualClass>(tenantId).ConfigureAwait(false);

            HashSet<string> titlesHasSet = null;
            if (titlesSet != null && titlesSet.Entity != null && titlesSet.Entity.Items != null)
                titlesHasSet = new HashSet<string>(titlesSet.Entity.Items.Select(x => x.Tag));

            var failedRecords = new List<EventData>();
            for (int i = 0; i < ondemandEvents.Events.Count; i++)
            {
                var ondemandEvent = ondemandEvents.Events[i];

                // Check if Mandatory Data Missing then we add into failed records and continue to the next event
                if (!IsMandatoryDataAvailable(ondemandEvent))
                {
                    failedRecords.Add(ondemandEvent);
                    continue;
                }

                // Checking if event Session Start date greater than end date then we add into failed records and continue to the next event
                if (ondemandEvent.SessionStart > ondemandEvent.SessionEnd)
                {
                    failedRecords.Add(ondemandEvent);
                    continue;
                }

                // If VideoId doesn't exists for this tenant then we need to add in failed
                if (titlesHasSet == null || !titlesHasSet.Contains(ondemandEvent.VideoId))
                {
                    failedRecords.Add(ondemandEvent);
                    continue;
                }
            }

            validateBackgroundTask.Status = ValidateTaskStatus.Validated.ToString();
            validateBackgroundTask.Result = JsonSerializer.Serialize(new BackgroundTaskResult() { Total = ondemandEvents.Events.Count, Currupt = failedRecords.Count });
            validateBackgroundTask.ErrorItems = JsonSerializer.Serialize(failedRecords);
            validateBackgroundTask.EndedDateTimeUtc = DateTime.UtcNow;
            UpdateBackgroundTaskStatus(validateBackgroundTask);
        }

        private async void UpdateBackgroundTaskStatus(BackgroundTaskStatus validateBackgroundTask)
        {
            await _cmsStoreRepo.StoreAsync<BackgroundTaskStatus>(validateBackgroundTask);
        }


        /// <summary>
        /// Checking the mandatory data available
        /// </summary>
        /// <param name="eventData"></param>
        /// <returns></returns>
        private bool IsMandatoryDataAvailable(EventData eventData)
        {
            _logger.Info("EventsValidateCommandHandler > Events > Mandatory Data -  Start Checking mandatory data");

            if (string.IsNullOrEmpty(eventData.EventName) || string.IsNullOrEmpty(eventData.VideoId)
                || string.IsNullOrEmpty(eventData.UserHash) || eventData.SessionDuration <= 0
                || eventData.SessionStart == default(DateTime) || eventData.SessionEnd == default(DateTime)
                || eventData.SessionStart == null || eventData.SessionEnd == null)
            {
                return false;
            }

            return true;
        }


    }
}
