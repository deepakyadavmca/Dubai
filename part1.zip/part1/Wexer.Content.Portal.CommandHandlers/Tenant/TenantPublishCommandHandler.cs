﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Command.Commands.Tenant;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.CommandHandlers.Tenant
{
    public class TenantPublishCommandHandler : ICommandHandler<TenantPublishCommand>
    {
        private readonly ILogger _logger;
        private readonly IBlobRepo _blobRepo;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly ITitleService _titleService;
        private readonly IChannelService _channelService;
        private readonly string _baseUrl;
        private readonly string _adminBaseUrl;

        public TenantPublishCommandHandler(ILoggerFactory loggerFactory, IBlobRepo blobRepo, ICmsStoreRepo cmsStore, ITitleService titleService, IChannelService channelService,
            string baseUrl, string adminBaseUrl)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _blobRepo = blobRepo;
            _cmsStore = cmsStore;
            _titleService = titleService;
            _channelService = channelService;
            _baseUrl = baseUrl;
            _adminBaseUrl = adminBaseUrl;
        }

        public async Task HandleCommandAsync(TenantPublishCommand command)
        {
            try
            {
                _logger.Info($"TenantPublishCommandHandler begin");
                var masterTitlesTask = _cmsStore.GetBulk<VirtualClass>();
                var channelsTask = _channelService.List();
                await Task.WhenAll(masterTitlesTask, channelsTask).ConfigureAwait(false);
                
                if (masterTitlesTask != null && masterTitlesTask.Result.Count() > 0 && channelsTask != null && channelsTask.Result.Length > 0)
                {
                    
                    var titlesByChannelId = masterTitlesTask.Result.GroupBy(x => x.ChannelId)
                                                .Where(x => command.ChannelsToPublish.Contains(x.Key))
                                                    .SelectMany(x => x).Where(x => x.Status == Models.MediaProcessingStatus.Published).ToList();

                    if(titlesByChannelId != null && titlesByChannelId.Count() > 0)
                    {
                        await _titleService.PublishBulk(titlesByChannelId, command.TenantId).ConfigureAwait(false);
                        var updateIndexesResponse = await _titleService.UpdateIndexes(command.TenantId, _adminBaseUrl).ConfigureAwait(false);
                        var bustCache = await _titleService.BustChannelCachePlatform(command.TenantId, _baseUrl).ConfigureAwait(false);

                        _logger.Info($"TenantPublishCommandHandler UpdateIndexesReponse: {updateIndexesResponse}");
                        _logger.Info($"TenantPublishCommandHandler BustChannelCachePlatform: {bustCache}");
                    }
                    else
                    {
                        _logger.Info($"TenantPublishCommandHandler no titles for channels");
                    }
                }
            }
            catch (Exception e)
            {
                _logger.Warn("TenantPublishCommandHandler exception", "warn", e.ToString());
            }
        }
    }
}
