﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.CommandHandlers.Titles
{
    public class TitlesPublishCommandHandler : ICommandHandler<TitlePublishCommand>
    {
        private readonly ILogger _logger;
        private readonly IChannelService _channelService;
        private readonly IBlobRepo _blobRepo;
        private readonly ITitleService _titleService;
        private readonly string _adminBaseUrl;
        private readonly string _baseUrl;

        public TitlesPublishCommandHandler(ILoggerFactory loggerFactory, IChannelService channelService, IBlobRepo blobRepo, 
            ITitleService titleService, string baseUrl, string adminBaseUrl)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _channelService = channelService;
            _blobRepo = blobRepo;
            _titleService = titleService;
            _adminBaseUrl = adminBaseUrl;
            _baseUrl = baseUrl;
        }
        public async Task HandleCommandAsync(TitlePublishCommand command)
        {
            try
            {
                var channelTask = _channelService.Get(command.ChannelId);
                var titleTask = _titleService.Get(command.ProviderId, command.Tag);
                await Task.WhenAll(channelTask, titleTask).ConfigureAwait(false);
                if(channelTask.Result != null && titleTask.Result != null)
                {
                    var channel = channelTask.Result;
                    var title = titleTask.Result;
                    var tenants = channel.Tenants;
                    
                    foreach (var tenant in tenants)
                    {
                        await _titleService.Publish(title, tenant).ContinueWith(async x => 
                        {
                            if (x.Status == TaskStatus.RanToCompletion)
                            {
                                var indexResult = await _titleService.UpdateIndexes(tenant, _adminBaseUrl).ConfigureAwait(false);
                                var bustCacheResponse = await _titleService.BustChannelCachePlatform(tenant, _baseUrl).ConfigureAwait(false);
                                _logger.Info($"UpdateIndexes response {indexResult} Tenant:{tenant}");
                                _logger.Info($"BustChannelCachePlatform response {bustCacheResponse} Tenant:{tenant}");
                            }
                        }).ConfigureAwait(false);
                    }

                }
                else
                {
                    _logger.Info($"TitlePublishCommandHandler channel or title not found");
                }
            }
            catch (Exception e)
            {
                _logger.Warn("TitlePublishCommandHandler exception", "warn", e.ToString());
            }
        }
    }
}
