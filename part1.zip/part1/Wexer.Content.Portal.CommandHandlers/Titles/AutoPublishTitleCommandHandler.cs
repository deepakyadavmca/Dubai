﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.EventService;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.CommandHandlers.Titles
{
    public class AutoPublishTitleCommandHandler : ICommandHandler<AutoPublishTitleCommand>
    {
        private readonly ILogger _logger;
        private readonly IEventService _eventService;
        private readonly ITitleService _titleService;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly string _adminBaseUrl;
        private readonly string _portalBaseUrl;
        private readonly string _baseUrl;
        private readonly IHttpClientFactory _httpClientFactory;

        public AutoPublishTitleCommandHandler(IEventService eventService, ITitleService titleService, ILoggerFactory loggerFactory, ICmsStoreRepo cmsStore,
            IHttpClientFactory httpClientFactory, string baseUrl, string adminBaseUrl, string portalBaseUrl)
        {
            _eventService = eventService;
            _titleService = titleService;
            _cmsStore = cmsStore;
            _logger = loggerFactory.GetLoggerForClass(this);
            _adminBaseUrl = adminBaseUrl;
            _portalBaseUrl = portalBaseUrl;
            _baseUrl = baseUrl;
            _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        }
        public async Task HandleCommandAsync(AutoPublishTitleCommand command)
        {
            try
            {
                _logger.Info($"AutopublishTitleCommandHandler > Begin for EventId:{command.Event_Id} TenantId:{command.TenantId}");
                var scheduleEvent = await _eventService.GetEvent(command.TenantId, command.Event_Id).ConfigureAwait(false);
                if (scheduleEvent != null && scheduleEvent.Active && scheduleEvent.Video != null && scheduleEvent.Video.Status == Models.MediaProcessingStatus.Complete && scheduleEvent.AllowAutoPublish)
                {
                    scheduleEvent.Video.StartDate = scheduleEvent.Scheduled_Time.Date + scheduleEvent.Schedule.Daily_Time.TimeOfDay;
                    scheduleEvent.Video.ScheduleDate = scheduleEvent.Scheduled_Time.Date + scheduleEvent.Schedule.Daily_Time.TimeOfDay;
                    _logger.Info($"AutopublishTitleCommandHandler > Begin for EventId:{command.Event_Id} TenantId:{command.TenantId}");

                    VirtualClass eventVideo = DeepClone(scheduleEvent.Video);
                    await _titleService.Publish(eventVideo, command.TenantId, "autopublish").ContinueWith(async x =>
                    {
                        if (x.Status == TaskStatus.RanToCompletion)
                        {
                            await _titleService.UpdateIndexes(command.TenantId, _adminBaseUrl).ConfigureAwait(false);
                            var bustCacheResponse = await _titleService.BustChannelCachePlatform(command.TenantId, _baseUrl).ConfigureAwait(false);
                            scheduleEvent.Slot.PublishedToTenant = true;
                            await _cmsStore.StoreAsync(eventVideo.Tag, eventVideo, "", eventVideo.ProviderID).ConfigureAwait(false);
                            await _cmsStore.StoreAsync(scheduleEvent).ConfigureAwait(false);
                            _logger.Info($"AutoPublishTitleCommand > BustChannelCachePlatform response {bustCacheResponse} Tenant:{command.TenantId}");
                            await BustCache().ConfigureAwait(false);
                        }
                    }).ConfigureAwait(false);
                }
                else
                {
                    _logger.Info($"AutoPublishTitleCommand > Unable to auto-publish title tag:{scheduleEvent.Video.Tag} tenant:{command.TenantId}");
                }
            }
            catch (Exception e)
            {
                _logger.Warn("AutoPublishTitleCommand exception", "warn", e.ToString());
            }

        }

        async Task BustCache() 
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                var response = await client.GetAsync($"{_portalBaseUrl}staff/bustcache").ConfigureAwait(false);
                if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    _logger.Info("AutoPublishTitleCommandHandler > Cleared cache");
                }
                else
                {
                    _logger.Info("AutoPublishTitleCommandHandler > Failed to clear cache");
                }
            }
            catch (Exception e)
            {
                _logger.Warn("AutoPublishTitleCommandHandler > BustCache exception", "warn", e.ToString());
            }
        }

        private T DeepClone<T>(T instance)
        {
            return JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(instance));
        }
    }
}
