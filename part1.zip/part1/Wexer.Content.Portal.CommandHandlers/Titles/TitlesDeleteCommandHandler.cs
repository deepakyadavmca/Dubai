﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.CommandHandlers.Titles
{
    public class TitlesDeleteCommandHandler : ICommandHandler<TitleDeleteCommand>
    {
        readonly ITitleService _titleService;
        private readonly ICmsStoreRepo _cmsStoreRepo;
        private readonly string _baseUrl;
        private readonly string _adminBaseUrl;
        readonly ILogger _logger;

        public TitlesDeleteCommandHandler(ITitleService titleService, ILoggerFactory loggerFactory, ICmsStoreRepo cmsStoreRepo, string baseUrl, string adminBaseUrl)
        {
            _titleService = titleService;
            _cmsStoreRepo = cmsStoreRepo;
            _baseUrl = baseUrl;
            _adminBaseUrl = adminBaseUrl;
            _logger = loggerFactory.GetLoggerForClass(this);
        }
        public async Task HandleCommandAsync(TitleDeleteCommand command)
        {
            try
            {
                _logger.Info("Delete titles begin");
                List<Task> task = new List<Task>();
                foreach (var item in command.TitlesData)
                {
                    task.Add(_cmsStoreRepo.DeleteAsync<VirtualClass>(item.Value, item.Key));
                }

                await Task.WhenAll(task).ConfigureAwait(false);
                _logger.Info("Delete titles end");
            }
            catch (Exception e)
            {
                _logger.Warn("Delete titles exception", e.ToString());
            }
        }
    }
}
