﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Channel;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.CommandHandlers.Channel
{
    public class ChannelPublishCommandHandler : ICommandHandler<ChannelPublishCommand>
    {
        private readonly ITitleService _titleService;
        private readonly ICmsStoreRepo _cmsStoreRepo;
        private readonly string _adminBaseUrl;
        private readonly string _baseUrl;
        private readonly ILogger _logger;

        public ChannelPublishCommandHandler(ITitleService titleService, ICmsStoreRepo cmsStoreRepo, ILoggerFactory loggerFactory, string baseUrl, string adminBaseUrl)
        {
            _titleService = titleService;
            _cmsStoreRepo = cmsStoreRepo;
            _adminBaseUrl = adminBaseUrl;
            _baseUrl = baseUrl;
            _logger = loggerFactory.GetLoggerForClass(this);
        }
        public async Task HandleCommandAsync(ChannelPublishCommand command)
        {
            try
            {
                _logger.Info($"ChannelPublishing Handler begin: {command.ChannelTag}");
                var titles = await _cmsStoreRepo.GetBulk<VirtualClass>();
                var titlesByChannel = titles.GroupBy(x => x.ChannelId)
                                        .Where(x => x.Key == command.ChannelTag)
                                            .SelectMany(x => x).Where(x => x.Status == Models.MediaProcessingStatus.Published).ToList();

                if (titlesByChannel != null && titlesByChannel.Count > 0)
                {
                    _logger.Info($"ChannelPublishing titles found:{titlesByChannel.Count}");
                    foreach (var tenant in command.TenantIdsToPublish)
                    {
                        await _titleService.PublishBulk(titlesByChannel, tenant).ConfigureAwait(false);
                        var indexResponse = await _titleService.UpdateIndexes(tenant, _adminBaseUrl).ConfigureAwait(false);
                        var bustCache = await _titleService.BustChannelCachePlatform(tenant, _baseUrl).ConfigureAwait(false);

                        _logger.Info($"ChannelPublishing UpdateIndexes response:{indexResponse}");
                        _logger.Info($"ChannelPublishing BustChannelCachePlatform response:{bustCache}");
                    }
                }
                else
                {
                    _logger.Info($"ChannelPublishing No titles found for :{command.ChannelTag}");
                }
                

                _logger.Info($"ChannelPublishing Handler end: {command.ChannelTag}");
            }
            catch (Exception e)
            {
                _logger.Warn("ChannelPublish handler exception", "warn", e.ToString());
            }
        }
    }
}
