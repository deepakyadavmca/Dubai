﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Channel;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.CommandHandlers.Channel
{
    public class ChannelUnPublishCommandHandler : ICommandHandler<ChannelUnPublishCommand>
    {
        private readonly ICmsStoreRepo _cmsStoreRepo;
        private readonly ITitleService _titleService;
        private readonly string _baseUrl;
        private readonly string _adminBaseUrl;
        private readonly ILogger _logger;

        public ChannelUnPublishCommandHandler(ICmsStoreRepo cmsStoreRepo, ILoggerFactory loggerFactory, ITitleService titleService, string baseUrl, string adminBaseUrl)
        {
            _cmsStoreRepo = cmsStoreRepo;
            _titleService = titleService;
            _baseUrl = baseUrl;
            _adminBaseUrl = adminBaseUrl;
            _logger = loggerFactory.GetLoggerForClass(this);
        }
        public async Task HandleCommandAsync(ChannelUnPublishCommand command)
        {
            try
            {
                _logger.Info($"ChannelUnPublish handler begin: {command.ChannelTag}");
                var titles = await _cmsStoreRepo.GetBulk<VirtualClass>();
                var titlesByChannel = titles.GroupBy(x => x.ChannelId)
                                        .Where(x => x.Key == command.ChannelTag)
                                            .SelectMany(x => x).Where(x => x.Status == Models.MediaProcessingStatus.Published).ToList();

                if(titlesByChannel != null && titlesByChannel.Count > 0)
                {
                    _logger.Info($"ChannelUnPublishing titles found:{titlesByChannel.Count}");
                    foreach (var tenant in command.TenantIdsToUnPublish)
                    {
                        await _titleService.UnPublishBulk(titlesByChannel, tenant).ConfigureAwait(false);
                        var indexResponse = await _titleService.UpdateIndexes(tenant, _adminBaseUrl).ConfigureAwait(false);
                        var bustCache = await _titleService.BustChannelCachePlatform(tenant, _baseUrl).ConfigureAwait(false);

                        _logger.Info($"ChannelPublishing UpdateIndexes response:{indexResponse}");
                        _logger.Info($"ChannelPublishing BustChannelCachePlatform response:{bustCache}");
                    }
                }
                else
                {
                    _logger.Info($"ChannelUnPublish handler No classes for Channel: {command.ChannelTag}");
                }

                _logger.Info($"ChannelUnPublish handler end: {command.ChannelTag}");
            }
            catch (Exception e)
            {
                _logger.Warn("ChannelUnPublish handler exception", "warn", e.ToString());
            }
        }
    }
}
