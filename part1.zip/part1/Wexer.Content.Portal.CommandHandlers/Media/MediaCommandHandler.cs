﻿using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Command.Commands.Media;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.MediaService;
using Wexer.Content.Portal.Models.VirtualClasses;
using System.Linq;
using Wexer.Content.Portal.Models;
using Microsoft.Azure.Management.Media.Models;
using Microsoft.Azure.Management.Media;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.EventService;
using Wexer.Content.Portal.Models.ScheduleEvents;
using Wexer.Content.Portal.Repositories.Database.Models;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.Repositories.JWPlayer;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Models.JWPlayer.Request;

namespace Wexer.Content.Portal.CommandHandlers.Media
{
    public class MediaCommandHandler : ICommandHandler<EncodeMediaCommand>, ICommandHandler<EncodeEventMediaCommand>
    {
        private readonly IBlobRepo _blobRepo;
        private readonly IMediaServiceRepo _mediaServiceRepo;
        private readonly ILogger _logger;
        private readonly IContentWriteStoreRepo _contentWriteStoreRepo;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly ITitleService _titleService;
        private readonly IEventService _eventService;
        private readonly string _baseUrl;
        private readonly IJWPlayerRepo _jwplayerRepo;
        private readonly IProviderService _providerService;
        public MediaCommandHandler(IBlobRepo blobRepo, IMediaServiceRepo mediaServiceRepo, ILoggerFactory loggerFactory,
            IContentWriteStoreRepo contentWriteStoreRepo, ICmsStoreRepo cmsStore, ITitleService titleService, IEventService eventService, string baseUrl
            , IJWPlayerRepo jwplayerRepo, IProviderService providerService)
        {
            _blobRepo = blobRepo;
            _mediaServiceRepo = mediaServiceRepo;
            _logger = loggerFactory.GetLoggerForClass(this);
            _contentWriteStoreRepo = contentWriteStoreRepo;
            _cmsStore = cmsStore;
            _titleService = titleService;
            _eventService = eventService;
            _baseUrl = baseUrl;
            _jwplayerRepo = jwplayerRepo;
            _providerService = providerService;
        }
        public async Task HandleCommandAsync(EncodeMediaCommand command)
        {
            try
            {
                _logger.Info(string.Format("MediaCommandHandler > EncodeMediaCommand Handler START at {0}", DateTime.UtcNow));
                var selectedVirtualClass = await _cmsStore.GetAsync<VirtualClass>(command.ProviderId, command.ClassTag).ConfigureAwait(false);
                _logger.Info(string.Format("MediaCommandHandler > EncodeMediaCommand Handler selected title: {0}", selectedVirtualClass.Tag));

                if (selectedVirtualClass != null)
                {
                    try
                    {
                        _logger.Info(string.Format("MediaCommandHandler > EncodeMediaCommand, Starting encoding process for {0} file", command.AssetName));

                        Models.ContentPortal.Provider provider = await _providerService.Get(command.ProviderId).ConfigureAwait(false);

                        MediaResponse existingMedia = null;
                        if(!string.IsNullOrEmpty(selectedVirtualClass.ExternalClassId))
                        {
                            existingMedia = await _jwplayerRepo.GetMediaById<MediaResponse>(new MediaRequest { ProviderId = provider.Tag, MediaId = selectedVirtualClass.ExternalClassId }).ConfigureAwait(false);
                        }
                        if (provider.MediaPlatform == MediaPlatform.JWPlayer)
                        {
                            MediaResponse mediaStatus = new MediaResponse();
                            if (existingMedia == null)
                            {
                                var media = new MediaMetadata { Title = selectedVirtualClass.ClassName, ExternalId = selectedVirtualClass.Tag, Author = "", Description = "" };
                                mediaStatus = await _jwplayerRepo.InsertMedia<MediaResponse>(new MediaRequest { ProviderId = command.ProviderId, DownloadUrl = command.AssetUrl, Metadata = media });
                                _logger.Info(string.Format("MediaCommandHandler > HandleCommandAsync, Media added with {0} mediaid", mediaStatus?.Id));
                            }
                            else
                            {
                                mediaStatus = await _jwplayerRepo.UpdateMedia<MediaResponse>(new MediaRequest { ProviderId = command.ProviderId, DownloadUrl = command.AssetUrl, MediaId = existingMedia.Id });
                                _logger.Info(string.Format("MediaCommandHandler > HandleCommandAsync, Media having {0} mediaid updated", mediaStatus.Id));
                            }
                            selectedVirtualClass.ExternalClassId = mediaStatus.Id;
                            await _cmsStore.StoreAsync(selectedVirtualClass.Tag, selectedVirtualClass, "", selectedVirtualClass.ProviderID).ConfigureAwait(false);
                            _logger.Info(string.Format("MediaCommandHandler > HandleCommandAsync, Title external id updated with {0} mediaid", mediaStatus.Id));
                        }
                        else
                        {
                            var encodedJob = await _mediaServiceRepo.EncodeVideo(command.AssetUrl, command.AssetName, command.IsTrailerFile, command.Stage1Encode).ConfigureAwait(false);
                            if (encodedJob != null)
                            {
                                _logger.Info(string.Format("Encoding successful, publishing process started for {0} file", command.AssetName));

                                if (encodedJob.State == JobState.Finished)
                                {
                                    var publishCommand = new PublishMediaCommand
                                    {
                                        ClassTag = command.ClassTag,
                                        AssetName = command.AssetName,
                                        IsTrailerFile = command.IsTrailerFile,
                                        ProviderId = command.ProviderId,
                                        AssetUrl = command.AssetUrl,
                                        Stage1Encode = command.Stage1Encode,
                                        TenantUploadReportTrackingId = command.TenantUploadReportTrackingId
                                    };

                                    await PublishMediaFile(publishCommand).ConfigureAwait(false);
                                    return;
                                }

                                if (encodedJob.State == JobState.Error)
                                {
                                    selectedVirtualClass.Status = MediaProcessingStatus.Error;
                                    selectedVirtualClass.ErrorType = MediaProcessingError.EncodingError;
                                }

                                if (encodedJob.State == JobState.Canceled)
                                {
                                    selectedVirtualClass.Status = MediaProcessingStatus.Incomplete;
                                    selectedVirtualClass.ErrorType = MediaProcessingError.Canceled;
                                }
                            }
                            else
                            {
                                _logger.Info(string.Format("Encoding is null (failed) for class tag: {0}, asset name:{1}", command.ClassTag, command.AssetName));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        selectedVirtualClass.Status = MediaProcessingStatus.Error;
                        selectedVirtualClass.ErrorType = MediaProcessingError.EncodingError;
                        _logger.Warn("MediaCommandHandler > EncodeMediaCommand Exception, Error in the title", "warn", ex.ToString());
                        await UpdateVirtualClass(selectedVirtualClass).ConfigureAwait(false);
                    }
                }
                await UpdateVirtualClass(selectedVirtualClass).ConfigureAwait(false);
                _logger.Info(string.Format("MediaCommandHandler > EncodeMediaCommand Handler ENDED at {0}", DateTime.UtcNow));

            }
            catch (Exception e)
            {
                _logger.Error("MediaCommandHandler > EncodeMediaCommand, Error in encoding", e.Message);
            }
        }
        private async Task UpdateVirtualClass(VirtualClass selectedVirtualClass)
        {
            await _cmsStore.StoreAsync(selectedVirtualClass.Tag, selectedVirtualClass, "", selectedVirtualClass.ProviderID).ConfigureAwait(false);

            var bustCacheResponse = await _titleService.BustCachePortal(_baseUrl, CacheKeys.VirtualClass).ConfigureAwait(false);
            _logger.Info($"MediaCommandHandler > EncodeMediaCommand, BustCachePortal response: {bustCacheResponse}, key: {CacheKeys.VirtualClass}");

        }

        private async Task UpdateEventVirtualClass(ScheduleEvent selectedEvent)
        {
            if (selectedEvent != null)
            {
                await _cmsStore.StoreAsync(selectedEvent).ConfigureAwait(false);
            }
            else
            {
                _logger.Info($"MediaCommandHandler > UpdateEventVirtualClass > Schedule event not found {selectedEvent.Event_Id}");
            }
        }
        private async Task PublishMediaFile(PublishMediaCommand command)
        {
            int DurationSecond = 0;
            _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand started at {0}", DateTime.UtcNow));
            var selectedVirtualClass = await _cmsStore.GetAsync<VirtualClass>(command.ProviderId, command.ClassTag).ConfigureAwait(false);
            try
            {
                if (selectedVirtualClass != null)
                {
                    if (command.IsTrailerFile)
                    {
                        string trailerEncodedAssetName = string.Format("{0}-Mobile", command.AssetName);
                        var trailerEncodedAsset = await _mediaServiceRepo.GetAsset(trailerEncodedAssetName).ConfigureAwait(false);

                        if (trailerEncodedAsset != null)
                        {
                            _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, Publish process started for encoded trailer file: {0}", trailerEncodedAssetName));
                            var locator = await _mediaServiceRepo.CreateStreamingLocatorAsync(trailerEncodedAssetName, string.Format("{0}-Locator", trailerEncodedAssetName)).ConfigureAwait(false);
                            var streamingUrls = await _mediaServiceRepo.GetStreamingUrlsAsync(locator.Name).ConfigureAwait(false);

                            _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, encoded trailer streaming locator {0}", locator.Name));

                            if (streamingUrls != null && streamingUrls.Count() > 0)
                            {
                                selectedVirtualClass.TrailerLinkMobile = streamingUrls.FirstOrDefault();
                                _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, TrailerLinkMobile : {0}", streamingUrls.FirstOrDefault()));
                            }
                            else
                            {
                                _logger.Error(string.Format("MediaCommandHandler > PublishMediaCommand, Publishing failed for the encoded trailer file: {0} and class: {1} ", trailerEncodedAssetName, selectedVirtualClass.Tag));
                                selectedVirtualClass.Status = MediaProcessingStatus.Error;
                                selectedVirtualClass.ErrorType = MediaProcessingError.PublishError;
                            }
                        }
                    }

                    if (!command.IsTrailerFile)
                    {
                        if (command.Stage1Encode)
                        {
                            string Stage1EncodedAssetName = string.Format("{0}-Stage1-MediaStandardEncoded", command.AssetName);
                            var Stage1EncodedAsset = await _mediaServiceRepo.GetAsset(Stage1EncodedAssetName).ConfigureAwait(false);

                            if (Stage1EncodedAsset != null)
                            {
                                var url = _mediaServiceRepo.GetAssetBlobUrl(Stage1EncodedAsset.Container, "1920x1080_4500");
                                selectedVirtualClass.Stage1EncodeVideoFileUrl = url.ToString();
                                _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, Stage1EncodeVideoFileUrl : {0}", url.ToString()));
                            }
                        }

                        string encodedAssetName = string.Format("{0}-MediaStandardEncoded", command.AssetName);
                        var encodedAsset = await _mediaServiceRepo.GetAsset(encodedAssetName).ConfigureAwait(false);

                        if (encodedAsset != null)
                        {
                            _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, Publish process started for the {0} file and class {1}", encodedAssetName, selectedVirtualClass.Tag));
                            var locator = await _mediaServiceRepo.CreateStreamingLocatorAsync(encodedAssetName, string.Format("{0}-Locator", encodedAssetName)).ConfigureAwait(false);
                            var streamingUrls = await _mediaServiceRepo.GetStreamingUrlsAsync(locator.Name).ConfigureAwait(false);

                            _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, Video publish locator {0}", locator.Name));

                            DurationSecond = _mediaServiceRepo.GetTitleDuration(encodedAsset.Container);
                            if (DurationSecond != 0)
                            {
                                selectedVirtualClass.DurationSecond = DurationSecond;
                            }

                            if (streamingUrls != null && streamingUrls.Count() > 0)
                            {
                                selectedVirtualClass.Status = MediaProcessingStatus.Incomplete;
                                selectedVirtualClass.StreamingLink = streamingUrls.FirstOrDefault();
                                var url = _mediaServiceRepo.GetAssetBlobUrl(encodedAsset.Container, "1280x720_3000");
                                selectedVirtualClass.AlternateLink = url.ToString();

                                _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, StreamingLink : {0}", streamingUrls.FirstOrDefault()));
                                _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand, AlternateLink : {0}", url.ToString()));
                            }
                            else
                            {
                                _logger.Error(string.Format("MediaCommandHandler > PublishMediaCommand, Publishing failed for the video file: {0} and class: {1}", encodedAssetName, selectedVirtualClass.Tag));
                                selectedVirtualClass.Status = MediaProcessingStatus.Error;
                                selectedVirtualClass.ErrorType = MediaProcessingError.PublishError;
                            }
                        }
                    }
                    _logger.Info(string.Format("MediaCommandHandler > PublishMediaCommand ended at {0}", DateTime.UtcNow));
                    await UpdateVirtualClass(selectedVirtualClass).ConfigureAwait(false);

                    #region Logic to update TenantUpload record after encoding
                    if (!command.IsTrailerFile)
                    {
                        var multiplier = GetMultiplierValue(command.IsTrailerFile, command.Stage1Encode);
                        var tenantUploadReportTrackingEntity = _contentWriteStoreRepo.FindAll<OndemandTenantUploadTrackingEntity>(x => x.Id == command.TenantUploadReportTrackingId).FirstOrDefault();
                        tenantUploadReportTrackingEntity.DurationSecond = DurationSecond;
                        tenantUploadReportTrackingEntity.EncodedDurationMultiplier = Convert.ToDecimal(multiplier);
                        tenantUploadReportTrackingEntity.EncodedDurationMinutes = Convert.ToDecimal(GetRoundOffMinutes(tenantUploadReportTrackingEntity.DurationSecond) * multiplier);
                        tenantUploadReportTrackingEntity.EncodedDate = DateTime.UtcNow;
                        await _contentWriteStoreRepo.UpsertAndReturnEntity(tenantUploadReportTrackingEntity.Id, tenantUploadReportTrackingEntity);
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                _logger.Error("MediaCommandHandler > PublishMediaCommand, Publish Error", ex);
                throw ex;
            }
        }

        private async Task PublishEventMediaFile(PublishEventMediaCommand command)
        {
            _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand started at {0} for event:{1}", DateTime.UtcNow, command.EventTag));
            var selectedEvent = await _eventService.GetEvent(command.Tenant, command.EventTag).ConfigureAwait(false);
            try
            {
                if (selectedEvent != null)
                {
                    if (command.IsTrailerFile)
                    {
                        string trailerEncodedAssetName = string.Format("{0}-Mobile", command.AssetName);
                        var trailerEncodedAsset = await _mediaServiceRepo.GetAsset(trailerEncodedAssetName).ConfigureAwait(false);

                        if (trailerEncodedAsset != null)
                        {
                            _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, Publish process started for encoded trailer file: {0}", trailerEncodedAssetName));
                            var locator = await _mediaServiceRepo.CreateStreamingLocatorAsync(trailerEncodedAssetName, string.Format("{0}-Locator", trailerEncodedAssetName)).ConfigureAwait(false);
                            var streamingUrls = await _mediaServiceRepo.GetStreamingUrlsAsync(locator.Name).ConfigureAwait(false);

                            _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, encoded trailer streaming locator {0}", locator.Name));

                            if (streamingUrls != null && streamingUrls.Count() > 0)
                            {
                                selectedEvent.Video.TrailerLinkMobile = streamingUrls.FirstOrDefault();
                                _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, TrailerLinkMobile : {0}", streamingUrls.FirstOrDefault()));
                            }
                            else
                            {
                                _logger.Error(string.Format("MediaCommandHandler > PublishEventMediaCommand, Publishing failed for the encoded trailer file: {0} and class: {1} ", trailerEncodedAssetName, selectedEvent.Video.Tag));
                                selectedEvent.Video.Status = MediaProcessingStatus.Error;
                                selectedEvent.Video.ErrorType = MediaProcessingError.PublishError;
                            }
                        }
                    }

                    if (!command.IsTrailerFile)
                    {
                        if (command.Stage1Encode)
                        {
                            string Stage1EncodedAssetName = string.Format("{0}-Stage1-MediaStandardEncoded", command.AssetName);
                            var Stage1EncodedAsset = await _mediaServiceRepo.GetAsset(Stage1EncodedAssetName).ConfigureAwait(false);

                            if (Stage1EncodedAsset != null)
                            {
                                var url = _mediaServiceRepo.GetAssetBlobUrl(Stage1EncodedAsset.Container, "1920x1080_4500");
                                selectedEvent.Video.Stage1EncodeVideoFileUrl = url.ToString();
                                _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, Stage1EncodeVideoFileUrl : {0}", url.ToString()));
                            }
                        }

                        string encodedAssetName = string.Format("{0}-MediaStandardEncoded", command.AssetName);
                        var encodedAsset = await _mediaServiceRepo.GetAsset(encodedAssetName).ConfigureAwait(false);

                        if (encodedAsset != null)
                        {
                            _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, Publish process started for the {0} file and class {1}", encodedAssetName, selectedEvent.Video.Tag));
                            var locator = await _mediaServiceRepo.CreateStreamingLocatorAsync(encodedAssetName, string.Format("{0}-Locator", encodedAssetName)).ConfigureAwait(false);
                            var streamingUrls = await _mediaServiceRepo.GetStreamingUrlsAsync(locator.Name).ConfigureAwait(false);

                            _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, Video publish locator {0}", locator.Name));

                            int DurationSecond = _mediaServiceRepo.GetTitleDuration(encodedAsset.Container);
                            if (DurationSecond != 0)
                            {
                                selectedEvent.Video.DurationSecond = DurationSecond;
                            }

                            if (streamingUrls != null && streamingUrls.Count() > 0)
                            {
                                selectedEvent.Video.Status = MediaProcessingStatus.Incomplete;
                                selectedEvent.Video.StreamingLink = streamingUrls.FirstOrDefault();
                                var url = _mediaServiceRepo.GetAssetBlobUrl(encodedAsset.Container, "1280x720_3000");
                                selectedEvent.Video.AlternateLink = url.ToString();

                                _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, StreamingLink : {0}", streamingUrls.FirstOrDefault()));
                                _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand, AlternateLink : {0}", url.ToString()));
                            }
                            else
                            {
                                _logger.Error(string.Format("MediaCommandHandler > PublishEventMediaCommand, Publishing failed for the video file: {0} and class: {1}", encodedAssetName, selectedEvent.Video.Tag));
                                selectedEvent.Video.Status = MediaProcessingStatus.Error;
                                selectedEvent.Video.ErrorType = MediaProcessingError.PublishError;
                            }
                        }
                    }
                    _logger.Info(string.Format("MediaCommandHandler > PublishEventMediaCommand ended at {0}", DateTime.UtcNow));
                    await UpdateEventVirtualClass(selectedEvent).ConfigureAwait(false);

                    #region Logic to update Tenant Event/Event Trailer Upload record after encoding
                    if (!command.IsTrailerFile)
                    {
                        var multiplier = GetMultiplierValue(command.IsTrailerFile, command.Stage1Encode);
                        var tenantUploadReportTrackingEntity = _contentWriteStoreRepo.FindAll<OndemandTenantUploadTrackingEntity>(x => x.Id == command.TenantUploadReportTrackingId).FirstOrDefault();
                        tenantUploadReportTrackingEntity.DurationSecond = selectedEvent.Video.DurationSecond;
                        tenantUploadReportTrackingEntity.EncodedDurationMultiplier = Convert.ToDecimal(multiplier);
                        tenantUploadReportTrackingEntity.EncodedDurationMinutes = Convert.ToDecimal(GetRoundOffMinutes(tenantUploadReportTrackingEntity.DurationSecond) * multiplier);
                        tenantUploadReportTrackingEntity.EncodedDate = DateTime.UtcNow;
                        await _contentWriteStoreRepo.UpsertAndReturnEntity(tenantUploadReportTrackingEntity.Id, tenantUploadReportTrackingEntity);
                    }
                    #endregion
                }
                else
                {
                    _logger.Info($"MediaCommandHandler > PublishEventMediaCommand event not found event:{command.EventTag}");
                }
            }
            catch (Exception ex)
            {
                _logger.Warn("MediaCommandHandler > PublishEventMediaCommand, Publish Error", "warn", ex.ToString());
                throw ex;
            }
        }

        public async Task HandleCommandAsync(EncodeEventMediaCommand command)
        {
            try
            {
                _logger.Info(string.Format("MediaCommandHandler > EncodeEventMediaCommand Handler START at {0}", DateTime.UtcNow));
                var selectedEvent = await _eventService.GetEvent(command.Tenant, command.EventId).ConfigureAwait(false);
                _logger.Info(string.Format("MediaCommandHandler > EncodeEventMediaCommand Handler selected title: {0}", selectedEvent.Event_Id));

                if (selectedEvent != null)
                {
                    try
                    {
                        _logger.Info(string.Format("MediaCommandHandler > EncodeEventMediaCommand, Starting encoding process for {0} file", command.AssetName));
                        var encodedJob = await _mediaServiceRepo.EncodeVideo(command.AssetUrl, command.AssetName, command.IsTrailerFile, command.Stage1Encode).ConfigureAwait(false);
                        if (encodedJob != null)
                        {
                            _logger.Info(string.Format("Encoding event video successful, publishing process started for {0} file", command.AssetName));

                            if (encodedJob.State == JobState.Finished)
                            {
                                var publishCommand = new PublishEventMediaCommand
                                {
                                    EventTag = command.EventId,
                                    AssetName = command.AssetName,
                                    IsTrailerFile = command.IsTrailerFile,
                                    ProviderId = command.ProviderId,
                                    AssetUrl = command.AssetUrl,
                                    Stage1Encode = command.Stage1Encode,
                                    Tenant = command.Tenant,
                                    TenantUploadReportTrackingId = command.TenantUploadReportTrackingId
                                };
                                await PublishEventMediaFile(publishCommand).ConfigureAwait(false);
                                return;
                            }

                            if (encodedJob.State == JobState.Error)
                            {
                                selectedEvent.Video.Status = MediaProcessingStatus.Error;
                                selectedEvent.Video.ErrorType = MediaProcessingError.EncodingError;
                            }

                            if (encodedJob.State == JobState.Canceled)
                            {
                                selectedEvent.Video.Status = MediaProcessingStatus.Incomplete;
                                selectedEvent.Video.ErrorType = MediaProcessingError.Canceled;
                            }
                        }
                        else
                        {
                            _logger.Info(string.Format("Encoding is null (failed) for class tag: {0}, asset name:{1}", command.ClassTag, command.AssetName));
                        }
                    }
                    catch (Exception ex)
                    {
                        selectedEvent.Video.Status = MediaProcessingStatus.Error;
                        selectedEvent.Video.ErrorType = MediaProcessingError.EncodingError;
                        _logger.Warn("MediaCommandHandler > EncodeEventMediaCommand Exception, Error in the title", "warn", ex.ToString());
                        await UpdateEventVirtualClass(selectedEvent).ConfigureAwait(false);
                    }
                }
                await UpdateEventVirtualClass(selectedEvent).ConfigureAwait(false);
                _logger.Info(string.Format("MediaCommandHandler > EncodeEventMediaCommand Handler ENDED at {0}", DateTime.UtcNow));
            }
            catch (Exception e)
            {
                throw;
            }
        }

        private double GetMultiplierValue(bool isTrailerFile, bool Stage1Encode)
        {
            double multiplier;
            if (!isTrailerFile)
            {
                if (Stage1Encode)
                {
                    multiplier = (0.25 + 2);//CreateCustomTransformStage1(AacAudio+"1920x1080")
                    multiplier = multiplier + (0.25 + 2 + 2 + 1 + 1);//CreateCustomTransform(AacAudio+"1920x1080"+"1280x720"+"960x540"+"640x360")
                    return multiplier;
                }
                else
                {
                    multiplier = (0.25 + 2 + 2 + 1 + 1);//CreateCustomTransform(AacAudio+"1920x1080"+"1280x720"+"960x540"+"640x360")
                    return multiplier;
                }
            }
            else
            {
                multiplier = (0.25 + 1);//CreateTrailerTransform(AacAudio+"848x480")
                return multiplier;
            }
        }

        private int GetRoundOffMinutes(int seconds)
        {
            if (seconds % 60 > 0)
            {
                return (seconds / 60) + 1;
            }
            else
            {
                return (seconds / 60);
            }
        }
    }
}
