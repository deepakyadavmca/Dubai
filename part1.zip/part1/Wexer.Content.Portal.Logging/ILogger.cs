﻿using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Logging
{
    public interface ILogger
    {
        void Trace(string message, params object[] args);
        void Debug(string message, params object[] args);
        void Info(string message, params object[] args);
        void Warn(string message, params object[] args);
        void Error(string message, params object[] args);

        void Debug(string message, string name, object value);
        void Info(string message, string name, object value);
        void Warn(string message, string name, object value);
        void Error(string message, string name, object value);

        void WarnException(string message, Exception exception);
        void ErrorException(string message, Exception exception);
        IDictionary<Guid, string> InternalLog { get; }
    }
}
