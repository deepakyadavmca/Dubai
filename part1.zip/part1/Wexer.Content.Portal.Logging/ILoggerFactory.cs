namespace Wexer.Content.Portal.Logging
{
    public interface ILoggerFactory
    {
        ILogger GetLoggerForClass<T>(T instance) where T : class;
    }
}