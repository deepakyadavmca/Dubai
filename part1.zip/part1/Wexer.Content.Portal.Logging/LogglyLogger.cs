using Wexer.Content.Portal.Models.User;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;


namespace Wexer.Content.Portal.Logging
{
    public class LogglyLogger : ILogger
    {
        public IDictionary<Guid, string> InternalLog { get; private set; }
        private int _recursionCount;
        private readonly string _loggerName;
        private readonly ILoggingCommunicator _loggingCommunicator;
        private readonly string _inputKey;
        private readonly string _tags;
        private readonly string _levels;
        private static readonly string Version;

        // http://stackoverflow.com/questions/7397207/json-net-error-self-referencing-loop-detected-for-type#18223985
        // The $id and $ref keeps all the references and makes the object graph level flat.
        private readonly JsonSerializerSettings _jsonSettings = new JsonSerializerSettings
        {
            ReferenceLoopHandling = ReferenceLoopHandling.Serialize,
            PreserveReferencesHandling = PreserveReferencesHandling.Objects
        };

        static LogglyLogger()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            Version = fvi.FileVersion;
        }

        public LogglyLogger(ILoggingCommunicator loggingCommunicator, string loggerName, string inputKey, string tags, string levels)
        {
            _loggingCommunicator = loggingCommunicator;
            _loggerName = loggerName;
            _inputKey = inputKey;
            _tags = tags;
            _levels = levels;
        }

        internal LogglyLogger(string loggerName, string inputKey, string loggerUrl, string tags, string levels)
        {
            _loggerName = loggerName;
            _inputKey = inputKey;
            _tags = tags;
            _levels = levels;

            if (!string.IsNullOrEmpty(inputKey))
            {
                _loggingCommunicator = new LoggingCommunicator(loggerUrl);
            }
        }

        public void Trace(string message, params object[] args)
        {
            args = SensitiseData(args);
            System.Diagnostics.Trace.WriteLine(string.Format(message, args));
            Log(string.Format(message, args), "trace");
        }

        public void Debug(string message, params object[] args)
        {
            args = SensitiseData(args);
            System.Diagnostics.Trace.WriteLine(string.Format(message, args));
            Log(string.Format(message, args), "debug");
        }

        public void Info(string message, params object[] args)
        {
            args = SensitiseData(args);
            System.Diagnostics.Trace.WriteLine(string.Format(message, args));
            Log(string.Format(message, args), "info");
        }

        public void Debug(string message, string name, object value)
        {
            value = SensitiseData(value);
            System.Diagnostics.Trace.WriteLine(string.Format("{0}={1}", name, JsonConvert.SerializeObject(value, Formatting.None, _jsonSettings)));
            Log(message, "debug", new Dictionary<string, object> { { name, value } });
        }

        public void Info(string message, string name, object value)
        {
            value = SensitiseData(value);
            System.Diagnostics.Trace.WriteLine(string.Format("{0}={1}", name, JsonConvert.SerializeObject(value, Formatting.None, _jsonSettings)));
            Log(message, "info", new Dictionary<string, object> { { name, value } });
        }

        public void Warn(string message, params object[] args)
        {
            args = SensitiseData(args);
            System.Diagnostics.Trace.WriteLine(string.Format(message, args));
            Log(string.Format(message, args), "warn");
        }

        public void Warn(string message, string name, object value)
        {
            value = SensitiseData(value);
            System.Diagnostics.Trace.WriteLine(string.Format("{0}={1}", name, JsonConvert.SerializeObject(value, Formatting.None, _jsonSettings)));
            Log(message, "warn", new Dictionary<string, object> { { name, value } });
        }

        public void Error(string message, params object[] args)
        {
            args = SensitiseData(args);
            System.Diagnostics.Trace.WriteLine(string.Format(message, args));
            Log(string.Format(message, args), "error");
        }

        public void Error(string message, string name, object value)
        {
            value = SensitiseData(value);
            System.Diagnostics.Trace.WriteLine(string.Format("{0}={1}", name, JsonConvert.SerializeObject(value, Formatting.None, _jsonSettings)));
            Log(message, "error", new Dictionary<string, object> { { name, value } });
        }

        public void TraceException(string message, Exception exception)
        {
            System.Diagnostics.Trace.WriteLine(string.Format(message, exception));
            Log(message, "trace", new Dictionary<string, object> { { "exception", exception } });
        }

        public void WarnException(string message, Exception exception)
        {
            System.Diagnostics.Trace.WriteLine(string.Format(message, exception));
            Log(message, "warn", new Dictionary<string, object> { { "exception", exception } });
        }

        public void ErrorException(string message, Exception exception)
        {
            System.Diagnostics.Trace.WriteLine(string.Format(message, exception));
            Log(message, "error", new Dictionary<string, object> { { "exception", exception } });
        }

        private void Log(string message, string category, Dictionary<string, object> data = null)
        {
            if (string.IsNullOrEmpty(_levels) || _levels.Contains(category))
            {
                var logEntry = new Dictionary<string, object>
                {
                    {"timestamp", DateTime.UtcNow.ToString("o")},
                    {"logger", _loggerName},
                    {"level", category},
                    {"host", Environment.MachineName},
                    {"version", Version}
                };
                if (!string.IsNullOrWhiteSpace(message))
                {
                    logEntry.Add("message", message);
                }
                if (data != null)
                {
                    foreach (var entry in data)
                    {
                        logEntry.Add(entry.Key, entry.Value);
                    }
                }

                var jsonLogEntry = JsonConvert.SerializeObject(logEntry, Formatting.None, _jsonSettings);
                LogInternal(jsonLogEntry, true);
            }
        }

        private object[] SensitiseData(IEnumerable<object> args)
        {
            return args.Select(SensitiseData).ToArray();
        }

        private object SensitiseData(object value)
        {
            if (value == null)
            {
                return null;
            }

            var properties = value.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var p in properties)
            {
                if (!IsPrimitiveType(p.PropertyType.UnderlyingSystemType))
                {
                    _recursionCount++;
                    if (_recursionCount <= 5)
                    {
                        if (p.CanWrite)
                        {
                            // http://stackoverflow.com/questions/6156577/
                            // One of the string's properties is the indexer for returning the character at the specified location.
                            // Thus, when you try to GetValue, the method expects an index but doesn't receive one, causing the exception.
                            if (p.GetIndexParameters().Length == 0)
                            {
                                var newVal = SensitiseData(p.GetValue(value));
                                p.SetValue(value, newVal, null);
                            }
                        }
                        continue;
                    }

                    _recursionCount = 0;
                    return value;
                }

                var attributes = p.GetCustomAttributes();
                if (attributes == null)
                {
                    continue;
                }

                if (attributes.FirstOrDefault(a => a.GetType() == typeof(SensitiveDataAttribute)) != null)
                {
                    switch (p.PropertyType.Name.ToLowerInvariant())
                    {
                        case "datetime":
                            p.SetValue(value, DateTime.MinValue, null);
                            break;
                        case "bool":
                            p.SetValue(value, false, null);
                            break;
                        case "string":
                            p.SetValue(value, "***", null);
                            break;
                        case "int":
                        case "decimal":
                            p.SetValue(value, -999, null);
                            break;
                        case "double":
                            p.SetValue(value, -999M, null);
                            break;
                        case "float":
                            p.SetValue(value, -999F, null);
                            break;
                    }
                }
            }

            return value;
        }

        private static bool IsPrimitiveType(Type fieldType)
        {
            return fieldType.IsPrimitive || (fieldType.Namespace != null && fieldType.Namespace.Equals("System"));
        }

        public void LogInternal(string message, bool json)
        {
            if (!string.IsNullOrEmpty(_inputKey))
            {
                _loggingCommunicator.SendPayload(string.Concat("inputs/", _inputKey), message, json, _tags);
            }

            if (InternalLog == null || InternalLog.Values.Count > 10)
            {
                InternalLog = new ConcurrentDictionary<Guid, string>();
            }

            InternalLog.Add(Guid.NewGuid(), message);
        }
    }
}