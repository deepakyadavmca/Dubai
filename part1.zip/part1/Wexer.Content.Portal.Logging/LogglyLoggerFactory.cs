namespace Wexer.Content.Portal.Logging
{
    public class LogglyLoggerFactory : ILoggerFactory
    {
        private readonly string _inputKey;
        private readonly string _loggerUrl;
        private readonly string _tags;
        private readonly string _levels;

        public LogglyLoggerFactory(string inputKey = null, string loggerUrl = null, string tags = null, string levels = null)
        {
            _inputKey = inputKey;
            _loggerUrl = loggerUrl;
            _tags = tags;
            _levels = levels;
        }

        public ILogger GetLoggerForClass<T>(T instance) where T : class
        {
            return new LogglyLogger(typeof(T).Name, _inputKey, _loggerUrl, _tags, _levels);
        }
    }
}