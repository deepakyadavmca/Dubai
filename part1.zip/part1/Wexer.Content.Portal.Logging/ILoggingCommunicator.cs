using System.Collections.Generic;

namespace Wexer.Content.Portal.Logging
{
    public interface ILoggingCommunicator
    {
        void SendPayload(string endPoint, string message, bool json, string tags, string verb = "POST");
        T GetPayload<T>(string endPoint, IDictionary<string, object> parameters);
    }
}