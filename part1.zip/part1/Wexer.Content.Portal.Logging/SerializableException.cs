using System;
using System.Collections;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Logging
{
    /// <summary>
    ///     A wrapper class for serializing exceptions.
    /// </summary>
    [Serializable]
    public class SerializableException
    {
        private KeyValuePair<object, object>[] _data;
        //This is the reason this class exists. Turning an IDictionary into a serializable object

        public SerializableException(Exception exception)
        {
            StackTrace = string.Empty;
            Source = string.Empty;
            Message = string.Empty;
            HelpLink = string.Empty;
            SetValues(exception);
        }

        public string HelpLink { get; set; }

        public string Message { get; set; }

        public string Source { get; set; }

        public string StackTrace { get; set; }

        public SerializableException InnerException { get; set; }

        // Allow null to be returned, so serialization doesn't cascade until an out of memory exception occurs

        public KeyValuePair<object, object>[] Data
        {
            get { return _data ?? new KeyValuePair<object, object>[0]; }
            set { _data = value; }
        }

        private void SetValues(Exception exception)
        {
            if (exception != null)
            {
                exception.
                HelpLink = exception.HelpLink ?? string.Empty;
                Message = exception.Message ?? string.Empty;
                Source = exception.Source ?? string.Empty;
                StackTrace = exception.StackTrace ?? string.Empty;
                SetData(exception.Data);
                InnerException = new SerializableException(exception.InnerException);
            }
        }

        private void SetData(ICollection collection)
        {
            _data = new KeyValuePair<object, object>[0];

            if (collection!= null)
            {
                collection.CopyTo(_data, 0);
            }
        }
    }
}