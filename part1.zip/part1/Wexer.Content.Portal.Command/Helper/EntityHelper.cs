﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Command
{
    public static class EntityHelper
    {
        /// <summary>
        /// Generates an id
        /// </summary>
        /// <returns>Guid string representation</returns>
        public static string GenerateId()
        {
            return Guid.NewGuid().ToString();
        }
    }
}
