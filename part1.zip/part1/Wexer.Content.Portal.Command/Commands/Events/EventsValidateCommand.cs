﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;
using Wexer.Content.Portal.Models.Events;

namespace Wexer.Content.Portal.Command.Commands.Events
{
    [QueueCommand(@"/v1/events/ondemand/playback/upload/validate", IsBackground = true)]
    [ProtoContract]
    public class EventsValidateCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string TaskId { get; set; }

    }
}
