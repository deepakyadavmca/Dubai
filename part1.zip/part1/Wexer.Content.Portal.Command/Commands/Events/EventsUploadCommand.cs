﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Events
{

    [QueueCommand(@"/v1/events/ondemand/playback/upload/process", IsBackground = true)]
    [ProtoContract]
    public class EventsUploadCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string TaskId { get; set; }

        [ProtoMember(2)]
        public string Action { get; set; }

    }
}
