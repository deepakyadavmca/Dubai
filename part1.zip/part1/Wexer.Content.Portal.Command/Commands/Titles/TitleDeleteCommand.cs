﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Titles
{
    [QueueCommand(@"/v1/title/delete", IsBackground = true)]
    [ProtoContract]
    public class TitleDeleteCommand: QueueCommand
    {
        [ProtoMember(1)]
        public Dictionary<string, string> TitlesData { get; set; } // key value pair of providerid and class tag
    }
}
