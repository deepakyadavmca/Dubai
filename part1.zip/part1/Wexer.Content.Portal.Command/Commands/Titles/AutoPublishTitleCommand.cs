﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;
using Wexer.Content.Portal.Models.VirtualClasses;

namespace Wexer.Content.Portal.Command.Commands.Titles
{
    [QueueCommand(@"/v1/title/autopublish", IsBackground = true)]
    [ProtoContract]
    public class AutoPublishTitleCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string TenantId { get; set; }
        
        [ProtoMember(2)]
        public string Event_Id { get; set; }
        
        [ProtoMember(3)]
        public string OldStreamingUrl { get; set; }

        [ProtoMember(4)]
        public string NewStreamingUrl { get; set; }
    }
}
