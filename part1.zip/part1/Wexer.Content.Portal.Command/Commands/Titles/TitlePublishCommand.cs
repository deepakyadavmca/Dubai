﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Titles
{
    [QueueCommand(@"/v1/title/publish", IsBackground = true)]
    [ProtoContract]
    public class TitlePublishCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string Tag { get; set; }
        
        [ProtoMember(2)]
        public string ChannelId { get; set; }

        [ProtoMember(3)]
        public string ProviderId { get; set; }
    }
}
