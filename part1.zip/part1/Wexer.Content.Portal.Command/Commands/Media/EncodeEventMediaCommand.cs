﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Media
{
    [QueueCommand(@"/v1/media/encodeeventmedia", IsBackground = true)]
    [ProtoContract]
    public class EncodeEventMediaCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string EventId { get; set; }

        [ProtoMember(2)]
        public string AssetName { get; set; }

        [ProtoMember(3)]
        public string LanguageCulture { get; set; }

        [ProtoMember(4)]
        public string Tenant { get; set; }

        [ProtoMember(5)]
        public bool IsTrailerFile { get; set; }

        [ProtoMember(6)]
        public string AssetUrl { get; set; }

        [ProtoMember(7)]
        public string ProviderId { get; set; }

        //[ProtoMember(8)]
        //public bool SkipStage1Encoding { get; set; }

        [ProtoMember(9)]
        public bool Stage1Encode { get; set; }

        [ProtoMember(10)]
        public string ClassTag { get; set; }
        [ProtoMember(11)]
        public int TenantUploadReportTrackingId { get; set; }
    }
}
