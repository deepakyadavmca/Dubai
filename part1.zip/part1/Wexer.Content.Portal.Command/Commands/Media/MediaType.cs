﻿using ProtoBuf;

namespace Wexer.Content.Portal.Command.Commands.Media
{
    [ProtoContract]
    public enum MediaType
    {
        [ProtoEnum(Name = "Video")]
        Video,

        [ProtoEnum(Name = "Image")]
        Image,

        [ProtoEnum(Name = "Audio")]
        Audio,
    }
}
