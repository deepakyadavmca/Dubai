﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Channel
{
    [QueueCommand(@"/v1/channel/un-publish", IsBackground = true)]
    [ProtoContract]
    public class ChannelUnPublishCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string ChannelTag { get; set; }

        [ProtoMember(2)]
        public List<string> TenantIdsToUnPublish { get; set; }
    }
}
