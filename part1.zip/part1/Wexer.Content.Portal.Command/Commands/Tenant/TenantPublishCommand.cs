﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Tenant
{
    [QueueCommand(@"/v1/tenant/publish", IsBackground = true)]
    [ProtoContract]
    public class TenantPublishCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string TenantId { get; set; }

        [ProtoMember(2)]
        public List<string> ChannelsToPublish { get; set; }

    }
}
