﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Commands.Tenant
{
    [QueueCommand(@"/v1/tenant/un-publish", IsBackground = true)]
    [ProtoContract]
    public class TenantUnPublishCommand : QueueCommand
    {
        [ProtoMember(1)]
        public string TenantId { get; set; }

        [ProtoMember(2)]
        public List<string> ChannelsToUnPublish { get; set; }
    }
}
