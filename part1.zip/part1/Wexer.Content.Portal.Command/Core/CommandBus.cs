using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Common;
using Wexer.Content.Portal.Logging;
using Microsoft.Azure.ServiceBus;
using System.Text;
using Newtonsoft.Json;

namespace Wexer.Content.Portal.Command.Core
{
    public class CommandBus : ICommandBus
    {

        private readonly Dictionary<Type, string> commandNamesByType = new Dictionary<Type, string>();
        private readonly ILogger _logger;
        private readonly IQueueClient _queueClient;
        private readonly IQueueClient _backgroundQueueClient;
        public CommandBus(ILoggerFactory loggerFactory, IQueueClient queueClient, IQueueClient backgroundQueueClient)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _queueClient = queueClient;
            _backgroundQueueClient = backgroundQueueClient;
        }

        public async Task<Tuple<bool, string>> SendAsync<T>(T queueCommand) where T : QueueCommand
        {
            var envelope = CreateCommandEnvelope(queueCommand);
            envelope.SetPayload(queueCommand);

            _logger.Info("Adding command to queue", "command", new
            {
                envelopeId = envelope.EnvelopeId,
                commandType = envelope.CommandName,
                isBackground = envelope.IsBackground,
                isIntensive = envelope.IsIntensive
            });

            Message message = new Message(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(envelope))) { Label = envelope.CommandName };
            message.ContentType = "application/json";
            //if (envelope.IsIntensive)
            //{
            //    await _intensiveQueueClient.SendAsync(message).ConfigureAwait(false);
            //}
            if (envelope.IsBackground)
            {
                await _backgroundQueueClient.SendAsync(message).ConfigureAwait(false);
            }
            else
            {
                await _queueClient.SendAsync(message).ConfigureAwait(false);
            }

            return Tuple.Create(true, envelope.EnvelopeId);
        }

        private CommandEnvelope CreateCommandEnvelope<T>(T queueCommand) where T : QueueCommand
        {
            var commandType = queueCommand.GetType();
            string commandName;
            bool isBackground = false;
            bool isIntensive = false;

            if (!commandNamesByType.TryGetValue(commandType, out commandName))
            {
                var attributes = commandType.GetCustomAttributes(typeof(QueueCommandAttribute), false).Select(x => x as QueueCommandAttribute).ToList();
                var attribute = attributes.First();
                commandName = attribute.CommandName; // TODO support multiple names for a given command for versioning
                isBackground = attribute.IsBackground;
                isIntensive = attribute.IsIntensive;
            }

            return new CommandEnvelope(commandName, EntityHelper.GenerateId(), isBackground, isIntensive);
        }

        public async Task<long> SendScheduledAsync<T>(T queueCommand, DateTimeOffset scheduleEnqueueTimeUtc) where T : QueueCommand
        {
            var envelope = CreateCommandEnvelope(queueCommand);
            envelope.SetPayload(queueCommand);
            _logger.Info("Adding command to queue", "command", new
            {
                envelopeId = envelope.EnvelopeId,
                commandType = envelope.CommandName,
                isBackground = envelope.IsBackground,
                isIntensive = envelope.IsIntensive
            });

            Message message = new Message(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(envelope))) { Label = envelope.CommandName };
            message.ContentType = "application/json";
            //if (envelope.IsIntensive)
            //{
            //    await _intensiveQueueClient.ScheduleMessageAsync(message, scheduleEnqueueTimeUtc).ConfigureAwait(false);
            //}
            long messageId;
            if (envelope.IsBackground)
            {
                messageId = await _backgroundQueueClient.ScheduleMessageAsync(message, scheduleEnqueueTimeUtc).ConfigureAwait(false);
            }
            else
            {
                messageId = await _queueClient.ScheduleMessageAsync(message, scheduleEnqueueTimeUtc).ConfigureAwait(false);
            }

            return messageId;
        }

        public async Task CancelScheduleAsync(long sequenceNumber)
        {
            try
            {
                _logger.Info($"CancelScheduleAsync with seq:{sequenceNumber}");
                await _backgroundQueueClient.CancelScheduledMessageAsync(sequenceNumber).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                _logger.Warn($"CancelScheduleAsync exception seq:{sequenceNumber}", "warn", e.ToString());
            }
            
        }
    }
}