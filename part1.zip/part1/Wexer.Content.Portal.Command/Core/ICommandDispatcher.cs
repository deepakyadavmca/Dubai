﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Core
{
    public interface ICommandDispatcher
    {
        Type GetCommandTypeFor(string commandName);
        void Register(IEnumerable<ICommandHandler> commandHandlers);
        Task<bool> ProcessMessageAsync(QueueCommand payload);
    }
}
