﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Core
{
    public class CommandDispatcher : ICommandDispatcher
    {
        private readonly Dictionary<Type, ICommandHandler> _handlers = new Dictionary<Type, ICommandHandler>();
        private readonly Dictionary<string, Type> _commandsByName = new Dictionary<string, Type>();
        // public Container Container { get; private set; }
        /// <summary>
        /// Registers the specified command handler.
        /// </summary>
        public void Register(IEnumerable<ICommandHandler> commandHandlers)
        {
            foreach (var commandHandler in commandHandlers)
            {
                var genericHandler = typeof(ICommandHandler<>);
                var supportedCommandTypes = commandHandler.GetType()
                                                          .GetInterfaces()
                                                          .Where(
                                                              iface =>
                                                              iface.IsGenericType &&
                                                              iface.GetGenericTypeDefinition() == genericHandler)
                                                          .Select(iface => iface.GetGenericArguments()[0])
                                                          .ToList();

                if (_handlers.Keys.Any(supportedCommandTypes.Contains))
                {
                    throw new ArgumentException(
                        "The command handled by the received handler already has a registered handler.");
                }

                // Register this handler for each of he handled types.
                foreach (var commandType in supportedCommandTypes)
                {
                    var customAttributes = commandType.GetCustomAttributes(typeof(QueueCommandAttribute), false);
                    foreach (QueueCommandAttribute attribute in customAttributes)
                    {
                        var key = attribute.CommandName;
                        if (_commandsByName.ContainsKey(key))
                        {
                            throw new ArgumentException("The command name has already ben assgined");
                        }
                        _commandsByName.Add(key, commandType);
                    }

                    _handlers.Add(commandType, commandHandler);
                }
            }
        }

        public Type GetCommandTypeFor(string commandName)
        {
            Type type;
            _commandsByName.TryGetValue(commandName, out type);
            return type;
        }

        /// <summary>
        /// Processes the message by calling the registered handler.
        /// </summary>
        public async Task<bool> ProcessMessageAsync(QueueCommand payload)
        {
            var commandType = payload.GetType();
            ICommandHandler handler;

            if (_handlers.TryGetValue(commandType, out handler))
            {
                await ((Task)((dynamic)handler).HandleCommandAsync((dynamic)payload)).ConfigureAwait(false);
                return true;
            }

            return false;
        }
    }
}
