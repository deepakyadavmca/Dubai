using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Core
{
    public interface ICommandBus
    {
        Task<Tuple<bool, string>> SendAsync<T>(T queueCommand) where T : QueueCommand;
        //int? GetQueueCount();
        Task<long> SendScheduledAsync<T>(T queueCommand, DateTimeOffset scheduleEnqueueTimeUtc) where T : QueueCommand;

        Task CancelScheduleAsync(long sequenceNumber);
    }
}