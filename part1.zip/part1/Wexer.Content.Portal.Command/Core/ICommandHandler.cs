﻿using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Common;

namespace Wexer.Content.Portal.Command.Core
{
    public interface ICommandHandler { } // Helps reflection in CommandDispatcher

    public interface ICommandHandler<in TCommand> : ICommandHandler where TCommand : QueueCommand
    {
        Task HandleCommandAsync(TCommand command);
    }

    public interface ICommandHandler<in TCommand, TResult> : ICommandHandler where TCommand : QueueCommand
    {
        Task<TResult> HandleCommandWithResultAsync(TCommand command);
    }
}
