﻿using System;
using System.IO;
using ProtoBuf;


namespace Wexer.Content.Portal.Command.Common
{
   
        [Serializable]
        public class CommandEnvelope 
        {
            public CommandEnvelope(string commandName, string envelopeId, bool isBackground, bool isIntensive)
            {
                CommandName = commandName;
                EnvelopeId = envelopeId;
                IsBackground = isBackground;
                IsIntensive = isIntensive;
            }

            public CommandEnvelope()
            {

            }

            public string EnvelopeId { get;  set; }
            public bool IsBackground { get;  set; }
            public bool IsIntensive { get;  set; }
            public string CommandName { get;  set; }
            public string ContentType { get;  set; }
            public byte[] Payload { get;  set; }

            public QueueCommand GetPayload(Type commandType)
            {
                if (commandType == null)
                {
                    throw new ArgumentException("Command Type cannot be null");
                }
                if (Payload == null)
                {
                    throw new ArgumentException("Payload cannot be null");
                }
                using (var ms = new MemoryStream(Payload))
                {
                    return Serializer.NonGeneric.Deserialize(commandType, ms) as QueueCommand;
                }
            }

        public void SetPayload<T>(T payload) where T : QueueCommand
        {
            if (payload == null)
            {
                throw new ArgumentException("Payload cannot be null");
            }
            ContentType = @"application/x-protobuf";

            using (var ms = new MemoryStream())
            {
                Serializer.Serialize(ms, payload);

                ms.Seek(0L, SeekOrigin.Begin);
                var buffer = new byte[ms.Length];
                ms.Read(buffer, 0, buffer.Length);
                Payload = buffer;
            }
        }
    }
    
}
