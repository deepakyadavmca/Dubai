﻿using System;

namespace Wexer.Content.Portal.Command.Common
{
    public class QueueCommandAttribute : Attribute
    {
        private readonly string _commandName;

        public QueueCommandAttribute(string commandName)
        {
            _commandName = commandName;
        }

        public string CommandName
        {
            get { return _commandName; }
        }

        public bool IsBackground { get; set; }
        public bool IsIntensive { get; set; }
    }
}
