﻿using ProtoBuf;
namespace Wexer.Content.Portal.Command.Common
{
    [ProtoContract]
    public abstract class QueueCommand
    {
        [ProtoMember(1000)]
        public string AppName { get; set; }
    }
}
