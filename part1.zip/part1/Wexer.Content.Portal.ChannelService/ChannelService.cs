﻿using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Blobs.Repo;

namespace Wexer.Content.Portal.ChannelService
{
    public class ChannelService : IChannelService
    {
        private readonly IBlobRepo _blobRepo;
        private readonly ILogger _logger;

        public ChannelService(IBlobRepo blobRepo, ILoggerFactory loggerFactory)
        {
            _blobRepo = blobRepo;
            _logger = loggerFactory.GetLoggerForClass(this);
        }

        public async Task<Channel> Get(string tag)
        {
            try
            {
                var entities = await _blobRepo.GetSetAsync<Channel>("*").ConfigureAwait(false);
                if (entities != null && entities.Entity != null && entities.Entity.Count > 0)
                {
                    return entities.Entity.Items.FirstOrDefault(t => t.Tag == tag);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Channel[]> List()
        {
            try
            {
                var entities = await _blobRepo.GetSetAsync<Channel>("*").ConfigureAwait(false);
                if (entities != null && entities.Entity != null && entities.Entity.Count > 0)
                {
                    return entities.Entity.Items;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<ReadStoreWriteOperation<EntitySet<Channel>>> Save(Channel entity)
        {
            ReadStoreWriteOperation<EntitySet<Channel>> result = null;
            try
            {
                var entities = await _blobRepo.GetSetAsync<Channel>("*").ConfigureAwait(false);
                if (entities != null && entities.Entity != null && entities.Entity.Count > 0)
                {
                    var newEntities = entities.Entity.Items.Append(entity).ToArray();
                    result = await _blobRepo.PutSetAsync("*", new EntitySet<Channel>
                    {
                        Count = newEntities.Length,
                        Items = newEntities
                    });
                }
                else
                {
                    result = await _blobRepo.PutSetAsync("*", new EntitySet<Channel>
                    {
                        Count = 1,
                        Items = new Channel[] { entity }
                    });
                }
            }
            catch
            {
                return null;
            }
            return result;
        }

        public async Task<bool> SaveMultiple(Channel[] entities)
        {
            ReadStoreWriteOperation<EntitySet<Channel>> result = null;
            try
            {
                result = await _blobRepo.PutSetAsync("*", new EntitySet<Channel>
                {
                    Count = entities.Length,
                    Items = entities
                });
                if (result != null && result.HttpStatusCode == 200)
                {
                    return true;
                }

                return false;
            }
            catch (Exception e)
            {
                _logger.Warn("SaveMultiple exception", "warn", e.ToString());
                return false;
            }
        }

        public async Task<HttpStatusCode> Delete(string tag)
        {
            try
            {
                var entities = await List().ConfigureAwait(false);
                if (entities != null && entities.Length > 0 && entities.Any(t => t.Tag == tag))
                {
                    var entryRemovedList = entities.Where(t => t.Tag != tag).ToArray();

                    var result = await SaveMultiple(entryRemovedList).ConfigureAwait(false);
                    if (result)
                    {
                        return HttpStatusCode.OK;
                    }
                    else
                    {
                        return HttpStatusCode.InternalServerError;
                    }

                }
                return HttpStatusCode.NotFound;
            }
            catch (Exception e)
            {
                return HttpStatusCode.InternalServerError;
            }
        }

        public async Task<HttpStatusCode> Update(Channel channel, string lang)
        {
            try
            {
                var channels = await List().ConfigureAwait(false);
                if (channels != null && channels.Length > 0 && channels.Any(t => t.Tag == channel.Tag))
                {
                    var channelToUpdate = channels.FirstOrDefault(t => t.Tag == channel.Tag);
                    if (channelToUpdate != null)
                    {
                        channelToUpdate.Name = channel.Name;
                        channelToUpdate.Description = channel.Description;
                        channelToUpdate.DisplayName = channel.DisplayName;
                        channelToUpdate.Availability = channel.Availability;
                        channelToUpdate.Active = channel.Active;
                        channelToUpdate.MediaSpaceImageUrl = channel.MediaSpaceImageUrl;
                        channelToUpdate.ProfileImageUrl = channel.ProfileImageUrl;
                        channelToUpdate.Tenants = channel.Tenants;
                        channelToUpdate.Provider = channel.Provider;

                        if (await SaveMultiple(channels).ConfigureAwait(false))
                        {
                            return HttpStatusCode.OK;
                        }
                        else
                        {
                            return HttpStatusCode.InternalServerError;
                        }
                    }
                }
                return HttpStatusCode.NotFound;
            }
            catch (Exception e)
            {
                return HttpStatusCode.InternalServerError;
            }
        }

        public async Task<Tuple<HttpStatusCode, Channel>> Create(ChannelViewModel model, string lang = "en-GB")
        {
            try
            {
                var channelList = await List().ConfigureAwait(false);
                if (channelList != null && channelList.Length > 0
                    && channelList.Any(x => x.Name.InvariantText.ToLowerInvariant() == model.Name.ToLowerInvariant().Trim()))
                {
                    return Tuple.Create(HttpStatusCode.Conflict, default(Channel));
                }


                var tag = Guid.NewGuid().ToString();
                Channel channelToPersist = new Channel();
                channelToPersist.Tag = tag;
                channelToPersist.Name = await CreateLocalisedText(model.Name, lang);
                channelToPersist.DisplayName = await CreateLocalisedText(model.DisplayName, lang);
                channelToPersist.CreatedDate = DateTime.UtcNow;
                channelToPersist.Provider = model.Provider;
                channelToPersist.Description = await CreateLocalisedText(model.Description, lang);
                channelToPersist.Active = model.Active;
                channelToPersist.Availability = model.Availability;
                channelToPersist.ProfileImageUrl = model.ProfileImageUrl;
                channelToPersist.MediaSpaceImageUrl = model.MediaSpaceImageUrl;
                channelToPersist.Tenants = model.Tenants;
                channelToPersist.IsTenantProviderChannel = model.IsTenantProviderChannel;

                var result = await Save(channelToPersist).ConfigureAwait(false);

                if (result != null && result.Entity != null)
                {
                    return Tuple.Create(HttpStatusCode.Created, channelToPersist);
                }

                return Tuple.Create(HttpStatusCode.InternalServerError, default(Channel));
            }
            catch (Exception e)
            {
                _logger.Warn("ChannelService Create Exception", "warn", e.ToString());
                throw e;
            }
        }

        async static Task<LocalisedText> CreateLocalisedText(string text, string ietfTag = "en-GB")
        {
            return new LocalisedText { InvariantText = text, LocalTexts = new[] { new LocalText { IETFTag = ietfTag, Text = text } } };
        }
    }
}
