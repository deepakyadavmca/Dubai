﻿using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using System;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.ReadStore;
using System.Collections.Generic;

namespace Wexer.Content.Portal.ChannelService
{
    public interface IChannelService
    {
        Task<Channel[]> List();
        Task<Channel> Get(string tag);
        Task<ReadStoreWriteOperation<EntitySet<Channel>>> Save(Channel entity);
        Task<HttpStatusCode> Delete(string tag);
        Task<bool> SaveMultiple(Channel[] entities);
        Task<HttpStatusCode> Update(Channel channel, string lang);
        Task<Tuple<HttpStatusCode, Channel>> Create(ChannelViewModel model, string lang = "en-GB");
    }
}
