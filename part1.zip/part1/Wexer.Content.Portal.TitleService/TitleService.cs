﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Tables.Repo;

namespace Wexer.Content.Portal.TitleService
{
    public class TitleService : ITitleService
    {
        private readonly IBlobRepo _blobRepo;
        private readonly IProviderService _providerService;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly ILogger _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        const char Separator = '|';

        public TitleService(IBlobRepo blobRepo, IProviderService providerService, ICmsStoreRepo cmsStore, ILoggerFactory loggerFactory,
            IHttpClientFactory httpClientFactory)
        {
            _blobRepo = blobRepo;
            _providerService = providerService;
            _cmsStore = cmsStore;
            _logger = loggerFactory.GetLoggerForClass(this);
            _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        }
        public async Task<VirtualClass[]> List(string userId, string role)
        {
            try
            {
                var titles = await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);

                if (titles != null && titles.Count() > 0)
                {
                    return titles.Where(x=>x.IsDelete==false).ToArray();
                }
                return new VirtualClass[0];
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task<VirtualClass> Update(VirtualClass title)
        {
            try
            {
                await Task.WhenAll(_cmsStore.StoreAsync(title.Tag, title, "", title.ProviderID)).ConfigureAwait(false);
                var updatedTitle = await _cmsStore.GetAsync<VirtualClass>(title.ProviderID, title.Tag).ConfigureAwait(false);
                return updatedTitle;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<VirtualClass> Get(string providerId, string tag)
        {
            try
            {
                var title = await _cmsStore.GetAsync<VirtualClass>(providerId, tag).ConfigureAwait(false);
                if (title != null)
                {
                    return title;
                }
                return null;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task Publish(VirtualClass title, string tenant, string commandType = null)
        {
            try
            {
                List<VirtualClass> finalBlobSet = new List<VirtualClass>();
                var sp = Stopwatch.StartNew();
                var tenantBlobSet = await _blobRepo.GetSetAsync<VirtualClass>(tenant).ConfigureAwait(false);
                _logger.Info($"Publish begin to Tenant:{tenant} for ClassTag:{title.Tag}");
                if(commandType != null && commandType == "autopublish")
                {
                    title.Status = MediaProcessingStatus.Published;
                }

                title.PublishedDate = DateTime.UtcNow;
                if (tenantBlobSet != null && tenantBlobSet.IsSuccessStatusCode && tenantBlobSet.Entity != null && tenantBlobSet.Entity.Count > 0)
                {
                    var titleSet = tenantBlobSet.Entity.Items.ToList();
                    if (titleSet.Any(x => x.Tag == title.Tag))
                    {
                        titleSet.RemoveAll(x => x.Tag == title.Tag);
                        titleSet.Add(title);
                        finalBlobSet = titleSet;
                    }
                    else
                    {
                        titleSet.Add(title);
                        finalBlobSet = titleSet;
                    }
                }
                else
                {
                    finalBlobSet = new List<VirtualClass> { title };
                }

                var result = await _blobRepo.PutSetAsync(tenant,
                            new EntitySet<VirtualClass>
                            {
                                Count = finalBlobSet.Count,
                                Items = finalBlobSet.ToArray()
                            }).ConfigureAwait(false);

                await UpdateTitlesMetadata(tenant).ConfigureAwait(false);

                sp.Stop();
                _logger.Info($"Publish end to Tenant:{tenant} for ClassTag:{title.Tag} Count:{finalBlobSet.Count} TimeTaken:{sp.Elapsed}");
            }
            catch (Exception e)
            {
                _logger.Warn($"Title publish exception Tenant:{tenant} for ClassTag:{title.Tag}", "warn", e.ToString());
                throw e;
            }

        }

        public async Task<HttpStatusCode> UpdateIndexes(string tenant, string baseUrl)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.TryAddWithoutValidation("Authentication", "1234123412341234:YLUiMnAzJryhooinTcXM5ZUBhj4=");
                client.DefaultRequestHeaders.TryAddWithoutValidation("TimeStamp", "11 January 2016 16:30:24");
                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                var response = await client.PutAsync($"admin/api/virtualclass/indexTitles/{tenant}", new StringContent(tenant, Encoding.UTF8, "application/json")).ConfigureAwait(false);
                _logger.Info($"UpdateIndexes for {tenant} response {response.StatusCode}");
                return response.StatusCode;
            }
            catch (Exception e)
            {
                _logger.Warn("UpdateIndexes exception", "warn", e.ToString());
                throw e;
            }
        }

        public async Task<HttpStatusCode> BustChannelCachePlatform(string tenantId, string baseUrl)
        {
            try
            {
                HttpStatusCode responseCode;
                ClientApplication clientApp = null;
                var clientAppStorage = await _blobRepo.GetSetAsync<ClientApplication>("*").ConfigureAwait(false);

                if (clientAppStorage != null && clientAppStorage.IsSuccessStatusCode && clientAppStorage.Entity != null && clientAppStorage.Entity.Count > 0 && clientAppStorage.Entity.Items != null)
                {
                    clientApp = clientAppStorage.Entity.Items.Where(x => x.ApplicationName.ToLowerInvariant() == "smoke test").FirstOrDefault();
                    if (clientApp != null && !string.IsNullOrWhiteSpace(clientApp.AppKey) && !string.IsNullOrWhiteSpace(clientApp.AppSecret))
                    {
                        var client = _httpClientFactory.CreateClient();
                        client.BaseAddress = new Uri(baseUrl);
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", string.Format("Basic {0}", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientApp.AppKey}:{clientApp.AppSecret}"))));
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                        var response = await client.DeleteAsync($"api/v1/channels/cache/{tenantId}").ConfigureAwait(false);

                        responseCode = response.StatusCode;
                        _logger.Info($"BustChannelCachePlatform for {tenantId} response {responseCode}");
                    }
                    else
                    {
                        _logger.Info("BustChannelCachePlatform no smoke key found");
                        responseCode = HttpStatusCode.BadRequest;
                    }
                }
                else
                {
                    _logger.Info("BustChannelCachePlatform no clientapp found");
                    responseCode = HttpStatusCode.BadRequest;
                }

                return responseCode;
            }
            catch (Exception e)
            {
                _logger.Warn("BustChannelCachePlatform exception", "warn", e.ToString());
                throw e;
            }
        }

        public async Task<HttpStatusCode> BustCachePortal(string baseUrl, string key)
        {
            try
            {
                HttpStatusCode responseCode;
                ClientApplication clientApp = null;
                var clientAppStorage = await _blobRepo.GetSetAsync<ClientApplication>("*").ConfigureAwait(false);

                if (clientAppStorage != null && clientAppStorage.IsSuccessStatusCode && clientAppStorage.Entity != null && clientAppStorage.Entity.Count > 0 && clientAppStorage.Entity.Items != null)
                {
                    clientApp = clientAppStorage.Entity.Items.Where(x => x.ApplicationName.ToLowerInvariant() == "smoke test").FirstOrDefault();
                    if (clientApp != null && !string.IsNullOrWhiteSpace(clientApp.AppKey) && !string.IsNullOrWhiteSpace(clientApp.AppSecret))
                    {
                        var client = _httpClientFactory.CreateClient();
                        client.BaseAddress = new Uri(baseUrl);
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", string.Format("Basic {0}", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientApp.AppKey}:{clientApp.AppSecret}"))));
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                        var response = await client.DeleteAsync($"api/v1/titles/cache/{key}").ConfigureAwait(false);

                        responseCode = response.StatusCode;
                        _logger.Info($"TitleService > BustCachePortal for key: {key}, response: {responseCode}");
                    }
                    else
                    {
                        _logger.Info("TitleService > BustCachePortal no smoke key found");
                        responseCode = HttpStatusCode.BadRequest;
                    }
                }
                else
                {
                    _logger.Info("TitleService > BustCachePortal no clientapp found");
                    responseCode = HttpStatusCode.BadRequest;
                }

                return responseCode;
            }
            catch (Exception e)
            {
                _logger.Warn("TitleService > BustCachePortal exception", "warn", e.ToString());
                throw e;
            }
        }

        public async Task MigrateTitleProvider(VirtualClassViewModel titleToUpdate)
        {
            try
            {
                var title = await Get(titleToUpdate.SourceProviderId, titleToUpdate.Tag).ConfigureAwait(false);
                if (title != null)
                {
                    var deleteOperation = await _cmsStore.DeleteAsync<VirtualClass>(titleToUpdate.SourceProviderId, titleToUpdate.Tag).ConfigureAwait(false);
                    if (deleteOperation.IsSuccessStatusCode)
                    {
                        await _cmsStore.StoreAsync(title.Tag, title, "", titleToUpdate.ProviderID).ConfigureAwait(false);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task PublishBulk(List<VirtualClass> titles, string tenant)
        {
            try
            {
                if (titles != null && titles.Count > 0 && !string.IsNullOrEmpty(tenant))
                {

                    List<VirtualClass> finalBlobSet = new List<VirtualClass>();
                    var sp = Stopwatch.StartNew();
                    var tenantBlobSet = await _blobRepo.GetSetAsync<VirtualClass>(tenant).ConfigureAwait(false);
                    _logger.Info($"PublishBulk begin for Tenant:{tenant}");
                    if (tenantBlobSet != null && tenantBlobSet.IsSuccessStatusCode && tenantBlobSet.Entity != null && tenantBlobSet.Entity.Count > 0)
                    {
                        var tenantTitles = tenantBlobSet.Entity.Items.ToList();
                        foreach (var title in titles)
                        {
                            title.PublishedDate = DateTime.UtcNow;

                            if (tenantTitles.Any(x => x.Tag == title.Tag))
                            {
                                tenantTitles.RemoveAll(x => x.Tag == title.Tag);
                                tenantTitles.Add(title);
                                finalBlobSet = tenantTitles;
                            }
                            else
                            {
                                tenantTitles.Add(title);
                                finalBlobSet = tenantTitles;
                            }
                        }
                    }
                    else
                    {
                        foreach (var title in titles)
                        {
                            title.PublishedDate = DateTime.UtcNow;
                        }
                        finalBlobSet = titles;
                    }

                    var result = await _blobRepo.PutSetAsync(tenant,
                                new Models.EntitySet<VirtualClass>
                                {
                                    Count = finalBlobSet.Count,
                                    Items = finalBlobSet.ToArray()
                                }).ConfigureAwait(false);

                    await UpdateTitlesMetadata(tenant).ConfigureAwait(false);

                    sp.Stop();
                    _logger.Info($"PublishBulk end for Tenant:{tenant} Count:{finalBlobSet.Count} TimeTaken:{sp.Elapsed}");

                }
            }
            catch (Exception e)
            {
                _logger.Warn("PublishBulk exception", "warn", e.ToString());
                throw e;
            }
        }


        public async Task UnPublishBulk(List<VirtualClass> titles, string tenant)
        {
            try
            {
                if (titles != null && titles.Count > 0 && !string.IsNullOrEmpty(tenant))
                {

                    List<VirtualClass> finalBlobSet = new List<VirtualClass>();
                    var sp = Stopwatch.StartNew();
                    var tenantBlobSet = await _blobRepo.GetSetAsync<VirtualClass>(tenant).ConfigureAwait(false);
                    _logger.Info($"UnPublishBulk begin for Tenant:{tenant}");
                    if (tenantBlobSet != null && tenantBlobSet.IsSuccessStatusCode && tenantBlobSet.Entity != null && tenantBlobSet.Entity.Count > 0)
                    {
                        finalBlobSet = tenantBlobSet.Entity.Items.Where(x => !titles.Any(t => t.Tag == x.Tag)).ToList();

                        var result = await _blobRepo.PutSetAsync(tenant,
                            new EntitySet<VirtualClass>
                            {
                                Count = finalBlobSet.Count,
                                Items = finalBlobSet.ToArray()
                            }).ConfigureAwait(false);

                        await UpdateTitlesMetadata(tenant).ConfigureAwait(false);

                        sp.Stop();
                        _logger.Info($"UnPublishBulk end for Tenant:{tenant} Count:{finalBlobSet.Count} TimeTaken:{sp.Elapsed}");

                    }
                }
            }
            catch (Exception e)
            {
                _logger.Warn("UnPublishBulk exception", "warn", e.ToString());
                throw e;
            }
        }

        public async Task<TitlesMetadata> UpdateTitlesMetadata(string tenant)
        {
            try
            {
                _logger.Info($"UpdateTitlesMetadata begin for {tenant}");
                TitlesMetadata metadata = new TitlesMetadata();
                var titlesSet = await _blobRepo.GetSetAsync<VirtualClass>(tenant).ConfigureAwait(false);
                var masterMetadata = await _blobRepo.GetAsync<TitlesMetadata>("*").ConfigureAwait(false);

                if (titlesSet != null && titlesSet.IsSuccessStatusCode && titlesSet.Entity != null && titlesSet.Entity.Items.Length > 0)
                {
                    var titles = titlesSet.Entity.Items.ToList();

                    metadata.Categories = titles.GroupBy(x => x.ClassCategoryId).Select(x => new Category
                    {
                        Id = x.Key,
                        Description = masterMetadata.Entity.Categories.Where(t => t.Id == x.Key) != null ? masterMetadata.Entity.Categories.Where(t => t.Id == x.Key).Select(t => t.Description).FirstOrDefault() : new LocalisedText(""),
                        Name = titles.Where(h => h.ClassCategoryId == x.Key).Select(h => h.ClassCategories.InvariantText).FirstOrDefault(),
                        Subcategory = titles.Where(h => h.ClassSubCategory != null && h.ClassCategoryId == x.Key)
                                        .Select(h => h.ClassSubCategory).Distinct(new LocalizedTextComparer()).ToList()
                    }).ToList();

                    var equipments = titles.Where(x => x.Equipments != null).SelectMany(x => x.Equipments.InvariantText.Split(Separator));
                    metadata.Equipments = (from t in equipments
                                           join m in masterMetadata.Entity.Equipments
                                           on t equals m.Name.InvariantText
                                           select m).GroupBy(x => x.TypeTag).Select(x => x.First()).ToList();

                    var focusAreas = titles.Where(x => x.FocusArea != null).SelectMany(x => x.FocusArea.InvariantText.Split(Separator));
                    metadata.FocusAreas = (from t in focusAreas
                                           join m in masterMetadata.Entity.FocusAreas
                                           on t equals m.Name.InvariantText
                                           select m).GroupBy(x => x.Tag).Select(x => x.First()).ToList();

                    metadata.Language = (from m in masterMetadata.Entity.Language
                                         join t in titles
                                         on m.IETFTag equals t.ClassLanguageCode
                                         select m).Distinct().ToList();

                    metadata.Providers = titles.Select(x => x.Provider).Distinct().ToList();

                    metadata.Intensity = titles.Select(x => x.Intensity).Distinct().ToList();
                    metadata.SkillLevel = titles.Select(x => x.Skill).Distinct().ToList();
                    int maxDuration = 90;
                    maxDuration = titles.Max(x => x.DurationSecond) / 60;
                    metadata.Duration = new List<int> { 1, maxDuration };

                    var result = await _blobRepo.PutAsync(tenant, metadata).ConfigureAwait(false);
                }
                else
                {
                    _logger.Info($"UpdateTitlesMetadata No classes for Tenant:{tenant}");
                }

                _logger.Info($"UpdateTitlesMetadata end for {tenant}");
                return metadata;
            }
            catch (Exception e)
            {
                _logger.Warn("UpdateTitlesMetadata exception", "warn", e.ToString());
                throw e;
            }
        }


        public async Task<VirtualClass> ModifyTitle(VirtualClassViewModel title, VirtualClass existingTitle, string lang, string operation, TitleSource source = TitleSource.Normal)
        {
            try
            {
                if (title.Skill >= 1 && title.Skill <= 4)
                {
                    existingTitle.Level = "Beginner";
                }
                else if (title.Skill >= 5 && title.Skill <= 7)
                {
                    existingTitle.Level = "Intermediate";
                }
                else
                {
                    existingTitle.Level = "Advanced";
                }


                if (!string.IsNullOrEmpty(title.ClassName))
                {
                    await UpdateLocalisedText(existingTitle.ClassName, title.ClassName, lang);
                }
                else
                {
                    existingTitle.ClassName = await CreateLocalisedText(title.ClassName, lang);
                }

                if (!string.IsNullOrEmpty(title.ClassDescription) && !string.IsNullOrEmpty(existingTitle.ClassDescription))
                {
                    await UpdateLocalisedText(existingTitle.ClassDescription, title.ClassDescription, lang);
                }
                else
                {
                    existingTitle.ClassDescription = await CreateLocalisedText(title.ClassDescription, lang);
                }

                if (title.ClassCategory != null)
                {
                    if (!String.IsNullOrEmpty(existingTitle.ClassCategories))
                    {
                        await UpdateLocalisedText(existingTitle.ClassCategories, title.ClassCategory, lang);
                    }
                    else
                    {
                        existingTitle.ClassCategories = await CreateLocalisedText(title.ClassCategory, lang);
                    }
                }

                if (title.ClassCategoryId != 0 && !string.IsNullOrWhiteSpace(title.ClassCategoryId.ToString()))
                {
                    existingTitle.ClassCategoryId = title.ClassCategoryId;
                }

                if (!string.IsNullOrEmpty(title.ClassSubCategory))
                {
                    if (!string.IsNullOrEmpty(existingTitle.ClassSubCategory))
                    {
                        await UpdateLocalisedText(existingTitle.ClassSubCategory, title.ClassSubCategory, lang);
                    }
                    else
                    {
                        existingTitle.ClassSubCategory = await CreateLocalisedText(title.ClassSubCategory, lang);
                    }
                }
                else
                {
                    existingTitle.ClassSubCategory = title.ClassSubCategory;
                }

                if (title.Equipments != null && title.Equipments.Length > 0)
                {
                    if (!String.IsNullOrEmpty(existingTitle.Equipments))
                    {
                        await UpdateLocalisedText(existingTitle.Equipments, string.Join(Separator, title.Equipments), lang);
                    }
                    else
                    {
                        existingTitle.Equipments = await CreateLocalisedText(string.Join(Separator, title.Equipments), lang);
                    }
                    existingTitle.IsEquipment = true;
                }
                else
                {
                    existingTitle.Equipments = title.Equipments != null ? string.Join(Separator, title.Equipments) : string.Empty;
                    existingTitle.IsEquipment = false;
                }

                if (existingTitle.ClassLanguageCode != null)
                {
                    existingTitle.ClassLanguage = GetLanguageNameByLanguagCode(title.ClassLanguageCode);
                }
                if (!string.IsNullOrEmpty(title.Keywords))
                {
                    if (!string.IsNullOrEmpty(existingTitle.Keywords))
                    {
                        await UpdateLocalisedText(existingTitle.Keywords, title.Keywords, lang);
                    }
                    else
                    {
                        existingTitle.Keywords = await CreateLocalisedText(title.Keywords, lang);
                    }
                }

                if (title.FocusArea != null && title.FocusArea.Length > 0)
                {
                    if (!String.IsNullOrEmpty(existingTitle.FocusArea))
                    {
                        await UpdateLocalisedText(existingTitle.FocusArea, string.Join(Separator, title.FocusArea), lang);
                    }
                    else
                    {
                        existingTitle.FocusArea = await CreateLocalisedText(string.Join(Separator, title.FocusArea), lang);
                    }
                }
                else
                {
                    existingTitle.FocusArea = title.FocusArea != null ? string.Join(Separator, title.FocusArea) : string.Empty;
                }

                existingTitle.Labels = title.Labels;
                existingTitle.Provider = title.Provider;
                existingTitle.ProviderID = title.ProviderID;
                //existingTitle.ProviderType = title.ProviderType;
                existingTitle.ClassLanguage = title.ClassLanguage;
                existingTitle.LastModifiedDate = DateTime.UtcNow;
                existingTitle.ImageLink = title.ImageLink;
                existingTitle.StreamingLink = existingTitle.Status == MediaProcessingStatus.Incomplete ? title.StreamingLink : existingTitle.StreamingLink;
                existingTitle.AlternateLink = existingTitle.Status == MediaProcessingStatus.Incomplete ? title.AlternateLink : existingTitle.AlternateLink;
                existingTitle.StartDate = title.StartDate;
                existingTitle.EndDate = title.EndDate;
                existingTitle.ScheduleDate = title.ScheduleDate;
                existingTitle.IsEquipment = title.IsEquipment;
                existingTitle.FileName = existingTitle.Status == MediaProcessingStatus.Incomplete ? title.FileName : existingTitle.FileName;
                existingTitle.ChannelId = title.ChannelId;
                existingTitle.Instructor = title.Instructor;
                existingTitle.TrailerLinkMobile = existingTitle.Status == MediaProcessingStatus.Incomplete ? title.TrailerLinkMobile : existingTitle.TrailerLinkMobile;
                existingTitle.TrailerLinkWeb = existingTitle.Status == MediaProcessingStatus.Incomplete ? title.TrailerLinkWeb : existingTitle.TrailerLinkWeb;
                existingTitle.TrailerName = existingTitle.Status == MediaProcessingStatus.Incomplete ? title.TrailerName : existingTitle.TrailerName;

                existingTitle.Skill = title.Skill;
                existingTitle.Intensity = title.Intensity;
                existingTitle.EquipmentTypeTags = title.EquipmentTypeTags;
                existingTitle.FocusAreaTags = title.FocusAreaTags;
                existingTitle.ClassLanguageCode = title.ClassLanguageCode;


                if (operation == "save")
                {
                    if(source == TitleSource.Event)
                    {
                        existingTitle.Status = MediaProcessingStatus.Complete;
                    }
                    else
                    {
                        existingTitle.Status = MediaProcessingStatus.Unpublished;
                    }
                }
                else
                {
                    existingTitle.Status = MediaProcessingStatus.Published;
                }

                return existingTitle;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        async static Task<LocalisedText> CreateLocalisedText(string text, string ietfTag = "en-GB")
        {
            return new LocalisedText { InvariantText = text, LocalTexts = new[] { new LocalText { IETFTag = ietfTag, Text = text } } };
        }

        async static Task UpdateLocalisedText(LocalisedText localisedText, string changedText, string ietfTag = "en-GB")
        {
            if (localisedText != null)
            {
                if (localisedText.LocalTexts == null)
                {
                    localisedText.LocalTexts = new[] { new LocalText { Text = changedText, IETFTag = ietfTag } };
                }
                else
                {
                    var localTextList = localisedText.LocalTexts.ToList();
                    var currentCultureText = localTextList.FirstOrDefault(t => t.IETFTag == ietfTag);
                    if (currentCultureText != null)
                    {
                        currentCultureText.Text = changedText;
                    }
                    else
                    {
                        localTextList.Add(new LocalText { IETFTag = ietfTag, Text = changedText });
                    }
                    localisedText.LocalTexts = localTextList.ToArray();
                }
                if (ietfTag == "en-GB")
                {
                    localisedText.InvariantText = changedText;
                }
            }
        }

        private string GetLanguageNameByLanguagCode(string languageCode)
        {
            try
            {
                var languagueDictionary = GetLanguageDictionary();

                if (languagueDictionary.ContainsKey(languageCode))
                {
                    return languagueDictionary[languageCode].ToString();
                }
                else
                {
                    return "English";
                }
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        private Dictionary<string, string> GetLanguageDictionary()
        {
            return new Dictionary<string, string> {
                { "en", "English" },
                { "ar", "Arabic" },
                {"as","Assamese"},
                {"my","Burmese"},
                {"da","Danish"},
                {"de","German"},
                {"nl","Dutch"},
                {"el","Greek"},
                {"eo","Esperanto"},
                {"fa","Persian"},
                {"fj","Fijian"},
                {"fi","Finnish"},
                {"fr","French"},
                {"he","Hebrew"},
                {"hi","Hindi"},
                {"hu","Hungarian"},
                {"id","Indonesian"},
                {"it","Italian"},
                {"ja","Japanese"},
                {"th","Thai"},
                {"zh","Chinese"},
                {"es", "Spanish" },
                {"pl", "Polish" },
                { "no", "Norwegian"}
            };
        }
    }

    public class LocalizedTextComparer : IEqualityComparer<LocalisedText>
    {
        public bool Equals([AllowNull] LocalisedText x, [AllowNull] LocalisedText y)
        {
            try
            {
                if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
                {
                    return false;
                }


                if (Object.ReferenceEquals(x, y))
                {
                    return true;
                }

                if (x.InvariantText == y.InvariantText)
                {
                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        public int GetHashCode([DisallowNull] LocalisedText obj)
        {
            try
            {
                if (Object.ReferenceEquals(obj, null)) return 0;

                int hashInvariantText = string.IsNullOrEmpty(obj.InvariantText) ? 0 : obj.InvariantText.GetHashCode();

                return hashInvariantText;
            }
            catch (Exception e)
            {
                throw e;
            }

        }
    }


}
