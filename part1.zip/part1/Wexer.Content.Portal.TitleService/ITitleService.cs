﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.VirtualClasses;

namespace Wexer.Content.Portal.TitleService
{
    public interface ITitleService
    {
        Task<VirtualClass[]> List(string userId, string role);
        Task<VirtualClass> Update(VirtualClass title);
        Task<VirtualClass> Get(string providerId, string tag);

        Task Publish(VirtualClass title, string tenant, string commandType = null);
        Task<HttpStatusCode> UpdateIndexes(string tenant, string baseUrl);

        Task MigrateTitleProvider(VirtualClassViewModel titleToUpdate);

        Task PublishBulk(List<VirtualClass> titles, string tenant);

        Task UnPublishBulk(List<VirtualClass> titles, string tenant);

        Task<HttpStatusCode> BustChannelCachePlatform(string tenantId, string baseUrl);

        Task<HttpStatusCode> BustCachePortal(string baseUrl, string key);

        Task<TitlesMetadata> UpdateTitlesMetadata(string tenant);

        Task<VirtualClass> ModifyTitle(VirtualClassViewModel title, VirtualClass existingTitle, string lang, string operation, TitleSource source = TitleSource.Normal);
    }
}
