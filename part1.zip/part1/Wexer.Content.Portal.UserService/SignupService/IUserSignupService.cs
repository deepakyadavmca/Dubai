﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.ContentPortal;

namespace Wexer.Content.Portal.UserService.SignupService
{
    public interface IUserSignupService
    {
        Task<string> CreatePortalUserIndexAsync(PortalUser user, string tenantid);
    }
}
