﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Tables.Repo;

namespace Wexer.Content.Portal.UserService.SignupService
{
    public class UserSignupService : IUserSignupService
    {
        private readonly ILogger _logger;
        private readonly IUserBlobRepo _userBlobRepo;
        private readonly ITableRepo _tableRepo;
        public UserSignupService(ILoggerFactory loggerFactory, IUserBlobRepo userBlobRepo, ITableRepo tableRepo)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _userBlobRepo = userBlobRepo;
            _tableRepo = tableRepo;
        }

        public async Task<string> CreatePortalUserIndexAsync(PortalUser user, string tenantid)
        {
            try
            {
                var email = user.Email;
                var displayName = user.DisplayName;

                //Create email index
                if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(tenantid) && !string.IsNullOrEmpty(displayName))
                {
                    var portalUserIndex = new PortalUserIndex()
                    {
                        Email = user.Email,
                        UserIdentifier = user.UId,
                        TenantId = tenantid,
                        Contact = user.Contact,
                        PhoneNumber = user.PhoneNumber,
                        DisplayName = user.DisplayName
                    };
                    var portalUserIndexResult = await _tableRepo.StoreAsync(portalUserIndex).ConfigureAwait(false);
                    if (portalUserIndexResult != null && portalUserIndexResult.IsSuccessStatusCode && portalUserIndexResult.Entity != null)
                    {
                        return portalUserIndex.UserIdentifier;
                    }
                }

                return null;
            }
            catch
            {
                _logger.Warn("Store user email index failed", "PortalUserIndex", user.UId);
                return null;
            }

        }
    }
}
