﻿using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.MembershipData;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.Models.User;
using Wexer.Content.Portal.Models.User.Profiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Tables.Repo;

namespace Wexer.Content.Portal.UserService
{
    public class UserService : IUserService
    {
        private readonly ITableRepo _tableRepo;
        private readonly IUserBlobRepo _userBlobRepo;
        private readonly IBlobRepo _blobRepo;

        public UserService(ITableRepo tableRepo, IUserBlobRepo userBlob, IBlobRepo blobRepo)
        {
            _tableRepo = tableRepo;
            _userBlobRepo = userBlob;
            _blobRepo = blobRepo;
        }
        public async Task<bool> DeleteUserForTenant(string tenantid, UserDetail existingUser)
        {
            try
            {
                var user = await CheckUserEmailIndexTenantIdAsync(existingUser.EmailAddress, tenantid).ConfigureAwait(false);
                if(user != null)
                {
                    
                        var userDetailResult = await _userBlobRepo.DeleteSetAsync<UserDetail>(existingUser.UserId).ConfigureAwait(false);
                        if(userDetailResult == HttpStatusCode.OK)
                        {
                            await DeleteTenantUserEmailIndex(existingUser.EmailAddress, tenantid).ConfigureAwait(false);
                            return true;
                        }
                    
                    return false;
                }
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public async Task<PortalUserIndex> CheckUserEmailIndexTenantIdAsync(string emailAddress, string tenantid)
        {
            PortalUserIndex tenantuserEmailIndexes = null;
            try
            {
                //var lowerCaseEmail = emailAddress.ToLowerInvariant().Trim();
                tenantuserEmailIndexes = await _tableRepo.GetAsync<PortalUserIndex>(tenantid, emailAddress).ConfigureAwait(false);

                if (tenantuserEmailIndexes == null)
                {
                    return null;
                }
            }
            catch (Exception)
            {
            }
            return tenantuserEmailIndexes;
        }

        public async Task DeleteTenantUserEmailIndex(string existingUserEmailIndexEmail, string tenantId)
        {
            try
            {
                await _tableRepo.DeleteAsync<PortalUserIndex>(tenantId, existingUserEmailIndexEmail).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<TenantDetail> GetTenant(string tenantId)
        {
            try
            {
                var tenants = await _blobRepo.GetSetAsync<TenantDetail>("*").ConfigureAwait(false);
                if(tenants != null && tenants.Entity != null && tenants.Entity.Count > 0)
                {
                    return tenants.Entity.Items.FirstOrDefault(t => t.TenantID == tenantId);
                }
                return null;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task<TenantDetail[]> GetTenants()
        {
            try
            {
                var tenants = await _blobRepo.GetSetAsync<TenantDetail>("*").ConfigureAwait(false);
                if (tenants != null && tenants.Entity != null && tenants.Entity.Count > 0)
                {
                    return tenants.Entity.Items;
                }
                return null;
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}
