﻿using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.MembershipData;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.Models.User;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.UserService
{
    public interface IUserService
    {

        Task<bool> DeleteUserForTenant(string tenantid, UserDetail existingUser);
        Task<PortalUserIndex> CheckUserEmailIndexTenantIdAsync(string emailAddress, string tenantid);
        Task DeleteTenantUserEmailIndex(string existingUserEmailIndexEmail, string tenantId);
        Task<TenantDetail> GetTenant(string tenantId);
        Task<TenantDetail[]> GetTenants();
    }
}
