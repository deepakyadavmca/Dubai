using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class Language
    {
        /// <summary>
        /// IETF language tag
        /// </summary>
        [ProtoMember(1)]
        public string IETFTag { get; set; }

        [ProtoMember(2)]
        public string DisplayName { get; set; }
    }
}