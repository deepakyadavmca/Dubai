﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Settings
{
    [ProtoContract]
    public class RunKeeperSettings
    {
        [ProtoMember(1)]
        public bool IsEnabled { get; set; }
        [ProtoMember(2)]
        public string ClientId { get; set; }
        [ProtoMember(3)]
        public string ClientSecret { get; set; }
        [ProtoMember(4)]
        public LocalisedText Description { get; set; }
    }
}
