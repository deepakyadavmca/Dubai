using ProtoBuf;

namespace Wexer.Content.Portal.Models.Settings
{
    [ProtoContract]
    public class FitBitSettings
    {
        [ProtoMember(1)]
        public bool IsEnabled { get; set; }
        [ProtoMember(2)]
        public string ConsumerKey { get; set; }
        [ProtoMember(3)]
        public string ConsumerSecret { get; set; }
        [ProtoMember(4)]
        public LocalisedText Description { get; set; }
    }
}