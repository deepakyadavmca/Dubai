using ProtoBuf;

namespace Wexer.Content.Portal.Models.Settings
{
    [ProtoContract]
    public class ConnectedAppSettings
    {
        [ProtoMember(1)]
        public FacebookSettings FacebookSettings { get; set; }
        [ProtoMember(2)]
        public FitBitSettings FitBitSettings { get; set; }
        [ProtoMember(3)]
        public RunKeeperSettings RunKeeperSettings { get; set; }
    }
}