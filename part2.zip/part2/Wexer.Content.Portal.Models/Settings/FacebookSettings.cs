using ProtoBuf;

namespace Wexer.Content.Portal.Models.Settings
{
    [ProtoContract]
    public class FacebookSettings
    {
        [ProtoMember(1)]
        public bool IsEnabled { get; set; }
        [ProtoMember(2)]
        public string AppId { get; set; }
        [ProtoMember(3)]
        public string AppSecret { get; set; }
        [ProtoMember(4)]
        public LocalisedText Description { get; set; }
    }
}