using System;
using System.Collections.Generic;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class Range
    {
        [ProtoMember(1)]
        public decimal Min { get; set; }
        [ProtoMember(2)]
        public decimal Max { get; set; }
        [ProtoMember(3)]
        public decimal[] Steps { get; set; }

        public static Range Parse(string range)
        {
            var steps = new List<decimal>();

            if (string.IsNullOrEmpty(range))
            {
                return new Range { Steps = steps.ToArray() };
            }

            int stepSize = 1;
            var stepTokens = range.Split(new[] {'/'}, StringSplitOptions.RemoveEmptyEntries);
            if (stepTokens.Length >= 1)
            {
                range = stepTokens[0];
                if (stepTokens.Length > 1)
                {
                    stepSize = int.Parse(stepTokens[1]);
                }
            }

            var rangeTokens = range.Split(new[] {'-'}, StringSplitOptions.RemoveEmptyEntries);
            if (rangeTokens.Length != 2)
            {
                return new Range { Steps = steps.ToArray() };
            }

            decimal min; 
            decimal max;

            decimal.TryParse(rangeTokens[0], out min);
            decimal.TryParse(rangeTokens[1], out max);

            var noOfSteps = (max - min) / stepSize;
            for (var i = 1; i <= noOfSteps; i++)
            {
                steps.Add(stepSize);
            }

            return new Range { Min = min, Max = max, Steps = steps.ToArray() };
        }
    }
}