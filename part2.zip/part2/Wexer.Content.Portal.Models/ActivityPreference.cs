﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum ActivityPreference: byte
    {
        [ProtoEnum(Name = "Both", Value = 10)]
        Both = 10, // No Equipment 

        [ProtoEnum(Name = "Gym workouts", Value = 20)]
        GymWorkouts = 20, // No Equipment 

        [ProtoEnum(Name = "Gym classes", Value = 30)]
        GymClasses = 30, // No Equipment 
    }
}
