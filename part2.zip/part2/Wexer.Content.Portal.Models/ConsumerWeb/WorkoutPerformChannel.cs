﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ConsumerWeb
{
    public enum WorkoutPerformChannel
    {
        None=0,
        Web = 1,
        AppleTv = 2,
        AndroidTv = 3,
        AndroidSdk = 4,
        iOSSdk = 5,
        iOSApp = 6,
        AndroidApp = 7,
        LiveStream = 9,
        Channel = 10,
        API = 11
    }
}