﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ConsumerWeb
{
    [ProtoContract]
    public class UserWorkoutPerform : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string ContentTag { get; set; }

        [ProtoMember(3)]
        public WorkoutContentType ContentType { get; set; }

        [ProtoMember(4)]
        public WorkoutPerformChannel Channel { get; set; }

        [ProtoMember(5)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime RequestedDateTimeUtc { get; set; }

        [ProtoMember(6)]
        public string SubscriptionTag { get; set; }

        public string PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        public string RowKey
        {
            get
            {
                return RequestedDateTimeUtc.ToString("yyyyMMddHHmmss");
            }
        }
    }
}
