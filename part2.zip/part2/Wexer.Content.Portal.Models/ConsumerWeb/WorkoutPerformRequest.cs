﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ConsumerWeb
{
    public class WorkoutPerformRequest
    {
        public WorkoutPerformChannel Channel { get; set; }
        public WorkoutContentType ContentType { get; set; }
        public string SubscriptionTag { get; set; }
    }
}
