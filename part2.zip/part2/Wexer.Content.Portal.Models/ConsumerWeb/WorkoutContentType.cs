﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ConsumerWeb
{
    public enum WorkoutContentType
    {
        None=0,
        OnDemand = 1,
        Workout = 2,
        Plan = 3,
        Challenge = 4
    }
}