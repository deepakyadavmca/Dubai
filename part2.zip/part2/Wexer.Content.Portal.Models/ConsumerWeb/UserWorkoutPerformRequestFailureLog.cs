﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ConsumerWeb
{
    [ProtoContract]
    public class UserWorkoutPerformRequestFailureLog : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string EmailAddress { get; set; }

        public string PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        public string RowKey
        {
            get
            {
                return DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            }
        }
    }
}
