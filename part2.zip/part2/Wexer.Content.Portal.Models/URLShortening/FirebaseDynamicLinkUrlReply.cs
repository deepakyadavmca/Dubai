﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.URLShortening
{
    public class FirebaseDynamicLinkUrlReply
    {
        public string shortLink { get; set; }
        public string previewLink { get; set; }
        public FirebaseDynamicLinkUrlReplyWarnings[] Warnings { get; set; }

    }


    public class FirebaseDynamicLinkUrlReplyWarnings
    {
        public string warningCode { get; set; }
        public string warningMessage { get; set; }
    }
}