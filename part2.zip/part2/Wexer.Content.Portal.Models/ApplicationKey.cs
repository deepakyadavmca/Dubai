﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class ApplicationKey
    {
        [ProtoMember(1)]
        public string NewKey { get; set; }
    }
}