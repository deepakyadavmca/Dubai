﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Referral
{
    public enum ReferralStatus
    {
        Processed,
        Pending,
        Abandoned
    }

    public enum ReferralPaymentType
    {
        PayOut,
        Discount
       
    }


    public static class ConstantValues
    {
        public const string RefundStripeStatus_success = "succeeded";
        public const string SubscriptionStatus_active = "active";
        public const string PlanMetadataKey_ReferralAmount = "ReferralAmount";
    }
   
}
