﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Referral
{
    [ProtoContract]
    public class ReferralLookUp : IStorageKey
    {
        [ProtoMember(1)]
        public string ReferralCode { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return ReferralCode.ToUpperInvariant();
            }
        }
        string IStorageKey.RowKey
        {
            get { return ReferralCode.ToUpperInvariant(); }
        }
    }
}
