﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Referral
{
    [ProtoContract]
    public class UserReferrals : IStorageKey
    {
        [ProtoMember(1)]
        public string ReferralCode { get; set; }

        [ProtoMember(2)]
        public string ReferredUserId { get; set; }


        [ProtoMember(3)]
        public ReferralStatus Status { get; set; }

        [ProtoMember(4)]
        public int ReferralAmount { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return this.ReferralCode.ToUpperInvariant();
            }
        }
        string IStorageKey.RowKey
        {
            get { return this.ReferredUserId; }
        }
    }
}
