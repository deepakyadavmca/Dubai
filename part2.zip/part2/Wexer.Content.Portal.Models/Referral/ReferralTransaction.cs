﻿using ProtoBuf;
using System;

namespace Wexer.Content.Portal.Models.Referral
{
    [ProtoContract]
    public class ReferralTransaction : IStorageKey
    {
        

        [ProtoMember(1)]
        public string ReferralCode { get; set; }

        [ProtoMember(2)]
        public DateTime RefundDate { get; set; }

        [ProtoMember(3)]
        public double RefundedAmount { get; set; }

        [ProtoMember(4)]
        public string ChargeId { get; set; }

        [ProtoMember(5)]
        public string RefundId { get; set; }

        [ProtoMember(6)]
        public ReferralPaymentType RefundType { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return ReferralCode.ToUpperInvariant();
            }
        }
        string IStorageKey.RowKey
        {
            get { return $"{RefundDate.ToString("yyyyMMddHHmmssfff")}"; }
        }
    }
}
