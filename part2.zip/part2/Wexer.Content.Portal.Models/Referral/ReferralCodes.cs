﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Referral
{
    [ProtoContract]
    public class ReferralCodes : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string ReferralCode { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return this.ReferralCode.ToUpperInvariant();
            }
        }
        string IStorageKey.RowKey
        {
            get { return this.UserId; }
        }
    }
}
