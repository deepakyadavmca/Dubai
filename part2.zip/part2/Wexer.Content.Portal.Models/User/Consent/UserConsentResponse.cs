﻿using Wexer.Content.Portal.Models.Consent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Consent
{
    public class UserConsentResponse
    {
        public string ConsentTag { get; set; }
        public string Policy { get; set; }
        public int Version { get; set; }
        public bool IsMandatory { get; set; }
        public bool UserAccepted { get; set; }
        public int UserLastActionedVersion { get; set; }
        public DateTime ConsentDate { get; set; }

        public bool Actionable { get; set; }
        
    }
}
