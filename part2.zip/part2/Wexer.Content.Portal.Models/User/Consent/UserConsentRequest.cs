﻿using Wexer.Content.Portal.Models.User.Consent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Consent
{
    [ProtoContract]
    public class UserConsentRequest
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        [ProtoMember(2)]
        public string ConsentTag { get; set; }
        [ProtoMember(3)]
        public ConsentAction Action { get; set; }
    }
}
