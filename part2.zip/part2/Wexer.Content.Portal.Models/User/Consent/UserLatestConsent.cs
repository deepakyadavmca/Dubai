﻿using Wexer.Content.Portal.Models.Consent;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Consent
{
    [ProtoContract]
    public class UserLatestConsent : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        [ProtoMember(2)]
        public String PolicyType { get; set; }
        [ProtoMember(3)]
        public int Version { get; set; }

        [ProtoMember(4)]
        public ConsentAction Action { get; set; }
        [ProtoMember(5)]
        public DateTime ConsentDate { get; set; }
        public string PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        public string RowKey
        {
            get
            {
                return PolicyType.ToString();
            }
        }
    }
}
