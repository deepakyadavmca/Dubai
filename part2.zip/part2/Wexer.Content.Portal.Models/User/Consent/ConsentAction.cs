﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Consent
{
    [ProtoContract]
    public enum ConsentAction
    {
        [ProtoEnum(Name = "None", Value = 0)]
        None = 0,
        [ProtoEnum(Name = "Rejected", Value = 1)]
        Rejected = 1,
        [ProtoEnum(Name = "Accepted", Value = 2)]
        Accepted = 2
    }
}
