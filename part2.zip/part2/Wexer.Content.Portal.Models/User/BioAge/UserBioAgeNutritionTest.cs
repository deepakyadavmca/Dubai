using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.BioAge
{
    [ProtoContract]
    public enum NutritionAnswer : byte
    {
        [ProtoEnum(Name = "AlmostNever", Value = 1)]
        AlmostNever = 1,
        [ProtoEnum(Name = "Rarely", Value = 2)]
        Rarely = 2,
        [ProtoEnum(Name = "Sometimes", Value = 3)]
        Sometimes = 3,
        [ProtoEnum(Name = "MostOfTheTime", Value = 4)]
        MostOfTheTime = 4,
        [ProtoEnum(Name = "Always", Value = 5)]
        Always = 5
    }

    [ProtoContract]
    public class UserBioAgeNutritionTest
    {
        [ProtoMember(1)]
        public NutritionAnswer EatFruit { get; set; }
        [ProtoMember(2)]
        public NutritionAnswer EatVegetables { get; set; }
        [ProtoMember(3)]
        public NutritionAnswer DrinkWater { get; set; }
        [ProtoMember(4)]
        public NutritionAnswer EatFish { get; set; }
        [ProtoMember(5)]
        public NutritionAnswer FatIntake { get; set; }
        [ProtoMember(6)]
        public NutritionAnswer EatSnacks { get; set; }
        [ProtoMember(7)]
        public NutritionAnswer SugaryDrinks { get; set; }
        [ProtoMember(8)]
        public NutritionAnswer EatHealthy { get; set; }
        [ProtoMember(9)]
        public NutritionAnswer EatFried { get; set; }
        [ProtoMember(10)]
        public NutritionAnswer DrinkAlcohol { get; set; }

        public int CalculateScore()
        {
            return (byte)EatFruit +
                    (byte)EatVegetables +
                    (byte)DrinkWater +
                    (byte)EatFish +
                    (byte)FatIntake +
                    (byte)EatSnacks +
                    (byte)SugaryDrinks +
                    (byte)EatHealthy +
                    (byte)EatFried +
                    (byte)DrinkAlcohol;
        }
    }
}