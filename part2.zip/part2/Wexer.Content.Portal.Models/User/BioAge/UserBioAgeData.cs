﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.BioAge
{
    [ProtoContract]
    public class UserBioAgeData : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string Tag { get; set; }
        
        [ProtoMember(3)]
        public UserBioAgeTest BioAgeTest { get; set; }

        [ProtoMember(4)]
        public UserBioAgeResult BioAgeResult { get; set; }

        [ProtoMember(5)]
        public DateTime CompletedDate { get; set; }

        public string PartitionKey
        {
            get { return UserId; }
        }

        public string RowKey
        {
            get { return Tag; }
        }
    }
}
