using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.BioAge
{
    [ProtoContract]
    public class UserBioAgeTest
    {
        [ProtoMember(1)]
        public DateTime DateOfBirth { get; set; }
        [ProtoMember(2)]
        public string Gender { get; set; }
        [ProtoMember(3)]
        public int WaistCm { get; set; }
        [ProtoMember(4)]
        public int HeightCm { get; set; }
        [ProtoMember(5)]
        public int Smoking { get; set; }
        [ProtoMember(6)]
        public int Alcohol { get; set; }
        [ProtoMember(7)]
        public int LoadedMovementAssessment { get; set; }
        [ProtoMember(8)]
        public int BloodPressureSystolic { get; set; }
        [ProtoMember(9)]
        public int BloodPressureDiasystolic { get; set; }
        [ProtoMember(10)]
        public double AgilityTestSeconds { get; set; }
        [ProtoMember(11)]
        public double TrxRowTestSeconds { get; set; }
        [ProtoMember(12)]
        public double Row500MTestSeconds { get; set; }
        [ProtoMember(13)]
        public int CoreTest { get; set; }
        [ProtoMember(14)]
        public int LungFunction { get; set; }
        [ProtoMember(15)]
        public UserBioAgeNutritionTest NutritionTest { get; set; }
        [ProtoMember(16)]
        public UserBioAgeStressTest StressTest { get; set; }
        [ProtoMember(17)]
        public int StandingJump { get; set; }
        [ProtoMember(18)]
        public double Glucose { get; set; }
        [ProtoMember(19)]
        public double Triglycerides { get; set; }
        [ProtoMember(20)]
        public double HighDensityLipoprotein { get; set; }
    }
}