using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.BioAge
{
    [ProtoContract]
    public enum StressAnswer : byte
    {
        [ProtoEnum(Name = "StronglyDisagree", Value = 1)]
        StronglyDisagree = 1,
        [ProtoEnum(Name = "Disagree", Value = 2)]
        Disagree = 2,
        [ProtoEnum(Name = "Neither", Value = 3)]
        Neither = 3,
        [ProtoEnum(Name = "Agree", Value = 4)]
        Agree = 4,
        [ProtoEnum(Name = "StronglyAgree", Value = 5)]
        StronglyAgree = 5
    }

    [ProtoContract]
    public class UserBioAgeStressTest
    {
        [ProtoMember(1)]
        public StressAnswer SleepWell { get; set; }
        [ProtoMember(2)]
        public StressAnswer InGoodHealth { get; set; }
        [ProtoMember(3)]
        public StressAnswer PhysicalAppearance { get; set; }
        [ProtoMember(4)]
        public StressAnswer Stress { get; set; }
        [ProtoMember(5)]
        public StressAnswer Refreshed { get; set; }
        [ProtoMember(6)]
        public StressAnswer Purpose { get; set; }
        [ProtoMember(7)]
        public StressAnswer FeelAccepted { get; set; }
        [ProtoMember(8)]
        public StressAnswer StrongNetwork { get; set; }
        [ProtoMember(9)]
        public StressAnswer EnjoyTime { get; set; }
        [ProtoMember(10)]
        public StressAnswer UseStrengths { get; set; }
        [ProtoMember(11)]
        public StressAnswer Grow { get; set; }
        [ProtoMember(12)]
        public StressAnswer SomethingInteresting { get; set; }
        [ProtoMember(13)]
        public StressAnswer Community { get; set; }
        [ProtoMember(14)]
        public StressAnswer CommunityPride { get; set; }
        [ProtoMember(15)]
        public StressAnswer CommunityContribution { get; set; }
        [ProtoMember(16)]
        public StressAnswer StandardOfLiving { get; set; }
        [ProtoMember(17)]
        public StressAnswer FinanceConcerns { get; set; }
        [ProtoMember(18)]
        public StressAnswer SatisfiedWithFinancesInFuture { get; set; }
        [ProtoMember(19)]
        public StressAnswer LifeNow { get; set; }
        [ProtoMember(20)]
        public StressAnswer LifeInFiveYears { get; set; }

        public int CalculateScore()
        {
            return (byte)InGoodHealth +
            (byte)PhysicalAppearance +
            (byte)Stress +
            (byte)SleepWell +
            (byte)Refreshed +
            (byte)Purpose +
            (byte)FeelAccepted +
            (byte)StrongNetwork +
            (byte)EnjoyTime +
            (byte)UseStrengths +
            (byte)Grow +
            (byte)SomethingInteresting +
            (byte)Community +
            (byte)CommunityPride +
            (byte)CommunityContribution +
            (byte)StandardOfLiving +
            (byte)FinanceConcerns +
            (byte)SatisfiedWithFinancesInFuture +
            (byte)LifeNow +
            (byte)LifeInFiveYears;
        }
    }
}