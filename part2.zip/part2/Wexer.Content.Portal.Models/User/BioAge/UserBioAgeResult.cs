using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.BioAge
{
    [ProtoContract]
    public class UserBioAgeResult
    {
        [ProtoMember(1)]
        public int ActualAge { get; set; }

        [ProtoMember(2)]
        public double BioAge { get; set; }

        [ProtoMember(3)]
        public double SmokingAge { get; set; }

        [ProtoMember(4)]
        public double LoadedMovementAssessmentAge { get; set; }

        [ProtoMember(5)]
        public double BloodPressureAge { get; set; }

        [ProtoMember(6)]
        public double AgilityAge { get; set; }

        [ProtoMember(7)]
        public double TrxRowAge { get; set; }

        [ProtoMember(8)]
        public double Row500MAge { get; set; }

        [ProtoMember(9)]
        public double CoreAge { get; set; }

        [ProtoMember(10)]
        public double LungFunctionAge { get; set; }

        [ProtoMember(11)]
        public double HeightWeightAge { get; set; }

        [ProtoMember(12)]
        public string StaffId { get; set; }

        [ProtoMember(13)]
        public double GlucoseAge { get; set; }

        [ProtoMember(14)]
        public double TrigHdlAge { get; set; }

        [ProtoMember(15)]
        public double StandingJumpAge { get; set; }

        [ProtoMember(16)]
        public string DigitalClubTag { get; set; }

        [ProtoMember(17)]
        public double LifestyleAge { get; set; }
    }
}