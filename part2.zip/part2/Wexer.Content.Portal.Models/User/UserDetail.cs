using System;
using Wexer.Content.Portal.Models.User.Profiles;
using ProtoBuf;
using Wexer.Content.Portal.Models.ContentPortal;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserDetail : User, IUserEntitlement
    {
        [ProtoMember(11)]
        public virtual UserMembershipProfile MembershipProfile { get; set; }

        [ProtoMember(12)]
        public virtual UserFacebookProfile FacebookProfile { get; set; }

        [ProtoMember(13)]
        public virtual UserFitbitProfile FitBitProfile { get; set; }

        [ProtoMember(14)]
        public virtual UserRunKeeperProfile RunKeeperProfile { get; set; }

        [ProtoMember(15)]
        public virtual UserMeasurement LatestMeasurement { get; set; }

        [ProtoMember(16)]
        public virtual ProspectProfile ProspectProfile { get; set; }

        [ProtoMember(17)]
        public virtual string StaffId { get; set; }

        [ProtoMember(18)]
        public bool IsTestUser { get; set; }

        [ProtoMember(19)]
        public virtual UserBioAgeProfile BioAgeProfile { get; set; }

        [ProtoMember(20)]
        public virtual string[] UserGroupTags { get; set; }

        [ProtoMember(21)]
        public virtual UserApplicationProfile ApplicationProfile { get; set; }

        [ProtoMember(22)]
        public virtual string ResetToken { get; set; }

        [ProtoMember(23)]
        public virtual DateTime? ResetTokenExpiryDate { get; set; }

        [ProtoMember(24)]
        public virtual string ProfileImageUrl { get; set; }

        [ProtoMember(25)]
        public virtual UserPaymentProfile PaymentProfile { get; set; }

        [ProtoMember(26)]
        public virtual UserReferralProfile ReferralProfile { get; set; }

        [ProtoMember(27)]
        public string TenantId { get; set; }

        [ProtoMember(28)]
        public virtual ExerpProfile ExerpProfile { get; set; }

        public static string GenerateNewUserId()
        {
            var guid = Guid.NewGuid().ToByteArray(); // Guid is 128 bits so convert to two int64 and concat
            return String.Format("{0}{1}", BitConverter.ToUInt64(guid, 0), BitConverter.ToUInt64(guid, 8));
        }

        public string Code { get; set; }

        public string CountryCode
        {
            get
            {
                //return MembershipProfile == null
                //    ? ProspectProfile == null ? ApplicationProfile == null ? FacebookProfile == null ? "NA" : FacebookProfile.CountryCode : ApplicationProfile.CountryCode : ProspectProfile.CountryCode
                //    : MembershipProfile.CountryCode;
                return ApplicationProfile == null
                    ? FacebookProfile == null ? MembershipProfile == null ? ProspectProfile == null ? "NA" : ProspectProfile.CountryCode : MembershipProfile.CountryCode : FacebookProfile.CountryCode
                    : ApplicationProfile.CountryCode;

            }
        }

        public string ClubTag
        {
            get
            {
                var clubTag = string.Empty;

                if ((MembershipProfile != null) &&
                    (!string.IsNullOrWhiteSpace(MembershipProfile.ClubTag)))
                {
                    clubTag = MembershipProfile.ClubTag.Trim();
                }
                else if ((ProspectProfile != null) &&
                         (!string.IsNullOrWhiteSpace(ProspectProfile.ClubTag)))
                {
                    clubTag = ProspectProfile.ClubTag.Trim();
                }

                return clubTag;
            }
        }

        public bool HasValidNonMemberProfile
        {
            get
            {
                return (ProspectProfile != null || FacebookProfile != null || ApplicationProfile != null) && MembershipProfile == null;
            }
        }

        public bool MembersOnly
        {
            get
            {
                return (ProspectProfile == null && FacebookProfile == null && ApplicationProfile == null) && MembershipProfile != null;
            }
        }

        public MarketingProfile MarketingProfile  { get; set; }
        public Roles UserRole { get; set; } // for content portal users

    }
}
