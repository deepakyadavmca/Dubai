﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.PremiumPlan;
using Wexer.Content.Portal.Models.User.FitnessTracking;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.PremiumPlan
{
    [ProtoContract]
    public class UserPremiumPlan 
    {

        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string PlanRefTag { get; set; }

        [ProtoMember(3)]
        public string Title { get; set; }

        [ProtoMember(4)]
        public string InternalName { get; set; }

        [ProtoMember(5)]
        public string CardShortDescription { get; set; }

        [ProtoMember(6)]
        public string Description { get; set; }

        [ProtoMember(7)]
        public PremiumPlanPrimaryMetric PrimaryMetric { get; set; }

        [ProtoMember(8)]
        public bool Featured { get; set; }

        [ProtoMember(9)]
        public bool Active { get; set; }

        [ProtoMember(10)]
        public UserPremiumPlanStage[] PremiumPlanStage { get; set; }

        [ProtoMember(11)]
        public FitnessExperience PlanLevels { get; set; }

        [ProtoMember(12)]
        public string[] AvailableCountry { get; set; }

        [ProtoMember(13)]
        public string PlanDashboardImageUrl { get; set; }

        [ProtoMember(14)]
        public string PlanImageUrl { get; set; }

        [ProtoMember(15)]
        public string PlanVideoUrl { get; set; }

        [ProtoMember(16)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(17)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(18)]
        public int PlanLength { get; set; }

        [ProtoMember(19)]
        public string UserId { get; set; }

        [ProtoMember(20)]
        public double PlanProgress { get; set; }

        [ProtoMember(21)]
        public int CurrentActiveStage { get; set; }

        [ProtoMember(22)]
        public string PlanCompleteText { get; set; }

        [ProtoMember(23)]
        public string PlanEquipment { get; set; }

        //[ProtoMember(24)]
        //public List<UserMetricMaster> PlanMetricResult { get; set; }

        [ProtoMember(25)]
        public string EndorsementQuote{get;set;}

        [ProtoMember(26)]
        public string EndorsementAuthor{get;set;}

        [ProtoMember(27)]
        public string EndorsementAuthorImageUrl { get; set; }

        [ProtoMember(28)]
        public bool IsPurchased { get; set; }

        [ProtoMember(29)]
        public TrainingStyle[] TrainingStyles { get; set; }

        public PremiumPlanAdvert PremiumPlanAdvert { get; set; }

        public static string GenerateUserPremiumPlanKey(string UserID, string PlanTag)
        {
            var key = string.Format("{0}_{1}",UserID,PlanTag);
            return key;
        }
      
    }
}
