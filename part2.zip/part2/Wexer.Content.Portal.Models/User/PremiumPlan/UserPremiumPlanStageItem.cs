﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.User.FitnessTracking;
using Wexer.Content.Portal.Models.VirtualClasses;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.PremiumPlan
{
    [ProtoContract]
    public class UserPremiumPlanStageItem   //UserPremiumPlanStageDetail
    {
        [ProtoMember(1)]
        public string RefTemplateId { get; set; }

        [ProtoMember(2)]
        public string Name { get; set; }

        [ProtoMember(3)]
        public string Description { get; set; }

        [ProtoMember(4)]
        public string ImageUrl { get; set; }

        [ProtoMember(5)]
        public TrainingStyle[] TrainingStyles { get; set; }

        [ProtoMember(6)]
        public int DurationMinutes { get; set; }

        [ProtoMember(7)]
        public UserWorkout UserWorkout { get; set; }

        [ProtoMember(8)]
        public PlanWorkoutState PlanWorkoutState { get; set; }

        [ProtoMember(9)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime UserWorkoutModifiedDate { get; set; }

        [ProtoMember(10)]
        public string WorkoutCompleteText { get; set; }

        [ProtoMember(11)]
        public UserPremiumPlanWorkoutResult UserWorkoutResult { get; set; }

        [ProtoMember(13)]
        public VirtualClass VirtualClass { get; set; }

        //[ProtoMember(12)]
        //public List<UserDailyMetric> PlanWorkoutResultMetrics { get; set; }

    }
}
