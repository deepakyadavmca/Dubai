﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.PremiumPlan
{
    [ProtoContract]
    public class UserPremiumPlanWorkoutResult
    {
        [ProtoMember(1)]
        public int DurationMinute { get; set; }

        [ProtoMember(2)]
        public int DurationSecond { get; set; }

        [ProtoMember(3)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CompletionDate { get; set; }

        [ProtoMember(4)]
        public int CalorieBurn { get; set; }

        [ProtoMember(5)]
        public int TrainingTime { get; set; }

        [ProtoMember(6)]
        public double WeightLifted { get; set; }

      

    }

}
