﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.PremiumPlan
{

    [ProtoContract]
    public class UserPremiumPlanStage
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string PremiumPlanTag { get; set; }

        [ProtoMember(3)]
        public string ShortName { get; set; }

        [ProtoMember(4)]
        public string LongName { get; set; }

        [ProtoMember(5)]
        public string Description { get; set; }

        [ProtoMember(6)]
        public int StageNumber { get; set; }

        [ProtoMember(7)]
        public string StageCompleteText { get; set; }

        [ProtoMember(8)]
        public int Duration { get; set; }

        [ProtoMember(10)]
        public UserPremiumPlanStageItem[] stageDetail { get; set; }

        [ProtoMember(11)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime StageStartDate { get; set; }

    }
}