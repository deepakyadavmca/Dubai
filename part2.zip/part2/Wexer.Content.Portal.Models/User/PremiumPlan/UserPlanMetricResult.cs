﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.PremiumPlan
{
    [ProtoContract]
    public class UserPlanMetricResult : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public List<UserMetricMaster> PlanMetricResult { get; set; }

        public string PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        public string RowKey
        {
            get
            {
                return Tag;
            }
        }
    }
}
