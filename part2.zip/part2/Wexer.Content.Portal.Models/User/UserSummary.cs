﻿using System;
using Wexer.Content.Portal.Models.User.Profiles;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserSummary : IUserEntitlement
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public DateTime BirthDate { get; set; }

        [ProtoMember(3)]
        public DateTime JoinDate { get; set; }

        [ProtoMember(4)]
        public string FirstName { get; set; }

        [ProtoMember(5)]
        public string LastName { get; set; }

        [ProtoMember(6)]
        public string Telephone { get; set; }

        [ProtoMember(7)]
        public string MobileTelephone { get; set; }

        [ProtoMember(8)]
        public string EmailAddress { get; set; }

        [ProtoMember(9)]
        public string Gender { get; set; }

        [ProtoMember(10)]
        public ClubTier Tier { get; set; }

        [ProtoMember(11)]
        public string ClubTag { get; set; }

        [ProtoMember(12)]
        public string CountryTag { get; set; }
        
        [ProtoMember(13)]
        public virtual UserMembershipProfile MembershipProfile { get; set; }

        [ProtoMember(14)]
        public virtual ProspectProfile ProspectProfile { get; set; }

        [ProtoMember(16)]
        public virtual string[] UserGroupTags{ get; set; }

        [ProtoMember(17)]
        public string[] Entitlements { get; set; }

        [ProtoMember(18)]
        public bool HasSelfServiceCredentials{ get; set; }

        [ProtoMember(19)]
        public UserApplicationProfile ApplicationProfile { get; set; }

        [ProtoMember(20)]
        public UserFacebookProfile FacebookProfile { get; set; }
    }
}