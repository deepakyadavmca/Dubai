﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class ProspectUserIndex : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public DateTime? DateCreated { get; set; }

        string IStorageKey.PartitionKey
        {
            get { return string.Format("{0:yyyy-MM-dd}", DateCreated); }
        }

        string IStorageKey.RowKey
        {
            get { return UserId; }
        }
    }
}
