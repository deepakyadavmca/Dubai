﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Wexer.Content.Portal.Models.User.FitnessTracking;

using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{

}
