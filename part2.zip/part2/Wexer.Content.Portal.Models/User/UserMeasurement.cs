using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserMeasurement
    {
        [ProtoMember(1)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime UtcTime { get; set; }

        [ProtoMember(2)]
        public decimal TotalWeightKg { get; set; }
        [ProtoMember(3)]
        public decimal FatPercentage { get; set; }
        [ProtoMember(4)]
        public decimal HeightCm { get; set; }
        [ProtoMember(5)]
        public decimal Bmi { get; set; }
        [ProtoMember(6)]
        public int? StepCount { get; set; }

    }
}