﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User
{
    public class UserData
    {
        public string Username { get; set; }
        public string Access_Token { get; set; }
        public string Email { get; set; }
        public string ExternalId { get; set; }
        public int CenterId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Password { get; set; }

        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string DataSource { get; set; }
        public string SubscriptionKey { get; set; }
        public string Tenant { get; set; }

        public string Time { get; set; }
        public Dictionary<string, string> Miscellaneous { get; set; }
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public string EndpointKey { get; set; }
        public string RoleId { get; set; }
        public string CardId { get; set; }
        public string UserId { get; set; }
        public string[] Memberships { get; set; }
        public bool? EmailPassword { get; set; }
    }

    public class ExerpUser
    {
        public string CenterId { get; set; }
        public string Address1 { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
        public string Birthday { get; set; }
        public string FirstName { get; set; }
        public string Gender { get; set; }
        public string LastName { get; set; }
        public string PersonType { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string SoapHashString { get; set; }
    }

    public class ExerpPaymentAgreement
    {
        public string ExpirationDate { get; set; }
        public string MaskedCreditCardNumber { get; set; }
        public string ExternalId { get; set; }
        public string Reference { get; set; }
        public string SoapHashString { get; set; }
    }
}
