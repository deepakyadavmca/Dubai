﻿using System.Linq;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserSearchResult
    {
        [ProtoMember(1)]
        public IndexedUserDetail[] MatchedIndexUserDetails { get; set; }
        
        [ProtoMember(2)]
        public UserSummary MatchedUserSummary { get; set; }

        public bool HasExactMatch
        {
            get { return MatchedUserSummary != null; }
        }

        public bool HasResults
        {
            get { return (HasExactMatch || (MatchedIndexUserDetails != null && MatchedIndexUserDetails.Any())); }
        }
    }
}
