﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class ProspectActivationIndex : IStorageKey
    {
        [ProtoMember(1)]
        public string ActivationCode { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        string IStorageKey.PartitionKey
        {
            get { return ActivationCode.ToLowerInvariant(); }
        }

        string IStorageKey.RowKey
        {
            get { return UserId; }
        }
    }
}
