using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    [ProtoInclude(100, typeof(UserDetail))]
    public class User
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        [SensitiveData]
        public string FirstName { get; set; }

        [ProtoMember(3)]
        [SensitiveData]
        public string LastName { get; set; }

        [ProtoMember(4)]
        public string Gender { get; set; }

        [ProtoMember(5)]
        [SensitiveData]
        public DateTime BirthDate { get; set; }

        [ProtoMember(6)]
        [SensitiveData]
        public string EmailAddress { get; set; }

        [ProtoMember(7)]
        [SensitiveData]
        public string Telephone { get; set; }

        [ProtoMember(8)]
        [SensitiveData]
        public string MobileTelephone { get; set; }

        [ProtoMember(9)]
        public int LifetimeTotal { get; set; }

        [ProtoMember(10)]
        public DateTime CustomFitStartDate { get; set; }

        [ProtoMember(11)]
        public DateTime? OnDemandSubscriptionStartDate { get; set; }
    }
}