using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserInteraction
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        
        [ProtoMember(2)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]

        public DateTime UtcTime { get; set; }
        [ProtoMember(3)]
        public string Channel { get; set; }
        [ProtoMember(4)]
        public string UserAgent { get; set; }
        [ProtoMember(5)]
        public string InteractionType { get; set; }
        [ProtoMember(6)]
        public string InteractionData { get; set; }
    }
}