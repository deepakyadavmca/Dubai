using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserGroupManagementModel
    {
        [ProtoMember(1)]
        public string EmailAddress { get; set; }

        [ProtoMember(2)]
        public string UserGroupName { get; set; }

    }
}