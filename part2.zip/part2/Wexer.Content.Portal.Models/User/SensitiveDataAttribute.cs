using System;

namespace Wexer.Content.Portal.Models.User
{
    public class SensitiveDataAttribute : Attribute
    {
    }
}