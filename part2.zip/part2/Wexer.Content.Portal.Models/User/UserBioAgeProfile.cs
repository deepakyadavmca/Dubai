using Wexer.Content.Portal.Models.User.Profiles;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserBioAgeProfile : UserProfile
    {
        [ProtoMember(1)]
        public int Age { get; set; }

        [ProtoMember(2)]
        public double BioAge { get; set; }
    }
}