using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    /// <summary>
    /// Represents a user's preferences
    /// </summary>
    /// 
    [ProtoContract]
    public class UserPreferences
    {
        /// <summary>
        /// The units used to represent distances can be either <code>miles</code> or <code>km</code>
        /// </summary>
        [ProtoMember(1)]
        public string DistanceUnits { get; set; }

        /// <summary>
        /// The units used to represent speed can be either <code>mph</code> or <code>kph</code>
        /// </summary>
        [ProtoMember(2)]
        public string SpeedUnits { get; set; }

        /// <summary>
        /// The units used to represent weight can be either <code>lbs</code> or <code>kg</code>
        /// </summary>
        [ProtoMember(3)]
        public string WeightUnits { get; set; }

        /// <summary>
        /// IANA Timezone name for user
        /// </summary>
        [ProtoMember(4)]
        public string IanaTimezone { get; set; }
    }
}