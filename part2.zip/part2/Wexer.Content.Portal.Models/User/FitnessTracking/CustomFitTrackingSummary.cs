﻿using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class CustomFitTrackingSummary
    {
        [ProtoMember(1)]
        public CustomFitTrackingResult LastWeek { get; set; }
        [ProtoMember(2)]
        public CustomFitTrackingResult CurrentWeek { get; set; }
        [ProtoMember(3)]
        public CustomFitTrackingResult Trend { get; set; }
        [ProtoMember(4)]
        public int LifetimeTotal { get; set; }
        [ProtoMember(5)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime StartDate { get; set; }
        [ProtoMember(6)]
        public CustomFitTrackingResult CurrentDay { get; set; }
        [ProtoMember(7)]
        public CustomFitTrackingResult CalorieBurnDay { get; set; }
        [ProtoMember(8)]
        public CustomFitTrackingResult CalorieBurnWeek { get; set; }
        [ProtoMember(9)]
        public CustomFitTrackingResult StepsDay { get; set; }
        [ProtoMember(10)]
        public CustomFitTrackingResult StepsWeek { get; set; }        
        [ProtoMember(11)]
        public int LifetimeTotalCalorieBurn { get; set; }
        [ProtoMember(12)]
        public int LifetimeTotalSteps { get; set; }

        [ProtoMember(13)]
        public int DailyTrainingCalories { get; set; }

        [ProtoMember(14)]
        public int WeeklyTrainingCalories { get; set; }
    }
}
