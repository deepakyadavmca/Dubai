﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserCompletedSetSummary
    {
        [ProtoMember(1)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(2)]
        public int? Reps { get; set; }

        [ProtoMember(3)]
        public decimal WeightKg { get; set; }

        [ProtoMember(4)]
        public int? RestSeconds { get; set; }
    }
}
