using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class ResultsSummary
    {
        [ProtoMember(1)]
        public UserWorkoutSummary[] UserWorkoutResults { get; set; }

        [ProtoMember(2)]
        public UserClassSummary[] UserClassSummaries { get; set; }
    }
}