namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    public enum ExtractEventType
    {
        User,
        Staff,
    }
}