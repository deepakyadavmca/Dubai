using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class ExerciseResult
    {
        [ProtoMember(1)]
        public string ExerciseTag { get; set; }

        [ProtoMember(2)]
        public int SlotNumber { get; set; }

        [ProtoMember(3)]
        public int DurationSeconds { get; set; }

        [ProtoMember(4)]
        public int Sets { get; set; }

        [ProtoMember(5)]
        public int Reps { get; set; }

        [ProtoMember(6)]
        public float Weight { get; set; }

        [ProtoMember(7)]
        public int Points { get; set; }

        [ProtoMember(8)]
        public float GoalEfficiency { get; set; }
    }
}