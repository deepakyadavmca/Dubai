using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserDailyMetric : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string MetricTag { get; set; }

        [ProtoMember(3)]
        public string MetricName { get; set; }

        [ProtoMember(4)]
        public string MetricType { get; set; }

        [ProtoMember(5)]
        public string MetricCategory { get; set; }

        [ProtoMember(6)]
        public string MetricLabel { get; set; }

        [ProtoMember(7)]
        public string MetricRefTag { get; set; }

        [ProtoMember(8)]
        public string Unit { get; set; }

        [ProtoMember(9)]
        public string Value { get; set; }

        [ProtoMember(10)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime RecordingDate { get; set; }

        [ProtoMember(11)]
        public string Level { get; set; }

        [ProtoMember(12)]
        public string DurationInSeconds { get; set; }

        [ProtoMember(13)]
        public string CaloriesBurned { get; set; }

        [ProtoMember(14)]
        public string ResultRefTag { get; set; }

        [ProtoMember(15)]
        public TrackingResult TrackingResult { get; set; }

        public string PartitionKey
        {
            get { return string.Format("{0}_{1}", UserId, MetricType.ToLower()); }
        }

        public string RowKey
        {
            get
            {
                return (!string.IsNullOrEmpty(MetricName) && (string.Equals(MetricName, "skill", StringComparison.InvariantCultureIgnoreCase) 
                     || string.Equals(MetricName, "intensity", StringComparison.InvariantCultureIgnoreCase)
                    || string.Equals(MetricName, "workout calories", StringComparison.InvariantCultureIgnoreCase)
                    || string.Equals(MetricName, "club visits", StringComparison.InvariantCultureIgnoreCase))) ?
                    string.Format("{0}_{1}", MetricTag.ToLower(), RecordingDate.ToString("yyyyMMddHHmmss")) : string.Format("{0}_{1}", MetricTag.ToLower(), RecordingDate.ToString("yyyyMMdd"));
            }
        }
    }
}