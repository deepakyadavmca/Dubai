using System;
using System.Collections.Generic;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserWorkoutResult : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId{ get; set; }

        [ProtoMember(2)]
        public string Tag { get; set; }

        [ProtoMember(3)]
        public string UserWorkoutTag { get; set; }

        [ProtoMember(4)]
        public int? DurationMinutes { get; set; }

        [ProtoMember(5)]
        public List<UserExerciseResult> Exercises { get; set; }

        [ProtoMember(6)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? CompletedDate { get; set; }

        [ProtoMember(7)]
        public string Mood { get; set; }

        [ProtoMember(8)]
        public byte PrimaryGoal { get; set; }

        [ProtoMember(9)]
        public byte? SecondaryGoal { get; set; }

        [ProtoMember(10)]
        public TrackingResult TrackingResult { get; set; }

        [ProtoMember(11)]
        public string ClassCommitmentTag{ get; set; }

        [ProtoMember(12)]
        public int SkillLevel { get; set; }

        [ProtoMember(13)]
        public int CalorieBurn { get; set; }

        [ProtoMember(14)]
        public int IntensityLevel { get; set; }

        [ProtoMember(15)]
        public bool PersonalBest { get; set; }

        [ProtoMember(16)]
        public string WorkoutName { get; set; }

        [ProtoMember(17)]
        public bool IsTimed { get; set; }

        [ProtoMember(18)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(19)]
        public string RefTemplateId { get; set; }

        [ProtoMember(20)]
        public string ImageUrl { get; set; }

        [ProtoMember(21)]
        public ResultSubmitType ResultSubmitType { get; set; }

        [ProtoMember(22)]
        public string WorkoutDescription { get; set; }

        [ProtoMember(23)]
        public string TrailerLinkWeb { get; set; }

        [ProtoMember(24)]
        public DateTime CreationDate { get; set; }

        //[ProtoMember(25)]
        //public string[] Keywords { get; set; }

        [ProtoMember(26)]
        public string Keywords { get; set; }

        [ProtoMember(27)]
        public string ClassCategories { get; set; }

        [ProtoMember(28)]
        public string Level { get; set; }

        string IStorageKey.PartitionKey
        {
            get { return UserId; }
        }

        string IStorageKey.RowKey
        {
            get { return Tag; }
        }
    }
}