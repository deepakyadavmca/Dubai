﻿using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
  public class UserMetricDetails
    {
        [ProtoMember(1)]
        public UserDailyMetric UserDailyMetric { get; set; }

        [ProtoMember(2)]
        public UserMetricMaster UserMetricMaster { get; set; }
    }
}
