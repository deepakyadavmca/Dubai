using System.Collections;
using System.Collections.Generic;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    public class WorkoutActivitySummary
    {
        [ProtoMember(1)]
        public int PageNumber { get; set; }

        [ProtoMember(2)]
        public IEnumerable<WorkoutActivityDetail> ActivityDetails { get; set; }

        [ProtoMember(3)]
        public bool IsCurrent { get; set; }

        [ProtoMember(4)]
        public bool IsLast { get; set; }

        [ProtoMember(5)]
        public int TotalRecords { get; set; }

        [ProtoMember(6)]
        public int TotalPages { get; set; }
    }
}