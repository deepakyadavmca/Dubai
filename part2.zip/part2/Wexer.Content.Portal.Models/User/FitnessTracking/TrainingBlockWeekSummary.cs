using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    public class TrainingBlockWeekSummary
    {
        [ProtoMember(1)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime StartDate { get; set; }

        [ProtoMember(2)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime EndDate { get; set; }

        [ProtoMember(3)]
        public int Points { get; set; }

        [ProtoMember(4)]
        public int PrimaryGoalPercentage { get; set; }

        [ProtoMember(5)]
        public int SecondaryGoalPercentage { get; set; }

        [ProtoMember(6)]
        public int EfficiencyPercent { get; set; }
    }
}