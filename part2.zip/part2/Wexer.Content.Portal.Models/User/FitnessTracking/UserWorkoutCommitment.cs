using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserWorkoutCommitment : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public string ClubTag { get; set; }

        [ProtoMember(4)]
        public string UserWorkoutTag { get; set; }

        [ProtoMember(6)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime StartTimeUtc { get; set; }

        [ProtoMember(7)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? CompletedTimeUtc { get; set; }

        [ProtoMember(8)]
        public string Mood { get; set; }

        [ProtoMember(9)]
        public string WorkoutResultTag { get; set; }

        [ProtoMember(10)]
        public DateTime? LastModifiedDate { get; set; }

        [ProtoMember(11)]
        public string RefPlanStageTag { get; set; }


        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return Tag;
            }
        }
    }
}