﻿using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserCompletedExerciseSummary
    {
        [ProtoMember(1)]
        public string ExerciseTag { get; set; }

        [ProtoMember(2)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? FirstCompletedUtc { get; set; }

        [ProtoMember(3)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? LastCompletedUtc { get; set; }

        [ProtoMember(4)]
        public int CompletedCount { get; set; }

        [ProtoMember(5)]
        public UserCompletedSetSummary[] Sets { get; set; }
    }
}
