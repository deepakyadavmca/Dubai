﻿using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;
using System;


namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserChallengeResult : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        [ProtoMember(2)]
        public string ChallengeTag { get; set; }
        [ProtoMember(3)]
        public ChallengeType ChallengeType { get; set; }
        [ProtoMember(4)]
        public bool IsFeatured { get; set; }
        [ProtoMember(5)]
        public DateTime CompletedDate { get; set; }
        [ProtoMember(6)]
        public string UserWorkoutResultTag { get; set; }

        public string PartitionKey
        {
            get { return ChallengeTag; }
        }

        public string RowKey
        {
            get { return UserId; }
        }
    }
}
