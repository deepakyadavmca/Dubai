using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserWorkoutSummary
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string WorkoutName { get; set; }

        [ProtoMember(3)]
        public string WorkoutDescription { get; set; }

        [ProtoMember(4)]
        public FitnessExperience FitnessExperience { get; set; }

        [ProtoMember(5)]
        public FitnessGoal PrimaryGoal { get; set; }

        [ProtoMember(6)]
        public FitnessGoal SecondaryGoal { get; set; }

        [ProtoMember(7)]
        public TrainingStyle TrainingStyle { get; set; }

        [ProtoMember(8)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? StartDate { get; set; }

        [ProtoMember(9)]
        public int? TotalLengthInMinutes { get; set; }

        [ProtoMember(10)]
        public string ImageUrl { get; set; }

        [ProtoMember(11)]
        public UserWorkoutResult[] WorkoutResults { get; set; }

        [ProtoMember(12)]
        public UserWorkoutCommitment[] Commitments { get; set; }

        [ProtoMember(13)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? CreationDate { get; set; }

        [ProtoMember(14)]
        public string SubTitle { get; set; }

        [ProtoMember(15)]
        public bool IsMultiDay{ get; set; }

        [ProtoMember(16)]
        public bool IsDeleted { get; set; }

        [ProtoMember(17)]
        public WorkoutCreationType WorkoutCreationType { get; set; }

        [ProtoMember(18)]
        public int SkillLevel { get; set; }

        [ProtoMember(19)]
        public int CalorieBurn { get; set; }

        [ProtoMember(20)]
        public int IntensityLevel { get; set; }
    }
}