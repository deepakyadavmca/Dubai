using Wexer.Content.Portal.Models.User.BioAge;
using Wexer.Content.Portal.Models.User.PremiumPlan;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserDashboard
    {
        [ProtoMember(1)]
        public UserBioAgeResult BioAgeResult { get; set; }
        
        [ProtoMember(2)]
        public UserClassCommitment[] ClassCommitments { get; set; }
        
        [ProtoMember(3)]
        public UserWorkoutCommitment[] WorkoutCommitments { get; set; }
        
        [ProtoMember(4)]
        public bool HasUntrackedVisits { get; set; }
        
        [ProtoMember(5)]
        public CustomFitTrackingSummary TrainingSummary { get; set; }

        [ProtoMember(6)]
        public int TotalWorkouts { get; set; }

        [ProtoMember(7)]
        public int TotalClubVisits { get; set; }   //Added By Avinash | US- Add Total Club Visits | 11 May 2015

        [ProtoMember(8)]
        public UserWorkout[] UserWorkouts { get; set; }
               
        [ProtoMember(9)]
        public UserPremiumPlan userPremiumPlan { get; set; }
    }
}