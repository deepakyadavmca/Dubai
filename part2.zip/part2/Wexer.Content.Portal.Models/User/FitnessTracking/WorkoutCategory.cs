﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public enum WorkoutCategory
    {
        [ProtoEnum(Name = "Main", Value = 0)]
        Main,
        [ProtoEnum(Name = "ExpressAlternative", Value = 1)]
        ExpressAlternative,
        [ProtoEnum(Name = "ExtendedAlternative", Value = 2)]
        ExtendedAlternative,
        [ProtoEnum(Name = "GoalAlternative", Value = 3)]
        GoalAlternative,
    }
}
