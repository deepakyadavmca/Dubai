﻿using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserDurationChange : IStorageKey
    {
        public UserDurationChange()
        {
            Tag = Guid.NewGuid().ToString();
        }

        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? CompletedDate { get; set; }

        [ProtoMember(3)]
        public int DurationMinutes { get; set; }

        [ProtoMember(4)]
        public string Tag { get; set; }

        [ProtoMember(5)]
        public byte PrimaryGoal { get; set; }

        [ProtoMember(6)]
        public byte? SecondaryGoal { get; set; }

        string IStorageKey.PartitionKey { get { return UserId; } }

        string IStorageKey.RowKey { get { return Tag; } }
    }
}
