using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserWorkout : IStorageKey, IValidatableObject
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public FitnessGoal PrimaryFitnessGoal { get; set; }

        [ProtoMember(3)]
        public FitnessGoal SecondaryFitnessGoal { get; set; }

        [ProtoMember(4)]
        public FitnessExperience FitnessExperience { get; set; }

        [ProtoMember(5)]
        public TrainingStyle TrainingStyle { get; set; }

        [ProtoMember(6)]
        public string Name { get; set; }

        [ProtoMember(7)]
        public string Description { get; set; }

        [ProtoMember(8)]
        public WorkoutSection[] Sections { get; set; }

        [ProtoMember(9)]
        public string UserId { get; set; }

        [ProtoMember(10)]
        public DateTime? LastModifiedDate { get; set; }

        [ProtoMember(11)]
        public DateTime? CreationDate { get; set; }

        [ProtoMember(12)]
        public int DurationMinutes { get; set; }

        [ProtoMember(13)]
        public string SubTitle { get; set; }

        [ProtoMember(14)]
        public bool IsMultiDay { get; set; }

        [ProtoMember(15)]
        public bool IsDeleted { get; set; }

        [ProtoMember(16)]
        public string ImageUrl { get; set; }

        [ProtoMember(17)]
        public WorkoutCategory WorkoutCategory { get; set; }

        [ProtoMember(18)]
        public WorkoutCreationType WorkoutCreationType { get; set; }

        [ProtoMember(19)]
        public bool MyWorkout { get; set; }

        [ProtoMember(20)]
        public bool IsTimed { get; set; }

        [ProtoMember(21)]
        public int SkillLevel { get; set; }

        [ProtoMember(22)]
        public int CalorieBurn { get; set; }

        [ProtoMember(23)]
        public int IntensityLevel { get; set; }

        [ProtoMember(24)]
        public bool PersonalBest { get; set; }

        [ProtoMember(25)]
        public bool IsPremium { get; set; }

        [ProtoMember(26)]
        public string VideoUrl { get; set; }

        [ProtoMember(27)]
        public string RefTemplateId { get; set; }

        [ProtoMember(28)]
        public bool Purchased { get; set; }

        [ProtoMember(29)]
        public FreeType FreeType { get; set; }

        [ProtoMember(30)]
        public string PremiumImageUrl { get; set; }

        [ProtoMember(31)]
        public string TrainerName { get; set; }

        [ProtoMember(32)]
        public string TrainerImgUrl { get; set; }

        [ProtoMember(33)]
        public string[] CountryCode { get; set; }

        [ProtoMember(34)]
        public string WorkoutIntroText { get; set; }

        [ProtoMember(35)]
        public string WorkoutCompleteDescription { get; set; }

        [ProtoMember(36)]
        public bool IsFavorite { get; set; }

        public int DurationSeconds { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return Tag;
            }
        }


        /// <summary>
        /// Overrides validation context to check integrity of UserWorkout object
        /// </summary>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (PrimaryFitnessGoal == SecondaryFitnessGoal)
            {
                yield return new ValidationResult("Primary and Secondary goals must be different");
            }

            if (Sections == null)
            {
                yield break;
            }

            foreach (var section in Sections)
            {
                if (section.Slots == null)
                {
                    continue;
                }

                if (section.Slots.Length == 0)
                {
                    yield return new ValidationResult("Section contains no slots.");
                }

                foreach (var workoutExerciseSlot in section.Slots)
                {
                    if (string.IsNullOrEmpty(workoutExerciseSlot.SelectedExerciseTag))
                    {
                        yield return new ValidationResult("slot has no selectedExerciseTag defined.");
                    }

                    if (workoutExerciseSlot.SlotType == SlotType.Single
                        && (workoutExerciseSlot.Sets == null || workoutExerciseSlot.Sets.Length == 0))
                    {
                        yield return new ValidationResult("slot contains no sets");
                    }

                    if (workoutExerciseSlot.SlotType == SlotType.Superset
                        && workoutExerciseSlot.Sets != null
                        && workoutExerciseSlot.Sets.Any())
                    {
                        yield return
                            new ValidationResult("slot type denotes superset, but slot contains single set data!");
                    }

                    if (workoutExerciseSlot.SlotType == SlotType.Single)
                    {
                        foreach (var validationResult in ValidateSingleSlot(workoutExerciseSlot))
                        {
                            yield return validationResult;
                        }
                    }
                    else
                    {
                        foreach (var validationResult1 in ValidateSupersetSlot(workoutExerciseSlot))
                        {
                            yield return validationResult1;
                        }
                    }
                }
            }
        }

        #region Private Static Methods

        private static IEnumerable<ValidationResult> ValidateSupersetSlot(WorkoutExerciseSlot workoutExerciseSlot)
        {
            if (workoutExerciseSlot.Supersets == null)
            {
                yield return new ValidationResult("slot denotes superset, but no supersets defined.");
            }

            if (workoutExerciseSlot.Supersets != null)
            {

                foreach (var set in workoutExerciseSlot.Supersets)
                {
                    if (set.Steps == null || set.Steps.Length <= 0)
                    {
                        yield return new ValidationResult("superset contains no steps");
                    }


                    foreach (var step in set.Steps)
                    {
                        if (step.DurationSeconds <= 0 && step.Reps < 0 && step.WeightKg <= 0 &&
                            (byte)step.ExerciseLengthType < 10)
                        {
                            yield return new ValidationResult("step has no valid values set!");
                        }

                        if (step.ExerciseLengthType == ExerciseLengthType.DurationMinutes &&
                            step.DurationSeconds < 60)
                        {
                            yield return
                                new ValidationResult(
                                    "superset exercise length type DurationMinutes, but durationSeconds < 60!");
                        }

                        if (string.IsNullOrEmpty(step.SelectedExerciseTag))
                        {
                            yield return new ValidationResult("superset has no selected exercise tag set!");
                        }
                    }
                }
            }
        }

        private static IEnumerable<ValidationResult> ValidateSingleSlot(WorkoutExerciseSlot workoutExerciseSlot)
        {
            if (workoutExerciseSlot.Sets == null)
            {
                yield return new ValidationResult("slot denotes single, but no sets defined.");
            }

            if (workoutExerciseSlot.Sets != null)
            {
                foreach (var set in workoutExerciseSlot.Sets)
                {
                    if (set.DurationSeconds <= 0 && set.Reps <= 0 && set.RestSeconds <= 0 &&
                        set.WeightKg <= 0)
                    {
                        yield return new ValidationResult("set definded, but has no values set.");
                    }

                    if (workoutExerciseSlot.ExerciseLengthType == ExerciseLengthType.DurationMinutes
                        && set.DurationSeconds < 60)
                    {
                        yield return
                            new ValidationResult(
                                "set denotes an exercise length type of minutes, but duration seconds < 60")
                            ;
                    }
                }
            }
        }

        #endregion
    }
}