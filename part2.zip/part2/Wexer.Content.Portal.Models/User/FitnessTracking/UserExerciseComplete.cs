﻿using System;
using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserExerciseComplete : IStorageKey
    {
        public UserExerciseComplete()
        {
            Tag = Guid.NewGuid().ToString();
        }

        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string Tag { get; set; }

        [ProtoMember(3)]
        public string UserWorkoutTag { get; set; }

        [ProtoMember(4)]
        public string ExerciseTag { get; set; }

        [ProtoMember(5)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(6)]
        public int? Set { get; set; }

        [ProtoMember(7)]
        public int? Reps { get; set; }

        [ProtoMember(8)]
        public decimal WeightKg { get; set; }

        [ProtoMember(9)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? CompletedDate { get; set; }

        [ProtoMember(10)]
        public SlotType ExerciseType { get; set; }

        [ProtoMember(11)]
        public int? RestSeconds { get; set; }

        [ProtoMember(12)]
        public ExerciseLengthType ExerciseLengthType { get; set; }

        string IStorageKey.PartitionKey { get { return UserId; } }
        
        string IStorageKey.RowKey { get { return Tag; } }
    }
}
