﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserClubPreference:IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string ClubTag { get; set; }

        [ProtoMember(3)]
        public DateTime? LastModifiedDate { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return this.UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return ClubTag;
            }
        }
    }
}
