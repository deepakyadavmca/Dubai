using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    public class WorkoutActivityDetail
    {
        [ProtoMember(1)]
        public DateTime CompletedDate { get; set; }

        [ProtoMember(2)]
        public decimal ActualDurationMinutes { get; set; }

        [ProtoMember(3)]
        public decimal TargetDurationMinutes { get; set; }

        [ProtoMember(4)]
        public string ClassCommitmentTag { get; set; }

        [ProtoMember(5)]
        public string UserWorkoutTag { get; set; }
    }
}