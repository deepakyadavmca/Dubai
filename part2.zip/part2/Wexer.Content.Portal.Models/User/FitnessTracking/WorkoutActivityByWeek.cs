using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    public class WorkoutActivityByWeek
    {
        [ProtoMember(1)]
        public DateTime StartDate { get; set; }

        [ProtoMember(2)]
        public DateTime EndDate { get; set; }

        [ProtoMember(3)]
        public decimal ActualDurationMinutes { get; set; }

        [ProtoMember(4)]
        public decimal TargetDurationMinutes { get; set; }
    }
}