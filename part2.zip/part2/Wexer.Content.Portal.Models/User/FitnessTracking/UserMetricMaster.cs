﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserMetricMaster : IStorageKey
    {

        [ProtoMember(1)]
        public string UserId { get; set; }
       
        [ProtoMember(2)]
        public string MetricTag { get; set; }

        [ProtoMember(3)]
        public string MetricName { get; set; }

        [ProtoMember(4)]
        public string MetricType { get; set; }

        [ProtoMember(5)]
        public string MetricCategory { get; set; }

        [ProtoMember(6)]
        public string MetricLabel { get; set; }

        [ProtoMember(7)]
        public string MetricRefTag { get; set; }

        [ProtoMember(8)]
        public string Unit { get; set; }

        [ProtoMember(9)]
        public string LatestValue { get; set; }

        [ProtoMember(10)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime LatestValueDate { get; set; }

        [ProtoMember(11)]
        public string PersonalBestValue { get; set; }

        [ProtoMember(12)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime PersonalBestValueDate { get; set; }



        public string PartitionKey
        {
            get { return UserId; }
        }

        public string RowKey
        {
            get { return MetricTag; }
        }
    }

    [ProtoContract]
    public enum MetricSection
    {
        [ProtoEnum(Name = "Standard", Value = 10)]
        Standard = 10,

        [ProtoEnum(Name = "Performance", Value = 20)]
        Performance = 20,
    }
}
