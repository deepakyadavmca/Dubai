﻿using System.Collections.Generic;
using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserExerciseSetResult
    {
        [ProtoMember(1)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(2)]
        public int? Reps { get; set; }

        [ProtoMember(3)]
        public decimal? WeightKg { get; set; }

        [ProtoMember(4)]
        public int? RestSeconds { get; set; }

        [ProtoMember(5)]
        public int? IntensityLevel { get; set; }

        [ProtoMember(6)]
        public int? CalorieBurn { get; set; }

        [ProtoMember(7)]
        public int TimePerRep { get; set; }

        [ProtoMember(8)]
        public bool PersonalBest { get; set; }

        [ProtoMember(9)]
        public bool Unilateral { get; set; }

    }

    [ProtoContract]
    public class UserSupersetExerciseSetResult
    {
        [ProtoMember(1)]
        public List<UserSupersetStepResult> Results { get; set; }
        
        [ProtoMember(2)]
        public int? RestInSeconds { get; set; }
    }

    [ProtoContract]
    public class UserSupersetStepResult
    {
        [ProtoMember(1)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(2)]
        public int? Reps { get; set; }

        [ProtoMember(3)]
        public decimal? WeightKg { get; set; }

        [ProtoMember(4)]
        public string ExerciseTag { get; set; }

        [ProtoMember(5)]
        public ExerciseLengthType ExerciseLengthType { get; set; }
    }
}