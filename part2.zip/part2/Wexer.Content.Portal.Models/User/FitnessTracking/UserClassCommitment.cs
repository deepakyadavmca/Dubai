using System;
using System.Security.Permissions;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserClassCommitment : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public string ClubTag { get; set; }

        [ProtoMember(4)]
        public string ClassTypeTag { get; set; }

        [ProtoMember(5)]
        public string Studio { get; set; }

        [ProtoMember(6)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime ClassStartTimeUtc { get; set; }

        [ProtoMember(7)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? VisitTimeUtc { get; set; }

        [ProtoMember(8)]
        public string Mood { get; set; }

        [ProtoMember(9)]
        public string FitnessClassId { get; set; }

        [ProtoMember(10)]
        public string WorkoutResultTag { get; set; }

        [ProtoMember(11)]
        public DateTime? LastModifiedDate { get; set; }

        [ProtoMember(12)]
        public string UserBookingTag { get; set; }

        [ProtoMember(13)]
        public int DurationMinutes { get; set; }

        string IStorageKey.PartitionKey 
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return string.Format("{0}-{1:yyyy-MM-dd}{2:HH:mm}-{3}", ClubTag, ClassStartTimeUtc, ClassStartTimeUtc, ClassTypeTag);
            }
        }
    }
}