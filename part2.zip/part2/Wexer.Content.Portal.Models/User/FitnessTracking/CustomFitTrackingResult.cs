﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class CustomFitTrackingResult
    {
        [ProtoMember(1)]
        public int? Target { get; set; }
        [ProtoMember(2)]
        public int? Actual { get; set; }
    }
}
