using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserWorkoutPreference : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public string ClubTag { get; set; }

        [ProtoMember(4)]
        public string UserWorkoutTag { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return this.UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return string.Format("{0}-{1}", this.ClubTag, this.UserWorkoutTag);
            }
        }
    }
}