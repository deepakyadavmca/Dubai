using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    /// <summary>
    /// is this stored when added/changed
    /// </summary>
    [ProtoContract]
    public class UserExercisePerformance : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string ExerciseTag { get; set; }

        [ProtoMember(3)]
        public int Weight { get; set; }

        [ProtoMember(3)]
        public DateTime LastUpdatedUtc { get; set; }


        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return ExerciseTag;
            }
        }
    }
}