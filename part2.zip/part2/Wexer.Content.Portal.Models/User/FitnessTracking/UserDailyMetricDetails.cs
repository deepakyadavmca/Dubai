﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserDailyMetricDetails
    {
        [ProtoMember(1)]
        public List<UserDailyMetric> userDailyMetric { get; set; }

        [ProtoMember(2)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime StartDate { get; set; }

        [ProtoMember(3)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime EndDate { get; set; }

        [ProtoMember(4)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime MetricStartDate { get; set; }

        [ProtoMember(5)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime MetricEndDate { get; set; }
    }
}
