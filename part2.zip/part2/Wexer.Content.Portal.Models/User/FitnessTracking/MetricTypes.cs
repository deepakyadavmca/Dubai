﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    public class MetricTypes
    {
        public const string BodyWeight = "BodyWeight";
        public const string Steps = "Steps";
        public const string Intensity = "Intensity";
        public const string Skill = "Skill";
        public const string Exercisereps = "ExerciseReps";
        public const string WorkoutTime = "WorkoutTime";
        public const string Calories = "Calories";
        public const string TrainingTIme = "TrainingTime";
        public const string ClubVisits = "ClubVisits";
        public const string ExerciseWeight = "ExerciseWeight";
        public const string WorkoutCalories = "WorkoutCalories";
        public const string StepCalories = "StepCalories";
        public const string ExerciseMeters = "ExerciseMeters";

    }
}
