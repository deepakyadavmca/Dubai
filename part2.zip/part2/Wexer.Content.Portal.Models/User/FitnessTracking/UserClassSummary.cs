using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserClassSummary
    {
        [ProtoMember(1)]
        public string ClassTypeTag { get; set; }

        [ProtoMember(2)]
        public UserWorkoutResult[] ClassResults { get; set; }
    }
}