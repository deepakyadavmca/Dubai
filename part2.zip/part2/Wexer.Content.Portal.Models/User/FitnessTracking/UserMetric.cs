﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserMetric: IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public DateTime UtcDate { get; set; }

        [ProtoMember(3)]
        public string MetricTag { get; set; }

        [ProtoMember(4)]
        public string MetricValue { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return MetricTag;
            }
        }
    }
}