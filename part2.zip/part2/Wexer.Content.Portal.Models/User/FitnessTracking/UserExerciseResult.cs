﻿using System.Collections.Generic;
using System.Linq;
using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserExerciseResult
    {
        public UserExerciseResult()
        {
        }

        public UserExerciseResult(IEnumerable<WorkoutExerciseSlotSuperset> superSets)
        {
            if (superSets == null)
            {
                return;
            }

            var sets = new List<UserSupersetExerciseSetResult>();
            foreach (var superSet in superSets.Where(superSet => superSet.Steps != null && superSet.Steps.Any()))
            {
                var superSetsResult = new UserSupersetExerciseSetResult
                {
                    RestInSeconds = superSet.RestSeconds,
                    
                    Results = new List<UserSupersetStepResult>()
                };

                foreach (var superSetStep in superSet.Steps)
                {
                    var step = new UserSupersetStepResult
                    {
                        DurationSeconds = superSetStep.DurationSeconds,
                        Reps = superSetStep.Reps,
                        WeightKg = superSetStep.WeightKg,
                        ExerciseTag = superSetStep.SelectedExerciseTag,
                        ExerciseLengthType = superSetStep.ExerciseLengthType
                    };

                    superSetsResult.Results.Add(step);
                }

                sets.Add(superSetsResult);
            }
            SuperSetResults = sets.ToArray();
        }

        public UserExerciseResult(IEnumerable<WorkoutExerciseSlotSet> sets)
        {
            if (sets != null)
            {
                Sets = sets.Select(x => new UserExerciseSetResult
                {
                    DurationSeconds = x.DurationSeconds,
                    Reps = x.Reps,
                    RestSeconds = x.RestSeconds,
                    WeightKg = x.WeightKg,
                    IntensityLevel =x.IntensityLevel,
                    CalorieBurn = x.CalorieBurn,
                    Unilateral = x.Unilateral,
                    TimePerRep = x.TimePerRep.GetValueOrDefault()
                }).ToArray();
            }
        }

        public static UserExerciseResult CreateSingleSlotUserExerciseResult(
            int sets,
            string exerciseTag,
            int? durationSeconds,
            int? reps,
            int? restSeconds,
            int? intensityLevel,
            int? calorieBurn,
            ExerciseLengthType exerciseLengthType,
            decimal? weightKg = null)
        {
            var setsList = new List<UserExerciseSetResult>();

            for (var i = 0; i < sets; i++)
            {
                setsList.Add(new UserExerciseSetResult
                {
                    DurationSeconds = durationSeconds,
                    Reps = reps,
                    RestSeconds = restSeconds,
                    WeightKg = weightKg,
                    IntensityLevel = intensityLevel,
                    CalorieBurn = calorieBurn
                });
            }
            
            return new UserExerciseResult
            {
                ExerciseLengthType = exerciseLengthType,
                ExerciseTag = exerciseTag,
                ExerciseType = SlotType.Single,
                Sets = setsList.ToArray()
            };
        }

        [ProtoMember(1)]
        public string ExerciseTag { get; set; }

        [ProtoMember(2)]
        public UserExerciseSetResult[] Sets { get; set; }

        [ProtoMember(3)]
        public SlotType ExerciseType { get; set; }

        [ProtoMember(4)]
        public UserSupersetExerciseSetResult[] SuperSetResults { get; set; }

        [ProtoMember(5)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(6)]
        public ExerciseLengthType? ExerciseLengthType { get; set; }

        [ProtoMember(7)]
        public bool CanTrackWeight { get; set; }

        [ProtoMember(8)]
        public string ExerciseName { get; set; }

       
    }
}
