﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class IndexedUserDetail : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public DateTime BirthDate { get; set; }

        [ProtoMember(3)]
        public string FirstName { get; set; }

        [ProtoMember(4)]
        public string LastName { get; set; }

        [ProtoMember(5)]
        public string Telephone { get; set; }

        [ProtoMember(6)]
        public string MobileTelephone { get; set; }

        [ProtoMember(7)]
        public string EmailAddress { get; set; }

        [ProtoMember(8)]
        public string ClubTag { get; set; }

        [ProtoMember(9)]
        public string Gender { get; set; }

        [ProtoMember(10)]
        public string MembershipNumber { get; set; }

        [ProtoMember(11)]
        public string TenantId { get; set; }

        string IStorageKey.PartitionKey
        {
            get { return UserId; }
        }

        string IStorageKey.RowKey { get { return EmailAddress; } }
    }
}