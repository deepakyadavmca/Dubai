using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserGroup
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string Name { get; set; }

        [ProtoMember(3)]
        public string[] Entitlements { get; set; }

        [ProtoMember(4)]
        public string[] Clubs { get; set; }
    }
}