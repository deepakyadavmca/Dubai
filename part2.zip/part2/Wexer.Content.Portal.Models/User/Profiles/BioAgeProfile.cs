using Wexer.Content.Portal.Models.User.BioAge;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class BioAgeProfile : UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public UserBioAgeResult BioAgeResult { get; set; }
    }
}