﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class UserPaymentProfile : UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        [SensitiveData]
        public string CustomerId { get; set; }

        //[ProtoMember(3)]
        //[SensitiveData]
        //public string EmailAddress { get; set; }

        [ProtoMember(4)]
        public bool LiveMode { get; set; }

        [ProtoMember(5)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(6)]
        public bool Deleted { get; set; }
    }
}
