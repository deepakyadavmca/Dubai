namespace Wexer.Content.Portal.Models.User.Profiles
{
    public abstract class UserProfile
    {
        
    }
}