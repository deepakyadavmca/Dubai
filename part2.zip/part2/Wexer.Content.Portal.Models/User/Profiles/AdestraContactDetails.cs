﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    public class AdestraContactDetails
    {        
        public string CoreTableId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserId { get; set; }
    }

    public class AddContactResponse
    {
        public string id { get; set; }
        public string email { get; set; }
        public string firstname { get; set; }
        public string lastName { get; set; }
    }
    public class AddListResponse
    {
        public string contact_id { get; set; }
        public string list_id { get; set; }
    }
    public class SendConfirmationEmailResponse
    {
        public string contact_id { get; set; }
        public bool? is_new_contact { get; set; }
    }
}
