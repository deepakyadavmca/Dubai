﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class UserReferralProfile :UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string ReferralCode { get; set; }

        [ProtoMember(3)]
        public string ReferrerCode { get; set; }

        [ProtoMember(4)]
        public bool ReferralDiscountReceived { get; set; }

    }
}
