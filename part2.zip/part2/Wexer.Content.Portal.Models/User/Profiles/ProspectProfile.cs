using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class ProspectProfile : UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        
        [ProtoMember(2)]
        [SensitiveData]
        public string EmailAddress { get; set; }
        
        [ProtoMember(3)]
        public string CountryCode { get; set; }
        
        [ProtoMember(4)]
        public string ClubTag { get; set; }

        [ProtoMember(5)]
        public DateTime? DateCreated { get; set; }

        [ProtoMember(6)]
        public DateTime ExpiryDate { get; set; }

        [ProtoMember(7)]
        public DateTime AuthExpiryDate { get; set; }

        [ProtoMember(8)]
        [SensitiveData]
        public string PasswordHash { get; set; }

        [ProtoMember(9)]
        [SensitiveData]
        public string ActivationCode { get; set; }
    }
}