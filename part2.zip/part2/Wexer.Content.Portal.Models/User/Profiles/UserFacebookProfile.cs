﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class UserFacebookProfile : UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        [ProtoMember(2)]
        public string FacebookUserId { get; set; }
        [ProtoMember(3)]
        public string AccessToken { get; set; }
        [ProtoMember(4)]
        public string EmailAddress { get; set; }
        [ProtoMember(5)]
        public string FirstName { get; set; }
        [ProtoMember(6)]
        public string LastName { get; set; }
        [ProtoMember(7)]
        public string CountryCode { get; set; }
        [ProtoMember(8)]
        public string FacebookImageUrl { get; set; }

        [ProtoMember(9)]
        public string ReferrerCode { get; set; }
    }
}
