﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.User.Profiles.Dashboard;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User
{
    public class UserDashboardSummary
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public int Target { get; set; }

        [ProtoMember(3)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime TargetSetDate { get; set; }

        [ProtoMember(4)]
        public TargetType TargetType { get; set; }     
        
    }

    [ProtoContract]
    public class UserTargets
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public virtual UserDailyTargetForSteps DailyStepTarget { get; set; }

        [ProtoMember(3)]
        public virtual UserWeeklyTargetForSteps WeeklyStepTarget { get; set; }

        [ProtoMember(4)]
        public virtual UserDailyTargetForTrainingTime DailyTrainingTarget { get; set; }

        [ProtoMember(5)]
        public virtual UserWeeklyTargetForTrainingTime WeeklyTrainingTarget { get; set; }

        [ProtoMember(6)]
        public virtual UserDailyTargetForCalorie DailyCalorieTarget { get; set; }

        [ProtoMember(7)]
        public virtual UserWeeklyTargetForCalorie WeeklyCalorieTarget { get; set; }
    }
}
