﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Profiles.Dashboard
{
    [ProtoContract]
    public class UserDailyTargetForTrainingTime : IStorageKey
    {
        [ProtoMember(1)]
        public string tag { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime TargetSetDate { get; set; }

        [ProtoMember(4)]
        public int Target { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return TargetSetDate.ToString("yyyyMMddHHmmss");
            }
        }
    }
}
