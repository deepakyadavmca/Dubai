﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.Profiles.Dashboard
{
    [ProtoContract]
    public enum TargetType : byte
    {
        [ProtoEnum(Name = "Steps", Value = 10)]
        Steps = 10,
        [ProtoEnum(Name = "Calorie", Value = 15)]
        Calorie = 15,
        [ProtoEnum(Name = "TrainingTime", Value = 20)]
        TrainingTime = 20,
    }
}
