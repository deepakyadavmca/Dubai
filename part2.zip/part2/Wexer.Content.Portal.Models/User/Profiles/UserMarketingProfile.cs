﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class UserMarketingProfile : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string ContactId { get; set; }

        [ProtoMember(3)]
        public string ListId { get; set; }

        //[ProtoMember(4)]
        //public string UserMarketingStatus { get; set; }

        //[ProtoMember(5)]
        //public bool OptinStatus { get; set; }     

        [ProtoMember(6)]
        public MarketingStatus UserMarketingStatus { get; set; }

        [ProtoMember(7)]
        public bool? OptinStatus { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return ContactId;
            }
        }
    }
}
