﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class UserApplicationProfile : UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        [SensitiveData]
        public string EmailAddress { get; set; }

        [ProtoMember(3)]
        public string CountryCode { get; set; }

        [ProtoMember(4)]
        [SensitiveData]
        public string FirstName { get; set; }

        [ProtoMember(5)]
        [SensitiveData]
        public string LastName { get; set; }

        [ProtoMember(6)]
        [SensitiveData]
        public string PasswordHash { get; set; }
    }
}
