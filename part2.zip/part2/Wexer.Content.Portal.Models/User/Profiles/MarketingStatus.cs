﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public enum MarketingStatus
    {
        [ProtoEnum(Name = "unconfirmed")]
        unconfirmed,

        [ProtoEnum(Name = "confirmed")]
        confirmed,

        [ProtoEnum(Name = "subscribed")]
        subscribed,

        //[ProtoEnum(Name = "unsubscribed")]
        //unsubscribed
    }
}
