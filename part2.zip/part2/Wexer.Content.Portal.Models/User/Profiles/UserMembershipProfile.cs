using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User.Profiles
{
    [ProtoContract]
    public class UserMembershipProfile : UserProfile
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        
        [ProtoMember(2)]
        [SensitiveData]
        public string EmailAddress { get; set; }
        
        [ProtoMember(3)]
        [SensitiveData]
        public string PasswordHash { get; set; }
        
        [ProtoMember(4)]
        public string CountryCode { get; set; }
        
        [ProtoMember(5)]
        public string ClubTag { get; set; }
        
        [ProtoMember(6)]
        public DateTime JoinDate { get; set; }
        
        [ProtoMember(7)]
        public DateTime? LeaveDate { get; set; }

        [ProtoMember(8)]
        public string MembershipNumber { get; set; }

    }
}