namespace Wexer.Content.Portal.Models.User.Profiles
{
    public static class UserProfileTypes
    {
        public const string FitnessFirst = "fitnessfirst";
        public const string Facebook = "facebook"; 
        public const string FitBit = "fitbit";
        public const string RunKeeper = "runkeeper";
        public const string ProspectUser = "prospectuser";
        public const string CustomFitProfile = "customfitprofile";
        public const string BioAgeProfile = "bioageprofile";
        public const string ApplicationProfile = "applicationprofile";
        public const string MembershipProfile = "membershipprofile";
        public const string PaymentProfile = "paymentprofile";
        public const string UserReferralProfile = "userreferralprofile";
    }
}
