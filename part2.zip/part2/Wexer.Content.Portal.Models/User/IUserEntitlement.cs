﻿namespace Wexer.Content.Portal.Models.User
{
    /// <summary>
    /// Defines the properties to determine which entitlements are available for the user via the configured <see cref="UserGroup"/>.
    /// </summary>
    public interface IUserEntitlement
    {
        /// <summary>
        /// Gets or sets the club tag.
        /// </summary>
        /// <value>
        /// The club tag.
        /// </value>
        string ClubTag { get; }

        /// <summary>
        /// Gets or sets the user group tags.
        /// </summary>
        /// <value>
        /// The user group tags.
        /// </value>
        string[] UserGroupTags { get; }
    }
}