﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserToken
    {
        [ProtoMember(1)]
        public string ProviderName { get; set; }

        [ProtoMember(2)]
        public string Hash { get; set; }

        [ProtoMember(3)]
        public string Token { get; set; }

        [ProtoMember(4)]
        public string Secret { get; set; }

        [ProtoMember(5)]
        public DateTime? ExpiryDate { get; set; }

    }
}