﻿using System;
using ProtoBuf;
using Wexer.Content.Portal.Models.Attributes;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserWeeklyTarget
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        [ProtoMember(2)]
        public string TargetType { get; set; }
        [ProtoMember(3)]
        public int Target { get; set; }
        [ProtoMember(4)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime TargetSetDate { get; set; }
    }
}
