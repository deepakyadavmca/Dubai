using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class UserClubVisit
    {
        [ProtoMember(1)]
        public string UserId { get; set; }
        [ProtoMember(2)]
        public string ClubTag { get; set; }
        [ProtoMember(3)]
        public DateTime VisitTimeUtc { get; set; }
    }
}
