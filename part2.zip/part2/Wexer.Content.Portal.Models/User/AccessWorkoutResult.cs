﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class AccessWorkoutResult
    {
        /// <summary>
        /// The swipe idenifier related to the MemberAccess.
        /// </summary>
        [ProtoMember(1)]
        public string AccessId { get; set; }

        /// <summary>
        /// The joined country code and membership number.
        /// </summary>
        [ProtoMember(2)]
        public string MemberAccessTag { get; set; }

        /// <summary>
        /// Either a workout, class or workout result tag.
        /// </summary>
        [ProtoMember(3)]
        public string ResultTag { get; set; }

        /// <summary>
        /// Which type the ResultTag applies to.
        /// </summary>
        [ProtoMember(4)]
        public TrackingResult Source { get; set; }

        /// <summary>
        /// Whether set by user, or intelligently.
        /// </summary>
        [ProtoMember(5)]
        public string ResultSource { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [ProtoMember(6)]
        public int? Actual { get; set; }

        /// <summary>
        /// User Custom Fit primary goal.
        /// </summary>
        [ProtoMember(7)]
        public byte PrimaryGoal { get; set; }

        /// <summary>
        /// User Custom Fit secondary goal.
        /// </summary>
        [ProtoMember(8)]
        public byte? SecondaryGoal { get; set; }

    }
}
