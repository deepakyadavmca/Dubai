﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User
{
    [ProtoContract]
    public class ExerpProfile
    {
        [ProtoMember(1)]
        [SensitiveData]
        public string EmailAddress { get; set; }

        [ProtoMember(2)]
        public string CountryCode { get; set; }

        [ProtoMember(3)]
        public string Token { get; set; }

        [ProtoMember(4)]
        public string ExternalId { get; set; }

        [ProtoMember(5)]
        public string Id { get; set; }

        [ProtoMember(6)]
        public int CenterId { get; set; }
    }
}
