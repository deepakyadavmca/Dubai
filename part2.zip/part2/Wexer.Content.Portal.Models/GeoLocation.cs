using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class GeoLocation
    {
        [ProtoMember(1)]
        public double Longitude { get; set; }
        [ProtoMember(2)]
        public double Latitude { get; set; }
    }
}