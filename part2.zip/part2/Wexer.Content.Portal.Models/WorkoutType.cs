using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum WorkoutType : byte
    {
        [ProtoEnum(Name = "Main", Value = 10)]
        Main = 10,

        [ProtoEnum(Name = "Extra", Value = 20)]
        Extra = 20
    }
}