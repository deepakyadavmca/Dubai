﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.BackgroundTasks
{
    public enum BackgroundActionType
    {
        Activate = 1,
        Cancel = 2
    }
}
