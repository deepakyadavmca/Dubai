﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.BackgroundTasks
{
    public enum ValidateTaskStatus
    {
        Validating,
        Validated,
        Rejected
    }
}
