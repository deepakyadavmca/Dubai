﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.BackgroundTasks
{
    public class BackgroundTaskResult
    {
        public int Total { get; set; }
        public int Currupt { get; set; }
    }

    public class BackgroundTaskProcessResult
    {
        public int Total { get; set; }
        public int Processed { get; set; }
    }
}
