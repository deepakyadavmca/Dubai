﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.BackgroundTasks
{

    [ProtoContract]
    public class BackgroundTaskStatus : IStorageKey
    {

        // Tracking Id
        [ProtoMember(1)]
        public string TaskId { get; set; }

        [ProtoMember(2)]
        public string TenantId { get; set; }

        /// <summary>
        /// Command Name
        /// </summary>
        [ProtoMember(3)]
        public string Name { get; set; }

        /// <summary>
        /// command handler name
        /// </summary>
        [ProtoMember(4)]
        public string Handler { get; set; }

        [ProtoMember(5)]
        public string TaskParameters { get; set; }

        [ProtoMember(6)]
        public string Status { get; set; }

        [ProtoMember(7)]
        public DateTime StartedDateTimeUtc { get; set; }

        [ProtoMember(8)]
        public DateTime EndedDateTimeUtc { get; set; }

        [ProtoMember(9)]
        /// <summary>
        /// an object with statusCode (success=0, failure=1)
        /// </summary>
        public string Result { get; set; }

        [ProtoMember(10)]
        public int ErrorCode { get; set; }

        [ProtoMember(11)]
        public string ErrorMessage { get; set; }

        [ProtoMember(12)]
        public string ErrorReason { get; set; }


        [ProtoMember(13)]
        /// <summary>
        /// string array of Ids skipped
        /// </summary>
        public string ErrorItems { get; set; }

        [ProtoMember(14)]
        /// <summary>
        /// Uploaded file name hash code to get that file from blob storage
        /// </summary>
        public string FileBlobName { get; set; }

        public string PartitionKey
        {
            get { return TaskId; }
        }

        public string RowKey
        {
            get { return StartedDateTimeUtc.ToString("yyyyMMddHHmmss"); }
        }
    }
}
