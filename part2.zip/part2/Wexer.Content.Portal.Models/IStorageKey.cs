namespace Wexer.Content.Portal.Models
{
    public interface IStorageKey
    {
        string PartitionKey { get; }
        string RowKey { get; }
    }
}