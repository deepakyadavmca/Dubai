﻿using System.Collections.Generic;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class QueueSummary
    {
        [ProtoMember(1)]
        public int QueueCount { get; set; }

        [ProtoMember(2)]
        public IEnumerable<QueueData> QueueData { get; set; }
    }
}