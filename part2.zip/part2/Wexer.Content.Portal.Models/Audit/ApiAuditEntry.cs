using System;
using ProtoBuf;
namespace Wexer.Content.Portal.Models.Audit
{
    [ProtoContract]
    public class ApiAuditEntry
    {
        [ProtoMember(1)]
        public string Id { get; set; }

        [ProtoMember(2)]
        public string Application { get; set; }

        [ProtoMember(3)]
        public string User { get; set; }

        [ProtoMember(4)]
        public string Machine { get; set; }

        [ProtoMember(5)]
        public string RequestIpAddress { get; set; }

        [ProtoMember(6)]
        public string RequestContentType { get; set; }

        [ProtoMember(7)]
        public string RequestContentBody { get; set; }

        [ProtoMember(8)]
        public string RequestUri { get; set; }

        [ProtoMember(9)]
        public string RequestMethod { get; set; }

        [ProtoMember(10)]
        public string RequestRouteTemplate { get; set; }

        [ProtoMember(11)]
        public string RequestRouteData { get; set; }

        [ProtoMember(12)]
        public string RequestHeaders { get; set; }

        [ProtoMember(13)]
        public DateTime? RequestTimestamp { get; set; }

        [ProtoMember(14)]
        public string ResponseContentType { get; set; }

        [ProtoMember(15)]
        public string ResponseContentBody { get; set; }

        [ProtoMember(16)]
        public int? ResponseStatusCode { get; set; }

        [ProtoMember(17)]
        public string ResponseHeaders { get; set; }

        [ProtoMember(18)]
        public DateTime? ResponseTimestamp { get; set; }
    }
}