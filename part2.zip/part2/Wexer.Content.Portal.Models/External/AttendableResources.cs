﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Wexer.Content.Portal.Models.External
{
    [XmlRoot(ElementName = "item")]
    public class AttendableResources
    {
        [XmlElement(ElementName = "resource")]
        public Resources[] Resource { get; set; }
    }
    public class Resources
    {
        [XmlElement(ElementName = "externalId")]
        public string ExternalId { get; set; }
        [XmlElement(ElementName = "key")]
        public ResourceKey Key { get; set; }
        [XmlElement(ElementName = "name")]
        public string Name { get; set; }
    }

    public class ResourceKey
    {
        [XmlElement(ElementName = "center")]
        public int Center { get; set; }
        [XmlElement(ElementName = "id")]
        public int Id { get; set; }
    }
}
