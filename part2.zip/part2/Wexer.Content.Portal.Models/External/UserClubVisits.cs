﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Wexer.Content.Portal.Models.External
{
    [XmlRoot("item")]
    public class UserClubVisits
    {
        [XmlElement(ElementName = "center")]
        public int Center { get; set; }

        [XmlElement(ElementName = "date")]
        public DateTime Date { get; set; }

        [XmlElement(ElementName = "personId")]
        public Person PersonId { get; set; }

        [XmlElement(ElementName = "startTime")]
        public string Start { get; set; }

        [XmlElement(ElementName = "stopTime")]
        public string End { get; set; }

        [XmlElement(ElementName = "type")]
        public string Type { get; set; }
    }


    public class Person
    {
        [XmlElement(ElementName = "center")]
        public int Center { get; set; }

        [XmlElement(ElementName = "id")]
        public int Id { get; set; }

        [XmlElement(ElementName = "externalId")]
        public string ExternalId { get; set; }
    }
}
