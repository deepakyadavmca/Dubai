﻿

using ProtoBuf;

namespace Wexer.Content.Portal.Models.Competition
{
    [ProtoContract]
    public class Leaderboard
    {
    }
}
