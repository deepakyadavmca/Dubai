﻿using System;
using ProtoBuf;
using System.Linq;

namespace Wexer.Content.Portal.Models.ExerciseSearch
{
    [ProtoContract]
    public class ExerciseSearchCriteria
    {
        private readonly static char[] Separator = { ',' };

        // ReSharper disable InconsistentNaming

        [ProtoMember(1)]
        public int? take { get; set; }

        [ProtoMember(2)]
        public int? skip { get; set; }

        [ProtoMember(3)]
        public string goals { get; set; }

        [ProtoMember(4)]
        public string types { get; set; }

        [ProtoMember(5)]
        public string levels { get; set; }

        [ProtoMember(6)]
        public string areas { get; set; }

        [ProtoMember(7)]
        public string equipment { get; set; }

        [ProtoMember(8)]
        public string sort { get; set; }

        [ProtoMember(9)]
        public string dir { get; set; }

        [ProtoMember(10)]
        public string query { get; set; }

        [ProtoMember(11)]
        public int? favourites { get; set; }

        [ProtoMember(12)]
        public string exercises { get; set; }

        [ProtoMember(13)]
        public string languageTag { get; set; }

        [ProtoMember(14)]
        public string exerciseType { get; set; }

        [ProtoMember(15)]
        public string skills { get; set; }

        [ProtoMember(16)]
        public string keywords { get; set; }

        // ReSharper restore InconsistentNaming

        public bool MatchAll()
        {
            return ((string.IsNullOrWhiteSpace(query)) &&
                    (string.IsNullOrWhiteSpace(types)) &&
                    (string.IsNullOrWhiteSpace(areas)) &&
                    (string.IsNullOrWhiteSpace(levels)) &&
                    (string.IsNullOrWhiteSpace(equipment)) &&
                    (string.IsNullOrWhiteSpace(exercises)) &&
                    (string.IsNullOrEmpty(exerciseType)) &&
                    (string.IsNullOrEmpty(skills)));
        }

        public string[] GetTypes()
        {
            return GetCollection(types);
        }

        public string[] GetLevels()
        {
            return GetCollection(levels);
        }

        public string[] GetAreas()
        {
            return GetCollection(areas);
        }

        public string[] GetEquipment()
        {
            return GetCollection(equipment);
        }

        public string[] GetExercises()
        {
            return GetCollection(exercises);
        }

        public int[] GetSkills()
        {
            return GetIntCollection(skills);
        }

        private static string[] GetCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                : new string[0];
        }

        private static int[] GetIntCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray()
                : new int[0];
        }


        public string[] GetExerciseTypes()
        {
            return GetCollection(exerciseType);
        }

        public string[] GetGoals()
        {
            return GetCollection(goals);
        }

        public string[] GetKeywords()
        {
            return GetKeywordCollection(keywords);
        }
        private static string[] GetKeywordCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                : new string[0];
        }
    }
}
