﻿namespace Wexer.Content.Portal.Models.ExerciseSearch
{
    public class ExerciseSearchResult
    {
        public ExerciseSearchResultItem[] Items { get; set; }
        public int ItemsRemaining { get; set; }
        public int Total { get; set; }

        public ExerciseSearchResult()
        {
            Items = new ExerciseSearchResultItem[0];
        }
    }
}