﻿using Wexer.Content.Portal.Models.FitnessTracking;

namespace Wexer.Content.Portal.Models.ExerciseSearch
{
    public class ExerciseSearchResultItem
    {
        public string ExerciseTag { get; set; }
        public Exercise Exercise { get; set; }
        public string PrimaryMuscleGroups { get; set; }
        public string SecondaryMuscleGroups { get; set; }
        public string EquipmentTypes { get; set; }
        public bool CanTrackWeight { get; set; }
    }
}
