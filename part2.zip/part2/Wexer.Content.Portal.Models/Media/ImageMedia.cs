using System.IO;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Media
{

    [ProtoContract]
    public class ImageMedia
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string MimeType { get; set; }

        [ProtoMember(3)]
        public string ETag { get; set; }

        [ProtoMember(4)]
        public string MediaCategory { get; set; }

        [ProtoMember(5)]
        public string Url { get; set; }

        public string GetImageTag()
        {
            return Tag != null ? Path.GetFileNameWithoutExtension(Tag) : null;
        }
    }
}