using System.ComponentModel.DataAnnotations;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Media
{
    [ProtoContract]
    public class VideoMedia
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string MimeType { get; set; }

        [ProtoMember(3)]
        public string ETag { get; set; }

        [ProtoMember(4)]
        public string MediaCategory { get; set; }

        [ProtoMember(5)]
        public string Url { get; set; }
    }
}