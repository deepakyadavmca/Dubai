﻿using System;

namespace Wexer.Content.Portal.Models.Events
{
    public class EventData
    {
        public string EventName { get; set; }

        public string UserHash { get; set; }

        public string VideoId { get; set; }

        public DateTime? SessionStart { get; set; }

        public DateTime? SessionEnd { get; set; }

        public int SessionDuration { get; set; }

        public bool Billable { get; set; }

        public string ExternalIdentifier { get; set; }
    }
}
