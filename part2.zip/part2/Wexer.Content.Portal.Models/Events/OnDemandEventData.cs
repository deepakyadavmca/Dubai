﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.Events
{
    public class OnDemandEventData
    {
        public string TenantId { get; set; }
        public List<EventData> Events { get; set; }

    }
}
