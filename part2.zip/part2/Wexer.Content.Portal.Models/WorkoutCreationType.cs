﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum WorkoutCreationType : byte
    {
        [ProtoEnum(Name = "Generated", Value = 0)]
        Generated = 0,
        [ProtoEnum(Name = "Created", Value = 1)]
        Created = 1,
        [ProtoEnum(Name = "PremiumPlan", Value = 2)]
        PremiumPlan = 2
    }
}
