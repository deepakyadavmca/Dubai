﻿using ProtoBuf;


namespace Wexer.Content.Portal.Models.PremiumPlan
{
    [ProtoContract]
    public class PremiumPlanAdvert
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string PremiumPlanTag { get; set; }

        [ProtoMember(3)]
        public LocalisedText Title { get; set; }

        [ProtoMember(4)]
        public LocalisedText Description { get; set; }

        [ProtoMember(5)]
        public LocalisedText Quote { get; set; }

        [ProtoMember(6)]
        public LocalisedText QuoteAuthor { get; set; }

        [ProtoMember(7)]
        public string QuoteImageUrl { get; set; }

    }
}
