﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.PremiumPlan
{
     [ProtoContract]
    public enum PremiumPlanPrimaryMetric : byte
    {
         //[ProtoEnum(Name = "BodyWeight", Value = 0)]
         //BodyWeight = 0,

         [ProtoEnum(Name = "Calorie", Value = 50)]
         Calorie = 50,

         [ProtoEnum(Name = "WeightLifted", Value = 100)]
         WeightLifted = 100,

         [ProtoEnum(Name = "TrainingTime", Value = 150)]
         TrainingTime = 150,
    }
}
