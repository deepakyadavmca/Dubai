﻿using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Models.VirtualClasses;
using ProtoBuf;
using System.Collections;
using System.Collections.Generic;


namespace Wexer.Content.Portal.Models.PremiumPlan
{
    [ProtoContract]
    public class PremiumPlanStage
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string PremiumPlanTag { get; set; }

        [ProtoMember(3)]
        public LocalisedText ShortName { get; set; }

        [ProtoMember(4)]
        public LocalisedText LongName { get; set; }

        [ProtoMember(5)]
        public LocalisedText Description { get; set; }

        [ProtoMember(6)]
        public int StageNumber { get; set; }

        [ProtoMember(7)]
        public LocalisedText StageCompleteText { get; set; }

        [ProtoMember(8)]
        public int Duration { get; set; }

        [ProtoMember(10)]
        public WorkoutTemplate[] WorkoutTemplate { get; set; }

        [ProtoMember(11)]
        public PremiumPlanWorkoutSlot[] StageSlots { get; set; }


        [ProtoMember(12)]
        public IDictionary<string, string> StageSlotItems { get; set; }
        //Key= workoutSlotTag_trainingStyle
        //Value = workoutTemplateTag

        //[ProtoMember(13)]
        //public IDictionary<string, object> StageSlotItems { get; set; }

        [ProtoMember(13)]
        public VirtualClass[] VirtualClass { get; set; }

        /// <summary>
        /// Returns a stage workout slot from a key previously generated using <see cref="WorkoutTemplateExerciseSlot.GetKey()"/>.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetSlotWorkoutTemplate(string key)
        {
            if (StageSlotItems == null)
            {
                StageSlotItems = new Dictionary<string, string>();
            }
            if (StageSlotItems.ContainsKey(key))
            {
                return StageSlotItems[key];
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Returns the stageSlot Item Key 
        /// </summary>
        /// <param name="stageSlotTag"></param>
        /// <param name="trainingStyle"></param>
        /// <returns></returns>
        public static string GenerateStageSlotItemKey(string stageSlotTag, TrainingStyle trainingStyle)
        {
            return string.Format("{0}|{1}", stageSlotTag, trainingStyle);
        }
    }
}
