﻿using System;
using ProtoBuf;
using Wexer.Content.Portal.Models.Attributes;


namespace Wexer.Content.Portal.Models.PremiumPlan
{
    [ProtoContract]
    public class PremiumPlanTemplate
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Title { get; set; }

        [ProtoMember(3)]
        public string InternalName { get; set; }

        [ProtoMember(4)]
        public LocalisedText CardShortDescription { get; set; }

        //[ProtoMember(5)]
        //public LocalisedText Description { get; set; }

        [ProtoMember(6)]
        public PremiumPlanPrimaryMetric PrimaryMetric { get; set; }

        [ProtoMember(7)]
        public string FeaturedCountries { get; set; }

        [ProtoMember(8)]
        public bool Active { get; set; }

        [ProtoMember(9)]
        public PremiumPlanAdvert PremiumPlanAdvert { get; set; }

        [ProtoMember(10)]
        public PremiumPlanStage[] PremiumPlanStage { get; set; }

        [ProtoMember(11)]
        public FitnessExperience PlanLevels { get; set; }

        [ProtoMember(12)]
        public string AvailableCountry { get; set; }

        [ProtoMember(13)]
        public string PlanDashboardImageUrl { get; set; }

        [ProtoMember(14)]
        public string PlanImageUrl { get; set; }

        [ProtoMember(15)]
        public LocalisedText PlanVideoUrl { get; set; }

        [ProtoMember(16)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(17)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(18)]
        public int PlanLength { get; set; }

        [ProtoMember(19)]
        public LocalisedText PlanCompleteText { get; set; }

        [ProtoMember(20)]
        public LocalisedText PlanEquipment { get; set; }

        [ProtoMember(21)]
        public TrainingStyle[] TrainingStyles { get; set; }

       

    }
}
