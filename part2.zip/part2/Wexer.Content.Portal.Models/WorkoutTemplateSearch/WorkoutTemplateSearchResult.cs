﻿using Wexer.Content.Portal.Models.FitnessTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.WorkoutTemplateSearch
{
    public class WorkoutTemplateSearchResult
    {
        public WorkoutTemplateSearchResultItem[] Items { get; set; }
        public int ItemsRemaining { get; set; }
        public int Total { get; set; }

        public WorkoutTemplateSearchResult()
        {
            Items = new WorkoutTemplateSearchResultItem[0];
        }
    }

    public class WorkoutTemplateSearchResultItem
    {
        public string TemplateTag { get; set; }
        public WorkoutTemplate WorkoutTemplate { get; set; }
    }
}