﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.WorkoutTemplateSearch
{
    [ProtoContract]
    public class WorkoutTemplateSearchCriteria
    {
        private readonly static char[] Separator = { ',' };

        [ProtoMember(1)]
        public int? take { get; set; }

        [ProtoMember(2)]
        public int? skip { get; set; }

        [ProtoMember(3)]
        public string query { get; set; }

        [ProtoMember(4)]
        public string languageTag { get; set; }

        [ProtoMember(5)]
        public string skills { get; set; }

        [ProtoMember(6)]
        public string goals { get; set; }

        [ProtoMember(7)]
        public string equipments { get; set; }

        [ProtoMember(8)]
        public string duration { get; set; }

        [ProtoMember(9)]
        public string dir { get;set; }

        [ProtoMember(10)]
        public string sort { get; set; }

        public string[] GetSkills()
        {
            return GetCollection(skills);
        }

        public string[] GetGoals()
        {
            return GetCollection(goals);
        }

        public string[] GetEquipments()
        {
            return GetCollection(equipments);
        }

        public int[] GetDurations()
        {
            return GetIntCollection(duration);
        }

        private static string[] GetCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                : new string[0];
        }

        private static int[] GetIntCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray()
                : new int[0];
        }


        public bool MatchAll()
        {
            return (string.IsNullOrWhiteSpace(query) &&
                (string.IsNullOrWhiteSpace(skills)) &&
                (string.IsNullOrWhiteSpace(goals)) &&
                (string.IsNullOrWhiteSpace(equipments)) &&
                (string.IsNullOrWhiteSpace(duration)));
        }
    }
}