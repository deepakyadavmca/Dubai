﻿using System;

namespace Wexer.Content.Portal.Models.Attributes
{
    public enum SpecializedType
    {
        UtcDateTime,
    }

    public class SpecializedPropertyAttribute : Attribute
    {
        public SpecializedType Type { get; set; }
    }
}
