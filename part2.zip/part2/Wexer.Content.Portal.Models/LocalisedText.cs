using System;
using System.Linq;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class LocalisedText : IComparable
    {
        [ProtoMember(1)]
        public string InvariantText { get; set; }

        [ProtoMember(2)]
        public LocalText[] LocalTexts { get; set; }

        public LocalisedText() { }
        public LocalisedText(string value)
        {
            InvariantText = value;
        }

        /// <summary>
        /// Initialise a LocalisedText instance using the values in an other LocalisedText instance
        /// </summary>
        public LocalisedText(LocalisedText other)
        {
            if (other == null)
            {
                return;
            }

            InvariantText = other.InvariantText;
            if (other.LocalTexts != null)
            {
                LocalTexts = (from LocalText possibleLocalText in other.LocalTexts
                              select new LocalText()
                              {
                                  IETFTag = possibleLocalText.IETFTag,
                                  Text = possibleLocalText.Text
                              }).ToArray();
            }
        }

        protected bool Equals(LocalisedText other)
        {
            return string.Equals(InvariantText, other.InvariantText) && Equals(LocalTexts, other.LocalTexts);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }
            if (ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != GetType())
            {
                return false;
            }
            return Equals((LocalisedText)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((InvariantText != null ? InvariantText.GetHashCode() : 0) * 397) ^ (LocalTexts != null ? LocalTexts.GetHashCode() : 0);
            }
        }

        public int CompareTo(object obj)
        {
            return 0;
        }

        public static implicit operator string(LocalisedText x)
        {
            return x == null ? string.Empty : x.InvariantText;
        }

        public static implicit operator LocalisedText(string x)
        {
            return new LocalisedText(x);
        }

        public override string ToString()
        {
            return InvariantText ?? string.Empty;
        }

        public string Text(string ietfTag)
        {
            var localText = default(LocalText);

            if (LocalTexts != null)
            {
                localText = LocalTexts.FirstOrDefault(x => x.IETFTag == ietfTag);
            }

            return localText == null ? InvariantText : localText.Text;
        }
    }
}