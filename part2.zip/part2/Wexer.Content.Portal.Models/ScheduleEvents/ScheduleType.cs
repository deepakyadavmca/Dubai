﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ScheduleEvents
{
    public enum ScheduleType
    {
        Weekly = 1,
        Weekdays = 2
    }
}
