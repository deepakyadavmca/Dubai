﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ScheduleEvents
{
    [ProtoContract]
    public class Schedule
    {
        [ProtoMember(1)]
        public ScheduleType Type { get; set; }

        [ProtoMember(2)]
        public int[] Weekdays { get; set; }

        [ProtoMember(3)]
        public DateTime Daily_Time { get; set; }
        public string Next_Occurence_Time { get; set; }
    }
}
