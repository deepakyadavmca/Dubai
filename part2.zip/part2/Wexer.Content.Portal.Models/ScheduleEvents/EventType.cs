﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ScheduleEvents
{
    public enum EventType
    {
        FeelsLikeLive = 1,
        TrueLive = 2
    }
}
