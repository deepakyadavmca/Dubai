﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Models.VirtualClasses;

namespace Wexer.Content.Portal.Models.ScheduleEvents
{
    [ProtoContract]
    public class PublishingSlot
    {
        [ProtoMember(1)]
        public string ScheduleMessageSequenceNumber { get; set; }

        [ProtoMember(2)]
        public VirtualClass Video { get; set; }

        [ProtoMember(3)]
        public DateTime Publish_Schedule_Time { get; set; }

        [ProtoMember(4)]
        public bool PublishedToTenant { get; set; }
    }
}
