﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.VirtualClasses;

namespace Wexer.Content.Portal.Models.ScheduleEvents
{
    [ProtoContract]
    public class ScheduleEvent : IStorageKey
    {
        [ProtoMember(1)]
        public string Event_Id { get; set; }

        [ProtoMember(2)]
        public LocalisedText Title { get; set; }

        [ProtoMember(3)]
        public LocalisedText Description { get; set; }

        [ProtoMember(4)]
        public string ImageUrl { get; set; }

        [ProtoMember(5)]
        public bool Active { get; set; }

        [ProtoMember(6)]
        public DateTime Scheduled_Time { get; set; } // first occurence time

        [ProtoMember(7)]
        public EventType Type { get; set; }

        [ProtoMember(8)]
        public string TenantId { get; set; }

        [ProtoMember(9)]
        public Schedule Schedule { get; set; }

        [ProtoMember(10)]
        public VirtualClass Video { get; set; }

        [ProtoMember(11)]
        public PublishingSlot Slot { get; set; }

        [ProtoMember(12)]
        public DateTime? CreationDate { get; set; }

        [ProtoMember(13)]
        public bool AllowAutoPublish { get; set; }

        [ProtoMember(14)]
        public EventStatus EventStatus { get; set; }

        [ProtoMember(15)]
        public string EventKey { get; set; }

        [ProtoMember(16)]
        public string LiveChannelId { get; set; }

        public bool IsLocked { get; set; }

        public string PartitionKey
        {
            get
            {
                return TenantId;
            }
        }

        public string RowKey
        {
            get
            {
                return Event_Id;
            }
        }

        public async Task SetNextOccurence()
        {
            try
            {
                if (Schedule != null && Scheduled_Time > DateTime.MinValue && Schedule.Daily_Time > DateTime.MinValue)
                {
                    var occurTime = Schedule.Daily_Time.TimeOfDay;
                    DateTime lastOccurence = DateTime.MinValue;
                    DateTime scheduleTimeWithDuration = DateTime.MinValue;

                    if (Video != null && Video.DurationSecond != 0)
                    {
                        scheduleTimeWithDuration = Scheduled_Time.AddSeconds(Video.DurationSecond);
                    }
                    else
                    {
                        scheduleTimeWithDuration = Scheduled_Time;
                    }

                    if (DateTime.UtcNow > scheduleTimeWithDuration)
                    {
                        lastOccurence = scheduleTimeWithDuration.AddDays(1).AddDays((Schedule.Weekdays.First() - Convert.ToInt32(scheduleTimeWithDuration.AddDays(1).DayOfWeek) + 7) % 7);
                        while (DateTime.UtcNow > lastOccurence)
                        {
                            lastOccurence = lastOccurence.AddDays(1).AddDays((Schedule.Weekdays.First() - Convert.ToInt32(lastOccurence.AddDays(1).DayOfWeek) + 7) % 7);
                        }
                    }
                    else
                    {
                        lastOccurence = scheduleTimeWithDuration;
                    }

                    Schedule.Next_Occurence_Time = new DateTime(lastOccurence.Year, lastOccurence.Month, lastOccurence.Day, occurTime.Hours, occurTime.Minutes, 0).ToString("yyy-MM-ddTHH:mm:ss");

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //public async Task SetNextOccurence()
        //{
        //    try
        //    {
        //        if (Schedule != null && Scheduled_Time > DateTime.MinValue && Schedule.Daily_Time > DateTime.MinValue)
        //        {
        //            var occurTime = Schedule.Daily_Time.TimeOfDay;
        //            DateTime nextOcurrence = DateTime.MinValue;

        //            if (DateTime.UtcNow > (Scheduled_Time.Date + occurTime))
        //            {
        //                nextOcurrence = DateTime.UtcNow.AddDays(1).AddDays((Schedule.Weekdays.First() - Convert.ToInt32(DateTime.UtcNow.AddDays(1).DayOfWeek) + 7) % 7);
        //            }
        //            else
        //            {
        //                nextOcurrence = Scheduled_Time;
        //            }

        //            Schedule.Next_Occurence_Time = new DateTime(nextOcurrence.Year, nextOcurrence.Month, nextOcurrence.Day, occurTime.Hours, occurTime.Minutes, 0).ToString("yyy-MM-ddTHH:mm:ss");

        //        }
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}


        public async Task GetEventLockStatus()
        {
            try
            {
                if (!string.IsNullOrEmpty(Schedule.Next_Occurence_Time))
                {
                    var timeToNextEvent = DateTime.Parse(Schedule.Next_Occurence_Time) - DateTime.UtcNow;
                    var timepassedSinceLastEvent = DateTime.UtcNow - Scheduled_Time;
                    if (Active)
                    {
                        if ((timepassedSinceLastEvent.TotalHours < 0 || timepassedSinceLastEvent.TotalHours > 4.0) && timeToNextEvent.TotalHours > 4.0) // allow editing only 4 hours after and 4 hours before event occurence
                        {
                            IsLocked = false;
                        }
                        else
                        {
                            IsLocked = true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
