﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum TrackingResult
    {
        [ProtoEnum(Name = "UnTracked", Value = 0)]
        UnTracked = 0,

        [ProtoEnum(Name = "DidNotWorkout", Value = 1)]
        DidNotWorkout = 1,

        [ProtoEnum(Name = "Workout", Value = 2)]
        Workout = 2,

        [ProtoEnum(Name = "WorkoutResult", Value = 3)]
        WorkoutResult = 3,

        [ProtoEnum(Name = "Class", Value = 4)]
        Class = 4,

        [ProtoEnum(Name = "Challenge", Value = 5)]
        Challenge = 5,

        [ProtoEnum(Name = "Plan", Value = 6)]
        PremiumPlan = 6,

        [ProtoEnum(Name = "VirtualClass", Value = 7)]
        VirtualClass = 7,

        [ProtoEnum(Name = "Vimeo", Value = 8)]
        Vimeo = 8,

        [ProtoEnum(Name = "LiveStream", Value = 9)]
        LiveStream = 9,

        [ProtoEnum(Name = "Channel", Value = 10)]
        Channel = 10
    }
}
