﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class Admin
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string Name { get; set; }

        [ProtoMember(3)]
        public string Contact { get; set; }

        [ProtoMember(4)]
        public string PhoneNumber { get; set; }

        [ProtoMember(5)]
        public string Email { get; set; }
    }
}
