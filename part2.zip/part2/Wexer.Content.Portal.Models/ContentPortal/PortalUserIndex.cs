﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class PortalUserIndex : IStorageKey
    {
        [ProtoMember(1)]
        public string UserIdentifier { get; set; } // provider's firebase id

        [ProtoMember(2)]
        public string TenantId { get; set; } // use wexer as tenantid for portal users

        [ProtoMember(3)]
        public string Email { get; set; }

        [ProtoMember(4)]
        public string DisplayName { get; set; }

        [ProtoMember(5)]
        public string Contact { get; set; }

        [ProtoMember(6)]
        public string PhoneNumber { get; set; }
        public string PartitionKey
        {
            get
            {
                return TenantId.ToLowerInvariant();
            }
        }

        public string RowKey
        {
            get
            {
                return UserIdentifier;
            }
        }
    }
}
