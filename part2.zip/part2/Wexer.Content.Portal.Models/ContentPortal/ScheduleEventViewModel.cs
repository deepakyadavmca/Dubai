﻿using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Models.ScheduleEvents;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class ScheduleEventViewModel
    {
        public string Event_Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public bool Active { get; set; }
        public DateTime Schedule_Time { get; set; }
        public EventType Type { get; set; }
        public Schedule Schedule { get; set; }
        public string TenantId { get; set; }
        public VirtualClassViewModel Video { get; set; }
        public bool AllowAutoPublish { get; set; }


    }
}
