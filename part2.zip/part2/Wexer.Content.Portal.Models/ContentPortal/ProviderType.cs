﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public enum ProviderType
    {
        [ProtoEnum(Name = "Regular", Value = 0)]
        Regular = 0,

        [ProtoEnum(Name = "Tenant", Value = 1)]
        Tenant = 1
    }
}
