﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public enum Roles
    {
        Admin = 0,
        Provider = 1,
        ClientProvider = 2
    }
}
