﻿using Wexer.Content.Portal.Models.ContentPortal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class ChannelViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ProfileImageUrl { get; set; }
        public string DisplayName { get; set; }
        public string MediaSpaceImageUrl { get; set; }
        public List<ChannelAvailability> Availability { get; set; }
        public bool Active { get; set; }
        public string Tag { get; set; }
        public string Provider { get; set; }
        public List<string> Tenants { get; set; }
        public bool IsTenantProviderChannel { get; set; }
    }
}
