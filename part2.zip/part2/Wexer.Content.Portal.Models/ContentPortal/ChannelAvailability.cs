﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public enum ChannelAvailability
    {
        [ProtoEnum(Name = "InClub", Value = 0)]
        InClub = 0,
        [ProtoEnum(Name = "AppAndWeb", Value = 1)]
        AppAndWeb = 1,
        [ProtoEnum(Name = "Hotel", Value = 2)]
        Hotel = 2
    }
}
