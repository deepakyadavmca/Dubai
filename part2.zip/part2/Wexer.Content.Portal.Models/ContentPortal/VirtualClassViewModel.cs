﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class VirtualClassViewModel
    {

        public string Tag { get; set; }


        public string ClassName { get; set; }


        public string ClassDescription { get; set; }


        public string ClassLanguage { get; set; }


        public string Provider { get; set; }


        public string Instructor { get; set; }


        public string ImageLink { get; set; }


        public string StreamingLink { get; set; }


        public string ClassCategory { get; set; }

        public int ClassCategoryId { get; set; }

        public int Intensity { get; set; }


        public int Skill { get; set; }


        public int DurationSecond { get; set; }


        public string[] Equipments { get; set; }


        public string Keywords { get; set; }


        public DateTime? StartDate { get; set; }


        public DateTime? EndDate { get; set; }


        public DateTime CreationDate { get; set; }


        public DateTime LastModifiedDate { get; set; }


        public string ProviderID { get; set; }


        public bool IsEquipment { get; set; }


        public string ClassLanguageCode { get; set; }


        public string AlternateLink { get; set; }


        public string FileName { get; set; }


        public MediaProcessingStatus Status { get; set; }


        public MediaProcessingError ErrorType { get; set; }


        public string JobID { get; set; }


        public string Level { get; set; }


        public bool Featured { get; set; }


        public string TrailerLinkWeb { get; set; }


        public string TrailerLinkMobile { get; set; }


        public string TrailerName { get; set; }


        public DateTime? ScheduleDate { get; set; }

        //[ProtoMember(34)]
        //public List<int> LabelIds { get; set; }


        public List<string> PublishedTenants { get; set; }


        public List<string> Labels { get; set; }


        public string ChannelId { get; set; }


        public string[] FocusArea { get; set; }


        public string ClassSubCategory { get; set; }

        public string SourceProviderId { get; set; }
        public bool IsMigrating { get; set; }

        public List<string> EquipmentTypeTags { get; set; }
        public List<string> FocusAreaTags { get; set; }

        public ProviderType ProviderType { get; set; }
    }
}
