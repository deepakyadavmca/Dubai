﻿using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Models.OnDemandCollection;
using Wexer.Content.Portal.Models.VirtualClasses;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class OnDemandCollectionViewModel
    {

        public string Tag { get; set; }

        public string InternalName { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public string AvailableCountry { get; set; }

        public OnDemandCollectionSection[] Section { get; set; }


        public DateTime CreationDate { get; set; }

        public DateTime LastModifiedDate { get; set; }

        public string TenantId { get; set; }

        public bool IsFeaturedCollection { get; set; }

        public int SequenceNumber { get; set; }

        public string Description { get; set; }

        public bool IsClassOfDayCollection { get; set; }

    }
}
