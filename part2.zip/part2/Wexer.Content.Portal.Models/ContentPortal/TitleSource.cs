﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public enum TitleSource
    {
        Normal = 0,
        Event = 1
    }
}
