﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class Provider
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string Name { get; set; }

        [ProtoMember(3)]
        public string Contact { get; set; }

        [ProtoMember(4)]
        public string PhoneNumber { get; set; }

        [ProtoMember(5)]
        public string Email { get; set; }

        [ProtoMember(6)]
        public string ProviderId { get; set; }

        [ProtoMember(7)]
        public bool Stage1Encode { get; set; }

        [ProtoMember(8)]
        public string TenantId { get; set; }

        [ProtoMember(9)]
        public bool IsTenantProvider { get; set; }
        
        [ProtoMember(10)]
        public MediaPlatform MediaPlatform { get; set; }

        [ProtoMember(11)]
        public string JWPlayerSiteId { get; set; }
    }
}
