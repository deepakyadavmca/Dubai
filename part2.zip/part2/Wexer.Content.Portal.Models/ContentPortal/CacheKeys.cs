﻿
namespace Wexer.Content.Portal.Models.ContentPortal
{
    public static class CacheKeys
    {
        public static string Providers = "providers";
        public static string Channels = "channels";
        public static string Tenants = "tenants";
        public static string VirtualClass = "virtualclass";
        public static string Metadata = "metadata";
    }
}
