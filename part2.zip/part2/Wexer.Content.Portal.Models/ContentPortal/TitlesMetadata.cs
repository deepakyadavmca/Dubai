﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class TitlesMetadata
    {
        public TitlesMetadata()
        {
            Equipments = new List<PortalEquipmentType>();
            Categories = new List<Category>();
            Providers = new List<string>();
            Language = new List<Language>();
            Duration = new List<int>();
            Intensity = new List<int>();
            //SubCategories = new List<SubCategory>();
            FocusAreas = new List<PortalMuscleGroup>();
            Labels = new List<LocalisedText>();
            Keywords = new List<LocalisedText>();
        }
        [ProtoMember(1)]
        public List<PortalEquipmentType> Equipments { get; set; } // todo create model for equipment replica of platform equipments to accomodate image url

        [ProtoMember(2)]
        public List<Category> Categories { get; set; }

        [ProtoMember(3)]
        public List<string> Providers { get; set; }

        [ProtoMember(4)]
        public List<Language> Language { get; set; }

        [ProtoMember(5)]
        public List<int> Duration { get; set; }

        [ProtoMember(6)]
        public List<int> Intensity { get; set; }

        //[ProtoMember(7)]
        //public List<SubCategory> SubCategories { get; set; }
        [ProtoMember(8)]
        public List<PortalMuscleGroup> FocusAreas { get; set; }  // todo create model for focusarea replica of platform musclegroups

        [ProtoMember(9)]
        public List<LocalisedText> Labels { get; set; }

        //[ProtoMember(10)]
        //public List<Language> Languages { get; set; }

        [ProtoMember(11)]
        public List<LocalisedText> Keywords { get; set; }

        [ProtoMember(12)]
        public List<int> SkillLevel { get; set; }
    }

    [ProtoContract]
    public class Category
    {        
        public Category()
        {
            Subcategory = new List<LocalisedText>();
        }

        [ProtoMember(1)]
        public int Id { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        [ProtoMember(3)]
        public List<LocalisedText> Subcategory { get; set; }

        [ProtoMember(4)]
        public LocalisedText Description { get; set; }
    }

    [ProtoContract]
    public class SubCategory
    {
        [ProtoMember(1)]
        public LocalisedText Name { get; set; }
        [ProtoMember(2)]
        public int CategoryId { get; set; }
    }
}
