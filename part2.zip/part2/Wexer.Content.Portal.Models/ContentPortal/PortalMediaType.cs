﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public enum PortalMediaType
    {
        [ProtoEnum(Name = "Video", Value = 0)]
        Video,

        [ProtoEnum(Name = "Image", Value = 1)]
        Image,

        [ProtoEnum(Name = "Audio", Value = 2)]
        Audio,
    }
}
