﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Wexer.Content.Portal.Models.VirtualClasses;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class Channel
    {
        public Channel()
        {
            Tenants = new List<string>();
            Availability = new List<ChannelAvailability>();
        }

        [ProtoMember(1)]
        public LocalisedText Name { get; set; }

        [ProtoMember(2)]
        public LocalisedText Description { get; set; }

        [ProtoMember(3)]
        public string ProfileImageUrl { get; set; }

        [ProtoMember(4)]
        public LocalisedText DisplayName { get; set; }

        [ProtoMember(5)]
        public string MediaSpaceImageUrl { get; set; }

        //[ProtoMember(6)]
        //public ChannelAvailability ChannelAvailability { get; set; }

        [ProtoMember(7)]
        public bool Active { get; set; }

        [ProtoMember(8)]
        public List<string> Tenants { get; set; }

        //[ProtoMember(9)]
        //public List<string> Providers { get; set; }

        [ProtoMember(10)]
        public string Tag { get; set; }

        [ProtoMember(11)]
        public string Provider { get; set; }

        [ProtoMember(12)]
        public List<ChannelAvailability> Availability { get; set; }

        [ProtoMember(13)]
        public DateTime? CreatedDate { get; set; }

        [ProtoMember(14)]
        public DateTime? LastUpdatedDate { get; set; }

        [ProtoMember(15)]
        public VirtualClass Title { get; set; }

        [ProtoMember(16)]
        public bool IsTenantProviderChannel { get; set; }
    }
}
