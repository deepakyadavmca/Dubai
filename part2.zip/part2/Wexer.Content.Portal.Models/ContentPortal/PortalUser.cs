﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class PortalUser
    {

        [Required(ErrorMessage = "Email is invalid", AllowEmptyStrings = false)]
        [EmailAddress(ErrorMessage = "Email is invalid")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Displayname is invalid", AllowEmptyStrings = false)]
        public string DisplayName { get; set; }

        [Required(ErrorMessage = "Role is invalid")]
        [Range(0, 2, ErrorMessage = "Role out of range")]
        public Roles UserRole { get; set; }

        [Required(ErrorMessage = "Password cannot be empty", AllowEmptyStrings = false)]
        public string Password { get; set; }
        public string PhotoUrl { get; set; }
        public string PhoneNumber { get; set; }
        public string UId { get; set; }
        public string Contact { get; set; }
        public string ProviderId { get; set; }
        public bool? Stage1Encode { get; set; }
        public string TenantId { get; set; }
        public MediaPlatform MediaPlatform { get; set; }
        public string JWPlayerSiteId { get; set; }
    }
}
