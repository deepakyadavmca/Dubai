﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class PortalEquipmentType
    {
        [ProtoMember(1)]
        public string TypeTag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        //[ProtoMember(3)]
        //public bool CanTrackWeight { get; set; }

        //[ProtoMember(4)]
        //public LocalisedText Keywords { get; set; }

        //[ProtoMember(5)]
        //public bool IsHidden { get; set; }

        [ProtoMember(6)]
        public string ImageUri { get; set; }
    }
}
