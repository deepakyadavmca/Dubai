﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    [ProtoContract]
    public class PortalMedia: IStorageKey
    {
        [ProtoMember(1)]
        public string BlockId { get; set; }

        [ProtoMember(2)]
        public string FileIdentifier { get; set; }

        [ProtoMember(3)]
        public PortalMediaType MediaType { get; set; }

        [ProtoMember(4)]
        public PortalMediaStatus Status { get; set; }

        [ProtoMember(5)]
        public int TotalChunks { get; set; }

        [ProtoMember(6)]
        public string Name { get; set; }

        [ProtoMember(7)]
        public int ChunkNumber { get; set; }
        public string PartitionKey
        {
            get
            {
                return FileIdentifier;
            }
        }

        public string RowKey
        {
            get
            {
                return ChunkNumber.ToString();
            }
        }

        public int GetChunkIdFromBlockId()
        {
            return BitConverter.ToInt32(Convert.FromBase64String(BlockId), 0);
        }
    }
}
