﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class OnDemandCollectionSectionSlotViewModel
    {
        public List<VirtualClassViewModel> VirtualClassesList { get; set; }
        public List<string> ProviderList { get; set; }
        public List<string> CategoryList { get; set; }
        public Dictionary<string, string> LanguageList { get; set; }
        public string SelectedVirtualClassTag { get; set; }
        public string SelectedProvider { get; set; }
        public string SelectedCategory { get; set; }
        public List<string> ExistingVirtualClassTag { get; set; }
        public string CollectionTag { get; set; }
    }
}
