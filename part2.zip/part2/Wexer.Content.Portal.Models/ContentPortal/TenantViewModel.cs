﻿using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Models.ContentPortal
{
    public class TenantViewModel
    {
        public TenantDetail Tenant { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public bool Active { get; set; }
        public string ChannelName { get; set; }
        public string ProviderName { get; set; }
        public MediaPlatform MediaPlatform { get; set; }
        public string JWPlayerSiteId { get; set; }
    }
}
