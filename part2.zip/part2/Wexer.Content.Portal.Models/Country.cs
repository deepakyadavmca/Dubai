using System;
using System.Collections.Generic;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class Country
    {
        /// <summary>
        /// ISO 3166 country code
        /// </summary>
        [ProtoMember(1)]
        public string ISO3166Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText DisplayName { get; set; }

        /// <summary>
        /// Ordered list of supported languages for country in order of preference
        /// </summary>
        [ProtoMember(3)]
        public List<string> LanguageTags { get; set; }

        /// <summary>
        /// Gets or sets the reset password link
        /// </summary>
        [ProtoMember(4)]
        public string ResetPasswordUri { get; set; }
        
        /// <summary>
        /// Gets or sets the customer support link
        /// </summary>
        [ProtoMember(5)]
        public string CustomerSupportUri { get; set; }
        
        /// <summary>
        /// Gets or sets the custom fit link
        /// </summary>
        [ProtoMember(6)]
        public string CustomFitUri { get; set; }

        /// <summary>
        /// Ts and Cs Web Link
        /// </summary>
        [ProtoMember(7)]
        public string TermsAndCondtionsUri { get; set; }

        /// <summary>
        /// Ts and Cs Web Link
        /// </summary>
        [ProtoMember(8)]
        public string PrivacyPolicyUri { get; set; }

        /// <summary>
        /// Ts and Cs Web Link
        /// </summary>
        [ProtoMember(9)]
        public string AboutUsUri { get; set; }

        /// <summary>
        /// Ts and Cs Web Link
        /// </summary>
        [ProtoMember(10)]
        public string FaqUri { get; set; }

        /// <summary>
        /// Ts and Cs Web Link
        /// </summary>
        [ProtoMember(11)]
        public string FeedbackUri { get; set; }

        /// <summary>
        /// Link to the Join Us page
        /// </summary>
        [ProtoMember(12)]
        public string JoinUsUri { get; set; }

        /// <summary>
        /// Link to the Try Us page
        /// </summary>
        [ProtoMember(13)]
        public string TryUsUri { get; set; }

        /// <summary>
        /// Link to the Account details page
        /// </summary>
        [ProtoMember(14)]
        public string AccountUri { get; set; }

        /// <summary>
        /// List of entitlements available in this country
        /// </summary>
        [ProtoMember(15)]
        public string[] Entitlements { get; set; }

        /// <summary>
        /// Terms and conditions (app specific) Uri
        /// </summary>
        [ProtoMember(16)]
        public string TermsAndCondtionsAppUri { get; set; }

        /// <summary>
        /// Link to the Register page
        /// </summary>
        [ProtoMember(17)]
        public string RegisterUri { get; set; }

        [ProtoMember(18)]
        public string CustomFitAppUri { get; set; }

        [ProtoMember(19)]
        public string OnDemandPromoVideoUri { get; set; }

    }
}