﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum ExerciseType : byte
    {
        [ProtoEnum(Name = "Resistance", Value = 10)]
        Resistance = 10,
        [ProtoEnum(Name = "CardioResistance", Value = 15)]
        CardioResistance = 15,
        [ProtoEnum(Name = "Cardio", Value = 20)]
        Cardio = 20,
        [ProtoEnum(Name = "Mobilizer", Value = 30)]
        Mobilizer = 30,
        [ProtoEnum(Name = "Stretch", Value = 60)]
        Stretch = 60,
        [ProtoEnum(Name = "FoamRoller", Value = 70)]
        FoamRoller = 70,
    }
}
