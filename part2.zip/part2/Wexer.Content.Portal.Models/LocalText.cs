using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class LocalText
    {
        [ProtoMember(1)]
        public string IETFTag { get; set; }

        [ProtoMember(2)]
        public string Text { get; set; }
    }
}