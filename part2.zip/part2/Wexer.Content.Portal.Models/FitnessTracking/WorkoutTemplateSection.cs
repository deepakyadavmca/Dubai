using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutTemplateSection
    {
        [ProtoMember(1)]
        public string WorkoutTag { get; set; }

        [ProtoMember(2)]
        public LocalisedText SectionName { get; set; }

        [ProtoMember(3)]
        public bool IsOptional { get; set; }

        [ProtoMember(4)]
        public WorkoutTemplateExerciseSlot[] ExerciseSlots { get; set; }

        [ProtoMember(5)]
        public Tuple<byte, LocalisedText> Day { get; set; }

        [ProtoMember(6)]
        public bool IsWarmUp { get; set; }

        [ProtoMember(7)]
        public bool IsCoolDown { get; set; }
    }
}