using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutExerciseSlotSet
    {
        [ProtoMember(1)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(2)]
        public int? Reps { get; set; }

        [ProtoMember(3)]
        public decimal? WeightKg { get; set; }

        [ProtoMember(4)]
        public int? RestSeconds { get; set; }

        [ProtoMember(5)]
        public int IntensityLevel { get; set; }

        [ProtoMember(6)]
        public int CalorieBurn { get; set; }

        [ProtoMember(7)]
        public bool Unilateral { get; set; }

        [ProtoMember(8)]
        public int? TimePerRep { get; set; }

        [ProtoMember(9)]
        public bool PersonalBest { get; set; }

        [ProtoMember(10)]
        public bool IsDualMode { get; set; }

        [ProtoMember(11)]
        public string PerformModeText { get; set; }   ///Added on 21 Spt 2016 to return the perform mode text in the workout sets


    }
}