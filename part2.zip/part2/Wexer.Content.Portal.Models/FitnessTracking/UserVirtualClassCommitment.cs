﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public class UserVirtualClassCommitment : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public string VirtualClassTypeTag { get; set; }

        [ProtoMember(4)]
        public string Studio { get; set; }

        [ProtoMember(5)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime ClassStartTimeUtc { get; set; }

        [ProtoMember(6)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? ClassCompletedTimeUtc { get; set; }

        [ProtoMember(7)]
        public string Mood { get; set; }

        [ProtoMember(8)]
        public string WorkoutResultTag { get; set; }

        [ProtoMember(9)]
        public string Provider { get; set; }


        [ProtoMember(10)]
        public DateTime? LastModifiedDate { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return string.Format("{0}-{1:yyyy-MM-dd}{2:HH:mm}-{3}", Provider, ClassStartTimeUtc, ClassStartTimeUtc, VirtualClassTypeTag);
            }
        }
    }
}
