﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public enum ChallengeType : byte
    {
        [ProtoEnum(Name = "Clubs", Value = 0)]
        Clubs = 0,

        [ProtoEnum(Name = "Countries", Value = 10)]
        Countries = 10,

        [ProtoEnum(Name = "None", Value = 99)]
        None = 99,
    }
}
