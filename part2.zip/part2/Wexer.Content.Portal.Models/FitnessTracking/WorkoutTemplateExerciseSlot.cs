using System.Collections.Generic;
using System.Linq;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{

    [ProtoContract]
    public enum SlotType
    {
        [ProtoEnum(Name = "Single", Value = 1)]
        Single,
        [ProtoEnum(Name = "Superset", Value = 2)]
        Superset
    }

    [ProtoContract(EnumPassthru = true)]
    public class WorkoutTemplateExerciseSlot : ISlotExerciseCriteria, IExerciseParameters
    {
        [ProtoMember(1)]
        public SlotType SlotType { get; set; }

        [ProtoMember(2)]
        public ExerciseType ExerciseType { get; set; }

        [ProtoMember(3)]
        public string MuscleGroupTag { get; set; }

        [ProtoMember(4)]
        public string EquipmentTag { get; set; }

        [ProtoMember(5)]
        public int? Sets { get; set; }

        [ProtoMember(6)]
        public int? DurationSeconds { get; set; }

        [ProtoMember(7)]
        public int? Reps { get; set; }

        [ProtoMember(8)]
        public int? RestSeconds { get; set; }

        [ProtoMember(9)]
        public SupersetExerciseTemplate[] SupersetExercises { get; set; }

        [ProtoMember(10)]
        public int SlotNumber { get; set; }

        [ProtoMember(11)]
        public ExerciseLengthType ExerciseLengthType { get; set; }

        [ProtoMember(12)]
        public int? TimePerRep { get; set; }

        [ProtoMember(13)]
        public bool Unilateral { get; set; }

        [ProtoMember(14)]
        public IDictionary<string, WorkoutTemplateSlotVariant> Variants { get; set; }

        [ProtoMember(15)]
        public string ExerciseTag { get; set; }

        [ProtoMember(16)]
        public LocalisedText PerformModeText { get; set; }

        public int? DistanceMeter { get; set; }

        public Exercise GetVariantExercise(TrainingStyle trainingStyle, FitnessExperience experienceLevel, Exercise[] exercises)
        {
            var key = WorkoutTemplate.GenerateVariantKey(trainingStyle, experienceLevel);
            if (Variants != null && Variants.ContainsKey(key))
            {
                var variant = Variants[key];
                var tag = variant != null ? variant.ExerciseTag : null;
                return exercises.FirstOrDefault(exercise => exercise.Tag == tag);
            }
            return null;
        }

        public void StoreVariantExercise(TrainingStyle trainingStyle, FitnessExperience experienceLevel, Exercise exercise)
        {
            var key = WorkoutTemplate.GenerateVariantKey(trainingStyle, experienceLevel);
            StoreVariantExercise(key, exercise);
        }

        public void StoreVariantExercise(string key, Exercise exercise)
        {
            StoreVariantExercise(key, exercise.Tag);
        }

        public void StoreVariantExercise(string key, string exerciseTag)
        {
            if (Variants == null)
            {
                Variants = new Dictionary<string, WorkoutTemplateSlotVariant>();
            }

            Variants[key] = new WorkoutTemplateSlotVariant { ExerciseTag = exerciseTag };

        }

    }
}