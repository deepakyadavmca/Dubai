using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class Exercise
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        [ProtoMember(3)]
        public ExerciseType ExerciseType { get; set; }

        [ProtoMember(4)]
        public int PlanesOfMovement { get; set; }

        [ProtoMember(5)]
        public bool ExcludeFromRecommendations { get; set; }

        [ProtoMember(6)]
        public LocalisedText Description { get; set; }

        [ProtoMember(7)]
        public string ImageUri { get; set; }

        [ProtoMember(8)]
        public string VideoUri { get; set; }

        [ProtoMember(9)]
        public string[] PrimaryMuscleGroupTags { get; set; }

        [ProtoMember(10)]
        public string[] SecondaryMuscleGroupTags { get; set; }

        [ProtoMember(11)]
        public string[] EquipmentTypeTags { get; set; }

        [ProtoMember(12)]
        public string VimeoUri { get; set; }

        [ProtoMember(13)]
        public ExerciseStep[] Steps { get; set; }

        [ProtoMember(14)]
        public ExerciseTip[] Tips { get; set; }

        [ProtoMember(15)]
        public ExerciseLengthType ExerciseLengthType { get; set; }

        [ProtoMember(17)]
        public LocalisedText Keywords { get; set; }

        [ProtoMember(18)]
        public TrainingStyle[] TrainingStyles { get; set; }

        [ProtoMember(19)]
        public FitnessExperience[] ExperienceLevels { get; set; }

        [ProtoMember(20)]
        public FitnessGoal[] FitnessGoals { get; set; }

        [ProtoMember(21)]
        public bool IsHidden { get; set; }

        [ProtoMember(22)]
        public bool ExcludeFromWarmUps { get; set; }

        [ProtoMember(23)]
        public bool ExcludeFromCoolDowns { get; set; }

        [ProtoMember(24)]
        public int SkillLevel { get; set; }

        [ProtoMember(25)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(26)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(27)]
        public bool Unilateral { get; set; }

        [ProtoMember(28)]
        public int BatchNumber { get; set; }

        [ProtoMember(29)]
        public int MinimumScore { get; set; }

        [ProtoMember(30)]
        public int MultiPlanar { get; set; }

        [ProtoMember(31)]
        public int StabilityAndControl { get; set; }
        
        [ProtoMember(32)]
        public int Speed { get; set; }
        
        [ProtoMember(33)]
        public int RangeOfMotion { get; set; }
        
        [ProtoMember(34)]
        public int LiftMoreThanHalfBodyWeight { get; set; }
        
        [ProtoMember(35)]
        public int MoreThanOneStep { get; set; }
        
        [ProtoMember(36)]
        public int MoreThanOneJoint { get; set; }
        
        [ProtoMember(37)]
        public int MoreThanTwoJoints { get; set; }      
    }
}