using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutExerciseSlotSuperset
    {
        [ProtoMember(1)]
        public SupersetStep[] Steps { get; set; }
        
        [ProtoMember(2)]
        public int? RestSeconds { get; set; }
        
        
    }
}