using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutTemplateVariant
    {
        [ProtoMember(1)]
        public LocalisedText Name { get; set; }
        [ProtoMember(2)]
        public LocalisedText Description { get; set; }
        [ProtoMember(3)]
        public LocalisedText WorkoutIntroText { get; set; }
        [ProtoMember(4)]
        public LocalisedText WorkoutCompleteDescription { get; set; }
    }
}