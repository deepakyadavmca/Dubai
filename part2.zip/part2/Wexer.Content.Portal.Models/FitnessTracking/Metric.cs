﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class Metric
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        [ProtoMember(3)]
        public string Unit { get; set; }
    }
}
