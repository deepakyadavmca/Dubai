﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class Challenge
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Instructions { get; set; }

        [ProtoMember(3)]
        public ChallengeType ChallengeType { get; set; }

        [ProtoMember(4)]
        public bool IsFeatured { get; set; }

        [ProtoMember(5)]
        public bool IsActive { get; set; }

        [ProtoMember(6)]
        public int ParticipantCount { get; set; }

        //[ProtoMember(7)]
        //public string WorkoutTemplateTag { get; set; } 

        [ProtoMember(8)]
        public string InternalName { get; set; }

        [ProtoMember(9)]
        public LocalisedText Name { get; set; }

        [ProtoMember(10)]
        public LocalisedText Description { get; set; }

        [ProtoMember(11)]
        public string ClubsTag { get; set; }

        [ProtoMember(12)]
        public string CountriesTag { get; set; }

        [ProtoMember(13)]
        public string ImageUrl { get; set; }

        [ProtoMember(14)]
        public string VideoUrl { get; set; }

        [ProtoMember(15)]
        public WorkoutTemplate WorkoutTemplate { get; set; }

        [ProtoMember(16)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(17)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(18)]
        public int Threshold { get; set; }
       
    }

}
