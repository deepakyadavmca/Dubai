﻿using System;
using System.Collections.Generic;
using ProtoBuf;
using System.Linq;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class IntensityCode
    {
        public IntensityCode()
        {
            IntensityModifiers = new []
            {
                new IntensityModifiers() {SkillLevel = 1, Modifier = -36},
                new IntensityModifiers() {SkillLevel = 2, Modifier = -32},
                new IntensityModifiers() {SkillLevel = 3, Modifier = -28},
                new IntensityModifiers() {SkillLevel = 4, Modifier = -24},
                new IntensityModifiers() {SkillLevel = 5, Modifier = -20},
                new IntensityModifiers() {SkillLevel = 6, Modifier = -16},
                new IntensityModifiers() {SkillLevel = 7, Modifier = -12},
                new IntensityModifiers() {SkillLevel = 8, Modifier = -8},
                new IntensityModifiers() {SkillLevel = 9, Modifier = -4},
                new IntensityModifiers() {SkillLevel = 10, Modifier = -0}
            };

            MaxWorkPercentage = new[]
            {
                new MaxWorkPercentage() {IntensityLevel = 1, HRmax = 59},
                new MaxWorkPercentage() {IntensityLevel = 2, HRmax = 62},
                new MaxWorkPercentage() {IntensityLevel = 3, HRmax = 67},
                new MaxWorkPercentage() {IntensityLevel = 4, HRmax = 72},
                new MaxWorkPercentage() {IntensityLevel = 5, HRmax = 77},
                new MaxWorkPercentage() {IntensityLevel = 6, HRmax = 82},
                new MaxWorkPercentage() {IntensityLevel = 7, HRmax = 87},
                new MaxWorkPercentage() {IntensityLevel = 8, HRmax = 92},
                new MaxWorkPercentage() {IntensityLevel = 9, HRmax = 97},
                new MaxWorkPercentage() {IntensityLevel = 10, HRmax = 100}
            };

            WorkRange = new []
            {
                new WorkRange() {IntensityLevel = 1, Min = 0, Max = 49},
                new WorkRange() {IntensityLevel = 2, Min = 50, Max = 54},
                new WorkRange() {IntensityLevel = 3, Min = 55, Max = 59},
                new WorkRange() {IntensityLevel = 4, Min = 60, Max = 64},
                new WorkRange() {IntensityLevel = 5, Min = 65, Max = 69},
                new WorkRange() {IntensityLevel = 6, Min = 70, Max = 74},
                new WorkRange() {IntensityLevel = 7, Min = 75, Max = 79},
                new WorkRange() {IntensityLevel = 8, Min = 80, Max = 84},
                new WorkRange() {IntensityLevel = 9, Min = 85, Max = 89},
                new WorkRange() {IntensityLevel = 10, Min = 90, Max = 100}
            };

            BMRMultiplierMapping = new []
            {
                new BMRMultiplierMapping() {StepsDayMin = int.MinValue, StepsDayMax = 4999, BMRMultiplier = 1.2},
                new BMRMultiplierMapping() {StepsDayMin = 5000, StepsDayMax = 9999, BMRMultiplier = 1.2},
                new BMRMultiplierMapping() {StepsDayMin = 10000, StepsDayMax = 14999, BMRMultiplier = 1.4},
                new BMRMultiplierMapping() {StepsDayMin = 15000, StepsDayMax = 19999, BMRMultiplier = 1.6},
                new BMRMultiplierMapping() {StepsDayMin = 20000, StepsDayMax = 24999, BMRMultiplier = 1.8},
                new BMRMultiplierMapping() {StepsDayMin = 25000, StepsDayMax  = int.MaxValue, BMRMultiplier = 2.0}          
            };

            Type = "Rest Factor";
            Value = -20;

        }

        public int GetIntensityForWorkPercentage(double workPercentage)
        {
            int intensity = WorkRange.FirstOrDefault(t => (t.Min < workPercentage && workPercentage < t.Max) || (t.Min == workPercentage) ||(t.Max == workPercentage)).IntensityLevel;
            return intensity;
        }

        public double GetBMRMultiplierForStepCount(int stepCount)
        {
            return BMRMultiplierMapping.Single( t => (t.StepsDayMax > stepCount && t.StepsDayMin < stepCount) || stepCount == t.StepsDayMax || stepCount == t.StepsDayMin).BMRMultiplier;
        }

        [ProtoMember(1)]
        public string Type { get; set; }

        [ProtoMember(2)]
        public double Value { get; set; }

        [ProtoMember(2)]
        public IntensityModifiers[] IntensityModifiers { get; set; }

        [ProtoMember(3)]
        public MaxWorkPercentage[] MaxWorkPercentage { get; set; }

        [ProtoMember(4)]
        public WorkRange[] WorkRange { get; set; }

        [ProtoMember(5)]
        public BMRMultiplierMapping[] BMRMultiplierMapping { get; set; }
      
    }

    [ProtoContract]
    public class IntensityModifiers
    {
        [ProtoMember(1)]
        public int SkillLevel { get; set; }

        [ProtoMember(2)]
        public double Modifier { get; set; }

    }

    [ProtoContract]
    public class MaxWorkPercentage
    {
        [ProtoMember(1)]
        public int IntensityLevel { get; set; }

        [ProtoMember(2)]
        public double HRmax { get; set; }

    }

    [ProtoContract]
    public class WorkRange
    {
        [ProtoMember(1)]
        public int IntensityLevel { get; set; }

        [ProtoMember(2)]
        public double Min { get; set; }

        [ProtoMember(3)]
        public double Max { get; set; }
    }

    [ProtoContract]
    public class BMRMultiplierMapping
    {
        [ProtoMember(1)]
        public int StepsDayMin { get; set; }

        [ProtoMember(2)]
        public int StepsDayMax { get; set; }

        [ProtoMember(3)]
        public double BMRMultiplier { get; set; }
    }

   
}
