namespace Wexer.Content.Portal.Models.FitnessTracking
{
    public interface ISlotExerciseCriteria
    {
        ExerciseType ExerciseType { get; }
        string MuscleGroupTag { get; }
        string EquipmentTag { get;  }

    }
}