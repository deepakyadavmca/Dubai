﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    /// <summary>
    /// Default exercise values.
    /// </summary>
    [ProtoContract]
    public class ExerciseDefaults
    {
        [ProtoMember(1)]
        public ExerciseType ExerciseType { get; set; }

        [ProtoMember(2)]
        public FitnessGoal FitnessGoal { get; set; }

        [ProtoMember(3)]
        public FitnessExperience FitnessExperience { get; set; }

        [ProtoMember(4)]
        public TrainingStyle TrainingStyle { get; set; }

        [ProtoMember(5)]
        public ExerciseLengthType ExerciseLengthType { get; set; }

        [ProtoMember(6)]
        public int DurationSeconds { get; set; }

        [ProtoMember(7)]
        public int Reps { get; set; }

        [ProtoMember(8)]
        public int Sets { get; set; }

        [ProtoMember(9)]
        public int RestSeconds { get; set; }

        [ProtoMember(10)]
        public int SecondsPerRep { get; set; }

        public string Tag
        {
            get { return string.Format("{0}{1}{2}{3}", ExerciseType, FitnessGoal, FitnessExperience, TrainingStyle).ToLowerInvariant(); }
        }
    }
}
