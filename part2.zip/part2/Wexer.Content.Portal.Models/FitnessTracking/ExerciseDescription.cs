﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class SystemCode
    {
        [ProtoMember(1)]
        public string Type { get; set; }

        [ProtoMember(2)]
        public int Value { get; set; }

        [ProtoMember(3)]
        public LocalisedText Label { get; set; }
    }
}
