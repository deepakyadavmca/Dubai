using System.IO;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class ExerciseStep
    {
        [ProtoMember(1)]
        public string ImageUri { get; set; }
        [ProtoMember(2)]
        public LocalisedText Description { get; set; }

        public string GetImageTag()
        {
            return ImageUri != null ? Path.GetFileNameWithoutExtension(ImageUri) : null;
        }
    }
}