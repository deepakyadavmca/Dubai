using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class SupersetStep
    {
        [ProtoMember(1)]
        public string SelectedExerciseTag { get; set; }
        [ProtoMember(2)]
        public string[] ExerciseTags { get; set; }
        [ProtoMember(3)]
        public ExerciseLengthType ExerciseLengthType { get; set; }
        [ProtoMember(4)]
        public int? DurationSeconds { get; set; }
        [ProtoMember(5)]
        public int? Reps { get; set; }
        [ProtoMember(6)]
        public decimal? WeightKg { get; set; }
    }
}