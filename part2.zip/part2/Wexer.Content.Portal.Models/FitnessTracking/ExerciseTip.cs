using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class ExerciseTip
    {
        [ProtoMember(1)]
        public LocalisedText Description { get; set; }
    }
}