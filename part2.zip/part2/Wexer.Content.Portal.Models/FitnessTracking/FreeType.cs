﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public enum FreeType : byte
    {
        [ProtoEnum(Name = "None", Value = 0)]
        None = 0,

        [ProtoEnum(Name = "Everyone", Value = 50)]
        Everyone = 50,

        [ProtoEnum(Name = "Members", Value = 100)]
        Members = 100,
    }
}
