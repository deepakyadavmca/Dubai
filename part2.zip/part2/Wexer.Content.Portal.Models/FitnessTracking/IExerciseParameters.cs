namespace Wexer.Content.Portal.Models.FitnessTracking
{
    public interface IExerciseParameters
    {
        int? Sets { get; set; }

        int? DurationSeconds { get; set; }
         
        int? Reps { get; set; }
         
        int? RestSeconds { get; set; }

        int? TimePerRep { get; set; }

        bool Unilateral { get; set; }

        string ExerciseTag { get; set; }

        LocalisedText PerformModeText { get; set; } //Added on 21 Spt 2016 to return the perform mode text in the workout sets

    }
}