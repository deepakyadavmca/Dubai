using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class SupersetExerciseTemplate : ISlotExerciseCriteria
    {
        [ProtoMember(1)]
        public ExerciseType ExerciseType { get; set; }

        [ProtoMember(2)]
        public string MuscleGroupTag { get; set; }

        [ProtoMember(3)]
        public string EquipmentTag { get; set; }

        [ProtoMember(4)]
        public ExerciseLengthType ExerciseLengthType { get; set; }
    }
}