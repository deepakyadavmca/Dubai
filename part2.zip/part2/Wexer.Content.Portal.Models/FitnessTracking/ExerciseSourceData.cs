﻿
namespace Wexer.Content.Portal.Models.FitnessTracking
{
    public class ExerciseSourceData
    {
        public Exercise[] Exercises { get; set; }
    }
}
