using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class Equipment
    {
        [ProtoMember(1)]
        public string TypeTag { get; set; }

        [ProtoMember(2)]
        public string SpecificTag { get; set; }

        [ProtoMember(3)]
        public string Manufacturer { get; set; }

        [ProtoMember(4)]
        public string Model { get; set; }

        [ProtoMember(5)]
        public string ImageUri { get; set; }

        [ProtoMember(6)]
        public LocalisedText Description { get; set; }

        //aerobic
        [ProtoMember(7)]
        public Range ResistanceRange { get; set; }
        [ProtoMember(8)]

        public Range InclineRange { get; set; }

        //strength
        [ProtoMember(9)]
        public Range MajorWeightRangeKg { get; set; }

        [ProtoMember(10)]
        public Range MinorWeightRangeKg { get; set; }


        [ProtoMember(11)]
        public bool CanTrackWeight { get; set; }

    }
}