using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public enum ExerciseLengthType
    {
        [ProtoEnum(Name = "Unknown", Value = 0)]
        Unknown = 0,

        [ProtoEnum(Name = "DurationSeconds", Value = 10)]
        DurationSeconds = 10,

        [ProtoEnum(Name = "DurationMinutes", Value = 20)]
        DurationMinutes = 20,

        [ProtoEnum(Name = "Reps", Value = 30)]
        Reps = 30,

        [ProtoEnum(Name = "Meters", Value = 40)]
        Meters = 40

    }
}