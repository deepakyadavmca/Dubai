﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    //[ProtoContract]
    //public class StepMetric : IStorageKey
    //{
    //    [ProtoMember(1)]
    //    public string Tag { get; set; }

    //    [ProtoMember(2)]
    //    public int StepCount { get; set; }

    //    [ProtoMember(3)]
    //    [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
    //    public DateTime PerformedDate { get; set; }

    //    [ProtoMember(4)]
    //    public int CalorieBurn { get; set; }

    //    [ProtoMember(5)]
    //    public string UserId { get; set; }

    //    [ProtoMember(6)]
    //    [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
    //    public DateTime ModifiedDate { get; set; }

    //    string IStorageKey.PartitionKey
    //    {
    //        get
    //        {
    //            return UserId;
    //        }
    //    }

    //    string IStorageKey.RowKey
    //    {
    //        get
    //        {
    //            return PerformedDate.ToString("yyyyMMddHHmmss");
    //        }
    //    }
    //}

    //[ProtoContract]
    //public class PersonalBestMetric : IStorageKey
    //{
    //    [ProtoMember(1)]
    //    public string Tag { get; set; }

    //    [ProtoMember(2)]
    //    public MetricType TargetType { get; set; }
        
    //    [ProtoMember(3)]
    //    public string Exercisetag { get; set; }

    //    [ProtoMember(4)]
    //    public string Name { get; set; }

    //    [ProtoMember(5)]
    //    public string UserWorkouttag { get; set; }

    //    [ProtoMember(6)]
    //    public int NoOfReps { get; set; }

    //    [ProtoMember(7)]
    //    public float DurationSecond { get; set; }

    //    [ProtoMember(8)]
    //    public decimal WeightKG { get; set; }

    //    [ProtoMember(9)]
    //    public float Distance { get; set; }
        
    //    [ProtoMember(10)]
    //    public int RestInSecond { get; set; }

    //    [ProtoMember(11)]
    //    [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
    //    public DateTime PerformedDate { get; set; }    

    //    [ProtoMember(12)]
    //    public ExerciseLengthType ExerciseLengthType { get; set; }

    //    [ProtoMember(13)]
    //    public int CalorieBurn { get; set; }

    //    [ProtoMember(14)]
    //    public int Intensity { get; set; }

    //    [ProtoMember(15)]
    //    public int SkillLevel { get; set; }

    //    [ProtoMember(16)]
    //    public string UserId { get; set; }

    //    [ProtoMember(17)]
    //    [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
    //    public DateTime LastModified { get; set; }

    //    [ProtoMember(18)]
    //    public bool IsTimed { get; set; }

    //    string IStorageKey.PartitionKey
    //    {
    //        get
    //        {
    //            return UserId;
    //        }
    //    }

    //    string IStorageKey.RowKey
    //    {
    //        get
    //        {
    //            return Name;
    //        }
    //    }
    //}

    //[ProtoContract]
    //public class WorkoutMetric : IStorageKey
    //{
    //    [ProtoMember(1)]
    //    public string Tag { get; set; }

    //    [ProtoMember(2)]
    //    public MetricType TargetType { get; set; }

    //    [ProtoMember(3)]
    //    public string Exercisetag { get; set; }

    //    [ProtoMember(4)]
    //    public string Name { get; set; }

    //    [ProtoMember(5)]
    //    public string UserWorkouttag { get; set; }

    //    [ProtoMember(6)]
    //    public int NoOfReps { get; set; }

    //    [ProtoMember(7)]
    //    public float DurationSecond { get; set; }

    //    [ProtoMember(8)]
    //    public decimal WeightKG { get; set; }

    //    [ProtoMember(9)]
    //    [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
    //    public DateTime PerformedDate { get; set; }

    //    [ProtoMember(10)]
    //    public float Distance { get; set; }

    //    [ProtoMember(10)]
    //    public ExerciseLengthType ExerciseLengthType { get; set; }

    //    [ProtoMember(11)]
    //    public int RestInSecond { get; set; }

    //    [ProtoMember(12)]
    //    public int CalorieBurn { get; set; }

    //    [ProtoMember(13)]
    //    public int Intensity { get; set; }

    //    [ProtoMember(14)]
    //    public int SkillLevel { get; set; }

    //    [ProtoMember(15)]
    //    public string UserId { get; set; }

    //    [ProtoMember(16)]
    //    [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
    //    public DateTime LastModified { get; set; }

    //    [ProtoMember(17)]
    //    public bool IsTimed { get; set; }

    //    [ProtoMember(18)]
    //    public bool PersonalBest { get; set; }

    //    string IStorageKey.PartitionKey
    //    {
    //        get
    //        {
    //            return UserId;
    //        }
    //    }

    //    string IStorageKey.RowKey
    //    {
    //        get
    //        {
    //            return Name;
    //        }
    //    }
    //}

    [ProtoContract]
    public enum MetricType : byte
    {
        [ProtoEnum(Name = "Exercise-reps", Value = 10)]
        ExerciseReps = 10,
        [ProtoEnum(Name = "Exercise-weight", Value = 15)]
        ExerciseWeight = 15,
        [ProtoEnum(Name = "Exercise-distance", Value = 20)]
        ExerciseDistance = 20,
        [ProtoEnum(Name = "Workout-time", Value = 25)]
        WorkoutTime = 25,
        [ProtoEnum(Name = "Exercise-time", Value = 30)]
        ExerciseTime = 30,
        [ProtoEnum(Name = "Exercise-meters", Value = 35)]
        ExerciseMeters = 35,
    }

    [ProtoContract]
    public class MetricFilter
    {
        [ProtoMember(1)]
        public string NoOfDays { get; set; }

        [ProtoMember(2)]
        public MetricType TargetType { get; set; }
    }

}
