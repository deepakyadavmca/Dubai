using System;
using System.Collections.Generic;
using System.Linq;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutExerciseSlot
    {
        private readonly IntensityCode _intensityCode;

        public WorkoutExerciseSlot()
        {
            _intensityCode = new IntensityCode();
        }

        public WorkoutExerciseSlot(WorkoutExerciseSlotSuperset[] superSets)
        {
            _intensityCode = new IntensityCode();
            UpdateSets(superSets);
        }

        public WorkoutExerciseSlot(int sets, int? durationSeconds, int? reps, int? restSeconds, decimal? weightKg = null)
        {
            _intensityCode = new IntensityCode();
            UpdateSets(sets, durationSeconds, reps, restSeconds, weightKg);
        }

        public void UpdateSets(WorkoutExerciseSlotSuperset[] superSets)
        {
            Supersets = superSets;
        }

        public void UpdateSets(int sets, int? durationSeconds, int? reps, int? restSeconds, decimal? weightKg = null)
        {
            var list = new List<WorkoutExerciseSlotSet>();
            for (var i = 0; i < sets; i++)
            {
                var exerciseSlot = new WorkoutExerciseSlotSet
                {
                    DurationSeconds = durationSeconds,
                    Reps = reps,
                    RestSeconds = restSeconds,
                    WeightKg = weightKg
                };

                //if (exerciseSlot.Reps != null)
                //{
                //    if (exerciseSlot.DurationSeconds.HasValue)
                //        exerciseSlot.TimePerRep = exerciseSlot.DurationSeconds.Value;
                //}

                list.Add(exerciseSlot);
            }
            Sets = list.ToArray();
        }


        public void UpdateSets(int sets, int? durationSeconds, int? reps, int? restSeconds, int? timePerRap)
        {
            var list = new List<WorkoutExerciseSlotSet>();
            for (var i = 0; i < sets; i++)
            {
                var exerciseSlot = new WorkoutExerciseSlotSet
                {
                    DurationSeconds = durationSeconds,
                    Reps = reps,
                    RestSeconds = restSeconds,
                    TimePerRep = timePerRap
                };

                //if (exerciseSlot.Reps != null)
                //{
                //    if (exerciseSlot.DurationSeconds.HasValue)
                //        exerciseSlot.TimePerRep = exerciseSlot.DurationSeconds.Value;
                //}

                list.Add(exerciseSlot);
            }
            Sets = list.ToArray();
        }

        public void UpdateSets(int sets, int? durationSeconds, int? reps, int? restSeconds, int? timePerRap, bool unilateral, string performModeText)
        {
            var list = new List<WorkoutExerciseSlotSet>();
            for (var i = 0; i < sets; i++)
            {
                var exerciseSlot = new WorkoutExerciseSlotSet
                {
                    DurationSeconds = durationSeconds,
                    Reps = reps,
                    RestSeconds = restSeconds,
                    TimePerRep = timePerRap,
                    Unilateral = unilateral,
                    PerformModeText= performModeText
                };

                //if (exerciseSlot.Reps != null)
                //{
                //    if (exerciseSlot.DurationSeconds.HasValue)
                //        exerciseSlot.TimePerRep = exerciseSlot.DurationSeconds.Value;
                //}

                list.Add(exerciseSlot);
            }
            Sets = list.ToArray();
        }

        public void UpdateSets(int sets, int? durationSeconds, int? reps, int? restSeconds, int? timePerRep, int? skillLevel, bool unilateral,string performModeText, decimal? weightKg = null)
        {

            var list = new List<WorkoutExerciseSlotSet>();
            //var intensity = CalculateIntensity(durationSeconds, reps, restSeconds, skillLevel, unilateral);
            bool isDualMode = false;

            for (var i = 0; i < sets; i++)
            {
                int? seconds = durationSeconds;
                //Time Per Rep if null then set default value 3
                if (reps != null)
                {
                    timePerRep = timePerRep != null ? timePerRep : 3;
                    if (seconds != null)
                    {
                        isDualMode = true;
                    }
                    seconds = (reps ?? 0) * (timePerRep ?? 0);
                }

                var exerciseSlot = new WorkoutExerciseSlotSet
                {
                    DurationSeconds = seconds,
                    Reps = reps,
                    RestSeconds = restSeconds,
                    WeightKg = weightKg,
                    TimePerRep = timePerRep,
                    IntensityLevel = CalculateIntensity(seconds, reps, restSeconds, skillLevel, unilateral),
                    Unilateral = unilateral,
                    IsDualMode = isDualMode,
                    PerformModeText = performModeText
                };


                //Need to be discuss and 


                list.Add(exerciseSlot);
            }
            Sets = list.ToArray();
        }

        private int CalculateIntensity(int? durationSeconds, int? reps, int? restSeconds, int? skillLevel, bool unilateral)
        {
            durationSeconds = durationSeconds ?? 0;
            //var workDuration = reps != null ? (reps * durationSeconds) : durationSeconds;
            var modifier = (skillLevel != null && skillLevel != 0) ? _intensityCode.IntensityModifiers.First(t => t.SkillLevel == skillLevel).Modifier : 0;
            var work = unilateral ? (2 * Convert.ToDouble(durationSeconds)) : Convert.ToDouble(durationSeconds);
            var netWork = Convert.ToDouble((((100 + modifier) / 100) * work));
            var restFactor = Convert.ToDouble(((100 + modifier + _intensityCode.Value) / 100) * (restSeconds ?? 0));
            var workPercentage = Math.Round(((durationSeconds + (restSeconds ?? 0) != 0) ? (Convert.ToDouble((restFactor + netWork) / (work + (restSeconds ?? 0))) * 100) : 0), 0, MidpointRounding.AwayFromZero);

            return _intensityCode.GetIntensityForWorkPercentage(workPercentage);
        }


        [ProtoMember(1)]
        public SlotType SlotType { get; set; }

        [ProtoMember(2)]
        public string SelectedExerciseTag { get; set; }

        [ProtoMember(3)]
        public WorkoutExerciseSlotSet[] Sets { get; set; }

        [ProtoMember(4)]
        public string[] ExerciseTags { get; set; }

        [ProtoMember(5)]
        public WorkoutExerciseSlotSuperset[] Supersets { get; set; }

        [ProtoMember(6)]
        public ExerciseLengthType ExerciseLengthType { get; set; }

        [ProtoMember(7)]
        public int SkillLevel { get; set; }
    }
}