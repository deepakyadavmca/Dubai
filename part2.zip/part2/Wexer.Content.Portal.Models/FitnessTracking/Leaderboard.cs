﻿using ProtoBuf;
using System;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
   [ProtoContract]
    public class Leaderboard 
    {
       [ProtoMember(1)]
       public string ChallengeTag { get; set; }
        [ProtoMember(2)]
        public string UserId { get; set; }
        [ProtoMember(3)]
        public int PerformedTime { get; set; } //(seconds)
        [ProtoMember(4)]
        public string FirstName { get; set; }
        [ProtoMember(5)]
        public string LastName { get; set; }
        [ProtoMember(6)]
        public DateTime CompletedDate { get; set; }
        [ProtoMember(7)]
        public int Rank { get; set; }

    }

}
