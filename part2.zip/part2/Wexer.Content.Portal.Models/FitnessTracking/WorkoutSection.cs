using System;

using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutSection : IComparable
    {
        [ProtoMember(1)]
        public string SectionName { get; set; }

        [ProtoMember(2)]
        public WorkoutExerciseSlot[] Slots{ get; set; }

        [ProtoMember(3)]
        public Tuple<byte, string> Day { get; set; }

        [ProtoMember(4)]
        public string Description { get; set; }

        [ProtoMember(5)]
        public bool IsWarmUp { get; set; }

        [ProtoMember(6)]
        public bool IsCoolDown { get; set; }
        
        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                return 0;
            }
            var compareToObj = (Tuple<byte, LocalisedText>) obj;

            return Day.Item1 - compareToObj.Item1;
        }
    }
}