using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutTemplateSlotVariant
    {
        [ProtoMember(1)]
        public string ExerciseTag { get; set; }
    }
}