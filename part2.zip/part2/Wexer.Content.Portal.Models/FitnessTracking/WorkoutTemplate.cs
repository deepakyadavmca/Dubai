using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class WorkoutTemplate
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        /// <summary>
        /// Name and description are now present for each Workout Template variant and the main name and description
        /// are only used as a default for older Workout Templates
        /// </summary>
        [ProtoMember(2)]
        public LocalisedText LegacyName { get; set; }

        /// <summary>
        /// Name and description are now present for each Workout Template variant and the main name and description
        /// are only used as a default for older Workout Templates
        /// </summary>
        [ProtoMember(3)]
        public LocalisedText LegacyDescription { get; set; }

        [ProtoMember(4)]
        public WorkoutTemplateSection[] Sections { get; set; }

        [ProtoMember(5)]
        public int LengthOfWorkout { get; set; }

        [ProtoMember(6)]
        public FitnessGoal[] FitnessGoals { get; set; }

        [ProtoMember(7)]
        public FitnessExperience[] ExperienceLevels { get; set; }

        [ProtoMember(8)]
        public TrainingStyle[] TrainingStyles { get; set; }

        [ProtoMember(9)]
        public int MaximumExerciseCount { get; set; }

        [ProtoMember(10)]
        public string InternalName { get; set; }

        [ProtoMember(11)]
        public bool IsTimed { get; set; }

        [ProtoMember(12)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(13)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(14)]
        public bool IsPremium { get; set; }

        [ProtoMember(15)]
        public string ImageUrl { get; set; }

        [ProtoMember(16)]
        public string VideoUrl { get; set; }

        [ProtoMember(17)]
        public FreeType[] FreeType { get; set; }

        [ProtoMember(18)]
        public bool ExcludeFromRecommendedWorkout { get; set; }

        [ProtoMember(19)]
        public string PremiumImageUrl { get; set; }

        [ProtoMember(20)]
        public string TrainerName { get; set; }

        [ProtoMember(21)]
        public string TrainerImgUrl { get; set; }

        [ProtoMember(22)]
        public string VimeoUri { get; set; }

        // 23,24 previously used

        [ProtoMember(25)]
        public IDictionary<string, WorkoutTemplateVariant> Variants { get; set; }

        [ProtoMember(26)]
        public bool AllowExerciseDuplicates { get; set; }

        [ProtoMember(27)]
        public string CountriesTag { get; set; }

        [ProtoMember(28)]
        public string AvailableClubs { get; set; }
        public WorkoutTemplateVariant GetVariant(string key)
        {
            if (Variants == null)
            {
                Variants = new Dictionary<string, WorkoutTemplateVariant>();
            }
            if (Variants.ContainsKey(key))
            {
                // Variant already exists
                return Variants[key];
            }
            else
            {
                WorkoutTemplateVariant variant = new WorkoutTemplateVariant()
                {
                    Name = new LocalisedText(LegacyName),
                    Description = new LocalisedText(LegacyDescription),
                    WorkoutIntroText = new LocalisedText(WorkoutIntroText),
                    WorkoutCompleteDescription = new LocalisedText(WorkoutCompleteDescription)
                };
                Variants.Add(key, variant);
                return variant;
            }
        }

        [ProtoMember(29)]
        public LocalisedText WorkoutIntroText { get; set; }

        [ProtoMember(30)]
        public LocalisedText WorkoutCompleteDescription { get; set; }

        [ProtoMember(31)]
        public LocalisedText Keywords { get; set; }

        [ProtoMember(32)]
        public string[] WorkoutCollectionLabels { get; set; }

        public WorkoutTemplateVariant GetVariant(TrainingStyle trainingStyle, FitnessExperience experienceLevel)
        {
            string key = GenerateVariantKey(trainingStyle, experienceLevel);
            return GetVariant(key);
        }

        /// <summary>
        /// Generate a key that identifies the combination of Training Style and Experience Level values.
        /// </summary>
        /// <remarks>Used to uniquely identify a variant shown in the CMS preview section</remarks>
        public static string GenerateVariantKey(TrainingStyle trainingStyle, FitnessExperience experienceLevel)
        {
            return string.Format("{0}|{1}", trainingStyle, experienceLevel);
        }

        /// <summary>
        /// Returns a slot from a key previously generated using <see cref="WorkoutTemplateExerciseSlot.GetKey()"/>.
        /// </summary>
        public WorkoutTemplateExerciseSlot GetSlotFromKey(string key)
        {
            string[] slotKeyValues = key.Split('|');

            string sectionName = slotKeyValues[0];
            int slotNumber = Convert.ToInt32(slotKeyValues[1]);

            WorkoutTemplateSection section = Sections.FirstOrDefault(s => s.SectionName == sectionName);
            if (section != null)
            {
                if (section.ExerciseSlots.Length >= slotNumber)
                {
                    return section.ExerciseSlots.FirstOrDefault(slot => slot.SlotNumber == slotNumber);
                }
            }

            // Slot not found
            return null;
        }
    }
}