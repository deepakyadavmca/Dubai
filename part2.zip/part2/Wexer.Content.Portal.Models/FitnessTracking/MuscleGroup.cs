using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class MuscleGroup
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        [ProtoMember(3)]
        public LocalisedText Keywords { get; set; }

        [ProtoMember(4)]
        public bool IsHidden { get; set; }

        //[ProtoMember(5)]
        //public string Tenant { get; set; }
    }
}