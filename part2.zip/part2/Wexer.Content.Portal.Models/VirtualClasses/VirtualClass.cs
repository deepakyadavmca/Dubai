﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Models.VirtualClasses
{
    [ProtoContract]
    public class VirtualClass
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText ClassName { get; set; }

        [ProtoMember(3)]
        public LocalisedText ClassDescription { get; set; }

        [ProtoMember(4)]
        public string ClassLanguage { get; set; }

        [ProtoMember(5)]
        public string Provider { get; set; }

        [ProtoMember(6)]
        public string Instructor { get; set; }

        [ProtoMember(7)]
        public string ImageLink { get; set; }

        [ProtoMember(8)]
        public string StreamingLink { get; set; }

        [ProtoMember(9)]
        public LocalisedText ClassCategories { get; set; }

        [ProtoMember(10)]
        public int Intensity { get; set; }

        [ProtoMember(11)]
        public int Skill { get; set; }

        [ProtoMember(12)]
        public int DurationSecond { get; set; }

        [ProtoMember(13)]
        public LocalisedText Equipments { get; set; }

        [ProtoMember(14)]
        public LocalisedText Keywords { get; set; }

        [ProtoMember(15)]
        public DateTime? StartDate { get; set; }

        [ProtoMember(16)]
        public DateTime? EndDate { get; set; }

        [ProtoMember(17)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(18)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(19)]
        public string ProviderID { get; set; }

        [ProtoMember(20)]
        public bool IsEquipment { get; set; }

        [ProtoMember(21)]
        public string ClassLanguageCode { get; set; }

        [ProtoMember(23)]
        public string AlternateLink { get; set; }

        [ProtoMember(24)]
        public string FileName { get; set; }

        [ProtoMember(25)]
        public MediaProcessingStatus Status { get; set; }

        [ProtoMember(26)]
        public MediaProcessingError ErrorType { get; set; }

        [ProtoMember(27)]
        public string JobID { get; set; }

        [ProtoMember(28)]
        public string Level { get; set; }

        [ProtoMember(29)]
        public bool Featured { get; set; }

        [ProtoMember(30)]
        public string TrailerLinkWeb { get; set; }

        [ProtoMember(31)]
        public string TrailerLinkMobile { get; set; }

        [ProtoMember(32)]
        public string TrailerName { get; set; }

        [ProtoMember(33)]
        public DateTime? ScheduleDate { get; set; }

        //[ProtoMember(34)]
        //public List<int> LabelIds { get; set; }

        [ProtoMember(35)]
        public List<string> PublishedTenants { get; set; }

        [ProtoMember(36)]
        public List<string> Labels { get; set; }

        [ProtoMember(37)]
        public string ChannelId { get; set; }

        [ProtoMember(38)]
        public LocalisedText FocusArea { get; set; }

        [ProtoMember(39)]
        public LocalisedText ClassSubCategory { get; set; }

        [ProtoMember(40)]
        public DateTime? PublishedDate { get; set; }

        [ProtoMember(41)]
        public string RawVideoFileUrl { get; set; }

        [ProtoMember(42)]
        public string Stage1EncodeVideoFileUrl { get; set; }

        [ProtoMember(43)]
        public List<string> EquipmentTypeTags { get; set; }

        [ProtoMember(44)]
        public List<string> FocusAreaTags { get; set; }

        [ProtoMember(45)]
        public int ClassCategoryId { get; set; }

        [ProtoMember(46)]
        public ProviderType ProviderType { get; set; }

        [ProtoMember(47)]
        public string Event_Id { get; set; }

        public bool isActive
        {
            get { return (StartDate <= DateTime.UtcNow || ScheduleDate <= DateTime.UtcNow); }
        }

        public bool isComplete
        {
            get { return (!(string.IsNullOrEmpty(StreamingLink))); }
        }
        
        public string QrCode { get; set; }

        [ProtoMember(48)]
        public string ExternalClassId { get; set; }

        [ProtoMember(49)]
        public MediaPlatform MediaPlatform { get; set; }

        [ProtoMember(50)]
        public bool IsDelete { get; set; }
    }
}