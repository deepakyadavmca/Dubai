﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.VirtualClasses
{
    public class VirtualClasses1
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText ClassName { get; set; }

        [ProtoMember(3)]
        public LocalisedText ClassDescription { get; set; }

        [ProtoMember(4)]
        public string ClassLanguage { get; set; }

        [ProtoMember(5)]
        public string Provider { get; set; }

        [ProtoMember(6)]
        public string Instructor { get; set; }

        [ProtoMember(7)]
        public string ImageLink { get; set; }

        [ProtoMember(8)]
        public string StreamingLink { get; set; }

        [ProtoMember(9)]
        public string[] ClassCategory { get; set; }

        [ProtoMember(10)]
        public int Intensity { get; set; }

        [ProtoMember(11)]
        public int Skill { get; set; }

        [ProtoMember(12)]
        public int DurationSecond { get; set; }

        [ProtoMember(13)]
        public string[] EquipmentType { get; set; }

        [ProtoMember(14)]
        public LocalisedText Keywords { get; set; }

        [ProtoMember(15)]
        public DateTime startDate { get; set; }

        [ProtoMember(16)]
        public DateTime endDate { get; set; }

        [ProtoMember(17)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(18)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime LastModifiedDate { get; set; }

        public string QrCode { get; set; }
    }
}