﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.VirtualClasses
{
    [ProtoContract]
    public enum VirtualClassCategory : byte
    {

        [ProtoEnum(Name = "None", Value = 0)]
        None = 0,

        [ProtoEnum(Name = "Cycling", Value = 10)]
        Cycling = 10,

        [ProtoEnum(Name = "Cardio", Value = 15)]
        Cardio = 15, //Weight loss and healthy heart

        [ProtoEnum(Name = "Conditioning", Value = 20)]
        Conditioning = 20, //Strong and firm

        [ProtoEnum(Name = "Mind-body", Value = 25)]
        Mindandbody = 25, //D'stress & Relax (Mind-body)

        [ProtoEnum(Name = "Rehab", Value = 30)]
        Rehab = 30, //No pain in back and shoulder

    }
}
