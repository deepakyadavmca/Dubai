﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.VirtualClasses
{
    [ProtoContract]
    public class OnDemandClassMetaData
    {
        [ProtoMember(1)]
        public Dictionary<string, string> Equipments { get; set; }

        [ProtoMember(2)]
        public LocalisedText[] ClassTypes { get; set; }

        [ProtoMember(3)]
        public string[] Providers { get; set; }

        [ProtoMember(4)]
        public Dictionary<string, string> Language { get; set; }

        [ProtoMember(5)]
        public int[] Duration { get; set; } 

        [ProtoMember(6)]
        public int[] Intensity { get; set; }

    }
}
