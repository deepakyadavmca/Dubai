using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class ClubArea
    {
        [ProtoMember(1)]
        public LocalisedText Name { get; set; }

        [ProtoMember(2)]
        public string ImageUri { get; set; }

        [ProtoMember(3)]
        public LocalisedText Description { get; set; }

        [ProtoMember(4)]
        public string[] EquipmentTags { get; set; }
    }
}