﻿using Wexer.Content.Portal.Models.VirtualClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Wexer.Content.Portal.Models.VirtualClassSearch
{
    public class VirtualClassSearchResultItem
    {
        public string ClassTag { get; set; }
        public VirtualClass VirtualClasses { get; set; }
        public string EquipmentTypes { get; set; }
      
    }
}
