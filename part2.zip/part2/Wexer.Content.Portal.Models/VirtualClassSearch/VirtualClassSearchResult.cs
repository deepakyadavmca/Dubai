﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.VirtualClassSearch
{
    public class VirtualClassSearchResult
    {
        public VirtualClassSearchResultItem[] Items { get; set; }
        public int ItemsRemaining { get; set; }
        public int Total { get; set; }

        public VirtualClassSearchResult()
        {
            Items = new VirtualClassSearchResultItem[0];
        }
    }
}
