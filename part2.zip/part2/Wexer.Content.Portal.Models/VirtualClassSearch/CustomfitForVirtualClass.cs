﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.CustomFit;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.VirtualClassSearch
{
    public class CustomfitForVirtualClass
    {
        public CustomfitForVirtualClass()
        {
            //AlternativeWorkoutOptions = new AlternativeWorkoutOptions();
            PrimaryGoal = (byte)FitnessGoal.None;
            ExperienceLevel = (byte)FitnessExperience.None;
            TrainingStyle = (byte)Models.TrainingStyle.None;
        }

        [ProtoMember(1), DefaultValue(99)]
        public byte PrimaryGoal { get; set; }

        [ProtoMember(2)]
        public byte? SecondaryGoal { get; set; }

        [ProtoMember(3)]
        public byte TrainingStyle { get; set; }

        [ProtoMember(4)]
        public byte ExperienceLevel { get; set; }

        //[ProtoMember(5)]
        //public byte MaximumExerciseCount { get; set; }

        [ProtoMember(6)]
        public string AverageLengthOfSession { get; set; }

        [ProtoMember(7)]
        public byte SessionLengthVariant { get; set; }

        [ProtoMember(8)]
        public string UserId { get; set; }

        //[ProtoMember(9)]
        //public string StaffId { get; set; }

        [ProtoMember(10)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime StartDate { get; set; }

        [ProtoMember(11)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? EndDate { get; set; }

        [ProtoMember(12)]
        public string ClubTag { get; set; }

        [ProtoMember(13)]
        public string Tag { get; set; }

        //[ProtoMember(14)]
        //public AlternativeWorkoutOptions AlternativeWorkoutOptions { get; set; }

        //[ProtoMember(15)]
        //public bool? SkippedCustomFit { get; set; }

        //[ProtoMember(16)]
        //public bool AcceptedTermsAndConditions { get; set; }

        //[ProtoMember(17)]
        //public DateTime? AcceptedTermsAndConditionsOnDate { get; set; }

        //[ProtoMember(18)]
        //public bool DoNotCopy { get; set; }

        // DateOfBirth, Weight and Gender added for implementation of uerstory : FFCFA-727
        // as, these 3 parameters are also required from client side for calculation of Calorie-Burn of a Workout
        //[ProtoMember(19)]
        //[SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        //public DateTime? DateOfBirth { get; set; }

        //[ProtoMember(20)]
        //public string Weight { get; set; }

        //[ProtoMember(21)]
        //public string Gender { get; set; }

        //[ProtoMember(22)]
        //public byte ActivityPreference { get; set; }

        //[ProtoMember(23)]
        //public string DeviceOS { get; set; }
        public DateTime GetStartDateOrDefaultTo(DateTime defaultDate)
        {
            return StartDate == DateTime.MinValue ? defaultDate : StartDate;
        }

        [ProtoMember(24)]
        public int? take { get; set; }

        [ProtoMember(25)]
        public int? skip { get; set; }

        //string IStorageKey.PartitionKey
        //{
        //    get { return UserId; }
        //}

        //string IStorageKey.RowKey
        //{
        //    get
        //    {
        //        if (string.IsNullOrWhiteSpace(Tag))
        //        {
        //            Tag = Guid.NewGuid().ToString();
        //        }

        //        return Tag;
        //    }
        //}

        /// <summary>
        /// Has the profile changed
        /// </summary>
        /// <param name="profile"></param>
        /// <returns></returns>
        //public bool HasChanged(UserCustomFitProfile profile)
        //{
        //    return (profile.PrimaryGoal != PrimaryGoal ||
        //            profile.SecondaryGoal != SecondaryGoal ||
        //            profile.AverageLengthOfSession != AverageLengthOfSession ||
        //            profile.ExperienceLevel != ExperienceLevel ||
        //            profile.TrainingStyle != TrainingStyle ||
        //            profile.SkippedCustomFit != SkippedCustomFit);
        //}

        //public bool HasAlternativeWorkoutOptionsSet
        //{
        //    get
        //    {
        //        return (AlternativeWorkoutOptions != null) && (AlternativeWorkoutOptions.HasThresholdSet);
        //    }
        //}


        public VirtualClassSearchCriteria Mapper()
        {
            VirtualClassSearchCriteria criteria = new VirtualClassSearchCriteria();
            if (string.IsNullOrEmpty(Enum.GetName(typeof(FitnessGoal), PrimaryGoal)) || string.IsNullOrEmpty(Enum.GetName(typeof(FitnessExperience), ExperienceLevel)))
            {
                return null;
            }
            else
            {
                criteria.duration = AverageLengthOfSession;
                criteria.take = take;
                criteria.skip = skip;
                criteria.level = GetExperienceLevel(ExperienceLevel);
                criteria.type = GetFocus(Enum.GetName(typeof(FitnessGoal), PrimaryGoal));
            }
            return criteria;
        }

        static string GetFocus(string focus)
        {
            List<string> selectedFocus = new List<string>();
            Dictionary<string, List<string>> mappings = new Dictionary<string, List<string>>();
            mappings.Add("WeightLoss", new List<string> { "Weight Loss", "Weight loss and healthy heart (Cardio)" });
            mappings.Add("Strength", new List<string> { "Strength & Conditioning" });
            mappings.Add("Focused", mappings["WeightLoss"].Concat(mappings["Strength"]).ToList());
            mappings.Add("GeneralFitness", new List<string> { "Weight Loss", "Weight loss and healthy heart (Cardio)" });
            mappings.TryGetValue(focus, out selectedFocus);
            return string.Join(",", selectedFocus);
        }

        static string GetExperienceLevel(byte experienceLevel)
        {
            if (experienceLevel == (byte)FitnessExperience.Experienced)
            {
                return "Advanced";
            }
            else if (experienceLevel == (byte)FitnessExperience.Inexperienced)
            {
                return "Beginner";
            }
            else if (experienceLevel == (byte)FitnessExperience.SomewhatExperienced)
            {
                return "Intermediate";
            }
            else
            {
                return "For everyone";
            }
        }
    }
}
