﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.VirtualClassSearch
{
    [ProtoContract]
    public class VirtualClassSearchCriteria
    {
        private readonly static char[] Separator = { ',' };

        [ProtoMember(1)]
        public int? take { get; set; }

        [ProtoMember(2)]
        public int? skip { get; set; }

        [ProtoMember(3)]
        public string type { get; set; }

        [ProtoMember(4)]
        public string equipment { get; set; }

        [ProtoMember(5)]
        public string provider { get; set; }

        [ProtoMember(6)]
        public string sort { get; set; }

        [ProtoMember(7)]
        public string dir { get; set; }

        [ProtoMember(8)]
        public string favourites { get; set; }

        [ProtoMember(9)]
        public string query { get; set; }

        [ProtoMember(10)]
        public string virtualClasses { get; set; }

        [ProtoMember(11)]
        public string languageTag { get; set; }

        [ProtoMember(12)]
        public string skill { get; set; }

        [ProtoMember(13)]
        public string duration { get; set; }

        [ProtoMember(14)]
        public string intensity { get; set; }

        [ProtoMember(15)]
        public string classLanguage { get; set; }

        [ProtoMember(16)]
        public string Tenant { get; set; }

        [ProtoMember(17)]
        public string level { get; set; }

        [ProtoMember(18)]
        public string keywords { get; set; }

        [ProtoMember(19)]
        public string focusArea { get; set; }

        [ProtoMember(20)]
        public string categoryId { get; set; }

        [ProtoMember(21)]
        public string labels { get; set; }

        [ProtoMember(22)]
        public string classLanguageName { get; set; }

        [ProtoMember(23)]
        public string subcategory { get; set; }

        [ProtoMember(25)]
        public string equipmenttags { get; set; }

        [ProtoMember(26)]
        public string focusareatags { get; set; }

        public bool MatchAll()
        {
            return ((string.IsNullOrWhiteSpace(query)) &&
                   (string.IsNullOrWhiteSpace(type)) &&
                    (string.IsNullOrWhiteSpace(provider)) &&
                    (string.IsNullOrWhiteSpace(virtualClasses)) &&
                     (string.IsNullOrWhiteSpace(equipment)) &&
                     (string.IsNullOrWhiteSpace(skill)) &&
                     (string.IsNullOrWhiteSpace(duration)) &&
                     (string.IsNullOrWhiteSpace(intensity)) &&
                     (string.IsNullOrWhiteSpace(classLanguage)) &&
                     string.IsNullOrEmpty(level) &&
                     string.IsNullOrEmpty(labels) &&
                     string.IsNullOrEmpty(classLanguageName) &&
                     string.IsNullOrEmpty(subcategory) &&
                     string.IsNullOrEmpty(categoryId) &&
                     string.IsNullOrEmpty(keywords) &&
                     string.IsNullOrEmpty(equipmenttags) &&
                     string.IsNullOrEmpty(focusareatags));
        }

        public string[] GetEquipments()
        {
            return GetCollection(equipment);
        }

        public string[] GetTypes()
        {
            return GetCollection(type);
        }

        public string[] GetCategoryId()
        {
            return GetCollection(categoryId);
        }

        public string[] GetLabels()
        {
            return GetCollection(labels);
        }

        public string[] GetVirtualClasses()
        {
            return GetCollection(virtualClasses);
        }

        public string[] GetProviders()
        {
            return GetCollection(provider);
        }

        public int[] GetSkills()
        {
            return GetIntCollection(skill);
        }

        public int[] GetDurations()
        {
            return GetIntCollection(duration);
        }

        public string[] GetClassLanguages()
        {
            return GetCollection(classLanguage);
        }

        public string[] GetClassLanguageNames()
        {
            return GetCollection(classLanguageName);
        }

        public string[] GetSubcategory()
        {
            return GetCollection(subcategory);
        }

        public string[] GetLevels()
        {
            return level != null ? level.Split(Separator, StringSplitOptions.RemoveEmptyEntries) : new string[0];
        }

        private static string[] GetCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                : new string[0];
        }

        private static int[] GetIntCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray()
                : new int[0];
        }

        public int[] GetIntensity()
        {
            return GetIntCollection(intensity);
        }

        public string[] GetKeywords()
        {
            return GetKeywordCollection(keywords);
        }
        private static string[] GetKeywordCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                : new string[0];
        }

        public string[] GetFocusAreas()
        {
            return GetFocusAreasCollection(focusArea);
        }

        private static string[] GetFocusAreasCollection(string filter)
        {
            return filter != null
                ? filter.Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                : new string[0];
        }
    }
}
