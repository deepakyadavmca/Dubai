﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Translation
{
    [ProtoContract]
    public class TranslationResult : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string TypeName { get; set; }

        [ProtoMember(3)]
        public string PropertyName { get; set; }

        [ProtoMember(4)]
        public LocalText[] LanguagesRequiringTranslation { get; set; }

        [ProtoMember(5)]
        public string InvariantText { get; set; }

        [ProtoMember(6)]
        public string LanguagesRequiringTransalationFlattened { get; set; }

        [ProtoMember(7)]
        public string EntityTag { get; set; }

        string IStorageKey.PartitionKey
        {
            get { return this.TypeName; }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return string.Format("{0}-{1}-{2}", TypeName, PropertyName, EntityTag);
            }
        }
    }
}
