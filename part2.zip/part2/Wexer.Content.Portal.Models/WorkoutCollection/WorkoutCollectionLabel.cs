﻿using ProtoBuf;
using System;

namespace Wexer.Content.Portal.Models.WorkoutCollection
{
    [ProtoContract]
    public class WorkoutCollectionLabel
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        [ProtoMember(3)]
        public bool Published { get; set; }

        [ProtoMember(4)]
        public bool AvailableOption { get; set; }

        [ProtoMember(5)]
        public string TenantId { get; set; }

        [ProtoMember(6)]
        public DateTime? CreatedDate { get; set; }

        [ProtoMember(7)]
        public DateTime? LastModifiedDate { get; set; }
        
    }
}
