using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public struct ClubOpeningHours
    {
        [ProtoMember(1)]
        public OpeningHours Monday { get; set; }
        [ProtoMember(2)]
        public OpeningHours Tuesday { get; set; }
        [ProtoMember(3)]
        public OpeningHours Wednesday { get; set; }
        [ProtoMember(4)]
        public OpeningHours Thursday { get; set; }
        [ProtoMember(5)]
        public OpeningHours Friday { get; set; }
        [ProtoMember(6)]
        public OpeningHours Saturday { get; set; }
        [ProtoMember(7)]
        public OpeningHours Sunday { get; set; }
        [ProtoMember(8)]
        public OpeningHours BankHoliday { get; set; }
    }
}