﻿using ProtoBuf;


    namespace Wexer.Content.Portal.Models.Tenant
    {
          [ProtoContract]
    public class TenantUserEmailIndex : IStorageKey
        {


            [ProtoMember(1)]
            public string EmailAddress { get; set; }

            [ProtoMember(2)]
            public string UserId { get; set; }

            [ProtoMember(3)]
            public string TenantID { get; set; }


            [ProtoMember(4)]
            public string CountryCode { get; set; }

            string IStorageKey.PartitionKey
            {
                get
                {
                    return TenantID.ToLowerInvariant();
                }
            }

            string IStorageKey.RowKey
            {
                get { return this.EmailAddress.ToLowerInvariant(); }
            }
        }
    }




