using ProtoBuf;

namespace Wexer.Content.Portal.Models.MembershipData
{
    [ProtoContract]
    public class UserMembershipIndex : IStorageKey
    {
        [ProtoMember(1)]
        public string MembershipNumber { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public string CountryCode { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return string.Format("{0}{1}", this.CountryCode.ToUpperInvariant(), this.MembershipNumber.ToLowerInvariant());
            }
        }

        string IStorageKey.RowKey
        {
            get { return MembershipNumber.ToLowerInvariant(); }
        }
    }
}