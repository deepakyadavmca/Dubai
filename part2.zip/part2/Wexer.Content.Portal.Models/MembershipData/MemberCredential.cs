using Wexer.Content.Portal.Models.User;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.MembershipData
{
    [ProtoContract]
    public class MemberCredential : IStorageKey
    {
        // Partition Key: CountryTag
        // RowKey: MembershipNumber
        [ProtoMember(1)]
        public string CountryTag { get; set; }
        
        [ProtoMember(2)]
        public string MembershipNumber { get; set; }

        [ProtoMember(3)]
        public string EmailAddress { get; set; }
        
        [SensitiveData]
        [ProtoMember(4)]
        public string PasswordHash { get; set; }

        //http://msdn.microsoft.com/en-us/library/windowsazure/hh508997.aspx
        string IStorageKey.PartitionKey
        {
            get { return string.Format("{0}{1}", CountryTag.ToUpperInvariant(), MembershipNumber); }
        }

        string IStorageKey.RowKey
        {
            get { return MembershipNumber; }
        }
    }
}