using System;
using Wexer.Content.Portal.Models.FitnessClasses;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.MembershipData
{
    [ProtoContract]
    public class TimetableUpdateTable : IStorageKey
    {
        [ProtoMember(1)]
        public string Tag{ get; set; }

        [ProtoMember(2)]
        public string CountryTag { get; set; }

        [ProtoMember(3)]
        public DateTime LastUpdated { get; set; }

        [ProtoMember(4)]
        public Timetable[] Timetables { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return Tag;
            }
        }

        string IStorageKey.RowKey
        {
            get { return LastUpdated.ToString("yyyy-MM-dd hh:mm:ss"); }
        }
    }
}