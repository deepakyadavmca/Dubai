﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.MembershipData
{
    public class UserProfileMerge
    {
        public string MembershipNumber { get; set; }

        public string LastName { get; set; }

        public string CountryTag { get; set; }

    }
}
