using ProtoBuf;

namespace Wexer.Content.Portal.Models.MembershipData
{
    [ProtoContract]
    public class TestUserIndex : IStorageKey
    {
        [ProtoMember(1)]
        public string EmailAddress { get; set; }

        [ProtoMember(2)]
        public string UserId { get; set; }

        [ProtoMember(3)]
        public string CountryCode { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return CountryCode;
            }
        }

        string IStorageKey.RowKey
        {
            get { return this.UserId; }
        }
    }
}