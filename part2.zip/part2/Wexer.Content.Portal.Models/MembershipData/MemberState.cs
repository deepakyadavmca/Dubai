﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.MembershipData
{
    [ProtoContract]
    public class MemberState : IStorageKey
    {        
      [ProtoMember(1)]
        public string CountryTag { get; set; }

        [ProtoMember(2)]
        public string MembershipNumber { get; set; }

        [ProtoMember(3)]
        public string HomeClubTag { get; set; }
        
        [ProtoMember(4)]
        public string FirstName { get; set; }
        
        [ProtoMember(5)]
        public string LastName { get; set; }
        
        [ProtoMember(6)]
        public string Gender { get; set; }
        
        [ProtoMember(7)]
        public DateTime BirthDate { get; set; }
        
        [ProtoMember(8)]
        public string EmailAddress { get; set; }

        [ProtoMember(9)]
        public DateTime JoinDate { get; set; }
        
        [ProtoMember(10)]
        public DateTime? LeaveDate { get; set; }

        [ProtoMember(11)]
        public string TierCode { get; set; }


        string IStorageKey.PartitionKey
        {
            get { return string.Format("{0}{1}", CountryTag, MembershipNumber); }
        }

        string IStorageKey.RowKey
        {
            get { return MembershipNumber; }
        }
    }
}
