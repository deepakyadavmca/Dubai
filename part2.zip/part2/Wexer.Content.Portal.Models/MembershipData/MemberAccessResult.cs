using ProtoBuf;

namespace Wexer.Content.Portal.Models.MembershipData
{
    [ProtoContract]
    public class MemberAccessResult : IStorageKey
    {
        [ProtoMember(1)]
        public string MemberAccessTag { get; set; }
        [ProtoMember(2)]
        public string AccessId { get; set; }

         [ProtoMember(3)]
        public TrackingResult TrackingResult { get; set; }
        [ProtoMember(4)]
        public string ResultTag { get; set; }
        [ProtoMember(5)]
        public string ResultSource { get; set; }

        string IStorageKey.PartitionKey
        {
            get { return MemberAccessTag; }
        }

        string IStorageKey.RowKey
        {
            get { return AccessId; }
        }


    }
}