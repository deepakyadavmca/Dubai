﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models
{
    public class ProviderUser
    {
        public string Id { get; set; }
        public string First_name { get; set; }
        public string Last_name { get; set; }
        public string Country_Code { get; set; }
        public string Email { get; set; }
        public string ExternalId { get; set; }
        public UserCenter Home_Center { get; set; }
        public Contracts[] Data { get; set; }
        public int SubscriptionStatusCode { get; set; }
    }

    public class UserCenter
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class Contracts
    {
        public int Id { get; set; }
        public DateTime ContractBegin { get; set; }
        public DateTime SigningDate { get; set; }
        public DateTime AccessEndDate { get; set; }
        public DateTime AccessBeginDate { get; set; }
        public string CService { get; set; }
        public string CName { get; set; }

    }


    public class RepeatSubscriptions
    {
        public string State { get; set; }
        public string Price { get; set; }
        public string StartDate { get; set; }
        public string BindingEndDate { get; set; }
        public SubscriptionId SubscriptionId { get; set; }
        public Product Product { get; set; }
        public PersonId PersonId { get; set; }
    }

    public class SubscriptionId
    {
        public string Center { get; set; }
        public string Id { get; set; }
    }
    public class Product
    {
        public string GlobalId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
    }

    public class PersonId
    {
        public string Center { get; set; }
        public string Id { get; set; }
    }
}
