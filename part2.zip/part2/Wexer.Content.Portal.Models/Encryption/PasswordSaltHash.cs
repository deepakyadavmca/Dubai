﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Wexer.Content.Portal.Models.Encryption
{
    public static class PasswordSaltHash
    {
        //http://www.obviex.com/samples/hash.aspx
        public static string GenerateHash(string password, byte[] saltBytes = null)
        {
            if (password != null)
            {
                if (saltBytes == null)
                {
                    // Define min and max salt sizes.
                    const int minSaltSize = 4;
                    const int maxSaltSize = 8;

                    // Generate a random number for the size of the salt.
                    var random = new Random();
                    int saltSize = random.Next(minSaltSize, maxSaltSize);

                    // Allocate a byte array, which will hold the salt.
                    saltBytes = new byte[saltSize];

                    // Initialize a random number generator.
                    var rng = new RNGCryptoServiceProvider();

                    // Fill the salt with cryptographically strong byte values.
                    rng.GetNonZeroBytes(saltBytes);
                }

                // Convert plain text into a byte array.
                byte[] plainTextBytes = Encoding.UTF8.GetBytes(password);

                // Allocate array, which will hold plain text and salt.
                var plainTextWithSaltBytes =
                    new byte[plainTextBytes.Length + saltBytes.Length];

                // Copy plain text bytes into resulting array.
                for (int i = 0; i < plainTextBytes.Length; i++)
                {
                    plainTextWithSaltBytes[i] = plainTextBytes[i];
                }

                // Append salt bytes to the resulting array.
                for (int i = 0; i < saltBytes.Length; i++)
                {
                    plainTextWithSaltBytes[plainTextBytes.Length + i] = saltBytes[i];
                }

                HashAlgorithm hash = new SHA512Managed();

                // Compute hash value of our plain text with appended salt.
                byte[] hashBytes = hash.ComputeHash(plainTextWithSaltBytes);

                // Create array which will hold hash and original salt bytes.
                var hashWithSaltBytes = new byte[hashBytes.Length +
                                                 saltBytes.Length];

                // Copy hash bytes into resulting array.
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    hashWithSaltBytes[i] = hashBytes[i];
                }

                // Append salt bytes to the result.
                for (int i = 0; i < saltBytes.Length; i++)
                {
                    hashWithSaltBytes[hashBytes.Length + i] = saltBytes[i];
                }

                // Convert result into a base64-encoded string.
                string hashValue = Convert.ToBase64String(hashWithSaltBytes);

                // Return the result.
                return hashValue;
            }
            return null;
        }

        public static bool VerifyHash(string password, string hashValue)
        {
            if (string.IsNullOrEmpty(hashValue))
            {
                return false;
            }

            // Convert base64-encoded hash value into a byte array.
            byte[] hashWithSaltBytes = Convert.FromBase64String(hashValue);

            // We must know size of hash (without salt).

            const int hashSizeInBits = 512;

            // Convert size of hash from bits to bytes.
            const int hashSizeInBytes = hashSizeInBits / 8;

            // Make sure that the specified hash value is long enough.
            if (hashWithSaltBytes.Length < hashSizeInBytes)
            {
                return false;
            }

            // Allocate array to hold original salt bytes retrieved from hash.
            var saltBytes = new byte[hashWithSaltBytes.Length -
                                        hashSizeInBytes];

            // Copy salt from the end of the hash to the new array.
            for (int i = 0; i < saltBytes.Length; i++)
            {
                saltBytes[i] = hashWithSaltBytes[hashSizeInBytes + i];
            }

            // Compute a new hash string.
            string expectedHashString =
                        GenerateHash(password, saltBytes);

            // If the computed hash matches the specified hash,
            // the plain text value must be correct.
            return (hashValue == expectedHashString);
        }

        public static string GenerateSHA256Checksum(Stream stream)
        {
            using (var sha = new SHA256Managed())
            {
                byte[] checksum = sha.ComputeHash(new BufferedStream(stream));
                return (BitConverter.ToString(checksum).Replace("-", String.Empty));
            }
        }

        public static string GenerateSHA256Checksum(string value)
        {
            using (var sha = new SHA256Managed())
            {
                byte[] checksum = sha.ComputeHash(Encoding.Unicode.GetBytes(value));
                return (BitConverter.ToString(checksum).Replace("-", String.Empty));
            }
        }
    }
}
