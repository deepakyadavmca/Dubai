﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Encryption
{
    [ProtoContract]
    public class SecurityPhrase
    {
        [ProtoMember(1)]
        public string PassPhrase { get; set; }

        [ProtoMember(2)]
        public string SaltValue { get; set; }
    }
}
