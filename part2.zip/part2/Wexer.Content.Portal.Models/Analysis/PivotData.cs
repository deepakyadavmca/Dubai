using ProtoBuf;
using Wexer.Content.Portal.Models.FitnessTracking;


namespace Wexer.Content.Portal.Models.Analysis
{
    [ProtoContract]
    public class PivotData
    {
        public string[] Headers { get; set; }
        public PivotPoints[] DataPoints { get; set; }
    }
}