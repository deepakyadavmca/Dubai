using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Analysis
{
    [ProtoContract]
    public class PivotPoints
    {
        public DateTime Date { get; set; }
        public int[] Values { get; set; }
    }
}