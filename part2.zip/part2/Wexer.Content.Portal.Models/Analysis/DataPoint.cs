using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Analysis
{
    [ProtoContract]
    public class DataPoint
    {
        public DateTime Date { get; set; }
        public int Value { get; set; }
    }
}