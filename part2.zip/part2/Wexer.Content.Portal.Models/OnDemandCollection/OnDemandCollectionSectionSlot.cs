﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class OnDemandCollectionSectionSlot
    {
        [ProtoMember(1)]
        public string OnDemandClassTag { get; set; }

        [ProtoMember(2)]
        public int ItemNumber { get; set; }

        [ProtoMember(3)]
        public string Provider { get; set; }

        [ProtoMember(4)]
        public string Category { get; set; }

        [ProtoMember(5)]
        public DateTime? ScheduleDate { get; set; }
    }
}
