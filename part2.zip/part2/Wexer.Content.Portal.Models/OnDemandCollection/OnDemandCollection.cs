﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.OnDemandCollection;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.FitnessTracking
{
    [ProtoContract]
    public class OnDemandCollection
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string InternalName { get; set; }

        [ProtoMember(3)]
        public LocalisedText Name { get; set; }

        [ProtoMember(4)]
        public bool IsActive { get; set; }

        [ProtoMember(5)]
        public string AvailableCountry { get; set; }

        [ProtoMember(6)]
        public OnDemandCollectionSection[] Section { get; set; }

        [ProtoMember(7)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime CreationDate { get; set; }

        [ProtoMember(8)]
        public DateTime LastModifiedDate { get; set; }

        [ProtoMember(9)]
        public string TenantId { get; set; }

        [ProtoMember(10)]
        public bool IsFeaturedCollection { get; set; }

        [ProtoMember(11)]
        public int SequenceNumber { get; set; }

        [ProtoMember(12)]
        public string Description { get; set; }

        [ProtoMember(13)]
        public bool IsClassOfDayCollection { get; set; }

        [ProtoMember(14)]
        public DateTime? StartDate { get; set; }
    }
}
