﻿using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.OnDemandCollection
{
    [ProtoContract]
    public class OnDemandCollectionSection
    {
        [ProtoMember(1)]
        public string OnDemandCollectionTag { get; set; }

        [ProtoMember(2)]
        public LocalisedText SectionName { get; set; }

        [ProtoMember(3)]
        public bool IsOptional { get; set; }

        [ProtoMember(4)]
        public OnDemandCollectionSectionSlot[] Slot { get; set; }
    }
}
