﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Models.OnDemandCollection
{
    public class OnDemandCollectionType
    {
        public const string Featured = "Featured";
        public const string Managed = "Managed";
        public const string Favourites = "Favourites";
        public const string ClassOfTheDay = "ClassOfTheDay";
    }
}
