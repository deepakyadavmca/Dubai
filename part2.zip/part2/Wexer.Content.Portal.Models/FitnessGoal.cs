using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum FitnessGoal : byte
    {
        [ProtoEnum(Name = "GeneralFitness", Value = 0)]
        GeneralFitness = 0,

        [ProtoEnum(Name = "WeightLoss", Value = 10)]
        WeightLoss = 10,

        [ProtoEnum(Name = "Strength", Value = 20)]
        Strength = 20,

        [ProtoEnum(Name = "Hypertrophy", Value = 30)]
        Hypertrophy = 30,

        [ProtoEnum(Name = "AthleticFitness", Value = 40)]
        AthleticFitness = 40,

        [ProtoEnum(Name = "Flexibility", Value = 50)]
        Flexibility = 50,

        [ProtoEnum(Name = "Focused", Value = 60)]
        Focused = 60,

        [ProtoEnum(Name = "None", Value = 99)]
        None = 99,
    }
}