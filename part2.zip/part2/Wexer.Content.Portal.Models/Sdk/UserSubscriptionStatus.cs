﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Sdk
{
    public enum UserSubscriptionStatus
    {
        NotActive,
        Active,
        Inactive
    }
}
