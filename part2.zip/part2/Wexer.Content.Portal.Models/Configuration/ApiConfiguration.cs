﻿namespace Wexer.Content.Portal.Models.Configuration
{
    using ProtoBuf;

    [ProtoContract]
    public class ApiConfiguration
    {
        /// <summary>
        /// Gets or sets the API version number.
        /// </summary>
        /// <value>
        /// The API version number.
        /// </value>
        [ProtoMember(1)]
        public string ApiVersionNumber { get; set; }
    }
}