﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    public enum BookingStatus
    {
        Cancelled = 0,
        Booked = 1,
        UserCheckIn = 2,
        StaffCheckIn = 3
    }
}
