﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProtoBuf;
namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class FitnessClassBooking
    {
        [ProtoMember(1)]
        public DateTime ClassStartTimeUTC { get; set; }
        [ProtoMember(2)]
        public string UserBookingTag { get; set; }
        [ProtoMember(3)]
        public int AvailableSlots { get; set; }
    }
}
