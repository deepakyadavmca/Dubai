﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    public class BookingRequest
    {
        public string tag { get; set; }
        public string FitnessClassID { get; set; }
        public string ClubTag { get; set; }
        public string ClassTypeTag { get; set; }
        public DateTime StartDate { get; set; }
        public int StartTimeMinutes { get; set; }
        public int Duration { get; set; }
        public DateTime ClassStartTimeUtc { get; set; }
        public string UserID { get; set; }
        public string LanguageTag { get; set; }
        public string CreatedBy { get; set; }
    }
}
