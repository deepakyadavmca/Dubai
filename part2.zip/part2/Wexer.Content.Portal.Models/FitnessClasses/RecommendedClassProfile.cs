using System.Collections.Generic;

using Wexer.Content.Portal.Models.CustomFit;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    /// <summary>
    /// Custom Fit recommended class profile
    /// </summary>
    public class RecommendedClassProfile
    {
        public IEnumerable<RecommendedClass> RecommendedClasses { get; set; }
        public UserCustomFitProfile CustomFitProfile { get; set; }
    }
}