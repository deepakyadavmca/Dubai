using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class ClassCategory
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }
    }
}