﻿using ProtoBuf;
using System;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class Booking
    {
        [ProtoMember(1)]
        public string ID { get; set; }

        [ProtoMember(2)]
        public string FitnessClassID { get; set; }

        [ProtoMember(3)]
        public DateTime FitnessClassInstanceDate { get; set; }

        [ProtoMember(4)]
        public string UserID { get; set; }

        [ProtoMember(5)]
        public BookingStatus BookingStatus { get; set; }

        [ProtoMember(6)]
        public string BookedBy { get; set; }

        [ProtoMember(7)]
        public DateTimeOffset CreateUTC { get; set; }

        [ProtoMember(8)]
        public bool IsPaymentDone { get; set; }

        [ProtoMember(9)]
        public double PaymentAmount { get; set; }

        [ProtoMember(10)]
        public DateTimeOffset LastModifiedUTC { get; set; }

        [ProtoMember(11)]
        public string Studio { get; set; }

        [ProtoMember(12)]
        public DateTime ClassStartTimeUTC { get; set; }
    }
}