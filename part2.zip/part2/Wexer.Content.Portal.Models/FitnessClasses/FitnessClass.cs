using ProtoBuf;
using System;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class FitnessClass
    {
        [ProtoMember(1)]
        public string ClubTag { get; set; }
        [ProtoMember(2)]
        public string ClassTypeTag { get; set; }
        [ProtoMember(3)]
        public int DayOfWeek { get; set; }
        [ProtoMember(4)]
        public int StartTimeMinutes { get; set; }
        [ProtoMember(5)]
        public int DurationMinutes { get; set; }
        [ProtoMember(6)]
        public bool IsBookingRequired { get; set; }
        [ProtoMember(7)]
        public bool IsFeeRequired { get; set; }
        [ProtoMember(8)]
        public bool IsNew { get; set; }
        [ProtoMember(9)]
        public string InstructorName { get; set; }
        [ProtoMember(10)]
        public string FitnessLevel { get; set; }
        [ProtoMember(11)]
        public string Id { get; set; }
        [ProtoMember(12)]
        public string StudioName { get; set; }

        [ProtoMember(13)]
        public int EndTimeMinutes { get; set; }
        [ProtoMember(14)]
        public DateTime StartDate { get; set; }
        [ProtoMember(15)]
        public DateTime? EndDate { get; set; }
        [ProtoMember(16)]
        public bool Repeat { get; set; }
        [ProtoMember(17)]
        public bool IsCancelled { get; set; }
        [ProtoMember(18)]
        public Instructor Instructor { get; set; }
        [ProtoMember(19)]
        public Studio Studio { get; set; }
        [ProtoMember(20)]
        public BookingInfo BookingInfo { get; set; }
        [ProtoMember(21)]
        public string[] SkipDate { get; set; }
        [ProtoMember(22)]
        public FitnessClassBooking[] FitnessClassBooking { get; set; }
        [ProtoMember(23)]
        public string CreatedBy { get; set; }
        [ProtoMember(24)]
        public DateTime? CreatedUtc { get; set; }
        [ProtoMember(25)]
        public string UpdatedBy { get; set; }
        [ProtoMember(26)]
        public DateTime? LastModifiedUtc { get; set; }

    }
}