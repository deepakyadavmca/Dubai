using System;
using Wexer.Content.Portal.Models.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class ClassType
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public LocalisedText Name { get; set; }

        [ProtoMember(3)]
        public string ImageUri { get; set; }

        [ProtoMember(4)]
        public LocalisedText Description { get; set; }

        [ProtoMember(5)]
        public FitnessGoal PrimaryFitnessGoal { get; set; }

        [ProtoMember(6)]
        public FitnessGoal[] SecondaryFitnessGoals { get; set; }

        [ProtoMember(7)]
        public FitnessExperience FitnessExperience { get; set; }

        [ProtoMember(8)]
        public TrainingStyle TrainingStyle { get; set; }

        [ProtoMember(9)]
        public float PlanesOfMovement { get; set; }

        [ProtoMember(10)]
        public float CardioPercentage { get; set; }

        [ProtoMember(11)]
        public float ResistancePercentage { get; set; }
        
        [ProtoMember(12)]
        public string CountryCode { get; set; }

        [ProtoMember(13)]
        public string VideoUri { get; set; }

        [ProtoMember(14)]
        public string[] CategoryTags { get; set; }

        [ProtoMember(15)]
        public LocalisedText Strapline { get; set; }

        [ProtoMember(16)]       
        public bool Deleted { get; set; }

        [ProtoMember(17)]        
        public int IntensityLevel { get; set; }

        [ProtoMember(18)] 
        public DateTime LastModified { get; set; }

        [ProtoMember(19)]
        public string TagLine { get; set; }

    }
}