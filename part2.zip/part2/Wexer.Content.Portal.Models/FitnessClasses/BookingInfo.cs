﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProtoBuf;
namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class BookingInfo
    {
        [ProtoMember(1)]
        public int TotalCapacity { get; set; }
        [ProtoMember(2)]
        public int BookableCapacity { get; set; }
        [ProtoMember(3)]
        public int PreBookingTime { get; set; }
        //[ProtoMember(4)]
        //public int BookingModificationsAllowed { get; set; }
        [ProtoMember(4)]
        public int WaitListTime { get; set; }
        [ProtoMember(5)]
        public double MemberPrice { get; set; }
        [ProtoMember(6)]
        public double NonMemberPrice { get; set; }
    }
}
