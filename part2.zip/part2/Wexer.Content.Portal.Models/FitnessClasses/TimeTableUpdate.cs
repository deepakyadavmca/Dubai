﻿using System;
using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class TimetableUpdate
    {
        [ProtoMember(1)]
        public string ClubTag { get; set; }
        [ProtoMember(2)]
        public string ETag { get; set; }
        [ProtoMember(3)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime LastModified { get; set; }
    }
}
