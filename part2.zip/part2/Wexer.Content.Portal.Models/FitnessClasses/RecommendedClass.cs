namespace Wexer.Content.Portal.Models.FitnessClasses
{
    /// <summary>
    /// Used by custom fit engine.  Club timetables Passed in from Web / Mobile app
    /// and filtered by custom fit engine.
    /// </summary>
    public class RecommendedClass
    {
        public string ClassTypeTag { get; set; }
        public int DurationInMinutes{ get; set; }
        public string ClubTag { get; set; }
    }
}