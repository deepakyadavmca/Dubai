using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.FitnessClasses
{
    [ProtoContract]
    public class Timetable : IEquatable<Timetable>
    {
        [ProtoMember(1)]
        public string ClubTag { get; set; }

        [ProtoMember(2)]
        public FitnessClass[] FitnessClasses { get; set; }

        /// <summary>
        /// Indicates whether the current object is equal to another object of the same type.
        /// </summary>
        /// <param name="other">An object to compare with this object.</param>
        /// <returns>
        /// true if the current object is equal to the <paramref name="other" /> parameter; otherwise, false.
        /// </returns>
        public bool Equals(Timetable other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }

            return string.Equals(ClubTag, other.ClubTag);
        }

        /// <summary>
        /// Determines whether the specified <see cref="System.Object" />, is equal to this instance.
        /// </summary>
        /// <param name="obj">The <see cref="System.Object" /> to compare with this instance.</param>
        /// <returns>
        ///   <c>true</c> if the specified <see cref="System.Object" /> is equal to this instance; otherwise, <c>false</c>.
        /// </returns>
        public override bool Equals(object obj)
        {
            return Equals(obj as Timetable);
        }

        /// <summary>
        /// Returns a hash code for this instance.
        /// </summary>
        /// <returns>
        /// A hash code for this instance, suitable for use in hashing algorithms and data structures like a hash table. 
        /// </returns>
        public override int GetHashCode()
        {
            unchecked
            {
                return ClubTag == null ? 0 : ClubTag.GetHashCode();
            }
        }

        public static bool operator == (Timetable leftOperand, Timetable rightOperand)
        {
            if (ReferenceEquals(null, leftOperand))
            {
                return ReferenceEquals(null, rightOperand);
            }

            return leftOperand.Equals(rightOperand);
        }

        public static bool operator != (Timetable leftOperand, Timetable rightOperand)
        {
            return !(leftOperand == rightOperand);
        }
    }
}