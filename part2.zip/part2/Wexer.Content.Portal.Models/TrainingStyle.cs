using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum TrainingStyle : byte
    {
        [ProtoEnum(Name = "None", Value = 0)]
        None = 0, // No Equipment 

        [ProtoEnum(Name = "Progressive", Value = 50)]
        Progressive = 50,// Free Style

        [ProtoEnum(Name = "Hybrid", Value = 100)]
        Hybrid = 100,

        [ProtoEnum(Name = "Traditional", Value = 150)]
        Traditional = 150 // Standard 
    }
}