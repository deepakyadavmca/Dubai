﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class TermsAndConditions
    {
        /// <summary>
        /// The unique vesrion code for the TermsAndConditions Update
        /// </summary>
        [ProtoMember(1)]
        public string Tag { get; set; }


        [ProtoMember(2)]
        public DateTime TermsAndConditionsUpdateDate { get; set; }

      
    }
}
