﻿namespace Wexer.Content.Portal.Models.Authentication
{
    public class AuthenticationModel
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public string UserId { get; set; }
        public string Code { get; set; }

        public bool Success { get; set; }
        public string Error { get; set; }

        public string ExternalUserId { get; set; }

        public int SubscriptionStatusCode { get; set; }
    }
}
