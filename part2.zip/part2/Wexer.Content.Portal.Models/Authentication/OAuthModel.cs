﻿namespace Wexer.Content.Portal.Models.Authentication
{
    public class OAuthModel
    {
        public string UserToken { get; set; }
    }
}