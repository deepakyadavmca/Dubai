﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Authentication
{
    [ProtoContract]
    public enum AdminUserRole
    {
        [ProtoEnum(Name = "SuperUser", Value = 0)]
        SuperUser,

        [ProtoEnum(Name = "AdminUser", Value = 1)]
        AdminUser,

        [ProtoEnum(Name = "ContentEditor", Value = 2)]
        ContentEditor,

        [ProtoEnum(Name = "ReadOnly", Value = 3)]
        ReadOnly
    }
}