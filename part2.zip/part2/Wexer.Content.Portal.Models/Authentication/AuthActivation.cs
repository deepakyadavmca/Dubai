﻿
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Authentication
{
    [ProtoContract]
    public class AuthActivation
    {
        [ProtoMember(1)]
        public string ActivateId { get; set; }

        [ProtoMember(2)]
        public string UserName { get; set; }
    }
}
