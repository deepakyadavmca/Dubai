﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Authentication
{
    [ProtoContract]
    public class UserManagement
    {
    }
}