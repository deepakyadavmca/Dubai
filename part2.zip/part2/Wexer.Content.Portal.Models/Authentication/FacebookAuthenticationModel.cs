﻿namespace Wexer.Content.Portal.Models.Authentication
{
    public class FacebookAuthenticationModel
    {
        public string EmailAddress { get; set; }
        public string FacebookUserId { get; set; }
        public string UserId { get; set; }
        public string Code { get; set; }

        public bool Success { get; set; }
        public string Error { get; set; }
    }
}
