﻿using System;
using Wexer.Content.Portal.Models.Attributes;

namespace Wexer.Content.Portal.Models.Authentication
{
    using ProtoBuf;

    [ProtoContract]
    public class AdminUser
    {
        [ProtoMember(1)]
        public string UserName { get; set; }

        [ProtoMember(2)]
        public string Password { get; set; }

        [ProtoMember(3)]
        public AdminUserRole[] Roles { get; set; }

        [ProtoMember(4)]
        public string Email { get; set; }

        [ProtoMember(5)]
        public string MobileTelephone { get; set; }

        [ProtoMember(6)]
        public string FirstName { get; set; }

        [ProtoMember(7)]
        public string LastName { get; set; }

        [ProtoMember(8)]
        public bool Activated { get; set; }

        [ProtoMember(9)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? DateActivated { get; set; }

        [ProtoMember(10)]
        public string ActivationCode { get; set; }

        [ProtoMember(11)]
        public string IpAddress { get; set; }

        [ProtoMember(12)]
        public DateTime? LastLoggedIn { get; set; }

        [ProtoMember(13)]
        public string Culture { get; set; }

        //New property for current language selected by admin user.
        [ProtoMember(14)]
        public string LanguageSelected { get; set; }
    }
}
