using System;
using ProtoBuf;
using Wexer.Content.Portal.Models.FitnessClasses;

namespace Wexer.Content.Portal.Models
{
    /// <summary>
    /// Represents a Fitness First Club.
    /// </summary>
    [ProtoContract]
    public class Club
    {
        /// <summary>
        /// The unique identification code for the club
        /// </summary>
        [ProtoMember(1)]
        public string Tag { get; set; }

        /// <summary>
        /// The name of the club to be used when displaying the club. This is language neutral.
        /// </summary>
        [ProtoMember(2)]
        public string ClubName { get; set; }

        /// <summary>
        /// Gets or sets the members first club code.
        /// </summary>
        /// <value>
        /// The members first club code.
        /// </value>
        [ProtoMember(3)]
        public string MembersFirstClubCode { get; set; }

        /// <summary>
        /// Gets or sets the legacy CMS (EPiServer 6) page identifier.
        /// </summary>
        /// <value>
        /// The legacy CMS (EPiServer 6) page identifier.
        /// </value>
        [ProtoMember(4)]
        public string LegacyCmsPageId { get; set; }

        /// <summary>
        /// The geographic location of the club
        /// </summary>
        [ProtoMember(5)]
        public GeoLocation GeoLocation { get; set; }

        /// <summary>
        /// The postal address of the club
        /// </summary>
        [ProtoMember(6)]
        public PostalAddress PostalAddress { get; set; }

        /// <summary>
        /// The country that the club is within
        /// </summary>
        [ProtoMember(7)]
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        [ProtoMember(8)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the fax number.
        /// </summary>
        /// <value>
        /// The fax number.
        /// </value>
        [ProtoMember(9)]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets the email address.
        /// </summary>
        /// <value>
        /// The email address.
        /// </value>
        [ProtoMember(10)]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Gets or sets the opening date.
        /// </summary>
        /// <value>
        /// The opening date.
        /// </value>
        [ProtoMember(11)]
        public DateTime? OpeningDate { get; set; }

        /// <summary>
        /// Gets or sets the open hours for the club
        /// </summary>
        /// <value>
        /// The open hours.
        /// </value>
        [ProtoMember(12)]
        public BusinessHours BusinessHours { get; set; }

        /// <summary>
        /// Gets or sets the club tier.
        /// </summary>
        /// <value>
        /// The tier.
        /// </value>
        [ProtoMember(13)]
        public ClubTier Tier { get; set; }

        /// <summary>
        /// Gets or sets the studios.
        /// </summary>
        /// <value>
        /// The studios.
        /// </value>
        [ProtoMember(14)]
        public string[] Studios { get; set; }

        /// <summary>
        /// Gets or sets the instructor names.
        /// </summary>
        /// <value>
        /// The instructor names.
        /// </value>
        [ProtoMember(15)]
        public string[] InstructorNames { get; set; }

        /// <summary>
        /// Gets or sets the Sales First Club Name.
        /// </summary>
        [ProtoMember(16)]
        public string SalesFirstClubName { get; set; }

        /// <summary>
        /// Gets or sets the sales first club name partner leads.
        /// </summary>
        [ProtoMember(17)]
        public string SalesFirstClubNamePartnerLeads { get; set; }

        /// <summary>
        /// Gets or sets the GFM email address.
        /// </summary>
        [ProtoMember(18)]
        public string GfmEmailAddress { get; set; }

        /// <summary>
        /// Gets or sets the Time Zone.
        /// </summary>
        [ProtoMember(19)]
        public string TimeZone { get; set; }

        /// <summary>
        /// Gets or sets the gallery images.
        /// </summary>
        [ProtoMember(20)]
        public string[] ImageUri { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Club"/> is deleted.
        /// </summary>
        /// <value>
        ///   <c>true</c> if deleted; otherwise, <c>false</c>.
        /// </value>
        [ProtoMember(21)]
        public bool Deleted { get; set; }

        [ProtoMember(22)]
        public Instructor[] Instructor { get; set; }

        [ProtoMember(23)]
        public Studio[] Studio { get; set; }

        [ProtoMember(24)]
        public string Country { get; set; }

        [ProtoMember(25)]
        public string County { get; set; }

        [ProtoMember(26)]
        public bool BookingAllowed { get; set; }

        [ProtoMember(27)]
        public DateTime? LastUpdated { get; set; }

    }
}