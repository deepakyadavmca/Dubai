using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public struct OpeningHours
    {
        [ProtoMember(1)]
        public short OpeningTimeMinutes { get; set; }

        [ProtoMember(2)]
        public short ClosingTimeMinutes { get; set; }
    }
}