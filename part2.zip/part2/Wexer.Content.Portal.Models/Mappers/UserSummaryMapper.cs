﻿using System;
using System.Collections.Generic;
using System.Linq;
using Wexer.Content.Portal.Models.User;

namespace Wexer.Content.Portal.Models.Mappers
{
    public class UserSummaryMapper
    {
        public static UserSummary MapUserSummaryFrom(UserDetail userDetail)
        {
            if (userDetail == null)
            {
                return null;
            }

            var userSummary = new UserSummary
            {
                FirstName = userDetail.FirstName,
                LastName = userDetail.LastName,
                BirthDate = userDetail.BirthDate,
                Gender = userDetail.Gender,
                UserId = userDetail.UserId,
                EmailAddress = userDetail.EmailAddress,
                Telephone = userDetail.Telephone,
                MobileTelephone = userDetail.MobileTelephone,
                MembershipProfile = userDetail.MembershipProfile,
                ProspectProfile = userDetail.ProspectProfile,
                ApplicationProfile = userDetail.ApplicationProfile,
                FacebookProfile = userDetail.FacebookProfile,
                UserGroupTags = userDetail.UserGroupTags                
            };

            var membershipProfile = userDetail.MembershipProfile;

            if (membershipProfile != null)
            {
                userSummary.JoinDate = membershipProfile.JoinDate;
                userSummary.ClubTag = membershipProfile.ClubTag;
                userSummary.CountryTag = membershipProfile.CountryCode;
            }
            else if (userDetail.ProspectProfile != null)
            {
                userSummary.ClubTag = userDetail.ProspectProfile.ClubTag;
                userSummary.CountryTag = userDetail.ProspectProfile.CountryCode;
            }

            return userSummary;
        }

        public static UserSummary MapUserSummaryFrom(UserDetail userDetail, IList<UserGroup> userGroups, Func<IUserEntitlement, IList<UserGroup>, IList<string>> mergeEntitlements)
        {
            var userSummary = MapUserSummaryFrom(userDetail);
            if (userSummary == null || mergeEntitlements == null)
            {
                return userSummary;
            }

            var entitlements = mergeEntitlements(userSummary, userGroups);

            if (entitlements != null && entitlements.Any())
            {
                userSummary.Entitlements = entitlements.ToArray();
            }

            return userSummary;
        }
    }
}