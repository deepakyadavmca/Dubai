﻿using Wexer.Content.Portal.Models.User;

namespace Wexer.Content.Portal.Models.Mappers
{
    public class IndexedUserDetailMapper
    {
        public static IndexedUserDetail MapUserSearchIndexFrom(UserDetail userDetail)
        {
            return new IndexedUserDetail
            {
                BirthDate = userDetail.BirthDate,
                EmailAddress = userDetail.EmailAddress,
                FirstName = userDetail.FirstName,
                Gender = userDetail.Gender,
                LastName = userDetail.LastName,
                MobileTelephone = userDetail.MobileTelephone,
                Telephone = userDetail.Telephone,
                UserId = userDetail.UserId
            };
        }
    }
}
