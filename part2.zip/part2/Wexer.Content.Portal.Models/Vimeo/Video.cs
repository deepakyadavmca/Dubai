﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class Video
    {
        public string Id { get; set; }
        public string Uri { get; set; }
        public string Resource_Key { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long Duration { get; set; }
        public DateTime? Created_Time { get; set; }
        public Picture Pictures { get; set; }
        public File[] Files { get; set; }
        public string Status { get; set; }

        public void AssignVideoId()
        {
            this.Id = Regex.Split(this.Uri, "/videos/", RegexOptions.IgnoreCase).FirstOrDefault(t => !string.IsNullOrWhiteSpace(t));
        }

    }
}
