﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class StreamableClip
    {
        public Live Live { get; set; }
    }
}
