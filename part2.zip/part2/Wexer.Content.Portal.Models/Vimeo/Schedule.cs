﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class Schedule
    {
        public string Type { get; set; }
        public string Daily_Time { get; set; }
        public DateTime? Start_Time { get; set; }

        public string[] WeekDays { get; set; }

        public DateTime[] AvailableDate { get; set; }
    }
}
