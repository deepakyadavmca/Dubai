﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class File
    {
        //public DateTime? Expires { get; set; }
        //public FileQualityEnum FileQuality { get; set; }
        //public int Height { get; set; }
        public string Link { get; set; }
        //public string Link_secure { get; set; }
        public long Size { get; set; }
        public string Quality { get; set; }
        //public string Type { get; set; }
        //public int Width { get; set; }
    }
}
