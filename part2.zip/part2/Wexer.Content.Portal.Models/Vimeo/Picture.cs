﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class Picture
    {
        public string Uri { get; set; }
        public bool Active { get; set; }
        public Size[] Sizes { get; set; }
    }
}
