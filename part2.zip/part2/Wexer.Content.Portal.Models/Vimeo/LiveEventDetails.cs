﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class LiveEventDetails : LiveEventVideoCard
    {
        public string VideoId { get; set; }
        public DateTime? Scheduled_Start_Time { get; set; }
        public EventLiveStreaming eventLiveStreaming { get; set; }
        public Video[] Data { get; set; }

    }
}
