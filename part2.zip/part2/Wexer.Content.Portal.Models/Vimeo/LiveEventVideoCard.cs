﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class LiveEventVideoCard
    {
        public string Id { get; set; }
        public string Uri { get; set; }
        public string Stream_Key { get; set ; }
        public string Title { get; set; }
        public string Stream_Description { get; set; }
        public DateTime? Created_Time { get; set; }
        public Picture Pictures { get; set; }
        public string Status { get; set; }
        public DateTime? Next_Occurrence_Time { get; set; }
        public string Time_Zone { get; set; }
        public StreamableClip Streamable_Clip { get; set; }

        public Schedule schedule { get; set; }

        public void AssignEventId()
        {
            this.Id = Regex.Split(this.Uri, "/live_events/", RegexOptions.IgnoreCase).FirstOrDefault(t => !string.IsNullOrWhiteSpace(t));
        }

    }


}
