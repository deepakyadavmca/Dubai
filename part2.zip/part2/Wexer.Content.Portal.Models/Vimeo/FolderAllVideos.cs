﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class FolderAllVideos
    {
        public int Total { get; set; }
        public int Page { get; set; }
        public int Per_Page { get; set; }
        public LiveEventDetails[] Data { get; set; }
    }
}
