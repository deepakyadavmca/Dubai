﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class Live
    {
        public DateTime? Active_Time { get; set; }
        public DateTime? Scheduled_Start_Time { get; set; }
        public string Status { get; set; }

    }
}
