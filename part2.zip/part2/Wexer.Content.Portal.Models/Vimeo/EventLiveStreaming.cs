﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Wexer.Content.Portal.Models.Vimeo
{
    public class EventLiveStreaming
    {
        public string SreamingLink { get; set; }

        public string m3u8_playback_url { get; set; }

 
    }
}
