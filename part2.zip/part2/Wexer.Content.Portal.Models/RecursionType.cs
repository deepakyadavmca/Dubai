using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum RecursionType
    {
        [ProtoEnum(Name = "Yearly", Value = 0)]
        Yearly,

        [ProtoEnum(Name = "Monthly", Value = 1)]
        Monthly,

        [ProtoEnum(Name = "Daily", Value = 2)]
        Daily,

        [ProtoEnum(Name = "None", Value = 3)]
        None,

        [ProtoEnum(Name = "Weekly", Value = 4)]
        Weekly
    }
}