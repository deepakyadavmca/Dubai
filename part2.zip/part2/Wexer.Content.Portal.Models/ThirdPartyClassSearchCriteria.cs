﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models
{
    public class ThirdPartyClassSearchCriteria
    {
        public int CenterId { get; set; }
        public string CountryCode { get; set; }
        public int CenterGroupId { get; set; }
        public bool UserPreferredCenter { get; set; }
        public int ActivityGroupId { get; set; }
        public int ActivityId { get; set; }
        public int ColorId { get; set; }
        public int Day { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public TimeSpan TimeFrom { get; set; }
        public TimeSpan TimeTo { get; set; }
        public string InstructorName { get; set; }
        public string MaxScopeKey { get; set; }
    }
}
