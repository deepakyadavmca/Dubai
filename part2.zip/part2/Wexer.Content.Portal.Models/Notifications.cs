using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class UserNotification
    {
        [ProtoMember(1)]
        public string Platform { get; set; }

        [ProtoMember(2)]
        public string DeviceId { get; set; }

        [ProtoMember(3)]
        public string Categories { get; set; }

        [ProtoMember(4)]
        public string Templates { get; set; }

        [ProtoMember(5)]
        public string DeviceToken { get; set; }
    }
}