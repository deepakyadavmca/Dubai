﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class DeliveryMediaResponse
    {
        [JsonProperty("title")]
        public string title { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("kind")]
        public string Kind { get; set; }
        [JsonProperty("playlist")]
        public List<DeliveryPlaylistMetadata> Playlist { get; set; }
        [JsonProperty("feed_instance_id")]
        public string Feed_instance_id { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
    }
}
