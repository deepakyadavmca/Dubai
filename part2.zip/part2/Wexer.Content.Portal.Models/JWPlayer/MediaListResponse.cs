﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class MediaListResponse
    {
        [JsonProperty("media")]
        public List<MediaResponse> MediaList { get; set; }
    }
}
