﻿using Newtonsoft.Json;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class MediaWebhookResponse
    {
        [JsonProperty("event")]
        public string Event { get; set; }
        [JsonProperty("media_id")]
        public string MediaId { get; set; }
        [JsonProperty("channel_id")]
        public string ChannelId { get; set; }
        [JsonProperty("webhook_id")]
        public string WebhookId { get; set; }
        [JsonProperty("site_id")]
        public string SiteId { get; set; }
        [JsonProperty("event_time")]
        public string EventTime { get; set; }
    }
}
