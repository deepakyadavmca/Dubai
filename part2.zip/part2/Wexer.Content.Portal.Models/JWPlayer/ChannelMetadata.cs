﻿
using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.JWPlayer.Models
{
    public class ChannelMetadata
    {
        public string ChannelId { get; set; }
        public string Title { get; set; }
        public bool EnableDvr { get; set; }
        public IDictionary<string, string> CustomParameters { get; set; }
    }
}
