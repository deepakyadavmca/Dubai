﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class WebhookMetadataResponse
    {
        [JsonProperty("webhook_url")]
        public string Webhook_url { get; set; }
        [JsonProperty("events")]
        public List<string> Events { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("site_ids")]
        public List<string> Site_ids { get; set; }
    }
}
