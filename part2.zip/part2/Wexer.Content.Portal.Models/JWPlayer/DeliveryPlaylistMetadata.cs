﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class DeliveryPlaylistMetadata
    {
        [JsonProperty("title")]
        public string Title { get; set; }
        [JsonProperty("mediaid")]
        public string Mediaid { get; set; }
        [JsonProperty("link")]
        public string Link { get; set; }
        [JsonProperty("image")]
        public string Image { get; set; }
        [JsonProperty("images")]
        public List<DeliveryImageMetadata> Images { get; set; }
        [JsonProperty("duration")]
        public int Duration { get; set; }
        [JsonProperty("pubdate")]
        public long Pubdate { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("sources")]
        public List<DeliverySourceMetadata> Sources { get; set; }
        [JsonProperty("tracks")]
        public List<DeliveryTrackMetadata> Tracks { get; set; }
        [JsonProperty("variations")]
        public object Variations { get; set; }
    }
}
