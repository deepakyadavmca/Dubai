﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class ChannelResponse
    {
        [JsonProperty("created")]
        public string Created { get; set; }
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("last_modified")]
        public string Last_modified { get; set; }
        [JsonProperty("latency")]
        public string Latency { get; set; }
        [JsonProperty("metadata")]
        public ChannelMetadataResponse Metadata { get; set; }
        [JsonProperty("preview_url")]
        public string Preview_url { get; set; }
        [JsonProperty("recent_events")]
        public RecentEvents[] Recent_events { get; set; }
        [JsonProperty("reconnect_window")]
        public int Reconnect_window { get; set; }
        [JsonProperty("relationships")]
        public object Relationships { get; set; }
        [JsonProperty("schema")]
        public string Schema { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
        [JsonProperty("stream_key")]
        public string Stream_key { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("errors")]
        public List<ErrorMessage> Errors { get; set; }
    }
}
