﻿
using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.JWPlayer.Models
{
    public class MediaMetadata
    {
        public string MediaId { get; set; }
        public string ExternalId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }
        public string Category { get; set; }
        public IDictionary<string, string> Custom_params { get; set; }
        public List<string> Tags { get; set; }
        public string Permalink { get; set; }
        public string Protection_rule_key { get; set; }
        public string Publish_end_date { get; set; }
        public string Publish_start_date { get; set; }
    }
}
