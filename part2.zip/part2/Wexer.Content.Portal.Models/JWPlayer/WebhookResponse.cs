﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class WebhookResponse
    {
        [JsonProperty("created")]
        public string Created { get; set; }
        [JsonProperty("error_message")]
        public string Error_message { get; set; }
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("last_modified")]
        public string Last_modified { get; set; }
        [JsonProperty("metadata")]
        public WebhookMetadataResponse Metadata { get; set; }
        [JsonProperty("relationships")]
        public object Relationships { get; set; }
        [JsonProperty("schema")]
        public string Schema { get; set; }
        [JsonProperty("secret")]
        public string Secret { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("errors")]
        public List<ErrorMessage> Errors { get; set; }
    }
}
