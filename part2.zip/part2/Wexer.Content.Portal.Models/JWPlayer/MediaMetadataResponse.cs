﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class MediaMetadataResponse
    {
        [JsonProperty("author")]
        public string Author { get; set; }
        [JsonProperty("category")]
        public string Category { get; set; }
        [JsonProperty("custom_params")]
        public IDictionary<string, string> Custom_params { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("permalink")]
        public string Permalink { get; set; }
        [JsonProperty("protection_rule_key")]
        public string Protection_rule_key { get; set; }
        [JsonProperty("publish_end_date")]
        public string Publish_end_date { get; set; }
        [JsonProperty("publish_start_date")]
        public string Publish_start_date { get; set; }
        [JsonProperty("tags")]
        public List<string> Tags { get; set; }
        [JsonProperty("title")]
        public string Title { get; set; }
    }
}
