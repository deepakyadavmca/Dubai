﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class BulkMediaResponse
    {
        [JsonProperty("media")]
        public List<MediaResponse> Media { get; set; }
        [JsonProperty("page")]
        public long Page { get; set; }
        [JsonProperty("page_length")]
        public long Page_length { get; set; }
        [JsonProperty("total")]
        public long Total { get; set; }
        [JsonProperty("errors")]
        public List<ErrorMessage> Errors { get; set; }
    }
}
