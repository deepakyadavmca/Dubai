﻿using Newtonsoft.Json;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class RecentEvents
    {
        [JsonProperty("media_id")]
        public string MediaId { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
    }
}
