﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class MediaResponse
    {
        [JsonProperty("created")]
        public string Created { get; set; }
        [JsonProperty("duration")]
        public float Duration { get; set; }
        [JsonProperty("error_message")]
        public string Error_message { get; set; }
        [JsonProperty("external_id")]
        public string External_id { get; set; }
        [JsonProperty("hosting_type")]
        public string Hosting_type { get; set; }
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("last_modified")]
        public string Last_modified { get; set; }
        [JsonProperty("media_type")]
        public string Media_type { get; set; }
        [JsonProperty("metadata")]
        public MediaMetadataResponse Metadata { get; set; }
        [JsonProperty("mime_type")]
        public string Mime_type { get; set; }
        [JsonProperty("relationships")]
        public object Relationships { get; set; }
        [JsonProperty("schema")]
        public string Schema { get; set; }
        [JsonProperty("source_url")]
        public string Source_url { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
        [JsonProperty("trim_in_postring")]
        public string Trim_in_postring { get; set; }
        [JsonProperty("trim_out_postring")]
        public string Trim_out_postring { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("errors")]
        public List<ErrorMessage> Errors { get; set; }
    }
}
