﻿using Newtonsoft.Json;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class DeliveryImageMetadata
    {
        [JsonProperty("src")]
        public string Src { get; set; }
        [JsonProperty("width")]
        public int Width { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
    }
}
