﻿using Newtonsoft.Json;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class DeliverySourceMetadata
    {
        [JsonProperty("file")]
        public string File { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("height")]
        public int? Height { get; set; }
        [JsonProperty("width")]
        public int? Width { get; set; }
        [JsonProperty("label")]
        public string Label { get; set; }
        [JsonProperty("bitrate")]
        public int? Bitrate { get; set; }
        [JsonProperty("filesize")]
        public int? Filesize { get; set; }
        [JsonProperty("framerate")]
        public float? Framerate { get; set; }
    }
}
