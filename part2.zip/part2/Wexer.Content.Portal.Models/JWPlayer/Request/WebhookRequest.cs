﻿using Wexer.Content.Portal.Repositories.JWPlayer.Models;

namespace Wexer.Content.Portal.Models.JWPlayer.Request
{
    public class WebhookRequest
    {
        public string ProviderId { get; set; }
        public string WebhookId { get; set; }
        public WebhookMetadata Metadata { get; set; }
    }
}
