﻿using Wexer.Content.Portal.Repositories.JWPlayer.Models;

namespace Wexer.Content.Portal.Models.JWPlayer.Request
{
    public class MediaRequest
    {
        public string ProviderId { get; set; }
        public string DownloadUrl { get; set; }
        public string MediaId { get; set; }
        public MediaMetadata Metadata { get; set; }
    }
}
