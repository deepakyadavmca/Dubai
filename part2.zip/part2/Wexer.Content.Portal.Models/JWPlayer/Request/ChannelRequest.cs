﻿using Wexer.Content.Portal.Repositories.JWPlayer.Models;

namespace Wexer.Content.Portal.Models.JWPlayer.Request
{
    public class ChannelRequest
    {
        public string ProviderId { get; set; }
        public string ChannelId { get; set; }
        public ChannelMetadata Metadata { get; set; }
    }
}
