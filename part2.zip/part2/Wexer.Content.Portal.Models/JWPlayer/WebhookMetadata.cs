﻿using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.JWPlayer.Models
{
    public class WebhookMetadata
    {
        public string Webhook_url { get; set; }
        public List<string> Events { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public List<string> Site_ids { get; set; }
    }
}
