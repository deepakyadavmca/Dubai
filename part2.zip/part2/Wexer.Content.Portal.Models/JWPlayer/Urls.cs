﻿
namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class Urls
    {
        #region Media
        public static string InsertMediaUrl = "{0}/sites/{1}/media/";
        public static string UpdateMediaUrl = "{0}/sites/{1}/media/{2}/reupload";
        public static string GetMediaUrl = "{0}/sites/{1}/media/{2}";
        public static string GetAllMediaUrl = "{0}/sites/{1}/media/?page={2}&page_length={3}";
        public static string UpdateMediaMetadataUrl = "{0}/sites/{1}/media/{2}";
        #endregion

        #region Channel
        public static string InsertChannelUrl = "{0}/sites/{1}/channels/";
        public static string UpdateChannelUrl = "{0}/sites/{1}/channels/{2}";
        public static string GetChannelUrl = "{0}/sites/{1}/channels/{2}";
        public static string DeleteChannelUrl = "{0}/sites/{1}/channels/{2}";
        #endregion

        #region Delivery
        public static string GetDeliveryUrl = "{0}/media/{1}";
        #endregion

        #region Webhook
        public static string CreateWebhookUrl = "{0}/webhooks";
        public static string GetWebhookUrl = "{0}/webhooks/{1}";
        public static string UpdateWebhookUrl = "{0}/webhooks/{1}";
        public static string GetAllWebhookUrl = "{0}/webhooks/?page={1}&page_length={2}";
        #endregion
    }
}
