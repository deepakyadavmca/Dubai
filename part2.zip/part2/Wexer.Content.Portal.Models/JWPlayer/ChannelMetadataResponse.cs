﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class ChannelMetadataResponse
    {
        [JsonProperty("custom_params")]
        public IDictionary<string,string> Custom_params { get; set; }
        [JsonProperty("dvr")]
        public string Dvr { get; set; }
        [JsonProperty("publishing_mode")]
        public string Publishing_mode { get; set; }
        [JsonProperty("simulcast_targets")]
        public string[] Simulcast_targets { get; set; }
        [JsonProperty("tags")]
        public List<string> Tags { get; set; }
        [JsonProperty("title")]
        public string Title { get; set; }
    }
}
