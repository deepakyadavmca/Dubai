﻿using Newtonsoft.Json;

namespace Wexer.Content.Portal.Models.JWPlayer
{
    public class DeliveryTrackMetadata
    {
        [JsonProperty("file")]
        public string File { get; set; }
        [JsonProperty("kind")]
        public string Kind { get; set; }
    }
}
