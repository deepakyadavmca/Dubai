﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wexer.Content.Portal.Models.User.FitnessTracking
{
    [ProtoContract]
    public enum ResultSubmitType
    {
        [ProtoEnum(Name = "Skip", Value = 0)]
        Skip = 0,

        [ProtoEnum(Name = "Done", Value = 1)]
        Done = 1,

        [ProtoEnum(Name = "Submit", Value = 2)]
        Submit = 2,
      
    }
}
