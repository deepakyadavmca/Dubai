﻿namespace Wexer.Content.Portal.Models.CFPro
{
    using ProtoBuf;

    [ProtoContract]
    public class GlobalSetting
    {
        [ProtoMember(1)]
        public int PreBookingDays { get; set; }

        [ProtoMember(2)]
        public int BookingModificationsAllowedTime { get; set; }

        [ProtoMember(3)]
        public int CheckInOpenTime { get; set; }

        [ProtoMember(4)]
        public int CheckInCloseTime { get; set; }

        [ProtoMember(5)]
        public int BookingCancellationsAllowedTime { get; set; }

        [ProtoMember(6)]
        public TimeUnit PreBookingDaysUnit { get; set; }
        
        [ProtoMember(7)]
        public TimeUnit BookingModificationsAllowedTimeUnit { get; set; }

        [ProtoMember(8)]
        public TimeUnit CheckInOpenTimeUnit { get; set; }

        [ProtoMember(9)]
        public TimeUnit CheckInCloseTimeUnit { get; set; }
        
        [ProtoMember(10)]
        public TimeUnit BookingCancellationsAllowedTimeUnit { get; set; }
    }
}