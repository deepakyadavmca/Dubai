﻿namespace Wexer.Content.Portal.Models.CFPro
{
    using ProtoBuf;

    [ProtoContract]
    public class CFProContent
    {
        [ProtoMember(1)]
        public GlobalSetting GlobalSetting { get; set; }
    }
}