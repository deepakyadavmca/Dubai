﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.OnDemandTracking
{
    [ProtoContract]
    public class OnDemandTracking
    {
        [ProtoMember(1)]
        public DateTime FromDate { get; set; }
        [ProtoMember(2)]
        public DateTime ToDate { get; set; }
        [ProtoMember(3)]
        public string FileName { get; set; }
        [ProtoMember(4)]
        public DateTime CreatedDate { get; set; }
    }
}