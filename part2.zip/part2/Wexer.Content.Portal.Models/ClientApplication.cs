﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class ClientApplication
    {
        [ProtoMember(1)]
        public string ApplicationName { get; set; }

        [ProtoMember(2)]
        public string AppKey { get; set; }

        [ProtoMember(3)]
        public string AppSecret { get; set; }

        [ProtoMember(4)]
        public DateTime? ExpiresUtc { get; set; }

        [ProtoMember(5)]
        public string AuthenticationCallback { get; set; }
    }
}
