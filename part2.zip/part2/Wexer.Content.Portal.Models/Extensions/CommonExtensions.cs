﻿using System.Linq;

namespace Wexer.Content.Portal.Models.Extensions
{
    public static class CommonExtensions
    {
        public static string FlattenByLanguage(this LocalisedText localisedText, string languageTag)
        {
            if (localisedText == null)
            {
                return string.Empty;
            }

            if (localisedText.LocalTexts == null)
            {
                return localisedText.InvariantText;
            }

            var matchingLanguageLocalText =
                localisedText.LocalTexts.FirstOrDefault(e => e.IETFTag == languageTag);

            if (matchingLanguageLocalText != null)
            {
                return matchingLanguageLocalText.Text ?? string.Empty;
            }

            matchingLanguageLocalText =
                localisedText.LocalTexts.FirstOrDefault(e => e.IETFTag == "en-GB");

            return matchingLanguageLocalText != null ? matchingLanguageLocalText.Text : localisedText.InvariantText;
        }

        /// <summary>
        /// Return string only if the localisedText found corresponding to particular languageTag else returns empty
        /// </summary>
        /// <param name="localisedText">LocalisedText</param>
        /// <param name="languageTag">languageTag</param>
        /// <returns></returns>
        public static string FlattenByLanguageStrict(this LocalisedText localisedText, string languageTag)
        {
            if (localisedText == null)
            {
                return string.Empty;
            }

            if (localisedText.LocalTexts == null)
            {
                return localisedText.InvariantText;
            }

            var matchingLanguageLocalText =
               localisedText.LocalTexts.FirstOrDefault(e => e.IETFTag == languageTag);

            if (matchingLanguageLocalText != null)
            {
                return matchingLanguageLocalText.Text ?? string.Empty;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
