﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Tracing
{
    /// <summary>
    /// Represents a logged trace item
    /// </summary>
    [ProtoContract]
    public class TraceLog
    {
        /// <summary>
        /// The unique identifier of the trace log
        /// </summary>
        [ProtoMember(1)]
        public  string Id { get; set; }

        /// <summary>
        /// The date time the trace log was last updated
        /// </summary>
        [ProtoMember(2)]
        public string LastUpdatedDateTime { get; set; }

        /// <summary>
        /// The type of the trace log
        /// </summary>
        [ProtoMember(3)]
        public  string Type { get; set; }
        
        /// <summary>
        /// The trace log status
        /// </summary>
        [ProtoMember(4)]
        public  string Status { get; set; }
        
        /// <summary>
        /// The trace log details
        /// </summary>
        [ProtoMember(5)]
        public  string Details { get; set; }
    }
}
