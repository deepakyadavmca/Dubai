﻿using Microsoft.AspNetCore.Http;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Wexer.Content.Portal.Models.Consent
{
    [ProtoContract]
    public class ConsentPolicy
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string PolicyType { get; set; }

        [ProtoMember(3)]
        public bool IsMandatory { get; set; }

        [ProtoMember(4)]
        public LocalisedText Title { get; set; }

        //[ProtoMember(5)]
        //public LocalisedText Description { get; set; }

        [ProtoMember(6)]
        public LocalisedText PolicyUrl { get; set; }

        [ProtoMember(7)]
        public Int32 VersionNumber { get; set; }

        //[ProtoMember(8)]
        //public bool Active { get; set; }

        [ProtoMember(9)]
        public DateTime? PublishedDate { get; set; }

        [ProtoMember(10)]
        public DateTime CreatedDate { get; set; }

        [ProtoMember(11)]
        public bool Actionable { get; set; }

        [ProtoMember(12)]
        public string TenantID { get; set; }

        //[ProtoMember(13)]
        public IFormFile ConsentFile { get; set; }

        public string HtmlPolicyFile { get; set; }

        [ProtoMember(14)]
        public byte[] ConsentFileStore { get; set; }


    }
}
