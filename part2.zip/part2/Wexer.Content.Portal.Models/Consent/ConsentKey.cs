﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Consent
{
    public class ConsentKey
    {
        public const string webTermsAndConditions = "tnc";
        public const string cfproTermsAndConditions = "tnc-cfpro";
        public const string webTermsAndConditionsReadonly = "tnc-info";
        public const string cfproTermsAndConditionsReadonly = "tnc-cfpro-info";
        public const string cfprosignin = "signin-cfpro";
        public const string cfproprofile = "profile-cfpro";
    }
}
