﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Wexer.Content.Portal.Models.Consent
{
    [ProtoContract]
    public class ConsentTenantPolicy
    {

        [ProtoMember(1)]
        public string TenantID { get; set; }

        [ProtoMember(2)]
        public string Tag { get; set; }

        [ProtoMember(3)]
        public string PolicyType { get; set; }

        [ProtoMember(4)]
        public bool IsMandatory { get; set; }

        [ProtoMember(5)]
        public LocalisedText Title { get; set; }

        //[ProtoMember(5)]
        //public LocalisedText Description { get; set; }

        [ProtoMember(6)]
        public LocalisedText PolicyUrl { get; set; }

        [ProtoMember(7)]
        public Int32 VersionNumber { get; set; }

        //[ProtoMember(8)]
        //public bool Active { get; set; }

        [ProtoMember(9)]
        public DateTime? PublishedDate { get; set; }

        [ProtoMember(10)]
        public DateTime CreatedDate { get; set; }

        [ProtoMember(11)]
        public bool Actionable { get; set; }
    }
}
