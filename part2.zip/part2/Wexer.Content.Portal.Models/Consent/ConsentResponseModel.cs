﻿using Wexer.Content.Portal.Models.Consent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Wexer.Content.Portal.Models.Consent
{
    public class ConsentResponseModel
    {
        public string ConsentTag { get; set; }
        public string Policy { get; set; }
        public string Title { get; set; }
        public int Version { get; set; }
        public DateTime PublishedDate { get; set; }

        public bool IsMandatory { get; set; }

        public bool Actionable { get; set; }

        public UrlCollection[] Urls { get; set; }

        public string PolicyHtml { get; set; }
    }

    public class UrlCollection
    {
        public string LinkText { get; set; }
        public string LinkUrl { get; set; }
    }
}