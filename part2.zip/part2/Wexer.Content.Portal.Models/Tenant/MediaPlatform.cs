﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Tenant
{
    [ProtoContract]
    public enum MediaPlatform
    {
        [ProtoEnum(Name = "AMS", Value = 0)]
        AMS,

        [ProtoEnum(Name = "JWPlayer", Value = 1)]
        JWPlayer,
    }
}
