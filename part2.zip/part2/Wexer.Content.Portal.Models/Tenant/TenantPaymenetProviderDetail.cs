﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Tenant
{
    [ProtoContract]
    public class TenantPaymenetProviderDetail
    {

        [ProtoMember(1)]
        public virtual string SecretKey { get; set; }
        [ProtoMember(2)]
        public virtual string WebHookKey { get; set; }
        [ProtoMember(3)]
        public virtual string PlanId { get; set; }

        [ProtoMember(4)]
        public virtual string PublishableKey { get; set; }
    }
}
