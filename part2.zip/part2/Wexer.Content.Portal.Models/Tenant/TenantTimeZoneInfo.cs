﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Tenant
{
    [ProtoContract]
    public class TenantTimeZoneInfo
    {
        [ProtoMember(1)]
        public string OffsetName { get; set; }

        [ProtoMember(2)]
        public string UtcOffset { get; set; }
    }
}
