﻿using ProtoBuf;
using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.Tenant
{
    [ProtoContract]
    public class TenantDetail
    {
        [ProtoMember(1)]
        public string TenantID { get; set; }

        [ProtoMember(2)]
        public string Name { get; set; }

        [ProtoMember(3)]
        public TenantPaymenetProviderDetail TenantPaymenetProviderDetail { get; set; }


        [ProtoMember(4)]
        public string ContactEmailAddress { get; set; }
        [ProtoMember(5)]
        public IEnumerable<string> ProductList { get; set; }
        [ProtoMember(6)]
        public string NoReplyEmailAddress { get; set; }
        [ProtoMember(7)]
        public string ContactPersonName { get; set; }
        [ProtoMember(8)]
        public string LanguageTag { get; set; }
        [ProtoMember(9)]
        public string Url { get; set; }

        [ProtoMember(10)]
        public bool IsAccessCodeMandatory { get; set; }

        [ProtoMember(11)]
        public Dictionary<string, string> ExtendedAttributes { get; set; }

        [ProtoMember(12)]
        public string BaseURL { get; set; }

        [ProtoMember(13)]
        public string ClientId { get; set; }

        [ProtoMember(14)]
        public string ClientSecret { get; set; }

        [ProtoMember(15)]
        public string DataSource { get; set; }

        [ProtoMember(16)]
        public string SubscriptionKey { get; set; }

        //[ProtoMember(17)]
        //public string VimeFolderId { get; set; }

        [ProtoMember(18)]
        public string VimeoToken { get; set; }

        [ProtoMember(19)]
        public string VimeoFolderId { get; set; }

        [ProtoMember(20)]
        public string LocalyticsKey { get; set; }

        [ProtoMember(21)]
        public bool ShowClassOfTheDay { get; set; }

        [ProtoMember(22)]
        public bool ShowLiveConnect { get; set; }

        [ProtoMember(23)]
        public bool IsMasterTenant { get; set; }

        [ProtoMember(24)]
        public bool ShowDiscountTextField { get; set; }

        [ProtoMember(25)]
        public MarketingDetail MarketingDetail { get; set; }

        [ProtoMember(26)]
        public bool ShowLiveEvent { get; set; }

        [ProtoMember(27)]
        public int EventCardSize { get; set; }

        [ProtoMember(28)]
        public bool IsAdestraEnabled { get; set; }

        [ProtoMember(29)]
        public string AzureTenantID { get; set; }

        [ProtoMember(30)]
        public string CustomerNumber { get; set; }

        [ProtoMember(31)]
        public string ApiKey { get; set; }

        [ProtoMember(32)]
        public bool ShowChannels { get; set; }

        [ProtoMember(33)]
        public string[] AllowedAgreement { get; set; }

        [ProtoMember(34)]
        public string EndpointKey { get; set; }

        [ProtoMember(35)]
        public string IdentityProvider { get; set; }

        [ProtoMember(36)]
        public string ProviderId { get; set; }

        [ProtoMember(37)]
        public string ConnectSource { get; set; }

        [ProtoMember(38)]
        public string Connect { get; set; }

        [ProtoMember(39)]
        public TenantTimeZoneInfo TimeZoneInfo { get; set; }

        [ProtoMember(40)]
        public bool IsProviderActive { get; set; }

        [ProtoMember(41)]
        public bool IsAllowOnDemandContentDownload { get; set; }
        
        //[ProtoMember(42)]
        //public string JWPlayerSiteId { get; set; }
        
        //[ProtoMember(43)]
        //public string JWPlayerAPISecret { get; set; }

        /// <summary>
        /// Hold the language codes which supports Tenant
        /// </summary>
        [ProtoMember(44)]
        public string[] LanguageCodes { get; set; }
    }
}
