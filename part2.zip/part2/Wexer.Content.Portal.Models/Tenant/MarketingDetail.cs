﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.Tenant
{
    [ProtoContract]
    public class MarketingDetail
    {

        [ProtoMember(1)]
        public string SubscribedListId { get; set; }

        [ProtoMember(2)]
        public string ConfirmedListId { get; set; }

        [ProtoMember(3)]
        public string UnConfirmedListId { get; set; }

        [ProtoMember(4)]
        public string CoreTableId { get; set; }

        [ProtoMember(5)]
        public string ConfirmationEmailCampaignId { get; set; }

        [ProtoMember(6)]
        public string ResetPasswordEmailCampaignId { get; set; }

        //[ProtoMember(7)]
        //public string ResetPasswordListId { get; set; }

    }
}
