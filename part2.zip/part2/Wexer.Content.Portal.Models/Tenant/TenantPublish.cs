﻿using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.Tenant.TenantList
{
    public class TenantPublish
    {
        public List<TenantDisplay> TenantDisplayList { get; set; }
        public int PublishTypeId { get; set; }        
    }
    public class TenantDisplay
    {
        public string TenantID { get; set; }
        public string TenantName { get; set; }
        public bool IsClassPublished { get; set; }
    }
}
