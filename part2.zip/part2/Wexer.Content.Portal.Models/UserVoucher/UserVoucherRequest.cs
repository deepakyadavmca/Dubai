﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserVoucher
{
    public class UserVoucherRequest
    {
        public string UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public DateTime? ActualExpirationDate { get; set; }
        public string CampaignTag { get; set; }
    }
}
