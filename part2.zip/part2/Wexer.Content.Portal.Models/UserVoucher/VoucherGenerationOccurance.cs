﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserVoucher
{
    public enum VoucherGenerationOccurance
    {
        Once = 0,
        Monthly = 1,  ///property commited because no use of this property
        Bimonthly = 2,
        Quarterly = 3,
        HalfYearly = 6,
        Annual = 12
    }
}
