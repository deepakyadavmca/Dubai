﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;
using Wexer.Content.Portal.Models.FitnessClasses;

namespace Wexer.Content.Portal.Models.UserVoucher
{
    [ProtoContract]
    public class VoucherTemplate
    {
        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public string VoucherCodeFormat { get; set; }

        [ProtoMember(3)]
        public LocalisedText Title { get; set; }

        [ProtoMember(4)]
        public LocalisedText Description { get; set; }

        [ProtoMember(5)]
        public string CampaignTitle { get; set; }

        [ProtoMember(6)]
        public string CampaignTag { get; set; }

        [ProtoMember(7)]
        public string ImageUrl { get; set; }

        [ProtoMember(8)]
        public bool MembersOnly { get; set; }

        [ProtoMember(9)]
        public string TermsAndCondition { get; set; }

        [ProtoMember(10)]
        public RedemptionType Redemption { get; set; }

        [ProtoMember(11)]
        public int MaxVouchers { get; set; }

        [ProtoMember(12)]
        public double DiscountValue { get; set; }

        [ProtoMember(13)]
        public DiscountType DiscountUnit { get; set; }

        [ProtoMember(14)]
        public string Currency { get; set; }

        [ProtoMember(15)]
        public bool Active { get; set; }

        [ProtoMember(16)]
        public List<string> Clubs { get; set; }

        [ProtoMember(17)]
        public VoucherGenerationOccurance Occurance { get; set; }
    }
}
