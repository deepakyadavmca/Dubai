﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserVoucher
{
    [ProtoContract]
    public class UserVoucher : IStorageKey
    {

        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string VoucherCode { get; set; }

        [ProtoMember(3)]
        public DateTime Created { get; set; }

        [ProtoMember(4)]
        public DateTime? StartDate { get; set; }

        [ProtoMember(5)]
        public DateTime ExpirationDate { get; set; }

        [ProtoMember(6)]
        public UserVoucherStatus RedemptionStatus { get; set; }

        [ProtoMember(7)]
        public DateTime? Redemptiondate { get; set; }

        [ProtoMember(8)]
        public VoucherTemplate VoucherTemplate { get; set; }

        [ProtoMember(9)]
        public DateTime? ActualExpirationDate { get; set; }

        [ProtoMember(10)]
        public bool IsActive { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return this.UserId.ToLowerInvariant();
            }
        }
        string IStorageKey.RowKey
        {
            get { return this.VoucherCode; }
        }
    }
}
