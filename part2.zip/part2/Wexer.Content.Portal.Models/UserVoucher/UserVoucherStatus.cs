﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserVoucher
{
    public enum UserVoucherStatus
    {
        UnRedeem = 1,
        Redeem = 2
    }
}
