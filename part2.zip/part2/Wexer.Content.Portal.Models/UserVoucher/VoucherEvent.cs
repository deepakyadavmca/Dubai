﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.UserVoucher
{
    [ProtoContract]
    public class VoucherEvent
    {
        [ProtoMember(1)]
        public string VoucherEventTag { get; set; }

        [ProtoMember(2)]
        public string VoucherTemplateTag { get; set; }

        [ProtoMember(3)]
        public string VoucherCodeFormat { get; set; }

        [ProtoMember(4)]
        public string Title { get; set; }

        [ProtoMember(5)]
        public string Description { get; set; }

        [ProtoMember(6)]
        public string CampaignTitle { get; set; }

        [ProtoMember(7)]
        public string CampaignTag { get; set; }

        [ProtoMember(8)]
        public string ImageUrl { get; set; }

        [ProtoMember(9)]
        public bool MembersOnly { get; set; }

        [ProtoMember(10)]
        public string TermsAndCondition { get; set; }

        [ProtoMember(11)]
        public RedemptionType Redemption { get; set; }

        [ProtoMember(12)]
        public int MaxVouchers { get; set; }

        [ProtoMember(13)]
        public double DiscountValue { get; set; }

        [ProtoMember(14)]
        public DiscountType DiscountUnit { get; set; }

        [ProtoMember(15)]
        public string Currency { get; set; }

        [ProtoMember(16)]
        public bool Active { get; set; }

        [ProtoMember(17)]
        public List<string> Clubs { get; set; }

        [ProtoMember(18)]
        public string VoucherCode { get; set; }

        [ProtoMember(19)]
        public DateTime? RedemptionDate { get; set; }

        [ProtoMember(20)]
        public DateTime? StartDate { get; set; }

        [ProtoMember(21)]
        public DateTime ExpirationDate { get; set; }

        [ProtoMember(22)]
        public UserVoucherStatus RedemptionStatus { get; set; }

        [ProtoMember(23)]
        public DateTime CreatedUtc { get; set; }

        [ProtoMember(24)]
        public DateTime LastModifiedUtc { get; set; }

        [ProtoMember(25)]
        public string UserId { get; set; }

        [ProtoMember(26)]
        public DateTime? ActualExpirationDate { get; set; }

    }
}
