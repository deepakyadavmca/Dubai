﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract(EnumPassthru = true)]
    public class EfficiencyRule
    {
        [ProtoMember(1)]
        public MatchType PrimaryMatchType { get; set; }
        
        [ProtoMember(2)]
        public decimal PrimaryFactor { get; set; }

        [ProtoMember(3)]
        public decimal SecondaryFactor { get; set; }

        [ProtoMember(4)]
        public MatchType SecondaryMatchType { get; set; }
        
    }
}