﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public enum MatchType
    {
        [ProtoEnum(Name = "NoMatch", Value = 10)]
        NoMatch = 10,

        [ProtoEnum(Name = "Primary", Value = 20)]
        Primary = 20,

        [ProtoEnum(Name = "Secondary", Value = 30)]
        Secondary = 30,
    }
}