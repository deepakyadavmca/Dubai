﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public class UserCustomFitWorkout
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public UserWorkout[] RecommendedWorkouts { get; set; }
    }
}