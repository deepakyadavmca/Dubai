﻿using Wexer.Content.Portal.Models.Attributes;
using Wexer.Content.Portal.Models.User.Profiles;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public class CustomFitWorkoutGeneratorProfile : UserProfile
    {
        [ProtoMember(1)]
        public byte[] Goal { get; set; }

        [ProtoMember(2)]
        public byte[] Skill { get; set; }

        [ProtoMember(3)]
        public byte[] Equipment { get; set; }

        [ProtoMember(4)]
        public int Duration { get; set; }

        [ProtoMember(5)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? DateOfBirth { get; set; }

        [ProtoMember(6)]
        public string Weight { get; set; }

        [ProtoMember(7)]
        public string Gender { get; set; }       
    }
}
