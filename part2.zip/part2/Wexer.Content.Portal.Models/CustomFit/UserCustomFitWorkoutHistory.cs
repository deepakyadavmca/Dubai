﻿using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Models.User.FitnessTracking;

using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public class UserCustomFitWorkoutHistory : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public UserWorkout RecommendedWorkout { get; set; }


        string IStorageKey.PartitionKey
        {
            get
            {
                return this.UserId;
            }
        }

        string IStorageKey.RowKey
        {
            get
            {
                return this.RecommendedWorkout.Tag;
            }
        }
    }
}