﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public class CustomFitEffiencyRules
    {
        public CustomFitEffiencyRules()
        {
            EfficiencyRules = new
                []{
                    new EfficiencyRule{PrimaryMatchType = MatchType.Primary, SecondaryMatchType = MatchType.Primary, PrimaryFactor = 1M, SecondaryFactor = 0M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.Secondary, SecondaryMatchType = MatchType.Secondary, PrimaryFactor = 0M, SecondaryFactor = 1M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.Primary, SecondaryMatchType = MatchType.Secondary, PrimaryFactor = 1M, SecondaryFactor = 0M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.Secondary, SecondaryMatchType = MatchType.Primary, PrimaryFactor = 0.5M, SecondaryFactor = 0.5M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.Primary, SecondaryMatchType = MatchType.NoMatch, PrimaryFactor = 1M, SecondaryFactor = 0.0M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.Secondary, SecondaryMatchType = MatchType.NoMatch, PrimaryFactor = 1M, SecondaryFactor = 0.0M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.NoMatch, SecondaryMatchType = MatchType.Primary, PrimaryFactor = 0M, SecondaryFactor = 0.5M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.NoMatch, SecondaryMatchType = MatchType.Secondary, PrimaryFactor = 0M, SecondaryFactor = 0.3M},
                    new EfficiencyRule{PrimaryMatchType = MatchType.NoMatch, PrimaryFactor = 0M, SecondaryFactor = 0M},
                };
        }

        [ProtoMember(1)]
        public string Tag { get; set; }

        [ProtoMember(2)]
        public EfficiencyRule[] EfficiencyRules { get; set; }
    }
}