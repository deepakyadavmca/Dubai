﻿namespace Wexer.Content.Portal.Models.CustomFit
{
    public class CustomFitPoints
    {
        public static CustomFitPoints operator +(CustomFitPoints left, CustomFitPoints right)
        {
            return new CustomFitPoints
                       {
                           TotalPoints = left.TotalPoints + right.TotalPoints,
                           PrimaryGoalPoints = left.PrimaryGoalPoints + right.PrimaryGoalPoints,
                           SecondaryGoalPoints = left.SecondaryGoalPoints + right.SecondaryGoalPoints,
                           CardioPoints = left.CardioPoints + right.CardioPoints,
                           ResistancePoints = left.ResistancePoints + right.ResistancePoints,
                           AgilityPoints = left.AgilityPoints + right.AgilityPoints,

                       };
        }

        public int PrimaryGoalPoints { get; set; }
        public int SecondaryGoalPoints { get; set; }
        public int CardioPoints { get; set; }
        public int TotalPoints { get; set; }
        public int ResistancePoints { get; set; }
        public int AgilityPoints { get; set; }
    }
}