﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public class AlternativeWorkoutOptions
    {
        [ProtoMember(1)]
        public byte? ExpressThresholdMinutes { get; set; }
        [ProtoMember(2)]
        public byte? ExtendedThresholdMinutes { get; set; }
        [ProtoMember(3)]
        public byte? ExpressWorkoutLength { get; set; }
        [ProtoMember(4)]
        public byte? ExtendedWorkoutLength { get; set; }
        [ProtoMember(5)]
        public byte? SessionLengthVariant { get; set; }
        [ProtoMember(6)]
        public string MainWorkoutNameFormat { get; set; }
        [ProtoMember(7)]
        public string ExpressWorkoutNameFormat { get; set; }
        [ProtoMember(8)]
        public string ExtendedWorkoutNameFormat { get; set; }
        [ProtoMember(9)]
        public string GoalWorkoutNameFormat { get; set; }

        public bool HasThresholdSet
        {
            get { return (HasExpressThresholdSet || HasExtendedThresholdSet); }
        }

        public bool HasExpressThresholdSet 
        {
            get { return ExpressThresholdMinutes.HasValue; }
        }

        public bool HasExtendedThresholdSet
        {
            get { return ExtendedThresholdMinutes.HasValue; }
        }
    }
}