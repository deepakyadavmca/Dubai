﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.CustomFit
{
    [ProtoContract]
    public class UserProfileTermsAndConditionAcceptHistory : IStorageKey
    {
        /// <summary>
        /// User profile terms and condtions unique id
        /// </summary>
        [ProtoMember(1)]
        public string Tag { get; set; }

        /// <summary>
        /// User profile terms and condtions accept member id
        /// </summary>
        [ProtoMember(2)]
        public string UserId { get; set; }  

        /// <summary>
        /// User profile terms and condtions accept date
        /// </summary>
        [ProtoMember(3)]
        public DateTime ? UserProfileTermsAndConditionAcceptDate { get; set; }





        public string PartitionKey
        {
            get { return UserId;  }
        }

        public string RowKey
        {
            get
            {
                if (string.IsNullOrWhiteSpace(Tag))
                {
                    Tag = Guid.NewGuid().ToString();
                }

                return Tag;
            }
        }
    }
}
