﻿namespace Wexer.Content.Portal.Models.CustomFit
{
    public class AuthenticateResult
    {
        public bool IsAuthenticated { get; set; }
        public string UserToken { get; set; }
        public string UserId { get; set; }
    }

}
