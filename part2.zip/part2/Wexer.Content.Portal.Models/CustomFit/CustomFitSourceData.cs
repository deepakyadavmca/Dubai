﻿using Wexer.Content.Portal.Models.FitnessClasses;
using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Models.WorkoutCollection;

namespace Wexer.Content.Portal.Models.CustomFit
{
    public class CustomFitSourceData
    {
        public ClassType[] GxClasses { get; set; }
        public WorkoutTemplate[] WorkoutTemplates { get; set; }
        public Exercise[] Exercises { get; set; }
        public WorkoutCollectionLabel[] WorkoutCollectionLabels { get; set; }
        public string ietfTag { get; set; }
    }
}
