﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum MediaProcessingStatus
    {
        [ProtoEnum(Name = "None", Value = 0)]
        None = 0,

        [ProtoEnum(Name = "EncodingQueued", Value = 1)]
        EncodingQueued = 1,

        [ProtoEnum(Name = "Encoded", Value = 2)]
        Encoded = 2,

        [ProtoEnum(Name = "PublishQueued", Value = 3)]
        PublishQueued = 3,

        [ProtoEnum(Name = "Published", Value = 4)]
        Published = 4,

        [ProtoEnum(Name = "Error", Value = 5)]
        Error = 5,

        [ProtoEnum(Name = "Incomplete", Value = 6)]
        Incomplete = 6,

        [ProtoEnum(Name = "Unpublished", Value = 7)]
        Unpublished = 7,

        [ProtoEnum(Name = "Complete", Value = 8)]
        Complete = 8

    }

    [ProtoContract]
    public enum MediaProcessingError
    {
        [ProtoEnum(Name = "Enum", Value = 0)]
        None = 0,

        [ProtoEnum(Name = "FileNotFound", Value = 1)]
        FileNotFound = 1,

        [ProtoEnum(Name = "EncodingError", Value = 2)]
        EncodingError = 2,

        [ProtoEnum(Name = "PublishError", Value = 3)]
        PublishError = 3,

        [ProtoEnum(Name = "EncodedFileNotFound", Value = 4)]
        EncodedFileNotFound = 4,

        [ProtoEnum(Name="Canceled", Value=5)]
        Canceled = 5
    }
}