using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    /// <summary>
    /// 
    /// </summary>
    [ProtoContract]
    public class PublicHoliday
    {
        /// <summary>
        /// Gets or sets the tag.
        /// </summary>
        /// <value>
        /// The tag.
        /// </value>
        [ProtoMember(1)]
        public string Tag { get; set; }

        /// <summary>
        /// Gets or sets the country tag.
        /// </summary>
        /// <value>
        /// The country tag.
        /// </value>
        [ProtoMember(2)]
        public string CountryTag { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        [ProtoMember(3)]
        public LocalisedText Name { get; set; }


        /// <summary>
        /// Gets or sets the date.
        /// </summary>
        /// <value>
        /// The date.
        /// </value>
        [ProtoMember(4)]
        public DateTime Date { get; set; }


        /// <summary>
        /// Gets or sets the show from date.
        /// </summary>
        /// <value>
        /// The show from date.
        /// </value>
        [ProtoMember(5)]
        public DateTime ShowFromDate { get; set; }


        /// <summary>
        /// Gets or sets the show until date.
        /// </summary>
        /// <value>
        /// The show until date.
        /// </value>
        [ProtoMember(6)]
        public DateTime ShowUntilDate { get; set; }


        /// <summary>
        /// Gets or sets the show until date.
        /// </summary>
        /// <value>
        /// The show until date.
        /// </value>
        [ProtoMember(7)]
        public OpeningHours OpeningHours { get; set; }


    }
}