﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum EventStatus
    {
        [ProtoEnum(Name = "Saved", Value = 1)]
        Saved = 1,

        [ProtoEnum(Name = "Inactive", Value = 2)]
        Inactive = 2,

        [ProtoEnum(Name = "Active", Value = 3)]
        Active = 3,
    }
}
