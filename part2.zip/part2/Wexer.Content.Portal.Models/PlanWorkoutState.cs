﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum PlanWorkoutState : byte
    {
        [ProtoEnum(Name = "Locked", Value = 0)]
        Locked = 0,
        [ProtoEnum(Name = "UnLocked", Value = 50)]
        UnLocked = 50,
        [ProtoEnum(Name = "Planned", Value = 100)]
        Planned = 100,
        [ProtoEnum(Name = "RePlanned", Value = 150)]
        RePlanned = 150,
        [ProtoEnum(Name = "Completed", Value = 200)]
        Completed = 200
    }
}
