﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    /// <summary>
    /// Represents a club tier.
    /// </summary>
    [ProtoContract]
    public class ClubTier
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        [ProtoMember(1)]
        public int Code { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        [ProtoMember(2)]
        public string Name { get; set; }
    }
}