﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.LiveStreaming
{
    [ProtoContract]
    public class LiveStream : IStorageKey
    {
        [ProtoMember(1)]
        public string StreamID { get; set; }

        [ProtoMember(2)]
        public string HLSUrl { get; set; }

        [ProtoMember(3)]
        public LiveStreamStatus Status { get; set; }

        [ProtoMember(4)]
        public DateTime CreatedDate { get; set; }

        public string PartitionKey
        {
            get
            {
                return "stream";
            }
        }

        public string RowKey
        {
            get
            {
                return StreamID;
            }
        }
    }

    public enum LiveStreamStatus
    {
        Ended = 0,
        Active = 1
    }
}
