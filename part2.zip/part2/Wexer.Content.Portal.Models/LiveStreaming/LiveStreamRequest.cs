﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.LiveStreaming
{
    public class LiveStreamRequest
    {
        public string StreamId { get; set; }
        public LiveStreamStatus Operation { get; set; } 
    }
}
