﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.LiveStreaming
{
    public class Info
    {
        public object bitrate { get; set; }
        public int? height { get; set; }
        public object framesPerSecond { get; set; }
    }

    public class StreamInfo
    {
        public DateTime? startTime { get; set; }
        public DateTime? endTime { get; set; }
    }
}
