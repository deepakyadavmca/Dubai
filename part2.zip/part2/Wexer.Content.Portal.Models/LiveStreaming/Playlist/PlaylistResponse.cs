﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.LiveStreaming
{
    public class PlaylistResponse
    {
        public string status { get; set; }
        public List<Playlist> playlists { get; set; }
        public StreamInfo streamInfo { get; set; }

        public bool IsStreamActive
        {
            get
            {
                bool isActive = false;
                if(streamInfo.endTime==null && (streamInfo.startTime>streamInfo.endTime))
                {
                    isActive = true;
                }
                return isActive;

            }
        }
    }

    
}