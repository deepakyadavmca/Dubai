﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.LiveStreaming
{
    public class Playlist
    {
        public string name { get; set; }
        public string type { get; set; }
        public string uri { get; set; }
        public bool isVariant { get; set; }
        public bool isProtected { get; set; }
        public Info info { get; set; }
    }
}
