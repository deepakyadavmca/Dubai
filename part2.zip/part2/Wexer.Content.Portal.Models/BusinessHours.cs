using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class BusinessHours
    {
        /// <summary>
        /// Gets or sets the club tag.
        /// </summary>
        /// <value>
        /// The club tag.
        /// </value>
        [ProtoMember(1)]
        public string ClubTag { get; set; }

        /// <summary>
        /// Gets or sets the opening hours.
        /// </summary>
        /// <value>
        /// The opening hours.
        /// </value>
        [ProtoMember(2)]
        public ClubOpeningHours ClubOpenHours { get; set; }

        /// <summary>
        /// Gets or sets the creche open hours.
        /// </summary>
        /// <value>
        /// The creche open hours.
        /// </value>
        [ProtoMember(3)]
        public ClubOpeningHours? CrecheOpenHours { get; set; }

        /// <summary>
        /// Gets or sets the public holidays.
        /// </summary>
        /// <value>
        /// The public holidays.
        /// </value>
        [ProtoMember(4)]
        public PublicHoliday[] PublicHolidays{ get; set; }
    }
}