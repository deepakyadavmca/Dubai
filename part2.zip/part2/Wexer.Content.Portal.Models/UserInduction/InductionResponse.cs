﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserInduction
{
    public class InductionResponse
    {
        public HttpStatusCode StatusCode { get; set; }
        public string Message { get; set; }
        public InductionEntities InductionEntity { get; set; }
    }
}
