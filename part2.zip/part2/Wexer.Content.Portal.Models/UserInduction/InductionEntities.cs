﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserInduction
{
    public class InductionEntities
    {
        public string SectionId { get; set; }

        public string UserId { get; set; }

        public string Culture { get; set; }

        public UserInduction UserInduction { get; set; }

        public List<UserDailyMetric> UserDailyMetric { get; set; }

        public List<UserFitness> UserFitness { get; set; }
    }
}
