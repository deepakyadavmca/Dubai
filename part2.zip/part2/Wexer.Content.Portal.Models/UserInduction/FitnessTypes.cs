﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserInduction
{
    public class FitnessTypes
    {
        public const string OverheadSquat = "OverheadSquat";
        public const string Plank = "Plank";
        public const string TRXRow = "TRXRow";
        public const string Treadmill = "Treadmill";
        public const string Bike = "Bike";
        public const string BodyFat = "BodyFat";

    }
}
