﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserInduction
{
    public class InductionMetricTypes : MetricTypes
    {
        public const string Height = "Height";
        public const string HeartRate = "HeartRate";
        public const string BloodPressure = "BloodPressure";
        public const string BodyFat = "BodyFat";
        public const string WaistHeightRatio = "WaistHeightRatio";
        public const string LungCapacity = "LungCapacity";
    }
}
