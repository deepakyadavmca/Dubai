﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserInduction
{
    [ProtoContract]
    public class UserFitness : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public string FitnessTag { get; set; }

        [ProtoMember(3)]
        public string FitnessName { get; set; }

        [ProtoMember(4)]
        public string FitnessType { get; set; }

        [ProtoMember(5)]
        public string FitnessCategory { get; set; }

        [ProtoMember(6)]
        public string FitnessLabel { get; set; }

        [ProtoMember(7)]
        public string Unit { get; set; }

        [ProtoMember(8)]
        public string Value { get; set; }

        [ProtoMember(9)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime RecordingDate { get; set; }

        [ProtoMember(10)]
        public string Level { get; set; }

        [ProtoMember(11)]
        public string DurationInSeconds { get; set; }

        public string PartitionKey
        {
            get { return string.Format("{0}_{1}", UserId, FitnessType.ToLower()); }
        }

        public string RowKey
        {
            get
            {
                return string.Format(RecordingDate.ToString("yyyyMMdd"));
            }
        }
    }
}
