﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wexer.Content.Portal.Models.UserInduction
{
    [ProtoContract]
    public class HealthAssessment
    {
        [ProtoMember(1)]
        public string SectionId { get; set; }

        [ProtoMember(2)]
        public string SectionName { get; set; }

        [ProtoMember(3)]
        public Dictionary<string, string> Item { get; set; }
    }
}
