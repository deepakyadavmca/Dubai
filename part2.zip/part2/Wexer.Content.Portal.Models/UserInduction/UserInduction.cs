﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.UserInduction
{
    [ProtoContract]
    public class UserInduction
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        [ProtoMember(2)]
        public List<HealthAssessment> HealthAssessment { get; set; }

    }
}
