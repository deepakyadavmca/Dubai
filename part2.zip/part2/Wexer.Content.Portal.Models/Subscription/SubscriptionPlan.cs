﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public class SubscriptionPlan
    {
        public string Tag { get; set; }
        public double Amount { get; set; }
        public bool LiveMode { get; set; }
        public DateTime CreationDate { get; set; }
        public string Currency { get; set; }
        public string Interval { get; set; }
        public int IntervalCount { get; set; }
        public string Name { get; set; }
        public int TrialPeriodDays { get; set; }
        public string ProductId { get; set; }
        public Dictionary<string, string> Metadata { get; set; }
        public decimal SavePercent { get; set; }
        public string DisplayName { get; set; }
    }
}
