﻿using Wexer.Content.Portal.Models.User;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    [ProtoContract]
    public class UserSubscription : IStorageKey
    {
        [ProtoMember(1)]
        public string UserId { get; set; }

        //[ProtoMember(2)]
        //[SensitiveData]
        //public string EmailAddress { get; set; }

        [ProtoMember(3)]
        public string PlanTag { get; set; }

        [ProtoMember(4)]
        public string SubscriptionTag { get; set; }

        [ProtoMember(5)]
        public string CountryCode { get; set; }

        [ProtoMember(6)]
        public DateTime? CurrentPeriodStart { get; set; }

        [ProtoMember(7)]
        public DateTime? CurrentPeriodEnd { get; set; }

        [ProtoMember(8)]
        public string CustomerId { get; set; }

        [ProtoMember(9)]
        public string Status { get; set; }

        [ProtoMember(10)]
        public DateTime SubscriptionStartDate { get; set; }

        [ProtoMember(11)]
        public DateTime? CanceledAt { get; set; }

        [ProtoMember(12)]
        public bool CancelAtPeriodEnd { get; set; }

        [ProtoMember(13)]
        public DateTime? SubscriptionEndDate { get; set; }

        [ProtoMember(14)]
        public string Source { get; set; }

        [ProtoMember(15)]
        public DateTime? TrialPeriodStart { get; set; }

        [ProtoMember(16)]
        public DateTime? TrialPeriodEnd { get; set; }

        [ProtoMember(17)]
        public string DiscountCode { get; set; }

        [ProtoMember(18)]
        public string ProductId { get; set; }

        [ProtoMember(19)]
        public int GracePeriod { get; set; }

        [ProtoMember(20)]
        public bool IsFreeAccessSubscription { get; set; }

        [ProtoMember(21)]
        public decimal AmountPaid { get; set; }

        [ProtoMember(22)]
        public string FACCodeEndDate { get; set; }

        string IStorageKey.PartitionKey
        {
            get
            {
                return this.UserId.ToLowerInvariant();
            }
        }
        string IStorageKey.RowKey
        {
            get { return this.SubscriptionTag; }
        }
    }
}
