﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public class Coupon
    {
        public string CouponId { get; set; }
        public string Currency { get; set; }
        public decimal? PercentOff { get; set; }
        public double? AmountOff { get; set; }
        public string Duration { get; set; }
        public int? MaxRedemption { get; set; }
        public DateTime? RedeemBy { get; set; }
        public bool IsValid { get; set; }
        public int? DurationInMonths { get; set; }
        public bool LiveMode { get; set; }
        public int TimesRedeemed { get; set; }
        public Dictionary<string, string> Metadata { get; set; }
    }
}
