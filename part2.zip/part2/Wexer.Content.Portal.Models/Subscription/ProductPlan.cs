﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public class ProductPlan
    {
        public Product Product { get; set; }
        public List<SubscriptionPlan> Plans { get; set; }
    }
}
