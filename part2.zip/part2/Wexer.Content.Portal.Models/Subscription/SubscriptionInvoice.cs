﻿using Wexer.Content.Portal.Models.User;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    [ProtoContract]
    public class SubscriptionInvoice : IStorageKey
    {
        [ProtoMember(1)]
        public string SubscriptionId { get; set; }

        [ProtoMember(2)]
        public DateTime InvoiceDate { get; set; }

        [ProtoMember(3)]
        public string InvoiceId { get; set; }

        [ProtoMember(4)]
        public string ChargeId { get; set; }

        [ProtoMember(5)]
        public int InvoiceCharge { get; set; }


        string IStorageKey.PartitionKey
        {
            get
            {
                return this.SubscriptionId;
            }
        }
        string IStorageKey.RowKey
        {
            get { return string.Format("{0}", InvoiceDate.ToString("yyyyMMddHHmmssfff")); }
        }
    }
}
