﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public class PaymentCustomer
    {
        public string CustomerId { get; set; }
        public string Object { get; set; }
        public DateTime Created { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public bool Livemode { get; set; }
        public bool Deleted { get; set; }
    }
}
