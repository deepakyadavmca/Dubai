﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public class UserSubscriptionPayment
    {
        public string UserId { get; set; }
        public string CustomerId { get; set; }
        public string SubscriptionTag { get; set; }
        public string Last4Digits { get; set; }
        public int ExpiryMonth { get; set; }
        public int ExpiryYear { get; set; }
        public string PaymentMethodType { get; set; }
        public string BankCode { get; set; }
        public string MandateReference { get; set; }
        public string MandateUrl { get; set; }
        public string Type { get; set; }
        public string OwnerName { get; set; }
        // public DateTime SignedOnDate { get; set; }
    }
}
