﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public enum SubscriptionStatus
    {
        trialing = 0,
        active = 1,
        past_due = 2,
        canceled = 3,
        unpaid = 4
    }
}
