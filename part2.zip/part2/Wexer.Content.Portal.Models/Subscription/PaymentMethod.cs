﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public enum PaymentMethod
    {
        none = 0,
        sepa_debit = 1,
        card = 2,
    }
}
