﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Subscription
{
    public class PaymentRequest
    {
        public string PlanId { get; set; }
        public string ProductId { get; set; }
        public string SourceToken { get; set; }
        public string DiscountCode { get; set; }
        public PaymentMethod PaymentMethod { get; set; }
        public string ReferrerCode { get; set; }
    }
}
