using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public enum FitnessExperience : byte
    {
        [ProtoEnum(Name = "None", Value = 0)]
        None = 0,

        [ProtoEnum(Name = "Inexperienced", Value = 50)]
        Inexperienced = 50,

        [ProtoEnum(Name = "SomewhatExperienced", Value = 100)]
        SomewhatExperienced = 100,

        [ProtoEnum(Name = "Experienced", Value = 150)]
        Experienced = 150
    }
}