﻿using System;
using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class QueueData
    {
        [ProtoMember(1)]
        public string Command { get; set; }

        [ProtoMember(2)]
        public DateTime EnqueueTime { get; set; }
    }
}