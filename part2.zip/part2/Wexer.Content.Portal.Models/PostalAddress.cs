using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
     [ProtoContract]
    public class PostalAddress
    {
         [ProtoMember(1)]
         public string PremiseName { get; set; }
         [ProtoMember(2)]
         public string AddressLine1 { get; set; }
         [ProtoMember(3)]
         public string AddressLine2 { get; set; }
         [ProtoMember(4)]
         public string City { get; set; }
         [ProtoMember(5)]
         public string PostCode { get; set; }
    }
}