﻿using Wexer.Content.Portal.Models.User.FitnessTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.WorkoutLibrary
{
    public class WorkoutLibraryResponse
    {
        public int TotalTemplateCount { get; set; }
        public int RemainingTemplaetCount { get; set; }
        public UserWorkout[] Workouts { get; set; }
    }
}
