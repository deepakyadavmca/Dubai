﻿using ProtoBuf;

namespace Wexer.Content.Portal.Models
{
    [ProtoContract]
    public class EntitySet<T> 
    {
        [ProtoMember(1)]
        public int Count { get; set; }

        [ProtoMember(2)]
        public T[] Items { get; set; }
    }
}
