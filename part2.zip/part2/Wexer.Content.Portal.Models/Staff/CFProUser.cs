﻿using Wexer.Content.Portal.Models.Attributes;
using ProtoBuf;
using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Models.Staff
{
    [ProtoContract]
    public class CFProUser
    {
        [ProtoMember(1)]
        public string StaffId { get; set; }

        [ProtoMember(2)]
        public string Password { get; set; }

        [ProtoMember(3)]
        public string Role { get; set; }

        [ProtoMember(4)]
        public string HomeCountry { get; set; }

        [ProtoMember(5)]
        public string HomeClub { get; set; }

        [ProtoMember(6)]
        public List<string> Country { get; set; }

        [ProtoMember(7)]
        public List<string> Club { get; set; }

        [ProtoMember(8)]
        public string ImageUrl { get; set; }

        [ProtoMember(9)]
        public string Email { get; set; }

        [ProtoMember(10)]
        public string MobileTelephone { get; set; }

        [ProtoMember(11)]
        public string FirstName { get; set; }

        [ProtoMember(12)]
        public string LastName { get; set; }

        [ProtoMember(13)]
        public bool Activated { get; set; }

        [ProtoMember(14)]
        [SpecializedProperty(Type = SpecializedType.UtcDateTime)]
        public DateTime? DateActivated { get; set; }

        [ProtoMember(15)]
        public string ActivationCode { get; set; }

        [ProtoMember(16)]
        public DateTime? LastLoggedIn { get; set; }

        [ProtoMember(17)]
        public DateTime? LastUpated { get; set; }

        [ProtoMember(18)]
        public string LoggedInCountry { get; set; }

        [ProtoMember(19)]
        public string EmployeeId { get; set; }
    }
}
