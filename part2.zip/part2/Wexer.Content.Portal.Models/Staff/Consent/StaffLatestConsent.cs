﻿using Wexer.Content.Portal.Models.Consent;
using Wexer.Content.Portal.Models.User.Consent;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models.Staff.Consent
{
    [ProtoContract]
    public class StaffLatestConsent : IStorageKey
    {
        [ProtoMember(1)]
        public string StaffId { get; set; }
        [ProtoMember(2)]
        public String PolicyType { get; set; }
        [ProtoMember(3)]
        public int Version { get; set; }

        [ProtoMember(4)]
        public ConsentAction Action { get; set; }
        [ProtoMember(5)]
        public DateTime ConsentDate { get; set; }
        public string PartitionKey
        {
            get
            {
                return StaffId;
            }
        }

        public string RowKey
        {
            get
            {
                return PolicyType.ToString();
            }
        }
    }
}
