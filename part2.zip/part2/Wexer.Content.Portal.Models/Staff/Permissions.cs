﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Staff
{
    [ProtoContract]
    public class Permissions
    {
        [ProtoMember(1)]
        public string PermissionId { get; set; }
        public string PermissionName { get; set; }
    }
}
