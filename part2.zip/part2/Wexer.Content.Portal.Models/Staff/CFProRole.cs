﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace Wexer.Content.Portal.Models.Staff
{
    [ProtoContract]
    public class CFProRole
    {
        [ProtoMember(1)]
        public string RoleId { get; set; }
        [ProtoMember(2)]
        public string RoleName { get; set; }
        [ProtoMember(3)]
        public List<Permissions> Permission { get; set; }
    }
}
