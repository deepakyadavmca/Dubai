﻿using System;

namespace Wexer.Content.Portal.Repositories.Database
{
    public interface ILastModified
    {
        DateTime CreatedUtc { get; set; }
        DateTime LastModifiedUtc { get; set; }
    }
}