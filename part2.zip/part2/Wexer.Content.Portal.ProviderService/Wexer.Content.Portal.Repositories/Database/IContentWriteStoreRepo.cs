﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Repositories.Database
{
    public interface IContentWriteStoreRepo
    {
        IEnumerable<WriteStoreEntity<T>> ReadList<T>() where T : class;

        IEnumerable<WriteStoreEntity<T>> ReadTenantList<T>(string tenant) where T : class;
        WriteStoreEntity<T> Read<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        WriteStoreEntitySet<T> Read<T>(string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        WriteStoreEntitySet<T> ReadTenantData<T>(string tenant, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        void Create<T>(string key, T entity) where T : class;
        void Create<T>(string key, T entity, string tenant) where T : class;
        void Update<T>(string key, T entity) where T : class;
        void Update<T>(string key, T entity, string tenant) where T : class;
        void Delete<T>(string key) where T : class;
        void Delete<T>(string key, string tenant) where T : class;      // J(19/7/2019) added for tenant changes
        int BulkCreate<T>(Func<T, string> getKey, IEnumerable<T> entities) where T : class;
        void DeleteAll<T>() where T : class;

        void DeleteAll<T>(string tenant) where T : class;

        //Task<IEnumerable<WriteStoreEntity<T>>> ReadListAsync<T>() where T : class;
        //Task<WriteStoreEntity<T>> ReadAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        //Task<WriteStoreEntitySet<T>> ReadAsync<T>(string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        //Task CreateAsync<T>(string key, T entity) where T : class;
        //Task<int> BulkCreateAsync<T>(Func<T, string> getKey, IEnumerable<T> entities) where T : class;
        //Task UpdateAsync<T>(string key, T entity) where T : class;
        //Task DeleteAsync<T>(string key) where T : class;

        //Added by Poonam on 17 May to save data in DB without encoding it
        IEnumerable<T> GetAll<T>() where T : class;
        IEnumerable<T> FindAll<T>(System.Linq.Expressions.Expression<Func<T, bool>> predicate) where T : class;
        bool Add<T>(T item) where T : class;

        bool Upsert<T>(string key, T item) where T : class;

        // Added by Yogesh on 9 Apr 2020 to delete class from blob
        void DeleteRow<T>(string key, string tenant) where T : class;
        Task<T> UpsertAndReturnEntity<T>(object key, T item) where T : class;
    }
}
