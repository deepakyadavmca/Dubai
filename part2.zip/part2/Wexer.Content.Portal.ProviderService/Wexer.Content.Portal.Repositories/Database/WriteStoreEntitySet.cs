using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.Database
{
    public class WriteStoreEntitySet<T> : IWriteStoreEntity where T : class
    {
        public string Etag { get; set; }
        public DateTimeOffset? LastModified { get; set; }
        public HashSet<DataEntity<T>> Data { get; set; }

        public int HttpStatusCode { get; set; }
        public bool HasData()
        {
            return Data != null && Data.Count > 0;
        }

        public string Key { get; set; }
    }
}