﻿using Microsoft.EntityFrameworkCore;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Repositories.Database.Models;

namespace Wexer.Content.Portal.Repositories.Database
{
    public class ContentWriteStoreRepo : IContentWriteStoreRepo
    {
        private readonly ILogger _logger;
        private readonly ContentWriteStoreContext _dbContext;

        public ContentWriteStoreRepo(ContentWriteStoreContext context, ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _dbContext = context;
        }
        public WriteStoreEntity<T> Read<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class
        {

            var entityName = typeof(T).Name.ToLowerInvariant();
            var entity = _dbContext.ContentEntity.AsNoTracking().SingleOrDefault(x => x.Key == key && x.TypeName == entityName && !x.IsDeleted);

            var dataStoreEntity = new WriteStoreEntity<T>
            {
                HttpStatusCode = 404
            };

            if (entity == null)
            {
                return dataStoreEntity;
            }

            using (var ms = new MemoryStream(entity.Content))
            {
                dataStoreEntity.Data = new DataEntity<T>
                {
                    Key = entity.Key,
                    Entity = Serializer.Deserialize<T>(ms),
                };
                dataStoreEntity.Etag = entity.Etag;
                dataStoreEntity.LastModified = entity.LastModifiedUtc;
            }

            SetStatusCode(eTag, lastModified, dataStoreEntity);

            return dataStoreEntity;

        }

        private static void SetStatusCode(string eTag, DateTimeOffset? lastModified, IWriteStoreEntity writeStoreEntity)
        {
            if (writeStoreEntity.Etag == eTag ||
                lastModified.HasValue && lastModified.Value == writeStoreEntity.LastModified)
            {
                writeStoreEntity.HttpStatusCode = 302;
            }
            else
            {
                writeStoreEntity.HttpStatusCode = 200;
            }
        }

        public IEnumerable<WriteStoreEntity<T>> ReadList<T>() where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            var entities = _dbContext.ContentEntity.AsNoTracking().Where(x => x.TypeName == entityName && !x.IsDeleted);

            var storedEntities = new List<WriteStoreEntity<T>>();

            foreach (var entity in entities)
            {
                using (var ms = new MemoryStream(entity.Content))
                {
                    var dataStoreEntity = new WriteStoreEntity<T>
                    {
                        HttpStatusCode = 200,
                        Data = new DataEntity<T>
                        {
                            Key = entity.Key,
                            Entity =
                                Serializer
                                    .Deserialize<T>(ms),
                        },
                        Etag = entity.Etag,
                        LastModified = entity.LastModifiedUtc
                    };

                    storedEntities.Add(dataStoreEntity);
                }
            }

            return storedEntities;

        }


        public IEnumerable<WriteStoreEntity<T>> ReadTenantList<T>(string tenant) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            var entities = _dbContext.ContentEntity.AsNoTracking().Where(x => x.TypeName == entityName && !x.IsDeleted && x.Tenant.ToLower() == tenant.Trim().ToLower());

            var storedEntities = new List<WriteStoreEntity<T>>();

            foreach (var entity in entities)
            {
                using (var ms = new MemoryStream(entity.Content))
                {
                    var dataStoreEntity = new WriteStoreEntity<T>
                    {
                        HttpStatusCode = 200,
                        Data = new DataEntity<T>
                        {
                            Key = entity.Key,
                            Entity =
                                Serializer
                                    .Deserialize<T>(ms),
                        },
                        Etag = entity.Etag,
                        LastModified = entity.LastModifiedUtc
                    };

                    storedEntities.Add(dataStoreEntity);
                }
            }

            return storedEntities;

        }


        public WriteStoreEntitySet<T> Read<T>(string eTag = null, DateTimeOffset? lastModified = null) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            var entities = _dbContext.ContentEntity.AsNoTracking().Where(x => x.TypeName == entityName && !x.IsDeleted).ToList();

            var dataStoreEntitySet = new WriteStoreEntitySet<T>
            {
                HttpStatusCode = 404,
                LastModified = null,
                Data = new HashSet<DataEntity<T>>()
            };
            var etags = new StringBuilder();
            foreach (var entity in entities)
            {
                using (var ms = new MemoryStream(entity.Content))
                {
                    dataStoreEntitySet.Data.Add(new DataEntity<T>
                    {
                        Entity = Serializer.Deserialize<T>(ms),
                        Key = entity.Key
                    });
                    etags.Append(entity.Etag);

                    if (!dataStoreEntitySet.LastModified.HasValue ||
                        entity.LastModifiedUtc > dataStoreEntitySet.LastModified)
                    {
                        dataStoreEntitySet.LastModified = entity.LastModifiedUtc;
                    }
                }
            }

            if (entities.Count > 0)
            {
                dataStoreEntitySet.Etag = CalculateETag(Encoding.UTF8.GetBytes(etags.ToString()));
                SetStatusCode(eTag, lastModified, dataStoreEntitySet);
            }

            _logger.Trace("Read (async): [{0}] entities of type: [{1}]!", entities.Count, entityName);

            return dataStoreEntitySet;

        }

        public WriteStoreEntitySet<T> ReadTenantData<T>(string tenant, string eTag = null, DateTimeOffset? lastModified = null) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            var entities = _dbContext.ContentEntity.AsNoTracking().Where(x => x.TypeName == entityName && x.Tenant == tenant && !x.IsDeleted).ToList();

            var dataStoreEntitySet = new WriteStoreEntitySet<T>
            {
                HttpStatusCode = 404,
                LastModified = null,
                Data = new HashSet<DataEntity<T>>()
            };
            var etags = new StringBuilder();
            foreach (var entity in entities)
            {
                using (var ms = new MemoryStream(entity.Content))
                {
                    dataStoreEntitySet.Data.Add(new DataEntity<T>
                    {
                        Entity = Serializer.Deserialize<T>(ms),
                        Key = entity.Key
                    });
                    etags.Append(entity.Etag);

                    if (!dataStoreEntitySet.LastModified.HasValue ||
                        entity.LastModifiedUtc > dataStoreEntitySet.LastModified)
                    {
                        dataStoreEntitySet.LastModified = entity.LastModifiedUtc;
                    }
                }
            }

            if (entities.Count > 0)
            {
                dataStoreEntitySet.Etag = CalculateETag(Encoding.UTF8.GetBytes(etags.ToString()));
                SetStatusCode(eTag, lastModified, dataStoreEntitySet);
            }

            _logger.Trace("Read (async): [{0}] entities of type: [{1}] for tenant: [{2}]!", entities.Count, entityName, tenant);

            return dataStoreEntitySet;

        }

        private static string CalculateETag(byte[] content)
        {
            using (var sha1 = new SHA1CryptoServiceProvider())
            {
                return string.Format("\"{0}\"", Convert.ToBase64String(sha1.ComputeHash(content)));
            }
        }

        public void Create<T>(string key, T entity) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            using (var ms = new MemoryStream())
            {
                try
                {
                    Serializer.Serialize(ms, entity);
                }
                catch (Exception e)
                {
                    Trace.WriteLine(string.Format(" Error Serializing entity name: {0} Exception: {1}", entityName,
                        e.Message));
                    throw;
                }

                var content = ms.ToArray();

                var toAdd = new ContentEntity
                {
                    Key = key,
                    TypeName = entityName,
                    Content = content,
                    Etag = CalculateETag(content),
                    LastModifiedUtc = DateTime.UtcNow,
                    CreatedUtc = DateTime.UtcNow,
                    IsDeleted = false,
                    Tenant = "*"
                };

                var context = new ValidationContext(toAdd, null, null);
                var results = new List<ValidationResult>();
                if (!Validator.TryValidateObject(toAdd, context, results, true))
                {
                    return;
                }

                var existing = _dbContext.ContentEntity.FirstOrDefault(e => e.Key == key && e.TypeName == entityName);
                if (existing != null)
                {
                    _dbContext.ContentEntity.Remove(existing);
                }

                _dbContext.ContentEntity.Add(toAdd);
                _dbContext.SaveChanges();
                // _logger.Info("Create (async) - Added [{0}] of type [{1}]", key, entityName);
                _logger.Info("Create (async) - Added data of type [{0}]", entityName);
            }

        }

        public void Create<T>(string key, T entity, string tenant) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            using (var ms = new MemoryStream())
            {
                try
                {
                    Serializer.Serialize(ms, entity);
                }
                catch (Exception e)
                {
                    Trace.WriteLine(string.Format(" Error Serializing entity name: {0} Exception: {1}", entityName,
                        e.Message));
                    throw;
                }

                var content = ms.ToArray();

                var toAdd = new ContentEntity
                {
                    Key = key,
                    TypeName = entityName,
                    Content = content,
                    Etag = CalculateETag(content),
                    LastModifiedUtc = DateTime.UtcNow,
                    CreatedUtc = DateTime.UtcNow,
                    IsDeleted = false,
                    Tenant = tenant
                };

                var context = new ValidationContext(toAdd, null, null);
                var results = new List<ValidationResult>();
                if (!Validator.TryValidateObject(toAdd, context, results, true))
                {
                    return;
                }

                var existing = _dbContext.ContentEntity.FirstOrDefault(e => e.Key == key && e.TypeName == entityName && e.Tenant == tenant);
                if (existing != null)
                {
                    _dbContext.ContentEntity.Remove(existing);
                }

                _dbContext.ContentEntity.Add(toAdd);
                _dbContext.SaveChanges();
                _logger.Info("Create (async) - Added data of type [{0}-{1}]", tenant, entityName);
            }

        }

        public int BulkCreate<T>(Func<T, string> getKey, IEnumerable<T> entities) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            var data = entities.Select(entity =>
            {
                using (var ms = new MemoryStream())
                {
                    Serializer.Serialize(ms, entity);

                    var content = ms.ToArray();
                    return new ContentEntity
                    {
                        Key = getKey(entity),
                        TypeName = entityName,
                        Content = content,
                        Etag = CalculateETag(content),
                        LastModifiedUtc = DateTime.UtcNow,
                        CreatedUtc = DateTime.UtcNow,
                        IsDeleted = false,
                        Tenant = "*"
                    };
                }
            }).Where(entity => Validator.TryValidateObject(entity, new ValidationContext(entity, null, null), new List<ValidationResult>(), true)).ToArray();

            int result = Int32.MinValue;
            //using (var connection = new SqlConnection())
            //{
            //    connection.Open();
            //    using (var command = new SqlCommand("dbo.MergeContentEntity", connection))
            //    {
            //        command.CommandType = CommandType.StoredProcedure;
            //        command.Parameters.Add(new SqlParameter("@SourceItems", SqlDbType.Structured) { TypeName = "[dbo].[ContentEntityType]", Value = data.CopyToDataTable() });
            //        result = command.ExecuteNonQuery();
            //    }
            //}

            //_logger.Info("Bulk Create (async) - Added [{0}] rows, of type [{1}]", result, entityName);


            return result;
        }

        public void Update<T>(string key, T entity) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            using (var ms = new MemoryStream())
            {
                Serializer.Serialize(ms, entity);
                var content = ms.ToArray();

                var existingEntity =
                    _dbContext.ContentEntity.SingleOrDefault(
                        x => x.Key == key && x.TypeName == entityName && !x.IsDeleted);

                if (existingEntity != null)
                {
                    existingEntity.Content = content;
                    existingEntity.Etag = CalculateETag(content);
                }
            }
            _dbContext.SaveChanges();
            _logger.Info("Update (async) - Updated data of type [{0}]", entityName);

        }
        public void Update<T>(string key, T entity, string tenant) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            using (var ms = new MemoryStream())
            {
                Serializer.Serialize(ms, entity);
                var content = ms.ToArray();

                var existingEntity =
                    _dbContext.ContentEntity.SingleOrDefault(
                        x => x.Key == key && x.TypeName == entityName && x.Tenant == tenant && !x.IsDeleted);

                if (existingEntity != null)
                {
                    existingEntity.Content = content;
                    existingEntity.Etag = CalculateETag(content);
                }
            }
            _dbContext.SaveChanges();
            _logger.Info("Update (async) - Updated data of type [{0}-{1}]", tenant, entityName);

        }

        public void DeleteAll<T>() where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            var existingEntities = _dbContext.ContentEntity.Where(x => x.TypeName == entityName);

            foreach (var existingEntity in existingEntities.Where(existingEntity => existingEntity != null))
            {
                _dbContext.ContentEntity.Remove(existingEntity);
            }
            _dbContext.SaveChanges();

            _logger.Info("DeleteAll (async) - Deleted all of type [{0}]", entityName);

        }

        public void DeleteAll<T>(string tenant) where T : class
        {
            IQueryable<ContentEntity> existingEntities = null;
            var entityName = typeof(T).Name.ToLowerInvariant();
            if (entityName.ToLowerInvariant() == "ondemandcollection")
            {
                var collections = ReadTenantList<Wexer.Content.Portal.Models.FitnessTracking.OnDemandCollection>(tenant);
                var classOfTheDay = collections.Where(t => t.IsSuccessStatusCode && t.Data.Entity.IsClassOfDayCollection).Select(t => t.Data.Key).FirstOrDefault();
                if (classOfTheDay != null)
                {
                    existingEntities = _dbContext.ContentEntity.Where(x => x.TypeName == entityName && x.Tenant == tenant && !x.Key.Equals(classOfTheDay));
                }
                else
                {
                    existingEntities = _dbContext.ContentEntity.Where(x => x.TypeName == entityName && x.Tenant == tenant);
                }

            }
            else
            {
                existingEntities = _dbContext.ContentEntity.Where(x => x.TypeName == entityName && x.Tenant == tenant);
            }


            foreach (var existingEntity in existingEntities.Where(existingEntity => existingEntity != null))
            {
                _dbContext.ContentEntity.Remove(existingEntity);
            }
            _dbContext.SaveChanges();

            _logger.Info("DeleteAll (async) - Deleted all of type [{0}-{1}]", tenant, entityName);

        }

        public void Delete<T>(string key) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();

            var existingEntity =
                _dbContext.ContentEntity.SingleOrDefault(x => x.Key == key && x.TypeName == entityName && !x.IsDeleted);

            if (existingEntity != null)
            {
                existingEntity.IsDeleted = true;
            }
            _dbContext.SaveChanges();

            _logger.Info("Delete (async) - Updated data of type [{0}]", entityName);

        }

        public void Delete<T>(string key, string tenant) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();

            var existingEntity =
                _dbContext.ContentEntity.SingleOrDefault(x => x.Key == key && x.TypeName == entityName && x.Tenant == tenant && !x.IsDeleted);

            if (existingEntity != null)
            {
                existingEntity.IsDeleted = true;
            }
            _dbContext.SaveChanges();

            _logger.Info("Delete (async) - Updated data of type [{0}]", entityName);

        }

        // Added by Yogesh on 9 Apr 2020 to delete class from blob
        public void DeleteRow<T>(string key, string tenant) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();

            var existingEntity =
                _dbContext.ContentEntity.SingleOrDefault(x => x.TypeName == entityName && x.Key == key && x.Tenant == tenant);

            if (existingEntity != null)
            {
                _dbContext.ContentEntity.Remove(existingEntity);
            }
            _dbContext.SaveChanges();

            _logger.Info("Delete (async) - Updated data of type [{0}]", entityName);

        }

        public void Dispose()
        {
        }

        #region Async Implementation


        //public async Task<IEnumerable<WriteStoreEntity<T>>> ReadListAsync<T>() where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();
        //    var entities = _writecontext.ContentEntity.AsNoTracking().Where(x => x.TypeName == entityName && !x.IsDeleted);

        //    var storedEntities = new List<WriteStoreEntity<T>>();

        //    return await Task.Factory.StartNew(() =>
        //    {
        //        foreach (var entity in entities)
        //        {
        //            using (var ms = new MemoryStream(entity.Content))
        //            {
        //                var dataStoreEntity = new WriteStoreEntity<T>
        //                {
        //                    HttpStatusCode = 200,
        //                    Data = new DataEntity<T>
        //                    {
        //                        Key = entity.Key,
        //                        Entity =
        //                            Serializer
        //                            .Deserialize<T>(ms),
        //                    },
        //                    Etag = entity.Etag,
        //                    LastModified = entity.LastModifiedUtc
        //                };

        //                storedEntities.Add(dataStoreEntity);
        //            }
        //        }

        //        return storedEntities;
        //    }).ConfigureAwait(false);
        //}

        //public async Task DeleteAsync<T>(string key) where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();

        //    var existingEntity = _writecontext.ContentEntity.SingleOrDefault(x => x.Key == key && x.TypeName == entityName && !x.IsDeleted);

        //    if (existingEntity != null)
        //    {
        //        existingEntity.IsDeleted = true;
        //    }
        //    await _writeContext.SaveChangesAsync(new CancellationToken()).ConfigureAwait(false);
        //    _logger.Info("Delete (async) - Updated [{0}] of type [{1}]", key, entityName);
        //}

        //public async Task<int> BulkCreateAsync<T>(Func<T, string> getKey, IEnumerable<T> entities) where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();

        //    var data = entities.Select(entity =>
        //    {
        //        using (var ms = new MemoryStream())
        //        {
        //            Serializer.Serialize(ms, entity);

        //            var content = ms.ToArray();
        //            return new ContentEntity
        //            {
        //                Key = getKey(entity),
        //                TypeName = entityName,
        //                Content = content,
        //                ETag = CalculateETag(content),
        //                LastModifiedUtc = DateTime.UtcNow,
        //                CreatedUtc = DateTime.UtcNow,
        //                IsDeleted = false
        //            };
        //        }
        //    }).Where(entity => Validator.TryValidateObject(entity, new ValidationContext(entity, null, null), new List<ValidationResult>(), true)).ToArray();

        //    var result = -1;
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        using (var command = new SqlCommand("dbo.MergeContentEntity", connection))
        //        {
        //            command.CommandType = CommandType.StoredProcedure;
        //            command.Parameters.Add(new SqlParameter("@SourceItems", SqlDbType.Structured) { TypeName = "[dbo].[ContentEntityType]", Value = data.CopyToDataTable() });
        //            result = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        //        }
        //    }


        //    _logger.Info("Bulk Create (async) - Added [{0}] rows, of type [{1}]", result, entityName);


        //    return result;
        //}

        //public async Task UpdateAsync<T>(string key, T entity) where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();
        //    using (var ms = new MemoryStream())
        //    {
        //        Serializer.Serialize(ms, entity);
        //        var content = ms.ToArray();

        //        var existingEntity = _writecontext.ContentEntity.SingleOrDefault(x => x.Key == key && x.TypeName == entityName && !x.IsDeleted);

        //        if (existingEntity != null)
        //        {
        //            existingEntity.Content = content;
        //            existingEntity.Etag = CalculateETag(content);
        //        }
        //    }
        //    await _writeContext.SaveChangesAsync().ConfigureAwait(false);
        //    _logger.Info("Update (async) - Updated [{0}] of type [{1}]", key, entityName);
        //}

        //public async Task<WriteStoreEntitySet<T>> ReadAsync<T>(string eTag = null, DateTimeOffset? lastModified = null) where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();
        //    var entities = await _writecontext.ContentEntity.AsNoTracking().Where(x => x.TypeName == entityName && !x.IsDeleted).ToListAsync().ConfigureAwait(false);

        //    var dataStoreEntitySet = new WriteStoreEntitySet<T>
        //    {
        //        HttpStatusCode = 404,
        //        LastModified = null,
        //        Data = new HashSet<DataEntity<T>>()
        //    };
        //    var etags = new StringBuilder();
        //    foreach (var entity in entities)
        //    {
        //        using (var ms = new MemoryStream(entity.Content))
        //        {
        //            dataStoreEntitySet.Data.Add(new DataEntity<T> { Entity = Serializer.Deserialize<T>(ms), Key = entity.Key });
        //            etags.Append(entity.Etag);

        //            if (!dataStoreEntitySet.LastModified.HasValue || entity.LastModifiedUtc > dataStoreEntitySet.LastModified)
        //            {
        //                dataStoreEntitySet.LastModified = entity.LastModifiedUtc;
        //            }
        //        }
        //    }

        //    if (entities.Count > 0)
        //    {
        //        dataStoreEntitySet.Etag = CalculateETag(Encoding.UTF8.GetBytes(etags.ToString()));
        //        SetStatusCode(eTag, lastModified, dataStoreEntitySet);
        //    }

        //    _logger.Trace("Read (async): [{0}] entities of type: [{1}]!", entities.Count, entityName);
        //    return dataStoreEntitySet;
        //}

        //public async Task CreateAsync<T>(string key, T entity) where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();
        //    using (var ms = new MemoryStream())
        //    {
        //        try
        //        {
        //            Serializer.Serialize(ms, entity);
        //        }
        //        catch (Exception e)
        //        {
        //            Trace.WriteLine(string.Format(" Error Serializing entity name: {0} Exception: {1}", entityName, e.Message));
        //            throw;
        //        }

        //        var content = ms.ToArray();

        //        var toAdd = new ContentEntity
        //        {
        //            Key = key,
        //            TypeName = entityName,
        //            Content = content,
        //            ETag = CalculateETag(content),
        //            LastModifiedUtc = DateTime.UtcNow,
        //            CreatedUtc = DateTime.UtcNow,
        //            IsDeleted = false
        //        };

        //        var context = new ValidationContext(toAdd, null, null);
        //        var results = new List<ValidationResult>();
        //        if (Validator.TryValidateObject(toAdd, context, results, true))
        //        {
        //            var existing = _writecontext.ContentEntity.FirstOrDefault(e => e.Key == key && e.TypeName == entityName);
        //            if (existing != null)
        //            {
        //                _writecontext.ContentEntity.Remove(existing);
        //            }

        //            _writecontext.ContentEntity.Add(toAdd);
        //            await _writeContext.SaveChangesAsync().ConfigureAwait(false);
        //            _logger.Info("Create (async) - Added [{0}] of type [{1}]", key, entityName);
        //        }
        //    }
        //}

        //public async Task<WriteStoreEntity<T>> ReadAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class
        //{
        //    var entityName = typeof(T).Name.ToLowerInvariant();
        //    var entity = _writecontext.ContentEntity.AsNoTracking().SingleOrDefault(x => x.Key == key && x.TypeName == entityName && !x.IsDeleted);

        //    var dataStoreEntity = new WriteStoreEntity<T>
        //    {
        //        HttpStatusCode = 404
        //    };
        //    if (entity != null)
        //    {
        //        using (var ms = new MemoryStream(entity.Content))
        //        {
        //            dataStoreEntity.Data = new DataEntity<T>
        //            {
        //                Key = entity.Key,
        //                Entity = Serializer.Deserialize<T>(ms),
        //            };
        //            dataStoreEntity.Etag = entity.Etag;
        //            dataStoreEntity.LastModified = entity.LastModifiedUtc;

        //        }

        //        SetStatusCode(eTag, lastModified, dataStoreEntity);
        //    }

        //    return dataStoreEntity;
        //} 

        #endregion


        /// <summary>
        /// Get All Data
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <returns>Entities</returns>
        public IEnumerable<T> GetAll<T>() where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            try
            {

                return _dbContext.Set<T>().AsNoTracking();

            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format(" Content Write Store : Error getting entites: {0} Exception: {1}", entityName, ex.Message));
                throw;
            }
        }

        /// <summary>
        /// Find all matching data based on condition passed
        /// </summary>
        /// <typeparam name="T">type of Entity</typeparam>
        /// <param name="predicate">condition</param>
        /// <returns>List of data</returns>
        public IEnumerable<T> FindAll<T>(System.Linq.Expressions.Expression<Func<T, bool>> predicate) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            try
            {

                return _dbContext.Set<T>().Where(predicate).AsNoTracking().ToList();

            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format("Content Write Store: Error Find all. Entites: {0} Exception: {1}", entityName, ex.Message));
                throw;
            }
        }

        /// <summary>
        /// Add Data to DB
        /// </summary>
        /// <typeparam name="T">type of entity</typeparam>
        /// <param name="item">Entity to be saved</param>
        /// <returns>bool</returns>
        public bool Add<T>(T item) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            try
            {
                var validationContext = new ValidationContext(item, null, null);
                var results = new List<ValidationResult>();
                if (!Validator.TryValidateObject(item, validationContext, results, true))
                {
                    Trace.WriteLine(string.Format("Validation failed for entity : {0}", entityName));
                    throw new InvalidDataException();
                }


                _dbContext.Set<T>().Add(item);
                return _dbContext.SaveChanges() > 0;

            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format("Content Write Store Add failed. Entity: {0} Exception: {1}", entityName, ex));
                throw;
            }
        }

        /// <summary>
        /// Insert or Update the Value
        /// </summary>
        /// <typeparam name="T">Entity</typeparam>
        /// <param name="key">primary key value</param>
        /// <param name="item">item to be inserted/updated</param>
        /// <returns></returns>
        public bool Upsert<T>(string key, T item) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            try
            {
                var validationContext = new ValidationContext(item, null, null);
                var results = new List<ValidationResult>();
                if (!Validator.TryValidateObject(item, validationContext, results, true))
                {
                    Trace.WriteLine(string.Format("Validation failed for entity : {0}", entityName));
                    throw new InvalidDataException();
                }


                var exisitnEntity = _dbContext.Set<T>().Find(key);
                if (exisitnEntity != null)
                {
                    _dbContext.Set<T>().Remove(exisitnEntity);
                }
                _dbContext.Set<T>().Add(item);

                return _dbContext.SaveChanges() > 0;

            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format("Content Write Store Add failed. Entity: {0} Exception: {1}", entityName, ex));
                throw;
            }
        }

        /// <summary>
        /// Insert or Update the Value
        /// </summary>
        /// <typeparam name="T">Entity</typeparam>
        /// <param name="key">primary key value</param>
        /// <param name="item">item to be inserted/updated</param>
        /// <returns>Inserted or updated entity</returns>
        public async Task<T> UpsertAndReturnEntity<T>(object key, T item) where T : class
        {
            var entityName = typeof(T).Name.ToLowerInvariant();
            try
            {
                var validationContext = new ValidationContext(item, null, null);
                var results = new List<ValidationResult>();
                if (!Validator.TryValidateObject(item, validationContext, results, true))
                {
                    Trace.WriteLine(string.Format("Validation failed for entity : {0}", entityName));
                    throw new InvalidDataException();
                }

                var exisitnEntity = await _dbContext.Set<T>().FindAsync(key);

                if (exisitnEntity != null)
                {
                    var x = _dbContext.Set<T>().Remove(exisitnEntity);
                }

                var y = await _dbContext.Set<T>().AddAsync(item);
                await _dbContext.SaveChangesAsync();
                return item;
            }
            catch (Exception ex)
            {
                Trace.WriteLine(string.Format("Content Write Store UpsertAndReturnEntity failed. Entity: {0} Exception: {1}", entityName, ex));
                throw;
            }
        }

    }
}
