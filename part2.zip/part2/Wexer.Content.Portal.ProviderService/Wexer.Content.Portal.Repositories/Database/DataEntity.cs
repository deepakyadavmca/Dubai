namespace Wexer.Content.Portal.Repositories.Database
{
    public class DataEntity<T>
    {
        public T Entity { get; set; }
        public string Key { get; set; }
    }
}