using System;

namespace Wexer.Content.Portal.Repositories.Database
{
    public static class WriteStoreEntityExtensions
    {
        public static bool IsNullOrEmpty(this IWriteStoreEntity writeStoreEntity)
        {
            return writeStoreEntity == null || !writeStoreEntity.HasData();
        }
    }

    public class WriteStoreEntity<T> : IWriteStoreEntity where T : class
    {
        public string Etag { get; set; }
        public DateTimeOffset? LastModified { get; set; }

        public int HttpStatusCode { get; set; }
        public bool HasData()
        {
            return Data != null && Data.Entity != null;
        }

        public DataEntity<T> Data { get; set; }

        public bool IsSuccessStatusCode
        {
            get { return HttpStatusCode >= 200 && HttpStatusCode <= 299; }
        }
    }
}