using System;

namespace Wexer.Content.Portal.Repositories.Database
{
    public interface IWriteStoreEntity
    {
        string Etag { get; set; }
        DateTimeOffset? LastModified { get; set; }
        int HttpStatusCode { get; set; }

        bool HasData();
    }
}