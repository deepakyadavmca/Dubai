﻿using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.Database.Models
{
    public partial class ContentEntity
    {
        public string Key { get; set; }
        public string TypeName { get; set; }
        public string Tenant { get; set; }
        public string Etag { get; set; }
        public DateTime CreatedUtc { get; set; }
        public DateTime LastModifiedUtc { get; set; }
        public byte[] Content { get; set; }
        public bool IsDeleted { get; set; }
    }
}
