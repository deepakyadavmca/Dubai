﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Repositories.Database.Models
{
    public class OnDemandUrlRequest
    {
        public string Id { get; set; }

        public string ClientId { get; set; }

        public string VideoId { get; set; }

        public string ProviderId { get; set; }

        public string ProviderName { get; set; }

        public string UserId { get; set; }

        public int VideoDurationSecond { get; set; }

        public DateTime EventDate { get; set; }

        public string CustomerNumber { get; set; }

        public DateTime CreatedUtc { get; set; }

        public DateTime LastModifiedUtc { get; set; }
    }
}
