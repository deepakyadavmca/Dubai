﻿using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.Database.Models
{
    public partial class Event
    {
        public string EntityKey { get; set; }
        public string TypeName { get; set; }
        public DateTime CreatedUtc { get; set; }
        public DateTime LastModifiedUtc { get; set; }
        public byte[] Content { get; set; }
        public bool IsDeleted { get; set; }
    }
}
