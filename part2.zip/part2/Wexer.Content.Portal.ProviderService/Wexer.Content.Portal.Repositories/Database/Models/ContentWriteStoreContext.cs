﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Wexer.Content.Portal.Repositories.Database.Models
{
    public partial class ContentWriteStoreContext : DbContext
    {
        public ContentWriteStoreContext()
        {
        }

        public ContentWriteStoreContext(DbContextOptions<ContentWriteStoreContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ContentEntity> ContentEntity { get; set; }
        public virtual DbSet<Event> Event { get; set; }
        public virtual DbSet<MigrationHistory> MigrationHistory { get; set; }
        public virtual DbSet<OnDemandTrackingEntity> OnDemandTrackingEntity { get; set; }
        public virtual DbSet<OndemandTenantUploadTrackingEntity> OndemandTenantUploadTrackingEntity { get; set; }

        public virtual DbSet<OnDemandUrlRequest> OnDemandUrlRequest { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //                optionsBuilder.UseSqlServer("data source=DML-05801\\SQLEXPRESS;Integrated Security=True;Initial Catalog=FitnessFirstCloud_Content;MultipleActiveResultSets=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ContentEntity>(entity =>
            {
                entity.HasKey(e => new { e.Key, e.TypeName, e.Tenant })
                    .HasName("PK_dbo.ContentEntity");

                entity.Property(e => e.Key).HasMaxLength(128);

                entity.Property(e => e.TypeName).HasMaxLength(128);

                entity.Property(e => e.Tenant).HasMaxLength(128);

                entity.Property(e => e.Content).IsRequired();

                entity.Property(e => e.CreatedUtc).HasColumnType("datetime");

                entity.Property(e => e.Etag)
                    .IsRequired()
                    .HasColumnName("ETag");

                entity.Property(e => e.LastModifiedUtc).HasColumnType("datetime");
            });

            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => new { e.EntityKey, e.TypeName })
                    .HasName("PK_dbo.Event");

                entity.Property(e => e.EntityKey).HasMaxLength(128);

                entity.Property(e => e.TypeName).HasMaxLength(128);

                entity.Property(e => e.CreatedUtc).HasColumnType("datetime");

                entity.Property(e => e.LastModifiedUtc).HasColumnType("datetime");
            });

            modelBuilder.Entity<MigrationHistory>(entity =>
            {
                entity.HasKey(e => new { e.MigrationId, e.ContextKey })
                    .HasName("PK_dbo.__MigrationHistory");

                entity.ToTable("__MigrationHistory");

                entity.Property(e => e.MigrationId).HasMaxLength(150);

                entity.Property(e => e.ContextKey).HasMaxLength(300);

                entity.Property(e => e.Model).IsRequired();

                entity.Property(e => e.ProductVersion)
                    .IsRequired()
                    .HasMaxLength(32);
            });

            modelBuilder.Entity<OnDemandTrackingEntity>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasMaxLength(128);

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ContentId)
                    .IsRequired()
                    .HasColumnName("ContentID");

                entity.Property(e => e.CountryId).HasColumnName("CountryID");

                entity.Property(e => e.CreatedUtc).HasColumnType("datetime");

                entity.Property(e => e.LastModifiedUtc).HasColumnType("datetime");

                entity.Property(e => e.PerformDate).HasColumnType("datetime");

                entity.Property(e => e.ProviderId).HasColumnName("ProviderID");

                entity.Property(e => e.SubscriptionStartDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<OndemandTenantUploadTrackingEntity>(entity =>
            {
                entity.Property(e => e.EncodedDate).HasColumnType("datetime");

                entity.Property(e => e.EncodedDurationMinutes).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.EncodedDurationMultiplier).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.ProviderId).IsRequired();

                entity.Property(e => e.TitleTag).IsRequired();

                entity.Property(e => e.UploadedDate).HasColumnType("datetime");
            });


            modelBuilder.Entity<OnDemandUrlRequest>(entity =>
            {
                entity.Property(e => e.EventDate).HasColumnType("datetime");
                entity.Property(e => e.CreatedUtc).HasColumnType("datetime");
                entity.Property(e => e.LastModifiedUtc).HasColumnType("datetime");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
