﻿using System;
using System.Collections.Generic;
using Wexer.Content.Portal.Models.ConsumerWeb;

namespace Wexer.Content.Portal.Repositories.Database.Models
{
    public partial class OnDemandTrackingEntity
    {
        public string Id { get; set; }
        public DateTime? PerformDate { get; set; }
        public bool IsTrial { get; set; }
        public int Year { get; set; }
        public int Month { get; set; }
        public string ProviderId { get; set; }
        public string ProviderName { get; set; }
        public string ClientId { get; set; }
        public string ClientName { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public string ContentId { get; set; }
        public string ContentName { get; set; }
        public int ActualDurationSecond { get; set; }
        public int PlayedDurationSecond { get; set; }
        public DateTime? SubscriptionStartDate { get; set; }
        public DateTime CreatedUtc { get; set; }
        public DateTime LastModifiedUtc { get; set; }

        public WorkoutPerformChannel Source { get; set; }

        public string ContentOwner { get; set; }

        public string CustomerNumber { get; set; }

        public string UserId { get; set; }

        public string ExternalIdentifier { get; set; }



    }
}
