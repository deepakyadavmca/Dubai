﻿using System;
using System.Collections.Generic;

namespace Wexer.Content.Portal.Repositories.Database.Models
{
    public partial class OndemandTenantUploadTrackingEntity
    {
        public int Id { get; set; }
        public string TitleTag { get; set; }
        public string Title { get; set; }
        public string FileName { get; set; }
        public string FileSize { get; set; }
        public int TitleType { get; set; }
        public int DurationSecond { get; set; }
        public string ProviderId { get; set; }
        public string ProviderName { get; set; }
        public decimal? EncodedDurationMinutes { get; set; }
        public decimal? EncodedDurationMultiplier { get; set; }
        public string EventId { get; set; }
        public string EventName { get; set; }
        public DateTime UploadedDate { get; set; }
        public DateTime? EncodedDate { get; set; }
        public string UploadedByUserEmail { get; set; }
        public string UploadedByUserId { get; set; }
    }
}
