﻿using Microsoft.Azure.Cosmos.Table;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Repositories.EntityTransforms;
using Wexer.Content.Repositories.Tables;
using System.Diagnostics;
using Wexer.Content.Portal.Models;

namespace Wexer.Content.Portal.Repositories.Tables.Repo
{
    public class TableRepo : ITableRepo
    {
        private readonly CloudStorageAccount _storageAccount;
        private readonly IModelTransformService _modelTransformService;
        private readonly ILogger _logger;

        private const int MaxByteCapacity = (960 * 1024 * 3) / 4;
        private const int MaxByteCapactiyPerField = (28 * 1024 * 3) / 4;
        private List<string> TableEntitiesByTenant = new List<string>() { "virtualclass", "ondemandcollection", "workoutcollectionlabel", "consentpolicy",
        "exercise", "workouttemplate", "workoutcollectionlabel", "musclegroup", "equipmenttype"};
        public TableRepo(string storageConnectionString, ILoggerFactory loggerFactory, IModelTransformService modelTransformService)
        {
            _storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            _modelTransformService = modelTransformService;
            _logger = loggerFactory.GetLoggerForClass(this);
            ServicePointManager.DefaultConnectionLimit = 100;
            ServicePointManager.UseNagleAlgorithm = false;
            ServicePointManager.Expect100Continue = false;
        }

        public async Task<T> GetAsync<T>(string partitionKey, string rowKey) where T : class, IStorageKey, new()
        {
            try
            {
                var table = await GetTableAsync<T>().ConfigureAwait(false);
                var tableResult =
                    await
                        table.ExecuteAsync(TableOperation.Retrieve<EntityAdapter<ReadStoreEntity>>(partitionKey, rowKey))
                            .ConfigureAwait(false);

                var elasticResult = tableResult.Result as EntityAdapter<ReadStoreEntity>;

                //_logger.Info("Table storage query (Type: [{0}], complete. Status: {1}", typeof(T).Name, tableResult.HttpStatusCode);

                if (elasticResult != null)
                {
                    if (elasticResult.InnerObject.IsFatEntity == false)
                    {
                        return elasticResult != null ?
                            GetEntityFrom<T>(new ReadStoreEntity
                            {
                                RowKey = rowKey,
                                PartitionKey = partitionKey,
                                EntityPayload = _modelTransformService.ApplyEntityTransforms(elasticResult.InnerObject.EntityPayload)
                            }) : null;
                    }
                    else
                    {
                        return elasticResult != null ?
                            GetEntityFrom<T>(elasticResult.InnerObject) : null;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return default;
            }
            
        }

        public IEnumerable<T> GetList<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            return GetListAsync<T>(partitionKey).Result;
        }

        public IQueryable<T> Query<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            return QueryAsync<T>(partitionKey).Result;
        }

        public async Task<IQueryable<T>> QueryAsync<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>().Where(x => x.PartitionKey == partitionKey);

            return GetListOfEntityFrom<T>(query).AsQueryable();
        }

        public async Task<IEnumerable<T>> GetListAsync<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>().Where(x => x.PartitionKey == partitionKey);

            return GetListOfEntityFrom<T>(query);
        }

        public IEnumerable<T> GetList<T>() where T : class, IStorageKey, new()
        {
            return GetListAsync<T>().Result;
        }

        public async Task<IEnumerable<T>> GetListAsync<T>() where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>();

            return GetListOfEntityFrom<T>(query);
        }
        
        public async Task<IEnumerable<PureEntity<T>>> GetPureListAsync<T>() where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>();

            return GetListOfPureEntities<T>(query);
        }

        private async Task<CloudTable> GetTableAsync<T>() where T : class, new()
        {
            string containerName = String.Empty;
            if (typeof(T).Name.ToLowerInvariant() == "virtualclass")
            {
                containerName = "VirtualClass";
            }
            else
            {
                containerName = typeof(T).Name;
            }

            var tableClient = _storageAccount.CreateCloudTableClient();
            var table = tableClient.GetTableReference(containerName);
            await table.CreateIfNotExistsAsync().ConfigureAwait(false);
            return table;
        }

        private IEnumerable<T> GetListOfEntityFrom<T>(IEnumerable<EntityAdapter<ReadStoreEntity>> query) where T : class
        {
            var readStoreEntities = query.AsEnumerable().Select(entity => entity.InnerObject);

            return readStoreEntities.Select(GetEntityFrom<T>).Where(entity => entity != null).ToList();
        }

        private IEnumerable<PureEntity<T>> GetListOfPureEntities<T>(IEnumerable<EntityAdapter<ReadStoreEntity>> query) where T : class
        {
            return query.AsEnumerable().Select(entity => new PureEntity<T> { Entity = GetEntityFrom<T>(entity.InnerObject), TimeStamp = entity.Timestamp });
        }

        private T GetEntityFrom<T>(IReadStoreEntity readStoreEntity) where T : class
        {
            try
            {
                T entity;

                byte[] entityPayLoad;
                //Access the base class properties by converting the interface to the class
                var storedEntity = ((ReadStoreEntity)(readStoreEntity));

                //Check if stroed is not an Fat entity
                if (!storedEntity.IsFatEntity)
                {
                    //Fetch its Entity Payload
                    //If its null return null wlse convert the entityPayload to bytes
                    if (storedEntity.EntityPayload == null)
                    {
                        return null;
                    }
                    entityPayLoad = Convert.FromBase64String(storedEntity.EntityPayload);

                }
                else
                {
                    //If it is Fat entity, convert the distributed bytes array to combine byte array
                    entityPayLoad = storedEntity.GetFatEntityData();
                }


                using (var memoryStream = new MemoryStream(entityPayLoad))
                {
                    entity = Serializer.Deserialize<T>(memoryStream);
                }

                return _modelTransformService.ApplyEntityTransforms(entity);
            }
            catch
            {
                return default;
            }
            
        }

        public async Task<TableReadStoreListWriteOperation<T>> StoreAsync<T>(T entity) where T : class, IStorageKey, new()
        {
            var storageOperation = new TableReadStoreListWriteOperation<T> { Entity = entity };
            var stopwatch = new Stopwatch();
            var existsStopwatch = new Stopwatch();
            var serlializeStopwatch = new Stopwatch();
            stopwatch.Start();
            serlializeStopwatch.Start();

            var content = Serialise(entity);
            if (content == null)
            {
                storageOperation.HttpStatusCode = (int)HttpStatusCode.BadRequest;
            }

            existsStopwatch.Start();
            await CreateTableIfNotExists<T>(entity);
            var table = GetTable<T>();
            existsStopwatch.Stop();

            try
            {
                var toAdd = ConvertToTableEntity(entity.PartitionKey, entity.RowKey, entity);
                var tableEntity = new EntityAdapter<ReadStoreEntity>(toAdd);

                serlializeStopwatch.Stop();
                var result = await table.ExecuteAsync(TableOperation.InsertOrReplace(tableEntity)).ConfigureAwait(false);
                stopwatch.Stop();
                _logger.Debug("StoreAsync complete", "store", new { _storageAccount.Credentials.AccountName, tableName = table.Name, result.HttpStatusCode, totalTimeTakenMs = stopwatch.ElapsedMilliseconds, existsTimeTakenMs = existsStopwatch.ElapsedMilliseconds, serlializeTimeTakenMs = serlializeStopwatch.ElapsedMilliseconds });
                storageOperation.Etag = result.Etag;
                storageOperation.HttpStatusCode = result.HttpStatusCode;

            }
            catch (StorageException exception)
            {
                _logger.ErrorException("StoreAsync", exception);
                storageOperation.HttpStatusCode = exception.RequestInformation.HttpStatusCode;
            }

            return storageOperation;
        }

        private ReadStoreEntity ConvertToTableEntity<T>(string partitionKey, string rowKey, T entity) where T : class, new()
        {
            byte[] content = SerlializeToBytes(entity);

            if (null == content) throw new ArgumentNullException("content");

            if (content.Length > MaxByteCapacity) throw new ArgumentOutOfRangeException("content");

            ReadStoreEntity tableEntity = null;

            if (content.Length < MaxByteCapactiyPerField)
            {
                // Store in a single field as a regular entity			
                string payload = Convert.ToBase64String(content);
                tableEntity = new ReadStoreEntity(partitionKey, rowKey, payload, false);
            }
            else
            {
                // Store as a fat entity			
                tableEntity = new ReadStoreEntity(partitionKey, rowKey, true);
                tableEntity.SetFatEntityData(content);
            }

            return tableEntity;
        }

        private CloudTable GetTable<T>() where T : class, new()
        {
            var containerName = typeof(T).Name;
            var tableClient = _storageAccount.CreateCloudTableClient();
            var table = tableClient.GetTableReference(containerName);
            return table;
        }

        private string Serialise<T>(T entity)
        {
            using (var ms = new MemoryStream())
            {
                try
                {
                    Serializer.Serialize(ms, entity);
                }
                catch (Exception e)
                {
                    _logger.ErrorException(string.Format("Error Serializing entity name: {0} Exception: {1}", entity.GetType().Name, e.Message), e);
                    return null;
                }

                return Convert.ToBase64String(ms.ToArray());
            }
        }

        private byte[] SerlializeToBytes<T>(T entity)
        {
            using (var ms = new MemoryStream())
            {
                Serializer.Serialize(ms, entity);

                return ms.ToArray();
            }
        }

        public async Task CreateTableIfNotExists<T>(T entity) where T : class, new()
        {
            _logger.Info("EnsureTableExist called");

            var tableClient = _storageAccount.CreateCloudTableClient();
            var tableType = entity.GetType();

            var table = tableClient.GetTableReference(tableType.Name);
            table.CreateIfNotExists();
        }

        public async Task<TableReadStoreListWriteOperation<T>> DeleteAsync<T>(string partitionKey, string rowKey) where T : class, IStorageKey, new()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var storageOperation = new TableReadStoreListWriteOperation<T>();

            var table = GetTable<T>();
            try
            {
                var result = await table.ExecuteAsync(TableOperation.Delete(new TableEntity(partitionKey, rowKey)
                {
                    ETag = "*"
                })).ConfigureAwait(false);

                stopwatch.Stop();

                _logger.Info("DeleteAsync complete", "delete",
                   new
                   {
                       _storageAccount.Credentials.AccountName,
                       tableName = table.Name,
                       result.HttpStatusCode,
                       timeTakenMs = stopwatch.ElapsedMilliseconds
                   });

                storageOperation.Etag = result.Etag;
                storageOperation.HttpStatusCode = result.HttpStatusCode;

            }
            catch (StorageException exception)
            {
                storageOperation.HttpStatusCode = exception.RequestInformation.HttpStatusCode;

                _logger.ErrorException("DeleteAsync", exception);
            }

            return storageOperation;
        }

        public async Task StoreAsync<T>(string tag, T entity, string userName, string tenant) where T : class, new()
        {
            var tableEntity = ConvertToTableEntity(tag, entity, tenant);
            var table = await GetTableAsync<T>().ConfigureAwait(false);

            var result = await table.ExecuteAsync(TableOperation.InsertOrReplace(tableEntity)).ConfigureAwait(false);
        }

        private async Task<CloudTable> GetTableAsync<T>(string suffix = "") where T : class, new()
        {
            var containerName = "Cms" + typeof(T).Name + suffix;
            var tableClient = _storageAccount.CreateCloudTableClient();
            var table = tableClient.GetTableReference(containerName);

            return table;
        }

        private CustomFitStudioEntity ConvertToTableEntity<T>(string tag, T entity, string tenant) where T : class, new()
        {
            byte[] content = SerlializeToBytes(entity);

            if (null == content) throw new ArgumentNullException("content");

            if (content.Length > MaxByteCapacity) throw new ArgumentOutOfRangeException("content");

            CustomFitStudioEntity tableEntity = null;

            if (content.Length < MaxByteCapactiyPerField)
            {
                // Store in a single field as a regular entity			
                string payload = Convert.ToBase64String(content);
                if (TableEntitiesByTenant.Contains(typeof(T).Name.ToLowerInvariant()))
                {
                    tableEntity = new CustomFitStudioEntity(tenant, tag, payload, false);
                }
                else
                {
                    tableEntity = new CustomFitStudioEntity(tag, tenant, payload, false);
                }

            }
            else
            {
                // Store as a fat entity
                if (typeof(T).Name.ToLowerInvariant() == "consentpolicy")
                {
                    tableEntity = new CustomFitStudioEntity(tenant, true, tag);
                }
                else
                {
                    tableEntity = new CustomFitStudioEntity(tag, true);
                }

                tableEntity.SetFatEntityData(content);
            }

            return tableEntity;
        }

        public async Task<TableReadStoreListWriteOperation<T>> DeleteAllAsync<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var storageOperation = new TableReadStoreListWriteOperation<T>();

            var table = GetTable<T>();
            try
            {
                var batchOperation = new TableBatchOperation();
                var filterQuery = new TableQuery<DynamicTableEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, partitionKey))
                    .Select(new string[] { "RowKey"});

                foreach (var e in table.ExecuteQuery(filterQuery))
                {
                    batchOperation.Delete(e);
                }


                var result = await table.ExecuteBatchAsync(batchOperation);
                stopwatch.Stop();

                _logger.Info("DeleteAllAsync complete", "delete",
                   new
                   {
                       _storageAccount.Credentials.AccountName,
                       tableName = table.Name,
                       timeTakenMs = stopwatch.ElapsedMilliseconds
                   });

                //storageOperation.Etag = result.Select(t => t.);
                //storageOperation.HttpStatusCode = result.HttpStatusCode;

            }
            catch (StorageException exception)
            {
                storageOperation.HttpStatusCode = exception.RequestInformation.HttpStatusCode;

                _logger.ErrorException("DeleteAsync", exception);
            }
            catch(Exception e)
            {

            }

            return storageOperation;
        }

    }
}

