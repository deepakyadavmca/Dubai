﻿using Wexer.Content.Portal.Models;
using Microsoft.Azure.Cosmos.Table;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.EntityTransforms;
using Wexer.Content.Repositories.Tables;

namespace Wexer.Content.Portal.Repositories.Tables.Repo
{
    public class CmsStoreRepo : ICmsStoreRepo
    {
        private readonly CloudStorageAccount _storageAccount;
        private readonly IModelTransformService _modelTransformService;
        private readonly ILogger _logger;

        private const int MaxByteCapacity = (960 * 1024 * 3) / 4;
        private const int MaxByteCapactiyPerField = (28 * 1024 * 3) / 4;
        private List<string> TableEntitiesByTenant = new List<string>() { "virtualclass", "ondemandcollection", "workoutcollectionlabel", "consentpolicy",
        "exercise", "workouttemplate", "workoutcollectionlabel", "musclegroup", "equipmenttype"};
        public CmsStoreRepo(string storageConnectionString, ILoggerFactory loggerFactory, IModelTransformService modelTransformService)
        {
            _storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            _modelTransformService = modelTransformService;
            _logger = loggerFactory.GetLoggerForClass(this);
            ServicePointManager.DefaultConnectionLimit = 100;
            ServicePointManager.UseNagleAlgorithm = false;
            ServicePointManager.Expect100Continue = false;
        }

        public async Task<T> GetAsync<T>(string partitionKey, string rowKey) where T : class, new()
        {
            try
            {
                var table = await GetTableAsync<T>().ConfigureAwait(false);
                var query = table.CreateQuery<CustomFitStudioEntity>().Where(x => x.PartitionKey == partitionKey && x.RowKey == rowKey);
                var listEntity = GetListOfEntityFrom<T>(query);
                return listEntity.FirstOrDefault();
                //var elasticResult = tableResult.Result as EntityAdapter<ReadStoreEntity>;

                //_logger.Info("Table storage query (Type: [{0}], complete. Status: {1}", typeof(T).Name, tableResult.HttpStatusCode);

                //if (elasticResult != null)
                //{
                //    if (elasticResult.InnerObject.IsFatEntity == false)
                //    {
                //        return elasticResult != null ?
                //            GetEntityFrom<T>(new CustomFitStudioEntity
                //            {
                //                RowKey = rowKey,
                //                PartitionKey = partitionKey,
                //                EntityPayload = _modelTransformService.ApplyEntityTransforms(elasticResult.InnerObject.EntityPayload)
                //            }) : null;
                //    }
                //    else
                //    {
                //        return elasticResult != null ?
                //            GetEntityFrom<T>(elasticResult.InnerObject) : null;
                //    }
                //}
                //else
                //{
                //    return null;
                //}
            }
            catch (Exception)
            {
                return default;
            }

        }

        public IEnumerable<T> GetList<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            return GetListAsync<T>(partitionKey).Result;
        }

        public IQueryable<T> Query<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            return QueryAsync<T>(partitionKey).Result;
        }

        public async Task<IQueryable<T>> QueryAsync<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>().Where(x => x.PartitionKey == partitionKey);

            return GetListOfEntityFrom<T>(query).AsQueryable();
        }

        public async Task<T> QueryAsync<T>(string partitionKey, string rowKey) where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>().Where(x => x.PartitionKey == partitionKey && x.RowKey == rowKey);

            return GetListOfEntityFrom<T>(query).FirstOrDefault();
        }

        public async Task<IEnumerable<T>> GetListAsync<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>().Where(x => x.PartitionKey == partitionKey);

            return GetListOfEntityFrom<T>(query);
        }

        public IEnumerable<T> GetList<T>() where T : class, IStorageKey, new()
        {
            return GetListAsync<T>().Result;
        }

        public async Task<IEnumerable<T>> GetListAsync<T>() where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>();

            return GetListOfEntityFrom<T>(query);
        }

        public async Task<IEnumerable<PureEntity<T>>> GetPureListAsync<T>() where T : class, IStorageKey, new()
        {
            var table = await GetTableAsync<T>().ConfigureAwait(false);
            var query = table.CreateQuery<EntityAdapter<ReadStoreEntity>>();

            return GetListOfPureEntities<T>(query);
        }

        private async Task<CloudTable> GetTableAsync<T>() where T : class, new()
        {
            var containerName = typeof(T).Name;

            var tableClient = _storageAccount.CreateCloudTableClient();
            var table = tableClient.GetTableReference(containerName);
            return table;
        }

        private IEnumerable<T> GetListOfEntityFrom<T>(IEnumerable<EntityAdapter<ReadStoreEntity>> query) where T : class
        {
            var readStoreEntities = query.AsEnumerable().Select(entity => entity.InnerObject);

            return readStoreEntities.Select(GetEntityFrom<T>).Where(entity => entity != null).ToList();
        }

        private T GetEntityFrom<T>(CustomFitStudioEntity customFitStudioEntity) where T : class
        {
            T entity;
            byte[] entityPayLoad;

            if (customFitStudioEntity.IsFatEntity)
            {
                entityPayLoad = customFitStudioEntity.GetFatEntityData();
            }
            else
            {
                entityPayLoad = Convert.FromBase64String(customFitStudioEntity.ProtobufPayload);
            }

            using (var memoryStream = new MemoryStream(entityPayLoad))
            {
                entity = Serializer.Deserialize<T>(memoryStream);
            }

            return entity;
        }

        private IEnumerable<PureEntity<T>> GetListOfPureEntities<T>(IEnumerable<EntityAdapter<ReadStoreEntity>> query) where T : class
        {
            return query.AsEnumerable().Select(entity => new PureEntity<T> { Entity = GetEntityFrom<T>(entity.InnerObject), TimeStamp = entity.Timestamp });
        }

        private T GetEntityFrom<T>(IReadStoreEntity readStoreEntity) where T : class
        {
            try
            {
                T entity;

                byte[] entityPayLoad;
                //Access the base class properties by converting the interface to the class
                var storedEntity = ((ReadStoreEntity)(readStoreEntity));

                //Check if stroed is not an Fat entity
                if (!storedEntity.IsFatEntity)
                {
                    //Fetch its Entity Payload
                    //If its null return null wlse convert the entityPayload to bytes
                    if (storedEntity.EntityPayload == null)
                    {
                        return null;
                    }
                    entityPayLoad = Convert.FromBase64String(storedEntity.EntityPayload);

                }
                else
                {
                    //If it is Fat entity, convert the distributed bytes array to combine byte array
                    entityPayLoad = storedEntity.GetFatEntityData();
                }


                using (var memoryStream = new MemoryStream(entityPayLoad))
                {
                    entity = Serializer.Deserialize<T>(memoryStream);
                }

                return _modelTransformService.ApplyEntityTransforms(entity);
            }
            catch
            {
                return default;
            }

        }

        public async Task<TableReadStoreListWriteOperation<T>> StoreAsync<T>(T entity) where T : class, IStorageKey, new()
        {
            var storageOperation = new TableReadStoreListWriteOperation<T> { Entity = entity };
            var stopwatch = new Stopwatch();
            var existsStopwatch = new Stopwatch();
            var serlializeStopwatch = new Stopwatch();
            stopwatch.Start();
            serlializeStopwatch.Start();

            var content = Serialise(entity);
            if (content == null)
            {
                storageOperation.HttpStatusCode = (int)HttpStatusCode.BadRequest;
            }

            existsStopwatch.Start();
            await CreateTableIfNotExists<T>(entity);
            var table = GetTable<T>();
            existsStopwatch.Stop();

            try
            {
                var toAdd = ConvertToTableEntity(entity.PartitionKey, entity.RowKey, entity);
                var tableEntity = new EntityAdapter<ReadStoreEntity>(toAdd);

                serlializeStopwatch.Stop();
                var result = await table.ExecuteAsync(TableOperation.InsertOrReplace(tableEntity)).ConfigureAwait(false);
                stopwatch.Stop();
                _logger.Debug("StoreAsync complete", "store", new { _storageAccount.Credentials.AccountName, tableName = table.Name, result.HttpStatusCode, totalTimeTakenMs = stopwatch.ElapsedMilliseconds, existsTimeTakenMs = existsStopwatch.ElapsedMilliseconds, serlializeTimeTakenMs = serlializeStopwatch.ElapsedMilliseconds });
                storageOperation.Etag = result.Etag;
                storageOperation.HttpStatusCode = result.HttpStatusCode;

            }
            catch (StorageException exception)
            {
                _logger.Warn("StoreAsync storage exception", "warn", exception.ToString());
                storageOperation.HttpStatusCode = exception.RequestInformation.HttpStatusCode;
            }
            catch(Exception e)
            {
                _logger.Warn("StoreAsync exception", "warn", e.ToString());
                storageOperation.HttpStatusCode = (int)HttpStatusCode.InternalServerError;
            }
            return storageOperation;
        }

        private ReadStoreEntity ConvertToTableEntity<T>(string partitionKey, string rowKey, T entity) where T : class, new()
        {
            byte[] content = SerlializeToBytes(entity);

            if (null == content) throw new ArgumentNullException("content");

            if (content.Length > MaxByteCapacity) throw new ArgumentOutOfRangeException("content");

            ReadStoreEntity tableEntity = null;

            if (content.Length < MaxByteCapactiyPerField)
            {
                // Store in a single field as a regular entity			
                string payload = Convert.ToBase64String(content);
                tableEntity = new ReadStoreEntity(partitionKey, rowKey, payload, false);
            }
            else
            {
                // Store as a fat entity			
                tableEntity = new ReadStoreEntity(partitionKey, rowKey, true);
                tableEntity.SetFatEntityData(content);
            }

            return tableEntity;
        }

        private CloudTable GetTable<T>() where T : class, new()
        {
            var containerName = typeof(T).Name;
            var tableClient = _storageAccount.CreateCloudTableClient();
            var table = tableClient.GetTableReference(containerName);
            return table;
        }

        private string Serialise<T>(T entity)
        {
            using (var ms = new MemoryStream())
            {
                try
                {
                    Serializer.Serialize(ms, entity);
                }
                catch (Exception e)
                {
                    _logger.ErrorException(string.Format("Error Serializing entity name: {0} Exception: {1}", entity.GetType().Name, e.Message), e);
                    return null;
                }

                return Convert.ToBase64String(ms.ToArray());
            }
        }

        private byte[] SerlializeToBytes<T>(T entity)
        {
            using (var ms = new MemoryStream())
            {
                Serializer.Serialize(ms, entity);

                return ms.ToArray();
            }
        }

        public async Task CreateTableIfNotExists<T>(T entity) where T : class, new()
        {
            _logger.Info("EnsureTableExist called");

            var tableClient = _storageAccount.CreateCloudTableClient();
            var tableType = entity.GetType();

            var table = tableClient.GetTableReference(tableType.Name);
            table.CreateIfNotExists();
        }

        public async Task<TableReadStoreListWriteOperation<T>> DeleteAsync<T>(string partitionKey, string rowKey) where T : class, new()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var storageOperation = new TableReadStoreListWriteOperation<T>();

            var table = GetTable<T>();
            try
            {
                var result = await table.ExecuteAsync(TableOperation.Delete(new TableEntity(partitionKey, rowKey)
                {
                    ETag = "*"
                })).ConfigureAwait(false);

                stopwatch.Stop();

                _logger.Info("DeleteAsync complete", "delete",
                   new
                   {
                       _storageAccount.Credentials.AccountName,
                       tableName = table.Name,
                       result.HttpStatusCode,
                       timeTakenMs = stopwatch.ElapsedMilliseconds
                   });

                storageOperation.Etag = result.Etag;
                storageOperation.HttpStatusCode = result.HttpStatusCode;

            }
            catch (StorageException exception)
            {
                storageOperation.HttpStatusCode = exception.RequestInformation.HttpStatusCode;

                _logger.ErrorException("DeleteAsync", exception);
            }

            return storageOperation;
        }

        public async Task StoreAsync<T>(string tag, T entity, string userName, string tenant) where T : class, new()
        {
            var tableEntity = ConvertToTableEntity(tag, entity, tenant);
            var table = await GetTableAsync<T>().ConfigureAwait(false);

            var result = await table.ExecuteAsync(TableOperation.InsertOrReplace(tableEntity)).ConfigureAwait(false);
        }

        private async Task<CloudTable> GetTableAsync<T>(string suffix = "") where T : class, new()
        {
            var containerName = "Cms" + typeof(T).Name + suffix;
            var tableClient = _storageAccount.CreateCloudTableClient();
            var table = tableClient.GetTableReference(containerName);

            return table;
        }

        private CustomFitStudioEntity ConvertToTableEntity<T>(string tag, T entity, string tenant) where T : class, new()
        {
            byte[] content = SerlializeToBytes(entity);

            if (null == content) throw new ArgumentNullException("content");

            if (content.Length > MaxByteCapacity) throw new ArgumentOutOfRangeException("content");

            CustomFitStudioEntity tableEntity = null;

            if (content.Length < MaxByteCapactiyPerField)
            {
                // Store in a single field as a regular entity			
                string payload = Convert.ToBase64String(content);
                if (TableEntitiesByTenant.Contains(typeof(T).Name.ToLowerInvariant()))
                {
                    tableEntity = new CustomFitStudioEntity(tenant, tag, payload, false);
                }
                else
                {
                    tableEntity = new CustomFitStudioEntity(tag, tenant, payload, false);
                }

            }
            else
            {
                // Store as a fat entity
                if (typeof(T).Name.ToLowerInvariant() == "consentpolicy")
                {
                    tableEntity = new CustomFitStudioEntity(tenant, true, tag);
                }
                else
                {
                    tableEntity = new CustomFitStudioEntity(tag, true);
                }

                tableEntity.SetFatEntityData(content);
            }

            return tableEntity;
        }

        public async Task<TableReadStoreListWriteOperation<T>> DeleteAllAsync<T>(string partitionKey) where T : class, IStorageKey, new()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var storageOperation = new TableReadStoreListWriteOperation<T>();

            var table = GetTable<T>();
            try
            {
                var batchOperation = new TableBatchOperation();
                var filterQuery = new TableQuery<DynamicTableEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, partitionKey))
                    .Select(new string[] { "RowKey" });

                var entities = table.ExecuteQuery(filterQuery).ToList();

                var offset = 0;
                while (offset < entities.Count)
                {
                    var batch = new TableBatchOperation();
                    var rows = entities.Skip(offset).Take(100).ToList();
                    foreach (var row in rows)
                    {
                        batch.Delete(row);
                    }

                    table.ExecuteBatch(batch);
                    offset += rows.Count;
                }

                stopwatch.Stop();

                _logger.Info("DeleteAllAsync complete", "delete",
                   new
                   {
                       _storageAccount.Credentials.AccountName,
                       tableName = table.Name,
                       timeTakenMs = stopwatch.ElapsedMilliseconds
                   });

            }
            catch (StorageException exception)
            {
                storageOperation.HttpStatusCode = exception.RequestInformation.HttpStatusCode;

                _logger.Warn("DeleteAllAsync storage exception", "warn", exception.ToString());
            }
            catch (Exception e)
            {
                storageOperation.HttpStatusCode = (int)HttpStatusCode.InternalServerError;
                _logger.Warn("DeleteAllAsync exception", "warn", e.ToString());
            }

            return storageOperation;
        }

        public async Task<IEnumerable<T>> GetBulk<T>() where T : class, new()
        {
            try
            {
                var table = await GetTableAsync<T>().ConfigureAwait(false);
                var query = table.CreateQuery<CustomFitStudioEntity>();
                return GetListOfEntityFrom<T>(query);
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task<IEnumerable<T>> GetBulk<T>(string partitionKey) where T : class, new()
        {
            try
            {
                var table = await GetTableAsync<T>().ConfigureAwait(false);
                var query = table.CreateQuery<CustomFitStudioEntity>().Where(x => x.PartitionKey == partitionKey);
                return GetListOfEntityFrom<T>(query);
            }
            catch (Exception e)
            {
                return null;
            }
        }

        private IEnumerable<T> GetListOfEntityFrom<T>(IEnumerable<CustomFitStudioEntity> query) where T : class
        {
            try
            {
                return query.Select(GetEntityFrom<T>).Where(entity => entity != null).ToList();
            }
            catch(Exception e)
            {
                return default;
            }
        }
    }

    public class CustomFitStudioEntity : TableEntity
    {
        public const int MaxByteCapacity = (960 * 1024 * 3) / 4;
        public CustomFitStudioEntity(string partitionKey, string payload, bool isFatEntity = false)
        {
            PartitionKey = partitionKey;
            RowKey = "*";
            ProtobufPayload = payload;
            IsFatEntity = isFatEntity;

        }
        // By J(19/7/2019)
        public CustomFitStudioEntity(string partitionKey, string rowKey, string payload, bool isFatEntity = false)
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
            ProtobufPayload = payload;
            IsFatEntity = isFatEntity;
        }

        public CustomFitStudioEntity(string partitionKey, bool isFatEntity = true)
        {
            PartitionKey = partitionKey;
            RowKey = "*";
            IsFatEntity = isFatEntity;
        }

        public CustomFitStudioEntity(string partitionKey, bool isFatEntity = true, string rowKey = "*")
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
            IsFatEntity = isFatEntity;
        }
        public CustomFitStudioEntity() { }

        public string ProtobufPayload { get; set; }
        public bool IsFatEntity { get; set; }


        public byte[] P0 { get; set; }
        public byte[] P1 { get; set; }
        public byte[] P2 { get; set; }
        public byte[] P3 { get; set; }
        public byte[] P4 { get; set; }
        public byte[] P5 { get; set; }
        public byte[] P6 { get; set; }
        public byte[] P7 { get; set; }
        public byte[] P8 { get; set; }
        public byte[] P9 { get; set; }
        public byte[] P10 { get; set; }
        public byte[] P11 { get; set; }
        public byte[] P12 { get; set; }
        public byte[] P13 { get; set; }
        public byte[] P14 { get; set; }


        IEnumerable<byte[]> GetProperties()
        {
            if (null != P0) yield return P0;
            if (null != P1) yield return P1;
            if (null != P2) yield return P2;
            if (null != P3) yield return P3;
            if (null != P4) yield return P4;
            if (null != P5) yield return P5;
            if (null != P6) yield return P6;
            if (null != P7) yield return P7;
            if (null != P8) yield return P8;
            if (null != P9) yield return P9;
            if (null != P10) yield return P10;
            if (null != P11) yield return P11;
            if (null != P12) yield return P12;
            if (null != P13) yield return P13;
            if (null != P14) yield return P14;
        }


        /// <summary>Returns the concatenated stream contained in the fat entity.</summary>
        public byte[] GetFatEntityData()
        {
            var arrays = GetProperties().ToArray();
            var buffer = new byte[arrays.Sum(a => a.Length)];

            var i = 0;
            foreach (var array in arrays)
            {
                Buffer.BlockCopy(array, 0, buffer, i, array.Length);
                i += array.Length;
            }

            return buffer;
        }

        /// <summary>Split the stream as a fat entity.</summary>
        public void SetFatEntityData(byte[] data)
        {
            if (null == data) throw new ArgumentNullException("data");
            if (data.Length >= MaxByteCapacity) throw new ArgumentOutOfRangeException("data");

            var setters = new Action<byte[]>[]
                {
                        b => P0 = b,
                        b => P1 = b,
                        b => P2 = b,
                        b => P3 = b,
                        b => P4 = b,
                        b => P5 = b,
                        b => P6 = b,
                        b => P7 = b,
                        b => P8 = b,
                        b => P9 = b,
                        b => P10 = b,
                        b => P11 = b,
                        b => P12 = b,
                        b => P13 = b,
                        b => P14 = b,
                };

            for (int i = 0; i < 15; i++)
            {
                if (i * 64 * 1024 < data.Length)
                {
                    var start = i * 64 * 1024;
                    var length = Math.Min(64 * 1024, data.Length - start);
                    var buffer = new byte[length];

                    Buffer.BlockCopy(data, start, buffer, 0, buffer.Length);
                    setters[i](buffer);
                }
                else
                {
                    setters[i](null); // discarding potential leftover
                }
            }
        }
    }
}
