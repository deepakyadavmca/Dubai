﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Repositories.Tables.Repo
{
    public enum Status
    {
        Unmodified,
        Created,
        Updated,
        Deleted
    }
}
