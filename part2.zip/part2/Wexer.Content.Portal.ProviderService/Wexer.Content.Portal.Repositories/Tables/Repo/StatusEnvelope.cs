﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Repositories.Tables.Repo
{
    class StatusEnvelope<T>
    {
        public StatusEnvelope(T item, Status status)
        {
            Item = item;
            Status = status;
        }

        public T Item { get; private set; }
        public Status Status { get; set; }
    }
}
