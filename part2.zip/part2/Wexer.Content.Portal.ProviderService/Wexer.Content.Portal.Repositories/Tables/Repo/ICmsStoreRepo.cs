﻿using Wexer.Content.Portal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.ReadStore;

namespace Wexer.Content.Portal.Repositories.Tables.Repo
{
    public interface ICmsStoreRepo
    {
        Task<T> GetAsync<T>(string partitionKey, string rowKey) where T : class, new();
        IEnumerable<T> GetList<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<IEnumerable<T>> GetListAsync<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<IEnumerable<T>> GetListAsync<T>() where T : class, IStorageKey, new();
        Task<IEnumerable<PureEntity<T>>> GetPureListAsync<T>() where T : class, IStorageKey, new();
        IQueryable<T> Query<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<IQueryable<T>> QueryAsync<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<T> QueryAsync<T>(string partitionKey, string rowKey) where T : class, IStorageKey, new();
        Task<TableReadStoreListWriteOperation<T>> StoreAsync<T>(T entity) where T : class, IStorageKey, new();
        Task CreateTableIfNotExists<T>(T entity) where T : class, new();

        Task<TableReadStoreListWriteOperation<T>> DeleteAsync<T>(string partitionKey, string rowKey) where T : class, new();
        Task<TableReadStoreListWriteOperation<T>> DeleteAllAsync<T>(string partitionKey) where T : class, IStorageKey, new();
        Task StoreAsync<T>(string tag, T entity, string userName, string tenant) where T : class, new();

        Task<IEnumerable<T>> GetBulk<T>() where T : class, new();

        Task<IEnumerable<T>> GetBulk<T>(string partitionKey) where T : class, new();
    }
}
