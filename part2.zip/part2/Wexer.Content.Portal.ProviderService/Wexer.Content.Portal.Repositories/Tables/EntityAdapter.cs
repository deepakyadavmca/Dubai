﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Helper;

namespace Wexer.Content.Repositories.Tables
{
    public class EntityAdapter<T> : ITableEntity where T : ReadStoreEntity, new()
    {
        public EntityAdapter()
        {
            // If you would like to work with objects that do not have a default Ctor you can use (T)Activator.CreateInstance(typeof(T));
            InnerObject = new T();
        }

        public EntityAdapter(T innerObject)
        {
            InnerObject = innerObject;
        }

        public T InnerObject { get; set; }

        /// <summary>
        /// Gets or sets the entity's partition key.
        /// </summary>
        /// <value>The partition key of the entity.</value>
        public string PartitionKey
        {
            get { return InnerObject.PartitionKey; }
            set { InnerObject.PartitionKey = value; }
        }

        /// <summary>
        /// Gets or sets the entity's row key.
        /// </summary>
        /// <value>The row key of the entity.</value>
        public string RowKey
        {
            get
            {
                if (InnerObject.RowKey == null || InnerObject.RowKey.Contains("/") || InnerObject.RowKey.Contains("\\")
                    || InnerObject.RowKey.Contains("#") || InnerObject.RowKey.Contains("?") || InnerObject.RowKey.ContainsControlCharacters())
                {
                    throw new InvalidDataException("Row key must not contain '\\', '/', '#', '?', null or 'control' characters.");
                }

                return InnerObject.RowKey;
            }
            set { InnerObject.RowKey = value; }
        }

        /// <summary>
        /// Gets or sets the entity's timestamp.
        /// </summary>
        /// <value>The timestamp of the entity.</value>
        public DateTimeOffset Timestamp { get; set; }

        /// <summary>
        /// Gets or sets the entity's current ETag. Set this value to '*' in order to blindly overwrite an entity as part of an update operation.
        /// </summary>
        /// <value>The ETag of the entity.</value>
        public string ETag { get; set; }

        public virtual void ReadEntity(IDictionary<string, EntityProperty> properties, OperationContext operationContext)
        {
            TableEntity.ReadUserObject(InnerObject, properties, operationContext);
        }

        public virtual IDictionary<string, EntityProperty> WriteEntity(OperationContext operationContext)
        {
            return TableEntity.WriteUserObject(InnerObject, operationContext);
        }
    }
}
