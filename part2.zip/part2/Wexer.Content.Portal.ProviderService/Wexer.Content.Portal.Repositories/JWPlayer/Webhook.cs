﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.RemoteService;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;

namespace Wexer.Content.Portal.Repositories.JWPlayer
{
    public class Webhook
    {
        private readonly string siteId;
        private readonly string apiSecret;
        private readonly string baseAddress;

        /// <summary>
        /// Constructor used to create webhook.
        /// </summary>
        /// <param name="siteId"> A JW Platform Site Id. </param>
        /// <param name="apiSecret"> A JW Platform API Secret. </param>
        /// <param name="baseAddress"> JWPlayer V2 API base address. </param>
        public Webhook(string siteId, string apiSecret, string baseAddress)
        {
            if (siteId == null || apiSecret == null || baseAddress == null)
                throw new ArgumentNullException("Site Id, API Secret and Base Address cannot be null");

            this.siteId = siteId;
            this.apiSecret = apiSecret;
            this.baseAddress = baseAddress;
        }

        /// <summary>
        /// Create new webhook
        /// </summary>
        /// <param name="metaData">Metadata related to webhook object</param>
        /// <returns>Created record</returns>
        public async Task<T> Create<T>(WebhookMetadata metaData)
        {
            try
            {
                var parameters = new
                {
                    metadata = new
                    {
                        webhook_url = metaData.Webhook_url,
                        events = metaData.Events,
                        name = metaData.Name,
                        description = metaData.Description,
                        site_ids = metaData.Site_ids
                    }
                };

                var client = new RemoteClient(string.Format(Urls.CreateWebhookUrl, baseAddress), apiSecret);
                string apiResponse = await client.Post(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get webhook by id
        /// </summary>
        /// <typeparam name="T">WebhookResponse</typeparam>
        /// <param name="webhookId">Webhook Id</param>
        /// <returns>Webhook response</returns>
        public async Task<T> Get<T>(string webhookId)
        {
            try
            {
                var client = new RemoteClient(string.Format(Urls.GetWebhookUrl, baseAddress, webhookId), apiSecret);
                string apiResponse = await client.Get();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Update webhook
        /// </summary>
        /// <typeparam name="T">WebhookResponse</typeparam>
        /// <param name="webhookId">Webhook Id</param>
        /// <returns>Updated webhook response</returns>
        public async Task<T> Update<T>(string webhookId, WebhookMetadata metaData)
        {
            try
            {
                var parameters = new
                {
                    metadata = new
                    {
                        webhook_url = metaData.Webhook_url,
                        events = metaData.Events,
                        name = metaData.Name,
                        description = metaData.Description,
                        site_ids = metaData.Site_ids
                    }
                };

                var client = new RemoteClient(string.Format(Urls.GetWebhookUrl, baseAddress, webhookId), apiSecret);
                string apiResponse = await client.Patch(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all webhooks available
        /// </summary>
        /// <typeparam name="T">BulkWebhookResponse</typeparam>
        /// <param name="pageNo">Page Number</param>
        /// <param name="pageLength">No. of records per page</param>
        /// <param name="query">Custom query can be created using id, event, name and site_id</param>
        /// <param name="sort">Custom sorting can be implemented using created, last_modified, and name property</param>
        /// <returns>Bulk webhook response</returns>
        public async Task<T> GetAll<T>(int pageNo = 1, int pageLength = 10, string query = "", string sort="")
        {
            try
            {
                string baseUrl = string.Format(Urls.GetAllWebhookUrl, baseAddress, pageNo, pageLength);
                if (query != "")
                {
                    baseUrl = baseUrl + "&q=" + query;
                }
                if (sort != "")
                {
                    baseUrl = baseUrl + "&sort=" + query;
                }

                var client = new RemoteClient(baseUrl, apiSecret);
                string apiResponse = await client.Get();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
