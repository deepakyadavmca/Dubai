﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.JWPlayer.Request;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
namespace Wexer.Content.Portal.Repositories.JWPlayer
{
    public class JWPlayerRepo : IJWPlayerRepo
    {
        private readonly ILogger _logger;
        private readonly IBlobRepo _blobRepo;

        private readonly bool isSandbox;
        private readonly string siteId;
        private readonly string apiSecret;
        private readonly string baseAddressV2;
        private readonly string baseAddressDelivery;

        public JWPlayerRepo(bool isSandbox, string siteId, string apiSecret, string baseAddressV2,
                            string baseAddressDelivery, ILoggerFactory loggerFactory, IBlobRepo blobRepo)
        {
            this.isSandbox = isSandbox;
            this.siteId = siteId;
            this.apiSecret = apiSecret;
            this.baseAddressV2 = baseAddressV2;
            this.baseAddressDelivery = baseAddressDelivery;
            _logger = loggerFactory.GetLoggerForClass(this);
            _blobRepo = blobRepo;
        }

        #region Media
        public async Task<T> InsertMedia<T>(MediaRequest media)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(media.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _media = new Media(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _media.Insert<T>(media.DownloadUrl, media.Metadata);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > InsertMedia , Download Url : {0} & Error : {1}", media.DownloadUrl, ex.ToString()));
                throw;
            }
        }

        public async Task<T> UpdateMedia<T>(MediaRequest media)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(media.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _media = new Media(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _media.Update<T>(media.DownloadUrl, media.MediaId);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > UpdateMedia , Download Url :{0} & Error:{1}", media.DownloadUrl, ex.ToString()));
                throw;
            }
        }

        public async Task<T> GetMediaById<T>(MediaRequest media)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(media.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _media = new Media(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _media.Get<T>(media.MediaId);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetMediaById , mediaId :{0} & Error:{1}", media.MediaId, ex.ToString()));
                throw;
            }
        }

        public async Task<T> GetAllMedia<T>(MediaRequest media)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(media.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _media = new Media(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _media.GetAll<T>();
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetAllMedia > Error:{0}", ex.ToString()));
                throw;
            }
        }

        public async Task<T> UpdateMediaMetadata<T>(MediaRequest media)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(media.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _media = new Media(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _media.UpdateMetada<T>(media.MediaId, media.Metadata);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > UpdateMediaMetadata > mediaId :{0} & Error:{1}", media.MediaId, ex.ToString()));
                throw;
            }
        }
        #endregion

        #region Channel
        public async Task<T> InsertChannel<T>(ChannelRequest channel)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(channel.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _channel = new Channel(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _channel.Insert<T>(channel.Metadata);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > InsertChannel > Error:{0}", ex.ToString()));
                throw;
            }
        }

        public async Task<T> UpdateChannel<T>(ChannelRequest channel)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(channel.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _channel = new Channel(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _channel.Update<T>(channel.ChannelId, channel.Metadata);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > UpdateChannel > Error:{0}", ex.ToString()));
                throw;
            }
        }

        public async Task<T> GetChannelById<T>(ChannelRequest channel)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(channel.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _channel = new Channel(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _channel.Get<T>(channel.ChannelId);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetChannelById > channelId :{0} & Error:{1}", channel.ChannelId, ex.ToString()));
                throw;
            }
        }

        public async Task<T> DeleteChannel<T>(ChannelRequest channel)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(channel.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _channel = new Channel(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _channel.Delete<T>(channel.ChannelId);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > DeleteChannel > channelId :{0} & Error:{1}", channel.ChannelId, ex.ToString()));
                throw;
            }
        }
        #endregion

        #region Delivery
        public async Task<T> GetStreamingUrlById<T>(MediaRequest media)
        {
            try
            {
                var _delivery = new Delivery(baseAddressDelivery);
                return await _delivery.GetStreamingUrlById<T>(media.MediaId);
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetStreamingUrlById > mediaId :{0} & Error:{1}", media.MediaId, ex.ToString()));
                throw;
            }
        }
        #endregion

        #region Webhooks
        public async Task<T> CreateWebhook<T>(WebhookRequest webhook)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(webhook.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _webhook = new Webhook(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _webhook.Create<T>(webhook.Metadata);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > CreateWebhook , Error : {0}", ex.ToString()));
                throw;
            }
        }

        public async Task<T> UpdateWebhook<T>(WebhookRequest webhook)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(webhook.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _webhook = new Webhook(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _webhook.Update<T>(webhook.WebhookId, webhook.Metadata);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > UpdateWebhook , Webhook Id :{0} & Error:{1}", webhook.WebhookId, ex.ToString()));
                throw;
            }
        }

        public async Task<T> GetWebhookById<T>(WebhookRequest webhook)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(webhook.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _webhook = new Webhook(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _webhook.Get<T>(webhook.WebhookId);
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetWebhookById , webhookId :{0} & Error:{1}", webhook.WebhookId, ex.ToString()));
                throw;
            }
        }

        public async Task<T> GetAllWebhook<T>(WebhookRequest webhook)
        {
            try
            {
                var jwCredentials = await GetJWCredentials(webhook.ProviderId);
                if (jwCredentials != null && jwCredentials.Count > 0)
                {
                    var _webhook = new Webhook(jwCredentials[0], jwCredentials[1], baseAddressV2);
                    return await _webhook.GetAll<T>();
                }
                return default;
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetAllWebhook > Error:{0}", ex.ToString()));
                throw;
            }
        }
        #endregion

        #region Private methods
        private async Task<List<string>> GetJWCredentials(string providerId)
        {
            try
            {
                if (isSandbox)
                {
                    return new List<string> { siteId, apiSecret };
                }
                else
                {
                    var providerEntities = await _blobRepo.GetSetAsync<Provider>("*").ConfigureAwait(false);
                    Provider currentProvider = null;
                    if (providerEntities != null && providerEntities.Entity != null && providerEntities.Entity.Count > 0)
                    {
                        currentProvider = providerEntities.Entity.Items.FirstOrDefault(t => t.Tag == providerId);
                    }

                    if (currentProvider != null)
                    {
                        return new List<string> { currentProvider.JWPlayerSiteId, apiSecret };
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Info(string.Format("JWPlayerRepo > GetJWCredentials > providerId :{0} & Error:{1}", providerId, ex.ToString()));
                throw;
            }
        }
        #endregion
    }
}
