﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.RemoteService;

namespace Wexer.Content.Portal.Repositories.JWPlayer
{
    public class Delivery
    {
        private readonly string apiSecret;
        private readonly string baseAddress;

        /// <summary>
        /// Constructor used to create Media.
        /// </summary>
        /// <param name="baseAddress"> JWPlayer Delivery API base address. </param>
        public Delivery(string baseAddress)
        {
            if (baseAddress == null)
                throw new ArgumentNullException("Base Address cannot be null");
            this.baseAddress = baseAddress;
        }

        /// <summary>
        /// Fetch media information to stream
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mediaId">Media Id</param>
        /// <returns>Single media object</returns>
        public async Task<T> GetStreamingUrlById<T>(string mediaId)
        {
            try
            {
                var client = new RemoteClient(string.Format(Urls.GetDeliveryUrl, baseAddress, mediaId), apiSecret);
                string apiResponse = await client.Get();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
