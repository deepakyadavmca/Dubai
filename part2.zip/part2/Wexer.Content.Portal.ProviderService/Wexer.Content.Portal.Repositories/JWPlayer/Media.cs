﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.RemoteService;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;

namespace Wexer.Content.Portal.Repositories.JWPlayer
{
    public class Media
    {
        private readonly string siteId;
        private readonly string apiSecret;
        private readonly string baseAddress;

        /// <summary>
        /// Constructor used to create Media.
        /// </summary>
        /// <param name="siteId"> A JW Platform Site Id. </param>
        /// <param name="apiSecret"> A JW Platform API Secret. </param>
        /// <param name="baseAddress"> JWPlayer V2 API base address. </param>
        public Media(string siteId, string apiSecret, string baseAddress)
        {
            if (siteId == null || apiSecret == null || baseAddress == null)
                throw new ArgumentNullException("Site Id, API Secret and Base Address cannot be null");

            this.siteId = siteId;
            this.apiSecret = apiSecret;
            this.baseAddress = baseAddress;
        }

        /// <summary>
        /// Insert new Media
        /// </summary>
        /// <param name="downloadUrl">Url of raw media file</param>
        /// <param name="metaData">Metadata related to Channel object</param>
        /// <returns>Inserted record</returns>
        public async Task<T> Insert<T>(string downloadUrl, MediaMetadata metaData)
        {
            try
            {
                var parameters = new
                {
                    upload = new
                    {
                        method = "fetch",
                        download_url = downloadUrl
                    },
                    metadata = new
                    {
                        external_id = metaData.ExternalId,
                        title = metaData.Title,
                        description = metaData.Description,
                        author = metaData.Author
                    }
                };

                var client = new RemoteClient(string.Format(Urls.InsertMediaUrl, baseAddress, siteId), apiSecret);
                string apiResponse = await client.Post(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Update Media
        /// </summary>
        /// <param name="downloadUrl">Url of raw media file</param>
        /// <param name="metaData">Metadata related to Channel object</param>
        /// <returns>Updated record</returns>
        public async Task<T> Update<T>(string downloadUrl, string mediaId)
        {
            try
            {
                var parameters = new
                {
                    upload = new
                    {
                        method = "fetch",
                        download_url = downloadUrl
                    },
                };

                var client = new RemoteClient(string.Format(Urls.UpdateMediaUrl, baseAddress, siteId, mediaId), apiSecret);
                string apiResponse = await client.Put(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get media by id
        /// </summary>
        /// <typeparam name="T">MediaResponse</typeparam>
        /// <param name="mediaId">Media Id</param>
        /// <returns>Media response</returns>
        public async Task<T> Get<T>(string mediaId)
        {
            try
            {
                var client = new RemoteClient(string.Format(Urls.GetMediaUrl, baseAddress, siteId, mediaId), apiSecret);
                string apiResponse = await client.Get();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all media available
        /// </summary>
        /// <typeparam name="T">BulkMediaResponse</typeparam>
        /// <param name="pageNo">Page Number</param>
        /// <param name="pageLength">No. of records per page</param>
        /// <param name="externalId">External Id</param>
        /// <returns>Bulk media response</returns>
        public async Task<T> GetAll<T>(int pageNo = 1, int pageLength = 10, string externalId = "")
        {
            try
            {
                string baseUrl = string.Format(Urls.GetAllMediaUrl, baseAddress, siteId, pageNo, pageLength);
                if (externalId != "")
                {
                    baseUrl = baseUrl + "&q=external_id:\"" + externalId + "\"";
                }

                var client = new RemoteClient(baseUrl, apiSecret);
                string apiResponse = await client.Get();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Update media metadata
        /// </summary>
        /// <typeparam name="T">MediaResponse</typeparam>
        /// <param name="mediaId">Media Id</param>
        /// <param name="metadataResponse">Media metadata</param>
        /// <returns>Updated media response</returns>
        public async Task<T> UpdateMetada<T>(string mediaId, MediaMetadata metadataResponse)
        {
            try
            {
                var parameters = new
                {
                    metadata = new
                    {
                        title = metadataResponse.Title,
                        description = metadataResponse.Description,
                        tags = metadataResponse.Tags,
                        publish_start_date = metadataResponse.Publish_start_date,
                        custom_params = metadataResponse.Custom_params
                    },
                };

                var client = new RemoteClient(string.Format(Urls.UpdateMediaMetadataUrl, baseAddress, siteId, mediaId), apiSecret);
                string apiResponse = await client.Patch(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
