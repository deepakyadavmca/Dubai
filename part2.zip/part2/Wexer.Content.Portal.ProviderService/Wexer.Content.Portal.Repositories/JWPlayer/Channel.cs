﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.RemoteService;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;

namespace Wexer.Content.Portal.Repositories.JWPlayer
{
    public class Channel
    {
        private readonly string siteId;
        private readonly string apiSecret;
        private readonly string baseAddress;

        /// <summary>
        /// Constructor used to create Channel
        /// </summary>
        /// <param name="siteId"> A JW Platform Site Id. </param>
        /// <param name="apiSecret"> A JW Platform API Secret. </param>
        /// <param name="baseAddress"> JWPlayer V2 API base address. </param>
        public Channel(string siteId, string apiSecret, string baseAddress)
        {
            if (siteId == null || apiSecret == null || baseAddress == null)
                throw new ArgumentNullException("Site Id, API Secret and Base Address cannot be null");

            this.siteId = siteId;
            this.apiSecret = apiSecret;
            this.baseAddress = baseAddress;
        }

        /// <summary>
        /// Insert Channel
        /// </summary>
        /// <param name="metaData">Metadata related to Channel object</param>
        /// <returns>Inserted channel record</returns>
        public async Task<T> Insert<T>(ChannelMetadata metaData)
        {
            try
            {
                var parameters = new
                {
                    metadata = new
                    {
                        title = metaData.Title,
                        dvr = metaData.EnableDvr ? "on" : "off",
                        custom_params = metaData.CustomParameters
                    }
                };

                var client = new RemoteClient(string.Format(Urls.InsertChannelUrl, baseAddress, siteId), apiSecret);
                string apiResponse = await client.Post(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Update Channel
        /// </summary>
        /// <param name="metaData">Metadata related to Channel object</param>
        /// <returns>Updated channel record</returns>
        public async Task<T> Update<T>(string channelId, ChannelMetadata metaData)
        {
            try
            {
                var parameters = new
                {
                    metadata = new
                    {
                        title = metaData.Title,
                        dvr = metaData.EnableDvr ? "on" : "off"
                    }
                };

                var client = new RemoteClient(string.Format(Urls.UpdateChannelUrl, baseAddress, siteId, channelId), apiSecret);
                string apiResponse = await client.Patch(parameters);
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Fetch channel by channel id
        /// </summary>
        /// <param name="channelId">Id of the channel</param>
        /// <returns>Channel for the respected id if exists</returns>
        public async Task<T> Get<T>(string channelId)
        {
            try
            {
                var client = new RemoteClient(string.Format(Urls.GetChannelUrl, baseAddress, siteId, channelId), apiSecret);
                string apiResponse = await client.Get();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Delete channel by channel id
        /// </summary>
        /// <param name="channelId">Id of the channel</param>
        /// <returns>Nothing if exists else returns error message</returns>
        public async Task<T> Delete<T>(string channelId)
        {
            try
            {
                var client = new RemoteClient(string.Format(Urls.DeleteChannelUrl, baseAddress, siteId, channelId), apiSecret);
                string apiResponse = await client.Delete();
                return JsonConvert.DeserializeObject<T>(apiResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
