﻿using System.Threading.Tasks;
using Wexer.Content.Portal.Models.JWPlayer.Request;

namespace Wexer.Content.Portal.Repositories.JWPlayer
{
    public interface IJWPlayerRepo
    {
        Task<T> InsertMedia<T>(MediaRequest mediaRequest);
        Task<T> UpdateMedia<T>(MediaRequest mediaRequest);
        Task<T> GetMediaById<T>(MediaRequest mediaRequest);
        Task<T> GetAllMedia<T>(MediaRequest mediaRequest);
        Task<T> InsertChannel<T>(ChannelRequest channelRequest);
        Task<T> UpdateChannel<T>(ChannelRequest channelRequest);
        Task<T> GetChannelById<T>(ChannelRequest channelRequest);
        Task<T> DeleteChannel<T>(ChannelRequest channelRequest);
        Task<T> GetStreamingUrlById<T>(MediaRequest media);
        Task<T> UpdateMediaMetadata<T>(MediaRequest mediaRequest);
        Task<T> CreateWebhook<T>(WebhookRequest webhook);
        Task<T> UpdateWebhook<T>(WebhookRequest webhook);
        Task<T> GetWebhookById<T>(WebhookRequest webhook);
        Task<T> GetAllWebhook<T>(WebhookRequest webhook);
    }
}
