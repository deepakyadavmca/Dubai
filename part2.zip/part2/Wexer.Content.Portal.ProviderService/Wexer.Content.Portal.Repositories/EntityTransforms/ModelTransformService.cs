﻿using System;
using System.Linq;
using System.Reflection;
using Wexer.Content.Portal.Models.Attributes;

namespace Wexer.Content.Portal.Repositories.EntityTransforms
{
    public class ModelTransformService : IModelTransformService
    {
        /// <summary>
        /// Service to check for Specialized model attributes, and apply special rules to value (depending on Type)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        public T ApplyEntityTransforms<T>(T entity) where T : class
        {

            if (entity == null)
            {
                return null;
            }

            var newEntity = entity;
            var properties = entity.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic);
            if (!properties.Any())
            {
                return newEntity;
            }

            var propertiesWithTransformAttributes = properties.Where(p => Attribute.IsDefined(p, typeof(SpecializedPropertyAttribute))).ToList();
            if (!propertiesWithTransformAttributes.Any())
            {
                return newEntity;
            }

            foreach (var property in propertiesWithTransformAttributes)
            {
                var specializedPropertyAttribute = (SpecializedPropertyAttribute)property.GetCustomAttribute(typeof(SpecializedPropertyAttribute));
                switch (specializedPropertyAttribute.Type)
                {
                    case SpecializedType.UtcDateTime:
                        var newProperty = newEntity.GetType().GetProperty(property.Name);
                        if (property.PropertyType == typeof(DateTime))
                        {
                            var value = property.GetValue(entity);
                            if (value != null)
                            {
                                var utcDate = DateTime.SpecifyKind((DateTime)value, DateTimeKind.Utc);
                                newProperty.SetValue(newEntity, utcDate, null);
                            }
                        }
                        break;
                }
            }

            return newEntity;
        }
    }

}