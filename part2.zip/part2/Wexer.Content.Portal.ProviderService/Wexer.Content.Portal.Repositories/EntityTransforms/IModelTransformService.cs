﻿namespace Wexer.Content.Portal.Repositories.EntityTransforms
{
    public interface IModelTransformService
    {
        T ApplyEntityTransforms<T>(T entity) where T : class;
    }
}
