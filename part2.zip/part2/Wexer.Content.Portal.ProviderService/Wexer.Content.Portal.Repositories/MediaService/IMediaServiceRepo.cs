﻿using Microsoft.Azure.Management.Media.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Repositories.MediaService
{
    public interface IMediaServiceRepo
    {        
        Task<Job> EncodeVideo(string fileUrl, string fileName, bool isTrailerFile, bool skipStage1Encoding);
        Task<Asset> GetAsset(string assetName);       
        Task<IList<string>> GetStreamingUrlsAsync(string locatorName);        
        Task<StreamingLocator> CreateStreamingLocatorAsync(string assetName, string locatorName);
        string GetAssetBlobUrl(string conatinerName, string fileName);
        public int GetTitleDuration(string containerName);
    }
}
