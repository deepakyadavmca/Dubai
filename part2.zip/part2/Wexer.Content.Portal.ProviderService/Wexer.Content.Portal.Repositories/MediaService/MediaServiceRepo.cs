﻿using Microsoft.Azure.Management.Media;
using Microsoft.Azure.Management.Media.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using System.IO;
using System.Threading;
using System.Net;
using Newtonsoft.Json;
using System.Xml;

namespace Wexer.Content.Portal.Repositories.MediaService
{
    public class MediaServiceRepo : IMediaServiceRepo
    {
        private IAzureMediaServicesClient _client;
        private const string CustomTransform = "Custom_LayerMp4";
        private const string CustomTransformStage1 = "CustomStage1_LayerMp4";
        private const string TrailerCustomTransform = "TrailerCustom_LayerMp4";
        private string _resourceGroup;
        private string _accountName;
        private readonly ILogger _logger;
        private readonly string _cdnUrl;
        private readonly string _mediaServiceConnectionString;
        public MediaServiceRepo(IAzureMediaServicesClient client, string resourceGroup, string accountName, 
            ILoggerFactory loggerFactory, string cdnUrl, string mediaServiceConnectionString)
        {          
            _client = client;            
            _resourceGroup = resourceGroup;
            _accountName = accountName;
            _logger = loggerFactory.GetLoggerForClass(this);
            _cdnUrl = cdnUrl;
            _mediaServiceConnectionString = mediaServiceConnectionString;
        }

        public async Task<Job> EncodeVideo(string fileUrl, string fileName, bool isTrailerFile, bool Stage1Encode)
        {
            try
            {
                // Set the polling interval for long running operations to 2 seconds.
                // The default value is 30 seconds for the .NET client SDK
                _client.LongRunningOperationRetryTimeout = 2;

                if (!isTrailerFile)
                {
                    if (Stage1Encode)
                    {
                        // Stage 1 encoding
                        _logger.Info("MediaServiceRepo > EncodeVideo, Stage1 encoding included");
                        string jobNameStage1 = string.Format("{0}-Stage1-Job", fileName);
                        string outputMediaAssetNameStage1 = string.Format("{0}-Stage1-MediaStandardEncoded", fileName);
                        // Ensure that you have customized encoding Transform.  This is really a one time setup operation.
                        Transform transformStage1 = await CreateCustomTransformStage1(_client, _resourceGroup, _accountName, CustomTransformStage1);
                        // Output from the Job must be written to an Asset, so let's create one
                        Asset outputAssetStage1 = await CreateOutputAssetAsync(_client, _resourceGroup, _accountName, outputMediaAssetNameStage1);
                        // Submit job where input asset is file url
                        Job jobStage1 = await SubmitJobAsyncInputUrl(_client, _resourceGroup, _accountName, CustomTransformStage1, jobNameStage1, fileUrl, outputAssetStage1.Name);
                        // wait for job to finish
                        Job jobToFinishStage1 = WaitForJobToFinish(_client, _resourceGroup, _accountName, CustomTransformStage1, jobStage1.Name);
                        _logger.Info(string.Format("MediaServiceRepo > EncodeVideo, stage1  return job state: {0}", jobToFinishStage1.State));
                        if (jobToFinishStage1.State == JobState.Finished)
                        {
                            await _client.Jobs.DeleteAsync(_resourceGroup, _accountName, CustomTransformStage1, jobStage1.Name);
                            string jobName = string.Format("{0}-Job", fileName);
                            string outputMediaAssetName = string.Format("{0}-MediaStandardEncoded", fileName);

                            // Ensure that you have customized encoding Transform.  This is really a one time setup operation.
                            Transform transform = await CreateCustomTransform(_client, _resourceGroup, _accountName, CustomTransform);
                            // Output from the Job must be written to an Asset, so let's create one
                            Asset outputAsset = await CreateOutputAssetAsync(_client, _resourceGroup, _accountName, outputMediaAssetName);

                            // this is to get stage1 encoded asset blob url
                            var Stage1EncodedAsset = await GetAsset(outputMediaAssetNameStage1).ConfigureAwait(false);
                           
                            var url = GetAssetBlobUrl(Stage1EncodedAsset.Container, "1920x1080_4500");

                            Job job = await SubmitJobAsyncInputUrl(_client, _resourceGroup, _accountName, CustomTransform, jobName, url, outputAsset.Name);
                            Job jobToFinish = WaitForJobToFinish(_client, _resourceGroup, _accountName, CustomTransform, job.Name);
                            _logger.Info(string.Format("MediaServiceRepo > EncodeVideo, non-trailer file return job state: {0}", jobToFinish.State));
                            // delete job
                            if(jobToFinish.State == JobState.Finished)
                            {
                                await _client.Jobs.DeleteAsync(_resourceGroup, _accountName, CustomTransform, job.Name);
                            }
                            
                            return jobToFinish;
                        }
                    }
                    else
                    {
                        string jobName = string.Format("{0}-Job", fileName);
                        string outputMediaAssetName = string.Format("{0}-MediaStandardEncoded", fileName);

                        // Ensure that you have customized encoding Transform.  This is really a one time setup operation.
                        Transform transform = await CreateCustomTransform(_client, _resourceGroup, _accountName, CustomTransform);
                        // Output from the Job must be written to an Asset, so let's create one
                        Asset outputAsset = await CreateOutputAssetAsync(_client, _resourceGroup, _accountName, outputMediaAssetName);
                        Job job = await SubmitJobAsyncInputUrl(_client, _resourceGroup, _accountName, CustomTransform, jobName, fileUrl, outputAsset.Name);
                        Job jobToFinish = WaitForJobToFinish(_client, _resourceGroup, _accountName, CustomTransform, job.Name);
                        _logger.Info(string.Format("MediaServiceRepo > EncodeVideo, non-trailer file return job state: {0}", jobToFinish.State));
                        // delete job
                        if (jobToFinish.State == JobState.Finished)
                        {
                            await _client.Jobs.DeleteAsync(_resourceGroup, _accountName, CustomTransform, job.Name);
                        }
                        return jobToFinish;
                    }
                }
                else
                {
                    string jobName = string.Format("{0}-Mobile-Job", fileName);
                    string outputMediaAssetName = string.Format("{0}-Mobile", fileName);
                    Transform transform = await CreateTrailerTransform(_client, _resourceGroup, _accountName, TrailerCustomTransform);

                    // Output from the Job must be written to an Asset, so let's create one
                    Asset outputAsset = await CreateOutputAssetAsync(_client, _resourceGroup, _accountName, outputMediaAssetName);

                    Job job = await SubmitJobAsyncInputUrl(_client, _resourceGroup, _accountName, TrailerCustomTransform, jobName, fileUrl, outputAsset.Name);
                    Job jobToFinish = WaitForJobToFinish(_client, _resourceGroup, _accountName, TrailerCustomTransform, job.Name);
                    _logger.Info(string.Format("MediaServiceRepo > EncodeVideo, trailer file return job state: {0}", job.State));
                    // delete trailer job
                    if(jobToFinish.State == JobState.Finished)
                    {
                        await _client.Jobs.DeleteAsync(_resourceGroup, _accountName, TrailerCustomTransform, job.Name);
                    }
                    
                    return jobToFinish;
                }
                return null;
            }
            catch (ApiErrorException e)
            {   
                _logger.Warn("MediaServiceRepo > EncodeVideo exception", "warn", e.ToString());
                throw e;
            }
        }


        /// <summary>
        /// If the specified transform exists, return that transform. If the it does not
        /// exist, creates a new transform with the specified output. In this case, the
        /// output is set to encode a video using a custom preset.
        /// </summary>
        /// <param name="client">The Media Services client.</param>
        /// <param name="resourceGroupName">The name of the resource group within the Azure subscription.</param>
        /// <param name="accountName"> The Media Services account name.</param>
        /// <param name="transformName">The transform name.</param>
        /// <returns></returns>
        private async Task<Transform> CreateTrailerTransform(IAzureMediaServicesClient client, string resourceGroupName, string accountName, string transformName)
        {
            // Does a transform already exist with the desired name? Assume that an existing Transform with the desired name
            // also uses the same recipe or Preset for processing content.
            Transform transform = client.Transforms.Get(resourceGroupName, accountName, transformName);

            if (transform == null)
            {
                _logger.Info("MediaServiceRepo > CreateTrailerTransform, Creating a custom trailer transform...");
                // Create a new Transform Outputs array - this defines the set of outputs for the Transform
                TransformOutput[] outputs = new TransformOutput[]
                {
                    // Create a new TransformOutput with a custom Standard Encoder Preset
                    // This demonstrates how to create custom codec and layer output settings

                  new TransformOutput(
                        new StandardEncoderPreset(
                            codecs: new Codec[]
                            {
                                // Add an AAC Audio layer for the audio encoding
                                new AacAudio(
                                    channels: 2,
                                    samplingRate: 48000,
                                    bitrate: 128000,
                                    profile: AacAudioProfile.AacLc
                                ),
                                // Next, add a H264Video for the video encoding
                               new H264Video (
                                    // Set the GOP interval to 2 seconds for both H264Layers
                                    keyFrameInterval:TimeSpan.FromSeconds(2),
                                     // Add H264Layers, one at HD and the other at SD. Assign a label that you can use for the output filename
                                    layers:  new H264Layer[]
                                    {
                                        new H264Layer (
                                            profile:H264VideoProfile.Auto,
                                            level:"auto",
                                            bitrate: 1300000, // Units are in bits per second
                                            maxBitrate:1300000,
                                            bufferWindow:TimeSpan.FromSeconds(5),
                                            width: "848",
                                            height: "480",
                                            bFrames:3,
                                            referenceFrames:3,
                                            adaptiveBFrame:true,
                                            frameRate:"0/1",
                                            label:"848x480"
                                        )
                                    }
                                ),                              
                            },
                            // Specify the format for the output files - one for video+audio, and another for the thumbnails
                            formats: new Format[]
                            {
                                // Mux the H.264 video and AAC audio into MP4 files, using basename, label, bitrate and extension macros
                                // Note that since you have multiple H264Layers defined above, you have to use a macro that produces unique names per H264Layer
                                // Either {Label} or {Bitrate} should suffice
                                 
                                new Mp4Format(
                                    filenamePattern:"{Basename}_{Label}_{Bitrate}{Extension}"
                                ),
                                //new PngFormat(
                                //    filenamePattern:"Thumbnail-{Basename}-{Index}{Extension}"
                                //)
                            }
                        ),
                        onError: OnErrorType.StopProcessingJob,
                        relativePriority: Priority.Normal
                    )
                };

                string description = "A simple custom encoding transform with  MP4 bitrates";
                // Create the custom Transform with the outputs defined above
                transform = await client.Transforms.CreateOrUpdateAsync(resourceGroupName, accountName, transformName, outputs, description);
            }

            return transform;
        }


        /// <summary>
        /// If the specified transform exists, return that transform. If the it does not
        /// exist, creates a new transform with the specified output. In this case, the
        /// output is set to encode a video using a custom preset.
        /// </summary>
        /// <param name="client">The Media Services client.</param>
        /// <param name="resourceGroupName">The name of the resource group within the Azure subscription.</param>
        /// <param name="accountName"> The Media Services account name.</param>
        /// <param name="transformName">The transform name.</param>
        /// <returns></returns>
        private async Task<Transform> CreateCustomTransform(IAzureMediaServicesClient client, string resourceGroupName, string accountName, string transformName)
        {
            // Does a transform already exist with the desired name? Assume that an existing Transform with the desired name
            // also uses the same recipe or Preset for processing content.
            Transform transform = client.Transforms.Get(resourceGroupName, accountName, transformName);

            if (transform == null)
            {
                _logger.Info("MediaServiceRepo > CreateCustomTransform, Creating a custom transform...");                
                // Create a new Transform Outputs array - this defines the set of outputs for the Transform
                TransformOutput[] outputs = new TransformOutput[]
                {
                    // Create a new TransformOutput with a custom Standard Encoder Preset
                    // This demonstrates how to create custom codec and layer output settings

                  new TransformOutput(
                        new StandardEncoderPreset(
                            codecs: new Codec[]
                            {
                                // Add an AAC Audio layer for the audio encoding
                                new AacAudio(
                                    channels: 2,
                                    samplingRate: 48000,
                                    bitrate: 128000,
                                    profile: AacAudioProfile.AacLc
                                ),
                                // Next, add a H264Video for the video encoding
                               new H264Video (
                                    // Set the GOP interval to 2 seconds for both H264Layers
                                    keyFrameInterval:TimeSpan.FromSeconds(2),
                                     // Add H264Layers, one at HD and the other at SD. Assign a label that you can use for the output filename
                                    layers:  new H264Layer[]
                                    {
                                        //new H264Layer (
                                        //    profile:H264VideoProfile.Auto,
                                        //    level:"auto",
                                        //    bitrate: 6000000, // Units are in bits per second
                                        //    maxBitrate:6000000,
                                        //    bufferWindow:TimeSpan.FromSeconds(5),
                                        //    width: "1920",
                                        //    height: "1080",
                                        //    bFrames:3,
                                        //    referenceFrames:3,
                                        //    adaptiveBFrame:true,
                                        //    frameRate:"0/1",
                                        //    label:"1920x1080"
                                        //),
                                        new H264Layer (
                                            profile:H264VideoProfile.Auto,
                                            level:"auto",
                                            bitrate: 4500000, // Units are in bits per second
                                            maxBitrate:4500000,
                                            bufferWindow:TimeSpan.FromSeconds(5),
                                            width: "1920",
                                            height: "1080",
                                            bFrames:3,
                                            referenceFrames:3,
                                            adaptiveBFrame:true,
                                            frameRate:"0/1",
                                            label:"1920x1080"
                                        ),
                                        new H264Layer (
                                            profile:H264VideoProfile.Auto,
                                            level:"auto",
                                            bitrate: 3000000, // Units are in bits per second
                                            maxBitrate:3000000,
                                            bufferWindow:TimeSpan.FromSeconds(5),
                                            width: "1280",
                                            height: "720",
                                            bFrames:3,
                                            referenceFrames:3,
                                            adaptiveBFrame:true,
                                            frameRate:"0/1",
                                            label:"1280x720"
                                        ),
                                         new H264Layer (
                                            profile:H264VideoProfile.Auto,
                                            level:"auto",
                                            bitrate: 2000000, // Units are in bits per second
                                            maxBitrate:2000000,
                                            bufferWindow:TimeSpan.FromSeconds(5),
                                            width: "960",
                                            height: "540",
                                            bFrames:3,
                                            referenceFrames:3,
                                            adaptiveBFrame:true,
                                            frameRate:"0/1",
                                            label:"960x540"
                                        ),
                                        //  new H264Layer (
                                        //    profile:H264VideoProfile.Auto,
                                        //    level:"auto",
                                        //    bitrate: 1500000, // Units are in bits per second
                                        //    maxBitrate:1500000,
                                        //    bufferWindow:TimeSpan.FromSeconds(5),
                                        //    width: "960",
                                        //    height: "540",
                                        //    bFrames:3,
                                        //    referenceFrames:3,
                                        //    adaptiveBFrame:true,
                                        //    frameRate:"0/1",
                                        //    label:"960x540"
                                        //),
                                          new H264Layer (
                                            profile:H264VideoProfile.Auto,
                                            level:"auto",
                                            bitrate: 1000000, // Units are in bits per second
                                            maxBitrate:1000000,
                                            bufferWindow:TimeSpan.FromSeconds(5),
                                            width: "640",
                                            height: "360",
                                            bFrames:3,
                                            referenceFrames:3,
                                            adaptiveBFrame:true,
                                            frameRate:"0/1",
                                            label:"640x360"
                                        )
                                        //  new H264Layer (
                                        //    profile:H264VideoProfile.Auto,
                                        //    level:"auto",
                                        //    bitrate: 650000, // Units are in bits per second
                                        //    maxBitrate:650000,
                                        //    bufferWindow:TimeSpan.FromSeconds(5),
                                        //    width: "640",
                                        //    height: "360",
                                        //    bFrames:3,
                                        //    referenceFrames:3,
                                        //    adaptiveBFrame:true,
                                        //    frameRate:"0/1",
                                        //    label:"640x360"
                                        //),
                                        //  new H264Layer (
                                        //    profile:H264VideoProfile.Auto,
                                        //    level:"auto",
                                        //    bitrate: 400000, // Units are in bits per second
                                        //    maxBitrate:400000,
                                        //    bufferWindow:TimeSpan.FromSeconds(5),
                                        //    width: "320",
                                        //    height: "180",
                                        //    bFrames:3,
                                        //    referenceFrames:3,
                                        //    adaptiveBFrame:true,
                                        //    frameRate:"0/1",
                                        //    label:"320x180"
                                        //),
                                        //  new H264Layer (
                                        //    profile:H264VideoProfile.Auto,
                                        //    level:"auto",
                                        //    bitrate: 150000, // Units are in bits per second
                                        //    maxBitrate:150000,
                                        //    bufferWindow:TimeSpan.FromSeconds(5),
                                        //    width: "320",
                                        //    height: "180",
                                        //    bFrames:3,
                                        //    referenceFrames:3,
                                        //    adaptiveBFrame:true,
                                        //    frameRate:"0/1",
                                        //    label:"320x180"
                                        //)
                                    }
                                ),
                                //// Also generate a set of PNG thumbnails
                                //new PngImage(
                                //    start: "25%",
                                //    step: "25%",
                                //    range: "80%",
                                //    layers: new PngLayer[]{
                                //        new PngLayer(
                                //            width: "50%",
                                //            height: "50%"
                                //        )
                                //    }
                                //)
                            },
                            // Specify the format for the output files - one for video+audio, and another for the thumbnails
                            formats: new Format[]
                            {
                                // Mux the H.264 video and AAC audio into MP4 files, using basename, label, bitrate and extension macros
                                // Note that since you have multiple H264Layers defined above, you have to use a macro that produces unique names per H264Layer
                                // Either {Label} or {Bitrate} should suffice
                                 
                                new Mp4Format(
                                    filenamePattern:"{Basename}_{Label}_{Bitrate}{Extension}"
                                ),
                                //new PngFormat(
                                //    filenamePattern:"Thumbnail-{Basename}-{Index}{Extension}"
                                //)
                            }
                        ),
                        onError: OnErrorType.StopProcessingJob,
                        relativePriority: Priority.Normal
                    )
                };

                string description = "A simple custom encoding transform with  MP4 bitrates";
                // Create the custom Transform with the outputs defined above
                transform = await client.Transforms.CreateOrUpdateAsync(resourceGroupName, accountName, transformName, outputs, description);
            }

            return transform;
        }


        private async Task<Transform> CreateCustomTransformStage1(IAzureMediaServicesClient client, string resourceGroupName, string accountName, string transformName)
        {
            // Does a transform already exist with the desired name? Assume that an existing Transform with the desired name
            // also uses the same recipe or Preset for processing content.
            Transform transform = client.Transforms.Get(resourceGroupName, accountName, transformName);

            if (transform == null)
            {
                _logger.Info("MediaServiceRepo > CreateCustomTransformStage1, Creating a custom transform...");
                // Create a new Transform Outputs array - this defines the set of outputs for the Transform
                TransformOutput[] outputs = new TransformOutput[]
                {
                    // Create a new TransformOutput with a custom Standard Encoder Preset
                    // This demonstrates how to create custom codec and layer output settings

                  new TransformOutput(
                        new StandardEncoderPreset(
                            codecs: new Codec[]
                            {
                                // Add an AAC Audio layer for the audio encoding
                                new AacAudio(
                                    channels: 2,
                                    samplingRate: 48000,
                                    bitrate: 192000,
                                    profile: AacAudioProfile.AacLc
                                ),
                                // Next, add a H264Video for the video encoding
                               new H264Video (
                                    // Set the GOP interval to 2 seconds for both H264Layers
                                    keyFrameInterval:TimeSpan.FromSeconds(2),
                                     // Add H264Layers, one at HD and the other at SD. Assign a label that you can use for the output filename
                                    layers:  new H264Layer[]
                                    {
                                        new H264Layer (
                                            profile:H264VideoProfile.Auto,
                                            level:"auto",
                                            bitrate: 4500000, // Units are in bits per second
                                            maxBitrate:4500000,
                                            bufferWindow:TimeSpan.FromSeconds(5),
                                            width: "1920",
                                            height: "1080",
                                            bFrames:3,
                                            referenceFrames:3,
                                            adaptiveBFrame:true,
                                            frameRate:"0/1",
                                            label:"1920x1080"
                                        )
                                    }
                                )
                            },
                            // Specify the format for the output files - one for video+audio, and another for the thumbnails
                            formats: new Format[]
                            {
                                // Mux the H.264 video and AAC audio into MP4 files, using basename, label, bitrate and extension macros
                                // Note that since you have multiple H264Layers defined above, you have to use a macro that produces unique names per H264Layer
                                // Either {Label} or {Bitrate} should suffice
                                 
                                new Mp4Format(
                                    filenamePattern:"{Basename}_{Label}_{Bitrate}{Extension}"
                                ),
                                //new PngFormat(
                                //    filenamePattern:"Thumbnail-{Basename}-{Index}{Extension}"
                                //)
                            }
                        ),
                        onError: OnErrorType.StopProcessingJob,
                        relativePriority: Priority.Normal
                    )
                };

                string description = "A simple custom stage1 encoding transform with  MP4 bitrates";
                // Create the custom Transform with the outputs defined above
                transform = await client.Transforms.CreateOrUpdateAsync(resourceGroupName, accountName, transformName, outputs, description);
            }

            return transform;
        }
        
        /// <summary>
        /// Creates an output asset. The output from the encoding Job must be written to an Asset.
        /// </summary>
        /// <param name="client">The Media Services client.</param>
        /// <param name="resourceGroupName">The name of the resource group within the Azure subscription.</param>
        /// <param name="accountName"> The Media Services account name.</param>
        /// <param name="assetName">The output asset name.</param>
        /// <returns></returns>
        /// 
        private async Task<Asset> CreateOutputAssetAsync(IAzureMediaServicesClient client, string resourceGroupName, string accountName, string assetName)
        {
            // Check if an Asset already exists
            Asset outputAsset = await client.Assets.GetAsync(resourceGroupName, accountName, assetName);

            if (outputAsset != null)
            {                
                _logger.Info(string.Format("MediaServiceRepo > CreateOutputAssetAsync, Warning: The asset named {0} already exists. It will be deleted.", assetName));
                await client.Assets.DeleteAsync(resourceGroupName, accountName, assetName);
                outputAsset = new Asset();
            }
            else
            {
                _logger.Info("MediaServiceRepo > CreateOutputAssetAsync, Creating an output asset..");
                outputAsset = new Asset();
            }
            _logger.Info(string.Format("MediaServiceRepo > CreateOutputAssetAsync, output asset name : {0}", outputAsset.Name));
            return await client.Assets.CreateOrUpdateAsync(resourceGroupName, accountName, assetName, outputAsset);
        }
         
        private async Task<Job> SubmitJobAsyncInputUrl(IAzureMediaServicesClient client,
           string resourceGroupName,
           string accountName,
           string transformName,
           string jobName,
           string filrUrl,
           string outputAssetName)
        {
            JobInputHttp jobInput = new JobInputHttp(files: new[] { filrUrl });

            JobOutput[] jobOutputs =
            {
                new JobOutputAsset(outputAssetName),
            };

            // In this example, we are assuming that the job name is unique.
            //
            // If you already have a job with the desired name, use the Jobs.Get method
            // to get the existing job. In Media Services v3, Get methods on entities returns null 
            // if the entity doesn't exist (a case-insensitive check on the name).

            var existingJob = await client.Jobs.GetAsync(resourceGroupName,
                         accountName,
                         transformName,
                         jobName);

            if (existingJob != null)
            {
                _logger.Info(string.Format("MediaServiceRepo > SubmitJobAsyncStage1, returning existing job: {0}", existingJob.Name));
                return existingJob;
            }

            Job job;
            try
            {
                _logger.Info(string.Format("MediaServiceRepo > SubmitJobAsyncStage1, Creating a new job: {0}", jobName));
                job = await client.Jobs.CreateAsync(
                         resourceGroupName,
                         accountName,
                         transformName,
                         jobName,
                         new Job
                         {
                             Input = jobInput,
                             Outputs = jobOutputs,
                         });
            }
            catch (Exception exception)
            {
                if (exception.GetBaseException() is ApiErrorException apiException)
                {
                    _logger.Error("MediaServiceRepo > SubmitJobAsyncStage1, API call failed with error code and message", apiException.Body.Error.Code, apiException.Body.Error.Message);
                }
                throw exception;
            }
            return job;
        }


        /// <summary>
        /// Polls Media Services for the status of the Job.
        /// </summary>
        /// <param name="client">The Media Services client.</param>
        /// <param name="resourceGroupName">The name of the resource group within the Azure subscription.</param>
        /// <param name="accountName"> The Media Services account name.</param>
        /// <param name="transformName">The name of the transform.</param>
        /// <param name="jobName">The name of the job you submitted.</param>
        /// <returns></returns>
        private Job WaitForJobToFinish(IAzureMediaServicesClient client, string resourceGroupName, string accountName, string transformName, string jobName)
        {
            const int SleepInterval = 10 * 1000;
            Job job;
            bool exit = false;

            do
            {
                _logger.Info(string.Format("MediaServiceRepo > WaitForJobToFinish, Job name: {0}", jobName));
                job = client.Jobs.Get(resourceGroupName, accountName, transformName, jobName);

                if (job.State == JobState.Finished || job.State == JobState.Error || job.State == JobState.Canceled)
                {
                    exit = true;
                }
                else
                {
                    _logger.Info(string.Format("MediaServiceRepo > WaitForJobToFinish, Job state is {0}", job.State));

                    for (int i = 0; i < job.Outputs.Count; i++)
                    {
                        JobOutput output = job.Outputs[i];

                        _logger.Info(string.Format("MediaServiceRepo > WaitForJobToFinish, Job output {0} state is  {1}", i, output.State));
                       
                        if (output.State == JobState.Processing)
                        {
                            _logger.Info(string.Format("MediaServiceRepo > WaitForJobToFinish, Job output progress {0}", output.Progress));                           
                        }

                        _logger.Info(Environment.NewLine);
                    }

                    System.Threading.Thread.Sleep(SleepInterval);
                }
            }
            while (!exit);

            return job;
        }

        public async Task<Asset> GetAsset(string assetName)
        {
            // Check if an asset already exists
            Asset asset = await _client.Assets.GetAsync(_resourceGroup, _accountName, assetName);
            if (asset != null)
            {
                _logger.Info(string.Format("MediaServiceRepo > GetAsset, The input asset named {0} exists.", assetName));
                return asset;

            }
            return null;
        }        

        public async Task<StreamingLocator> CreateStreamingLocatorAsync(string assetName, string locatorName)
        {
            var existingLocator = await _client.StreamingLocators.GetAsync(_resourceGroup, _accountName, locatorName);
            if(existingLocator != null)
            {
                return existingLocator;
            }

            StreamingLocator locator = await _client.StreamingLocators.CreateAsync(
                _resourceGroup,
                _accountName,
                locatorName,
                new StreamingLocator
                {
                    AssetName = assetName,
                    StreamingPolicyName = PredefinedStreamingPolicy.ClearStreamingOnly,
                    StartTime = DateTime.Now                   
                });

            return locator;
        }

        public async Task<IList<string>> GetStreamingUrlsAsync(string locatorName)
        {
            const string DefaultStreamingEndpointName = "default";

            IList<string> streamingUrls = new List<string>();          

            StreamingEndpoint streamingEndpoint = await _client.StreamingEndpoints.GetAsync(_resourceGroup, _accountName, DefaultStreamingEndpointName);

            if (streamingEndpoint != null)
            {
                if (streamingEndpoint.ResourceState != StreamingEndpointResourceState.Running)
                {
                    await _client.StreamingEndpoints.StartAsync(_resourceGroup, _accountName, DefaultStreamingEndpointName);
                }
            }

            ListPathsResponse paths = await _client.StreamingLocators.ListPathsAsync(_resourceGroup, _accountName, locatorName);
            
            foreach (StreamingPath path in paths.StreamingPaths)
            {
                UriBuilder uriBuilder = new UriBuilder
                {
                    Scheme = "https",
                    //Host = streamingEndpoint.HostName,
                    Host = _cdnUrl,
                    Path = path.Paths[0]
                };
                streamingUrls.Add(uriBuilder.ToString());
            }

            return streamingUrls;
        }        

        public string GetAssetBlobUrl(string conatinerName, string partialBlobName)
        {
            var storageAccount = CloudStorageAccount.Parse(_mediaServiceConnectionString);
            var blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(conatinerName);
            var blobs = blobContainer.ListBlobs();
            var blobName = "";
            foreach (var item in blobs)
            {
                if (item is CloudBlockBlob blockBlob)
                {
                    if (blockBlob.Name.Contains(partialBlobName))
                    {
                        blobName = blockBlob.Name;
                        break;
                    }
                }
            }
            if (!string.IsNullOrWhiteSpace(blobName))
            {
                var blob = blobContainer.GetBlockBlobReference(blobName);
                var sharedAccessSignature = blob.GetSharedAccessSignature(new SharedAccessBlobPolicy
                {
                    SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddYears(100),
                    Permissions = SharedAccessBlobPermissions.Read,
                    SharedAccessStartTime = DateTimeOffset.UtcNow
                });
                return string.Format("{0}{1}", blob.Uri.AbsoluteUri, sharedAccessSignature);
            }
            return "";                      
        }

        public int GetTitleDuration(string containerName)
        {
            using (WebClient wc = new WebClient())
            {
                var manifestUrl = GetAssetBlobUrl(containerName, "_manifest");
                if (!string.IsNullOrWhiteSpace(manifestUrl))
                {
                    var json = wc.DownloadString(manifestUrl);
                    dynamic array = JsonConvert.DeserializeObject(json);
                    string duration = array["AssetFile"][0]["Duration"];
                    if (duration != null && duration != "")
                    {
                        TimeSpan durationTime = XmlConvert.ToTimeSpan(duration);
                        _logger.Info(string.Format("MediaServiceRepo > GetTitleDuration, duration TimeSpan: {0}", durationTime));
                        _logger.Info(string.Format("MediaServiceRepo > GetTitleDuration, duration in seconds: {0}", Convert.ToInt32(durationTime.TotalSeconds)));
                        return Convert.ToInt32(durationTime.TotalSeconds);
                    }
                    else
                    {
                        _logger.Info(string.Format("MediaServiceRepo > GetTitleDuration, duration is null or blank: {0}", duration));
                    }
                }
                else
                {
                    _logger.Info("MediaServiceRepo > GetTitleDuration, manifest not found");
                }
                return 0;
            }
        }
    }
}
