﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Wexer.Content.Portal.Repositories.Helper
{
    /// <summary>
    /// Provides help methods for converting a string into a url friendly equivalent.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Convert 24 hr time string to minutes from midnight
        /// </summary>
        /// <param name="timeAsString"></param>
        /// <returns></returns>
        public static int ToMinutesFromMidnight(this string timeAsString)
        {
            var hours = default(int);
            var minutes = default(int);

            if (string.IsNullOrEmpty(timeAsString) || (timeAsString.Contains(":") && timeAsString.Length != 5) ||
                (!timeAsString.Contains(":") && timeAsString.Length != 4))
            {
                return default(int);
            }

            var time = timeAsString.Replace(":", "");
            var hoursAsString = time.Substring(0, 2);
            var minutesAsString = time.Substring(2, 2);

            int.TryParse(hoursAsString, out hours);
            int.TryParse(minutesAsString, out minutes);

            return (hours*60) + minutes;
        }

        /// <summary>
        /// Converts the string instance to a URL friendly string.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        /// <remarks>Removes whitespace, adds hyphens between each word and changes the casing to lowercase.</remarks>
        public static string ToUrlFriendlyString(this string value)
        {
            return Regex.Replace(RemoveDiacritics(value), @"\s+-?\s*", "-").ToLowerInvariant();
        }

        /// <summary>
        /// Converts the string instance to a tag representation.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="prefix">The prefix.</param>
        /// <returns></returns>
        public static string ToTag(this string value, string prefix = null)
        {
            return prefix == null ? 
                ToUrlFriendlyString(value) : 
                string.Format(CultureInfo.InvariantCulture, "{0}-{1}", prefix, value.ToUrlFriendlyString()).ToLowerInvariant();
        }

        /// <summary>
        /// Normalises the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static string ToAlphaNumeric(this string value)
        {
            return string.IsNullOrEmpty(value) ? 
                Guid.NewGuid().ToString().Replace("-","") : 
                Regex.Replace(value, @"[^A-Za-z0-9]+", "");
        }

        /// <summary>
        /// Remove umlauts etc
        /// </summary>
        /// <param name="text">string with German characters like the Queen's ancestors would have used</param>
        /// <returns>string with english characters like Prince Harry would use</returns>
        static string RemoveDiacritics(string text)
        {
            var normalizedString = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }

        /// <summary>
        /// Converts the string to Utf-8 byte array
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] ToUtf8(this string value)
        {
            var utf8 = Encoding.UTF8;
            var unicodeBytes = utf8.GetBytes(value);
            return unicodeBytes;
        }

        public static bool ContainsControlCharacters(this string val)
        {
            return val.Any(char.IsControl);
        }

        /// <summary>
        /// Normalises to conform to a table storage key
        /// </summary>
        /// <param name="val"></param>
        /// <returns>normalised string, table storage compliant</returns>
        ///<see cref="http://msdn.microsoft.com/en-us/library/windowsazure/dd179338.aspx"/>
        public static string TableStorageKeyNormalise(this string val)
        {
            //strip out any non alpha numeric chars
            val = Regex.Replace(val, @"[^A-Za-z0-9]+", "");

            if (val.ContainsControlCharacters())
            {
                //remove range of control characters
                val = Regex.Replace(val, @"[^\u0000-\u001F]", string.Empty);
            }

            return val;
        }
    }
}