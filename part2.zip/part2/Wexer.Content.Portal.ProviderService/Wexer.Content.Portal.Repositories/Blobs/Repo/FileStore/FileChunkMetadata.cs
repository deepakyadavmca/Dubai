﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore
{
    public class FileChunkMetadata
    {
        public int ResumableChunkNumber { get; set; }
        public int ResumableTotalChunks { get; set; }
        public int ResumableChunkSize { get; set; }
        public long ResumableTotalSize { get; set; }
        public string ResumableIdentifier { get; set; }
        public string ResumableFilename { get; set; }
        public string ResumableRelativePath { get; set; }
        public IFormFile File { get; set; }
        public byte[] FileContent { get; set; }

        public void SetByteArray()
        {
            var size = File.Length;
            FileContent = new byte[size];
        }
        public void GetByteArray()
        {
            using (var stream = File.OpenReadStream())
            {
                stream.ReadAsync(FileContent, 0, FileContent.Length);
            }
        }
    }
}
