﻿using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.Repositories.Tables.Repo;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore
{
    public class FileStoreRepo : IFileStoreRepo
    {
        private const int MaxBlockSize = 2 * 1024 * 1024; // Approx. 2MB chunk size
        private readonly string _storageConnectionString;
        private readonly IConfiguration _config;
        private static BlobRequestOptions _blobRequestOptions;
        private ILogger _logger;
        ConcurrentDictionary<string, HashSet<string>> _blocklist = new ConcurrentDictionary<string, HashSet<string>>();
        public FileStoreRepo(string storageConnectionString, ILoggerFactory loggerFactory, IConfiguration config)
        {
            _storageConnectionString = storageConnectionString;
            _config = config;
            _logger = loggerFactory.GetLoggerForClass(this);
            _config = config;
        }
        public async Task<HttpResponseMessage> GetStreamAsync(HttpRequestMessage request, string containerName, string key)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            try
            {
                var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
                using (var client = new HttpClient())
                {
                    var sas = await GetSasAsync(storageAccount, containerName, key).ConfigureAwait(false);
                    var endpoint = string.Format("http://{0}/{1}/{2}{3}", storageAccount.BlobEndpoint.Host, containerName, key, sas);
                    var requestMessage = new HttpRequestMessage(HttpMethod.Get, endpoint);

                    foreach (var header in request.Headers.Where(r => r.Key != null && r.Value != null && r.Key.ToLowerInvariant() != "cookie" && r.Key.ToLowerInvariant() != "host"))
                    {
                        requestMessage.Headers.TryAddWithoutValidation(header.Key, header.Value);
                    }

                    stopwatch.Stop();
                    return await client.SendAsync(requestMessage).ConfigureAwait(false);
                }
            }
            catch (StorageException)
            {
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }

        public async Task<FileStoreOperation> GetStreamAsync(Stream stream, string containerName, string key, string eTag, DateTimeOffset? lastModified)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var storageOperation = new FileStoreOperation();
            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);

            try
            {
                _logger.Info("GetStream begin", "getstream", new { storageAccount.Credentials.AccountName, containerName, key });
                var blobReference = await GetBlobReferenceAsync(storageAccount, containerName, key).ConfigureAwait(false);
                var condition = BuildCondition(eTag, lastModified);
                _blobRequestOptions = new BlobRequestOptions();

                await blobReference.FetchAttributesAsync().ConfigureAwait(false);
                await blobReference.DownloadToStreamAsync(stream, condition, _blobRequestOptions, null).ConfigureAwait(false);

                storageOperation.LastModified = blobReference.Properties.LastModified;
                storageOperation.Etag = blobReference.Properties.ETag;
                storageOperation.HttpStatusCode = (int)HttpStatusCode.OK;
                storageOperation.MimeType = blobReference.Properties.ContentType;
            }
            catch (StorageException ex)
            {
                _logger.Warn("GetStream Exception", "warn", ex.ToString());
                storageOperation.HttpStatusCode = ParseException(containerName, key, eTag, lastModified, ex);
            }

            stopwatch.Stop();
            // _logger.Info("GetStream complete", "getStream", new { storageAccount.Credentials.AccountName, containerName, key, storageOperation.HttpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds });
            _logger.Info("GetStream complete", "getStream", new { storageAccount.Credentials.AccountName, containerName, storageOperation.HttpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds, key });

            return storageOperation;
        }

        private static int ParseException(string containerName, string key, string eTag, DateTimeOffset? lastModified, StorageException ex)
        {
            switch (ex.RequestInformation.HttpStatusCode)
            {
                case (int)HttpStatusCode.NotModified:
                    Trace.TraceInformation("{0}:{1} returned not modified based on etag={2}, lastmodified={3}", containerName,
                                           key, eTag, lastModified);
                    break;
                case (int)HttpStatusCode.NotFound:
                    Trace.TraceWarning("{0}:{1} returned not found", containerName, key);
                    break;
                default:
                    Trace.TraceError("{0}:{1} returned {2} - {3}", containerName, key, ex.RequestInformation.HttpStatusCode,
                                     ex.Message);
                    // signal elmah error
                    break;
            }

            return ex.RequestInformation.HttpStatusCode;
        }

        private async Task<CloudBlockBlob> GetBlobReferenceAsync(CloudStorageAccount storageAccount, string containerName, string key)
        {
            var blobClient = storageAccount.CreateCloudBlobClient();

            var serviceProperties = blobClient.GetServiceProperties();
            serviceProperties.DefaultServiceVersion = "2013-08-15";
            blobClient.SetServiceProperties(serviceProperties);

            var blobContainer = blobClient.GetContainerReference(containerName);
            await blobContainer.CreateIfNotExistsAsync().ConfigureAwait(false);
            var blobReference = blobContainer.GetBlockBlobReference(key);

            return blobReference;
        }

        private async Task<string> GetSasAsync(CloudStorageAccount storageAccount, string containerName, string key)
        {
            var blobClient = storageAccount.CreateCloudBlobClient();

            var serviceProperties = blobClient.GetServiceProperties();
            serviceProperties.DefaultServiceVersion = "2013-08-15";
            blobClient.SetServiceProperties(serviceProperties);

            var blobContainer = blobClient.GetContainerReference(containerName);
            await blobContainer.CreateIfNotExistsAsync().ConfigureAwait(false);
            var blobReference = blobContainer.GetBlockBlobReference(key);

            return blobReference.GetSharedAccessSignature(new SharedAccessBlobPolicy
            {
                Permissions = SharedAccessBlobPermissions.Read,
                SharedAccessExpiryTime = DateTime.UtcNow.AddMinutes(1),
            });
        }

        private static AccessCondition BuildCondition(string eTag, DateTimeOffset? lastModified)
        {
            var condition = AccessCondition.GenerateEmptyCondition();
            if (!string.IsNullOrWhiteSpace(eTag))
            {
                condition.IfNoneMatchETag = eTag;
            }
            if (lastModified != null)
            {
                condition.IfModifiedSinceTime = lastModified;
            }

            return condition;
        }






        public async Task<HttpStatusCode> DeleteAsync(string containerName, string key, CancellationToken cancellationToken = default(CancellationToken))
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var httpStatusCode = HttpStatusCode.OK;
            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
            try
            {
                var blobReference = await GetBlobReferenceAsync(storageAccount, containerName, key).ConfigureAwait(false);
                await blobReference.DeleteIfExistsAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (StorageException ex)
            {
                httpStatusCode = (HttpStatusCode)ParseException(containerName, key, null, null, ex);
            }
            stopwatch.Stop();
            _logger.Info("PutStream complete", "putStream", new { storageAccount.Credentials.AccountName, containerName, httpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds });
            return httpStatusCode;
        }

        public async Task<FileStoreOperation> PutStreamAsync(string containerName, string key, Stream stream, string mimeType, bool isPublicContainer = false, string eTag = null, DateTimeOffset? lastModified = null)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var storageOperation = new FileStoreOperation();
            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
            try
            {
                var blobReference = await GetBlobReferenceAsync(storageAccount, containerName, key, isPublicContainer ? BlobContainerPublicAccessType.Blob : BlobContainerPublicAccessType.Off).ConfigureAwait(false);
                var condition = BuildCondition(eTag, lastModified);
                _blobRequestOptions = new BlobRequestOptions();
                
                await blobReference.DeleteIfExistsAsync().ConfigureAwait(false);
                await blobReference.UploadFromStreamAsync(stream, condition, _blobRequestOptions, null).ConfigureAwait(false);
                blobReference.Properties.ContentType = mimeType;
                blobReference.Properties.CacheControl = "public, max-age=31536000";
                await blobReference.SetPropertiesAsync().ConfigureAwait(false);
                storageOperation.LastModified = blobReference.Properties.LastModified;
                storageOperation.Etag = blobReference.Properties.ETag;
                storageOperation.Uri = blobReference.Uri;
                storageOperation.HttpStatusCode = (int)HttpStatusCode.OK;
            }
            catch (StorageException ex)
            {
                storageOperation.HttpStatusCode = ParseException(containerName, key, eTag, lastModified, ex);
            }
            stopwatch.Stop();
            _logger.Info("PutStream complete", "putStream", new { storageAccount.Credentials.AccountName, containerName, key, storageOperation.HttpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds });
            return storageOperation;
        }


        private async Task<CloudBlockBlob> GetBlobReferenceAsync(CloudStorageAccount storageAccount, string containerName, string key, BlobContainerPublicAccessType? publicAccessType = null)
        {
            var blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(containerName);
            
            await blobContainer.CreateIfNotExistsAsync().ConfigureAwait(false);

            if (publicAccessType.HasValue)
            {
                var permissions = await blobContainer.GetPermissionsAsync().ConfigureAwait(false);
                if (permissions.PublicAccess != publicAccessType.Value)
                {
                    var perms = new BlobContainerPermissions { PublicAccess = publicAccessType.Value };
                    await blobContainer.SetPermissionsAsync(perms).ConfigureAwait(false);
                }
            }

            var blobReference = blobContainer.GetBlockBlobReference(key);

            return blobReference;
        }


        public async Task<Tuple<HttpStatusCode, PortalMedia>> PutInBlocksAsync(FileChunkMetadata fileChunk, string containerName, CancellationToken stoppingToken)
        {
            try
            {
                return await PutDataInBlocks(fileChunk, containerName, stoppingToken).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                return Tuple.Create(HttpStatusCode.InternalServerError, default(PortalMedia));
            }
        }

        private async Task<Tuple<HttpStatusCode, PortalMedia>> PutDataInBlocks(FileChunkMetadata fileChunk, string containerName, CancellationToken stoppingToken)
        {

            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
            var servicePoint = ServicePointManager.FindServicePoint(storageAccount.BlobEndpoint);
            servicePoint.UseNagleAlgorithm = false;
            servicePoint.Expect100Continue = false;
            servicePoint.ConnectionLimit = 128;
            var blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(containerName);
            blobContainer.CreateIfNotExists();

            var fileIdentifier = fileChunk.ResumableIdentifier;

            CloudBlockBlob blob = await GetBlobReferenceAsync(storageAccount, containerName, fileIdentifier).ConfigureAwait(false);
            PortalMedia media = new PortalMedia();
            try
            {
                var blockId = Convert.ToBase64String(BitConverter.GetBytes(fileChunk.ResumableChunkNumber));
                media.TotalChunks = fileChunk.ResumableTotalChunks;
                media.BlockId = blockId;
                media.FileIdentifier = fileIdentifier;
                media.ChunkNumber = fileChunk.ResumableChunkNumber;

                try
                {
                    await blob.PutBlockAsync(blockId, new MemoryStream(fileChunk.FileContent, true), null, stoppingToken).ConfigureAwait(false);
                    media.Status = PortalMediaStatus.Complete;

                }
                catch (Exception exx)
                {
                    media.Status = PortalMediaStatus.Failed;
                    _logger.Warn("PutDataInBlocks storageException exception", "warn", exx.ToString());
                }

                return Tuple.Create(HttpStatusCode.NoContent, media);
            }
            catch (StorageException ex)
            {
                _logger.Warn("PutDataInBlocks storage exception", "warn", ex.ToString());
                return Tuple.Create(HttpStatusCode.InternalServerError, default(PortalMedia));
            }
            catch (Exception e)
            {
                _logger.Warn("PutDataInBlocks exception", "warn", e.ToString());
                return Tuple.Create(HttpStatusCode.InternalServerError, default(PortalMedia));
            }
        }

        public async Task<string> CommitBlocks(IEnumerable<string> blockIds, string containerName, string key, CancellationToken stoppingToken, bool isPublicContainer = false, MediaPlatform mediaPlatform = MediaPlatform.AMS)
        {
            try
            {
                var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
                var blobClient = storageAccount.CreateCloudBlobClient();
                var blobContainer = blobClient.GetContainerReference(containerName);
                blobContainer.CreateIfNotExists();
                var blob = await GetBlobReferenceAsync(storageAccount, containerName, key, isPublicContainer ? BlobContainerPublicAccessType.Blob : BlobContainerPublicAccessType.Off).ConfigureAwait(false);
                if (blockIds != null && blockIds.Count() > 0)
                {
                    string contentType = String.Empty;
                    switch (containerName)
                    {
                        case "images":
                            contentType = "image/jpeg";
                            break;
                        case "portal-raw-videos":
                        case "portal-raw-trailervideos":
                            contentType = "video/mp4";
                            break;
                        default:
                            break;
                    }
                    await blob.PutBlockListAsync(blockIds, new AccessCondition(), new BlobRequestOptions(),
                        new OperationContext { UserHeaders = new Dictionary<string, string> { { "x-ms-blob-content-type", contentType } } },
                        stoppingToken).ConfigureAwait(false);
                    
                    var sharedAccessSignature = blob.GetSharedAccessSignature(new SharedAccessBlobPolicy
                    {
                        SharedAccessExpiryTime = (mediaPlatform == MediaPlatform.JWPlayer) ? DateTimeOffset.UtcNow.AddDays(2) : DateTimeOffset.UtcNow.AddYears(100),
                        Permissions = SharedAccessBlobPermissions.Read,
                        SharedAccessStartTime = DateTimeOffset.UtcNow
                    });
                    return string.Format("{0}{1}",blob.Uri.AbsoluteUri, sharedAccessSignature);
                }
                return string.Empty;
            }
            catch(StorageException se)
            {
                _logger.Warn("CommitBlocks storage exception", "warn", se.ToString());
                throw se;
            }
            catch (Exception e)
            {
                _logger.Warn("CommitBlocks exception", "warn", e.ToString());
                throw e;
            }
        }
    }
}
