﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore
{
    public interface IFileStoreRepo
    {
        Task<FileStoreOperation> GetStreamAsync(Stream stream, string containerName, string key, string eTag = null, DateTimeOffset? lastModified = null);
        Task<HttpResponseMessage> GetStreamAsync(HttpRequestMessage request, string containerName, string key);


        Task<HttpStatusCode> DeleteAsync(string containerName, string key, CancellationToken cancellationToken = default(CancellationToken));
        Task<FileStoreOperation> PutStreamAsync(string containerName, string key, Stream stream, string mimeType, bool isPublicContainer = false, string eTag = null, DateTimeOffset? lastModified = null);

        Task<Tuple<HttpStatusCode, PortalMedia>> PutInBlocksAsync(FileChunkMetadata fileChunk, string containerName, CancellationToken stoppingToken);

        Task<string> CommitBlocks(IEnumerable<string> blockIds, string containerName, string key, CancellationToken stoppingToken, bool isPublicContainer = false, MediaPlatform mediaPlatform = MediaPlatform.AMS);
    }
}
