﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore
{
    public class FileStoreOperation
    {
        public string Etag { get; set; }
        public DateTimeOffset? LastModified { get; set; }
        public Uri Uri { get; set; }
        public int HttpStatusCode { get; set; }
        public string MimeType { get; set; }
    }
}
