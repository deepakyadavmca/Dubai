﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.ReadStore;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo
{
    public interface IBlobRepo
    {
        Task<ReadStoreQueryOperation<T>> GetAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        Task<ReadStoreQueryOperation<EntitySet<T>>> GetSetAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        Task<ReadStoreQueryOperation<EntitySet<T>>> GetDataAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;

        List<string> ListBlobsFromContainer(string key);

        Task<ReadStoreWriteOperation<T>> PutAsync<T>(string key, T entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class;
        Task<ReadStoreWriteOperation<EntitySet<T>>> PutSetAsync<T>(string key, EntitySet<T> entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class;
        Task<HttpStatusCode> DeleteSetAsync<T>(string key) where T : class;
        Task<HttpStatusCode> DeleteAsync<T>(string key) where T : class;

        event EventHandler<EntityUpdatedEventArgs> UpdateComplete;

        Task<ReadStoreWriteOperation<EntitySet<T>>> PutDataAsync<T>(string key, EntitySet<T> entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class;
    }
}
