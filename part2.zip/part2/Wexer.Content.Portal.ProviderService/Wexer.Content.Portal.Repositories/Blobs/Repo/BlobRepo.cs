﻿using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.EntityTransforms;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo
{
    public class BlobRepo : IBlobRepo
    {
        private const int MaxAllowedSnapshots = 5;
        private readonly string _storageConnectionString;
        private readonly IModelTransformService _modelTransformService;
        private static BlobRequestOptions _blobRequestOptions;
        private readonly ILogger _logger;

        public event EventHandler<EntityUpdatedEventArgs> UpdateComplete;

        public BlobRepo(string storageConnectionString, ILoggerFactory loggerFactory, IModelTransformService modelTransformService)
        {
            _storageConnectionString = storageConnectionString;
            _logger = loggerFactory.GetLoggerForClass(this);
            _modelTransformService = modelTransformService;

            ServicePointManager.DefaultConnectionLimit = 100;
            ServicePointManager.UseNagleAlgorithm = false;
            ServicePointManager.Expect100Continue = false;
        }

        public async Task<ReadStoreWriteOperation<T>> PutAsync<T>(string key, T entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class
        {
            var operation = new ReadStoreWriteOperation<T>();
            try
            {
                var containerName = typeof(T).Name.ToLowerInvariant();
                operation = await PutEntityAsync(key, entity, eTag, lastModified, containerName).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }

        public async Task<ReadStoreWriteOperation<EntitySet<T>>> PutSetAsync<T>(string key, EntitySet<T> entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class
        {
            var operation = new ReadStoreWriteOperation<EntitySet<T>>();
            try
            {
                var containerName = string.Format("{0}-set", typeof(T).Name.ToLowerInvariant());
                operation = await PutEntityAsync(key, entity, eTag, lastModified, containerName, createSnapshot: createSnapshot).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }
        public async Task<ReadStoreWriteOperation<EntitySet<T>>> PutDataAsync<T>(string key, EntitySet<T> entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class
        {
            var operation = new ReadStoreWriteOperation<EntitySet<T>>();
            try
            {
                var containerName = typeof(T).Name.ToLowerInvariant();
                operation = await PutEntityAsync(key, entity, eTag, lastModified, containerName, createSnapshot: createSnapshot).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }
        public async Task<HttpStatusCode> DeleteSetAsync<T>(string key) where T : class
        {
            var operation = HttpStatusCode.OK;
            try
            {
                var containerName = typeof(T).Name.ToLowerInvariant();
                operation = await DeleteEntityAsync<T>(key, containerName).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }

        public async Task<HttpStatusCode> DeleteAsync<T>(string key) where T : class
        {
            var operation = HttpStatusCode.OK;
            try
            {
                var containerName = string.Format("{0}-set", typeof(T).Name.ToLowerInvariant());
                operation = await DeleteEntityAsync<T>(key, containerName).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }

        private async Task<HttpStatusCode> DeleteEntityAsync<T>(string key, string containerName, CancellationToken cancellationToken = default(CancellationToken)) where T : class
        {
            var httpStatusCode = HttpStatusCode.OK;
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
            var servicePoint = ServicePointManager.FindServicePoint(storageAccount.BlobEndpoint);
            servicePoint.UseNagleAlgorithm = false;
            servicePoint.Expect100Continue = false;
            servicePoint.ConnectionLimit = 128;
            try
            {
                var blobReference = GetBlobReference<T>(storageAccount, key, containerName);

                await blobReference.DeleteIfExistsAsync(cancellationToken).ConfigureAwait(false);

                RaiseUpdateComplete(key, ReadStoreOperationVerbs.Delete);
            }
            catch (StorageException ex)
            {
                httpStatusCode = (HttpStatusCode)ParseException(containerName, key, null, null, ex);
            }

            stopwatch.Stop();
            _logger.Debug("Delete complete", "delete", new { storageAccount.Credentials.AccountName, containerName, httpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds });

            return httpStatusCode;
        }

        private async Task<ReadStoreWriteOperation<T>> PutEntityAsync<T>(string key, T entity, string eTag, DateTimeOffset? lastModified, string containerName, CancellationToken cancellationToken = default(CancellationToken), bool createSnapshot = false) where T : class
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
            var servicePoint = ServicePointManager.FindServicePoint(storageAccount.BlobEndpoint);
            servicePoint.UseNagleAlgorithm = false;
            servicePoint.Expect100Continue = false;
            servicePoint.ConnectionLimit = 128;
            var storageOperation = new ReadStoreWriteOperation<T>();
            try
            {
                storageOperation.Entity = entity;
                var blobReference = GetBlobReference<T>(storageAccount, key, containerName);

                if (createSnapshot)
                {
                    // Create a blob snapshot before modifying the blob
                    await CreateSnapshot<T>(cancellationToken, blobReference);
                }

                var condition = BuildCondition(eTag, lastModified);
                _blobRequestOptions = new BlobRequestOptions();

                using (var ms = new MemoryStream())
                {
                    Serializer.Serialize(ms, storageOperation.Entity);
                    ms.Seek(0L, SeekOrigin.Begin);
                    await blobReference.UploadFromStreamAsync(ms, condition, _blobRequestOptions, null, cancellationToken).ConfigureAwait(false);
                }
                storageOperation.LastModified = blobReference.Properties.LastModified;
                storageOperation.Etag = blobReference.Properties.ETag;
                storageOperation.HttpStatusCode = (int)HttpStatusCode.OK;

                RaiseUpdateComplete(key, ReadStoreOperationVerbs.Put, container: blobReference.Container.Name);
            }
            catch (StorageException ex)
            {
                storageOperation.HttpStatusCode = ParseException(containerName, key, eTag, lastModified, ex);
            }
            catch(Exception e)
            {
                throw e;
            }
            stopwatch.Stop();
            _logger.Debug("Put complete", "put", new { storageAccount.Credentials.AccountName, containerName, storageOperation.HttpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds });
            return storageOperation;
        }

        private static CloudBlockBlob GetBlobReference<T>(CloudStorageAccount storageAccount, string key, string containerName) where T : class
        {
            CloudBlockBlob blobReference = null;
            try
            {
                var blobClient = storageAccount.CreateCloudBlobClient();
                var blobContainer = blobClient.GetContainerReference(containerName);
                blobContainer.CreateIfNotExists();
                blobReference = blobContainer.GetBlockBlobReference(key);
            }
            catch
            {
            }
            return blobReference;
        }

        private int ParseException(string containerName, string key, string eTag, DateTimeOffset? lastModified, StorageException ex)
        {
            switch (ex.RequestInformation.HttpStatusCode)
            {
                case (int)HttpStatusCode.NotModified:
                    _logger.Trace("{0}:{1} returned not modified based on etag={2}, lastmodified={3}", containerName,
                                           key, eTag, lastModified);
                    break;
                case (int)HttpStatusCode.NotFound:
                    _logger.Warn("{0}:{1} returned not found", containerName, key);
                    break;
                default:
                    _logger.Error("{0}:{1} returned {2} - {3}", containerName, key, ex.RequestInformation.HttpStatusCode,
                                     ex.Message);
                    break;
            }

            return ex.RequestInformation.HttpStatusCode;
        }

        private static AccessCondition BuildCondition(string eTag, DateTimeOffset? lastModified)
        {
            var condition = AccessCondition.GenerateEmptyCondition();
            if (!string.IsNullOrWhiteSpace(eTag))
            {
                condition.IfMatchETag = eTag;
            }
            if (lastModified != null)
            {
                condition.IfNotModifiedSinceTime = lastModified;
            }

            return condition;
        }

        private void RaiseUpdateComplete(string key, ReadStoreOperationVerbs operation, string container = null)
        {
            if (UpdateComplete != null)
            {
                UpdateComplete(this, new EntityUpdatedEventArgs(key, operation, container));
            }
        }

        private static async Task CreateSnapshot<T>(CancellationToken cancellationToken, CloudBlockBlob blobReference) where T : class
        {
            try
            {
                if (blobReference == null)
                {
                    return;
                }

                await blobReference.CreateSnapshotAsync(cancellationToken);
                RemoveOlderSnapshots<T>(blobReference);
            }
            catch
            {
            }
        }

        private static void RemoveOlderSnapshots<T>(CloudBlockBlob blobReference) where T : class
        {
            CloudBlobContainer container = blobReference.Container;

            // get all snapshots for the current blob
            CloudBlockBlob[] snapshots = container.ListBlobs(null, true, BlobListingDetails.Snapshots)
                .Cast<CloudBlockBlob>()
                .Where(s => s.Name == blobReference.Name)
                .OrderBy(s => s.SnapshotTime).ToArray();

            // if there are more snapshots than the maximum allowed we need to clear them down
            int numberOfSnapshotsToDelete = Math.Max(0, snapshots.Length - MaxAllowedSnapshots);
            var earliestSnapShots = snapshots.Where(s => s.IsSnapshot).Take(numberOfSnapshotsToDelete).ToArray();

            foreach (CloudBlockBlob currentSnapShot in earliestSnapShots)
            {
                DateTimeOffset? snapshotTime = currentSnapShot != null ? currentSnapShot.SnapshotTime : null;

                CloudBlockBlob snapshot = container.GetBlockBlobReference(blobReference.Name, snapshotTime);

                //delete individual snapshot
                snapshot.Delete();
            }
        }









        public async Task<ReadStoreQueryOperation<T>> GetAsync<T>(string key = "*", string eTag = null, DateTimeOffset? lastModified = null) where T : class
        {
            var operation = new ReadStoreQueryOperation<T>();
            try
            {
                var containerName = typeof(T).Name.ToLowerInvariant();
                operation = await GetEntityAsync<T>(key, eTag, lastModified, containerName).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }

        public async Task<ReadStoreQueryOperation<EntitySet<T>>> GetSetAsync<T>(string key = "*", string eTag = null, DateTimeOffset? lastModified = null) where T : class
        {
            var operation = new ReadStoreQueryOperation<EntitySet<T>>();
            try
            {
                var containerName = string.Format("{0}-set", typeof(T).Name.ToLowerInvariant());
                operation = await GetEntityAsync<EntitySet<T>>(key, eTag, lastModified, containerName).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }
        public async Task<ReadStoreQueryOperation<EntitySet<T>>> GetDataAsync<T>(string key = "*", string eTag = null, DateTimeOffset? lastModified = null) where T : class
        {
            var operation = new ReadStoreQueryOperation<EntitySet<T>>();
            try
            {
                var containerName = typeof(T).Name.ToLowerInvariant();
                operation = await GetEntityAsync<EntitySet<T>>(key, eTag, lastModified, containerName).ConfigureAwait(false);
            }
            catch
            {
            }
            return operation;
        }
        private async Task<ReadStoreQueryOperation<T>> GetEntityAsync<T>(string key, string eTag, DateTimeOffset? lastModified, string containerName) where T : class
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);

            var storageOperation = new ReadStoreQueryOperation<T>();
            try
            {
                var blobClient = storageAccount.CreateCloudBlobClient();
                var blobContainer = blobClient.GetContainerReference(containerName);
                var blobcreationResponse = blobContainer.CreateIfNotExists();
                var blobReference = blobContainer.GetBlockBlobReference(key);
                var condition = BuildCondition(eTag, lastModified);
                _blobRequestOptions = new BlobRequestOptions();

                using (var ms = new MemoryStream())
                {
                    await blobReference.DownloadToStreamAsync(ms, condition, _blobRequestOptions, null).ConfigureAwait(false);
                    ms.Seek(0L, SeekOrigin.Begin);
                    storageOperation.Entity = Serializer.Deserialize<T>(ms);
                }

                storageOperation.Entity = _modelTransformService.ApplyEntityTransforms(storageOperation.Entity);
                storageOperation.LastModified = blobReference.Properties.LastModified;
                storageOperation.Etag = blobReference.Properties.ETag;
                storageOperation.HttpStatusCode = (int)HttpStatusCode.OK;
            }
            catch (StorageException ex)
            {
                storageOperation.HttpStatusCode = ParseException(containerName, key, eTag, lastModified, ex);
            }
            catch(Exception e)
            {
                storageOperation.HttpStatusCode = (int)HttpStatusCode.InternalServerError;
            }
            stopwatch.Stop();
            _logger.Debug("Query complete", "query", new { storageAccount.Credentials.AccountName, containerName, storageOperation.HttpStatusCode, timeTakenMs = stopwatch.ElapsedMilliseconds });

            return storageOperation;
        }


        public List<string> ListBlobsFromContainer(string key)
        {
            var containerName = key.ToLowerInvariant();
            List<string> blobs = new List<string>();

            var storageAccount = CloudStorageAccount.Parse(_storageConnectionString);
            var blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(containerName);

            foreach (var blob in blobContainer.ListBlobs(null, true, BlobListingDetails.None, null, null))
            {
                blobs.Add(((CloudBlockBlob)(blob)).Name);
            }
            return blobs;
        }
    }
}

