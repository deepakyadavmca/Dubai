﻿using System;
using System.Collections.Generic;
using System.Text;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Repositories.EntityTransforms;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo
{
    public class UserBlobRepo: BlobRepo, IUserBlobRepo
    {
        public UserBlobRepo(string storageConnectionString, ILoggerFactory loggerFactory, IModelTransformService modelTransformService)
            : base(storageConnectionString, loggerFactory, modelTransformService)
        {
        }
    }
}
