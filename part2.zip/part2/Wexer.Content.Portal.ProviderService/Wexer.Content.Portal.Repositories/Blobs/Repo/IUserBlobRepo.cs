﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wexer.Content.Portal.Repositories.Blobs.Repo
{
    public interface IUserBlobRepo : IBlobRepo
    {
    }
}
