using System;

namespace Wexer.Content.Portal.ReadStore
{
    public interface IQueryOperation
    {
       string Etag { get; set; }
       DateTimeOffset? LastModified { get; set; }
       int HttpStatusCode { get; set; }
    }
}