using System;

namespace Wexer.Content.Portal.ReadStore
{
    public class ReadStoreWriteOperation<T> where T : class
    {
        public string Key { get; set; }
        public string Etag { get; set; }
        public DateTimeOffset? LastModified { get; set; }
        public T Entity { get; set; }
        public int HttpStatusCode { get; set; }
    }
}