using System.Collections.Generic;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;

namespace Wexer.Content.Portal.ReadStore
{
    public interface IReadStoreListWriteProvider
    {
        Task<TableReadStoreListWriteOperation<T>> StoreAsync<T>(T entity) where T : class, IStorageKey, new();
        Task StoreBatchAsync<T>(IEnumerable<T> entities) where T : class, IStorageKey, new();
        Task<TableReadStoreListWriteOperation<T>> DeleteAsync<T>(string partitionKey, string rowKey) where T : class, IStorageKey, new();
        Task DropTableAsync<T>() where T : class, IStorageKey, new();

        void CreateTableIfNotExists<T>(T entity) where T : class, new();
    }
}