namespace Wexer.Content.Portal.ReadStore
{
    public class TableReadStoreListWriteOperation<T> where T : class
    {
        public string Etag { get; set; }
        public T Entity { get; set; }
        public int HttpStatusCode { get; set; }

        public bool IsSuccessStatusCode
        {
            get { return HttpStatusCode >= 200 && HttpStatusCode <= 299; }
        }
    }
}