using System;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;
using System.Collections.Generic;
using Wexer.Content.Portal.ReadStore;

namespace Wexer.Content.Portal.ReadStore
{
    public interface IReadStoreQueryProvider
    {
        Task<ReadStoreQueryOperation<T>> GetAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        Task<ReadStoreQueryOperation<EntitySet<T>>> GetSetAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;
        Task<ReadStoreQueryOperation<EntitySet<T>>> GetDataAsync<T>(string key, string eTag = null, DateTimeOffset? lastModified = null) where T : class;

        List<string> ListBlobsFromContainer(string key);
    }
}