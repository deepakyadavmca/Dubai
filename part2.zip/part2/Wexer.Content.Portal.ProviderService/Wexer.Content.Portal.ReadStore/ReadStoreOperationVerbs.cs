﻿using ProtoBuf;

namespace Wexer.Content.Portal.ReadStore
{
    [ProtoContract]
    public enum ReadStoreOperationVerbs : byte
    {
        [ProtoEnum(Name = "Post")]
        Post = 1,
        [ProtoEnum(Name = "Put")]
        Put = 2,
        [ProtoEnum(Name = "Delete")]
        Delete = 3,
    }
}