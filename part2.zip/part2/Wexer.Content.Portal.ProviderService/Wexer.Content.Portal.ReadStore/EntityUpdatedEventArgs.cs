﻿using System;

namespace Wexer.Content.Portal.ReadStore
{
    public class EntityUpdatedEventArgs : EventArgs
    {
        public EntityUpdatedEventArgs(string key, ReadStoreOperationVerbs verb, string container)
        {
            _key = key;
            _verb = verb;
            _container = container;
        }
        
        private readonly string _key;
        private readonly string _container;
        private readonly ReadStoreOperationVerbs _verb;

        public string Key
        {
            get { return _key; }
        }

        public string Container
        {
            get { return _container; }
        }

        public ReadStoreOperationVerbs Verb
        {
            get { return _verb; }
        }
    }
}
