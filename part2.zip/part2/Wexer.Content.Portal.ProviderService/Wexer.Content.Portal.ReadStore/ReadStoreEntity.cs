﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Wexer.Content.Portal.ReadStore
{
    [ProtoContract]
    public class ReadStoreEntity : IReadStoreEntity
    {
        private const int MaxByteCapacity = (960 * 1024 * 3) / 4;

        public ReadStoreEntity()
        {
        }

        public ReadStoreEntity(string partitionKey, string rowKey, string entityPayload,bool isFatEntity=false)
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
            EntityPayload = entityPayload;
            IsFatEntity = isFatEntity;
        }

        public ReadStoreEntity(string partitionKey, string rowKey, bool isFatEntity=true)
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
            IsFatEntity = isFatEntity;
        }

        [ProtoMember(1)]
        public string PartitionKey { get; set; }

        [ProtoMember(2)]
        public string RowKey { get; set; }

        [ProtoMember(3)]
        public string EntityPayload { get; set; }

        [ProtoMember(4)]
        public bool IsFatEntity { get; set; }

        [ProtoMember(5)]
        public byte[] P0 { get; set; }

        [ProtoMember(6)]
        public byte[] P1 { get; set; }

        [ProtoMember(7)]
        public byte[] P2 { get; set; }

        [ProtoMember(8)]
        public byte[] P3 { get; set; }

        [ProtoMember(9)]
        public byte[] P4 { get; set; }

        [ProtoMember(10)]
        public byte[] P5 { get; set; }

        [ProtoMember(11)]
        public byte[] P6 { get; set; }

        [ProtoMember(12)]
        public byte[] P7 { get; set; }

        [ProtoMember(13)]
        public byte[] P8 { get; set; }

        [ProtoMember(14)]
        public byte[] P9 { get; set; }

        [ProtoMember(15)]
        public byte[] P10 { get; set; }

        [ProtoMember(16)]
        public byte[] P11 { get; set; }

        [ProtoMember(17)]
        public byte[] P12 { get; set; }

        [ProtoMember(18)]
        public byte[] P13 { get; set; }

        [ProtoMember(19)]
        public byte[] P14 { get; set; }

        /// <summary>Split the stream as a fat entity.</summary>
        public void SetFatEntityData(byte[] data)
        {
            if (null == data) throw new ArgumentNullException("data");
            if (data.Length >= MaxByteCapacity) throw new ArgumentOutOfRangeException("data");

            var setters = new Action<byte[]>[]
                    {
                        b => P0 = b,
                        b => P1 = b,
                        b => P2 = b,
                        b => P3 = b,
                        b => P4 = b,
                        b => P5 = b,
                        b => P6 = b,
                        b => P7 = b,
                        b => P8 = b,
                        b => P9 = b,
                        b => P10 = b,
                        b => P11 = b,
                        b => P12 = b,
                        b => P13 = b,
                        b => P14 = b,
                    };

            for (int i = 0; i < 15; i++)
            {
                if (i * 64 * 1024 < data.Length)
                {
                    var start = i * 64 * 1024;
                    var length = Math.Min(64 * 1024, data.Length - start);
                    var buffer = new byte[length];

                    Buffer.BlockCopy(data, start, buffer, 0, buffer.Length);
                    setters[i](buffer);
                }
                else
                {
                    setters[i](null); // discarding potential leftover
                }
            }
        }


        /// <summary>Returns the concatenated stream contained in the fat entity.</summary>
        public byte[] GetFatEntityData()
        {
            var arrays = GetProperties().ToArray();
            var buffer = new byte[arrays.Sum(a => a.Length)];

            var i = 0;
            foreach (var array in arrays)
            {
                Buffer.BlockCopy(array, 0, buffer, i, array.Length);
                i += array.Length;
            }

            return buffer;
        }


        IEnumerable<byte[]> GetProperties()
        {
            if (null != P0) yield return P0;
            if (null != P1) yield return P1;
            if (null != P2) yield return P2;
            if (null != P3) yield return P3;
            if (null != P4) yield return P4;
            if (null != P5) yield return P5;
            if (null != P6) yield return P6;
            if (null != P7) yield return P7;
            if (null != P8) yield return P8;
            if (null != P9) yield return P9;
            if (null != P10) yield return P10;
            if (null != P11) yield return P11;
            if (null != P12) yield return P12;
            if (null != P13) yield return P13;
            if (null != P14) yield return P14;
        }
    }
}
