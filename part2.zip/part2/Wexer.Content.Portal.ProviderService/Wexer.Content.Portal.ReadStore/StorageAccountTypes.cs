﻿namespace Wexer.Content.Portal.ReadStore
{
    public enum StorageAccountTypes
    {
        Primary,
        Secondary
    }
}