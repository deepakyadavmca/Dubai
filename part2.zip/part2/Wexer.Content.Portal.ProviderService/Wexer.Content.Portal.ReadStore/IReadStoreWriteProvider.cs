using System;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.ReadStore;

namespace Wexer.Content.Portal.ReadStore
{
    public interface IReadStoreWriteProvider
    {
        Task<ReadStoreWriteOperation<T>> PutAsync<T>(string key, T entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class;
        Task<ReadStoreWriteOperation<EntitySet<T>>> PutSetAsync<T>(string key, EntitySet<T> entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class;
        Task<HttpStatusCode> DeleteSetAsync<T>(string key) where T : class;
        Task<HttpStatusCode> DeleteAsync<T>(string key) where T : class;
        event EventHandler<EntityUpdatedEventArgs> UpdateComplete; 

        //DMI 
        Task<ReadStoreWriteOperation<EntitySet<T>>> PutDataAsync<T>(string key, EntitySet<T> entity, string eTag = null, DateTimeOffset? lastModified = null, bool createSnapshot = false) where T : class;
    }
}