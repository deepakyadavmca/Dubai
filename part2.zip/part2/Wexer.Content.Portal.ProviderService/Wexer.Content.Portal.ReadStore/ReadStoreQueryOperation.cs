using System;

namespace Wexer.Content.Portal.ReadStore
{
    public class ReadStoreQueryOperation<T> : IQueryOperation where T : class
    {
        public string Etag { get; set; }
        public DateTimeOffset? LastModified { get; set; }
        public T Entity { get; set; }
        public int HttpStatusCode { get; set; }

        public bool IsSuccessStatusCode
        {
            get { return HttpStatusCode >= 200 && HttpStatusCode <= 299; }
        }
    }
}