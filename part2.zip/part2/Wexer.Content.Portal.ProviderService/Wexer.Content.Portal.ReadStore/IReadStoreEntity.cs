﻿using Wexer.Content.Portal.Models;

namespace Wexer.Content.Portal.ReadStore
{
    public interface IReadStoreEntity : IStorageKey
    {
        string EntityPayload { get; set; }
    }
}