using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;

namespace Wexer.Content.Portal.ReadStore
{
    public interface IReadStoreListQueryProvider
    {
        Task<T> GetAsync<T>(string partitionKey, string rowKey) where T : class, IStorageKey, new();
        IEnumerable<T> GetList<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<IEnumerable<T>> GetListAsync<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<IEnumerable<T>> GetListAsync<T>() where T : class, IStorageKey, new(); 
        Task<IEnumerable<PureEntity<T>>> GetPureListAsync<T>() where T : class, IStorageKey, new();
        IQueryable<T> Query<T>(string partitionKey) where T : class, IStorageKey, new();
        Task<IQueryable<T>> QueryAsync<T>(string partitionKey) where T : class, IStorageKey, new();
    }

    public class PureEntity<T>
    {
        public DateTimeOffset TimeStamp { get; set; }
        public T Entity { get; set; }
    }
}