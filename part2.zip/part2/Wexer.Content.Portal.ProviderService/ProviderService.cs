﻿using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.UserService;
using Wexer.Content.Portal.Clients;
using FirebaseAdmin.Auth;
using Wexer.Content.Portal.UserService.SignupService;

namespace Wexer.Content.Portal.ProviderService
{
    public class ProviderService : IProviderService
    {
        private readonly IBlobRepo _blobRepo;
        private readonly IUserService _userService;
        private readonly IUserBlobRepo _userBlob;
        private readonly ILogger _logger;
        private readonly IFirebaseClient _firebaseClient;
        private readonly IUserSignupService _userSignupService;
        private const string TenantId = "wexer";
        public ProviderService(IBlobRepo blobRepo, ILoggerFactory loggerFactory, IUserService userService, IUserBlobRepo userBlob,
            IFirebaseClient firebaseClient, IUserSignupService userSignupService)
        {
            _blobRepo = blobRepo;
            _userService = userService;
            _userBlob = userBlob;
            _firebaseClient = firebaseClient;
            _userSignupService = userSignupService;
            _logger = loggerFactory.GetLoggerForClass(this);
        }

        public async Task<HttpStatusCode> Delete(string tag)
        {
            try
            {
                var entities = await List().ConfigureAwait(false);

                if (entities != null && entities.Length > 0 && entities.Any(t => t.Tag == tag))
                {
                    var entryToRemove = entities.FirstOrDefault(t => t.Tag == tag);
                    var portalUserIndex = await _userService.CheckUserEmailIndexTenantIdAsync(entryToRemove.Tag, TenantId).ConfigureAwait(false);
                    if (portalUserIndex != null)
                    {
                       
                        await Task.WhenAll(_userService.DeleteTenantUserEmailIndex(entryToRemove.Tag, TenantId)).ConfigureAwait(false);
                        
                        entities = entities.Where(t => t.Tag != entryToRemove.Tag).ToArray();

                        var result = await SaveMultiple(entities).ConfigureAwait(false);
                        if (result)
                        {
                            return HttpStatusCode.OK;
                        }
                        
                        return HttpStatusCode.InternalServerError;
                    }
                }
                return HttpStatusCode.NotFound;
            }
            catch (Exception e)
            {
                return HttpStatusCode.InternalServerError;
            }
        }

        public async Task<Provider> Get(string uId)
        {
            try
            {
                var entities = await _blobRepo.GetSetAsync<Provider>("*").ConfigureAwait(false);
                if (entities != null && entities.Entity != null && entities.Entity.Count > 0)
                {
                    return entities.Entity.Items.FirstOrDefault(t => t.Tag == uId);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Provider[]> List()
        {
            try
            {
                var entities = await _blobRepo.GetSetAsync<Provider>("*").ConfigureAwait(false);
                if (entities != null && entities.Entity != null && entities.Entity.Count > 0)
                {
                    return entities.Entity.Items;
                }
                return null;
            }
            catch
            {
                return null;
            }

        }

        public async Task<ReadStoreWriteOperation<EntitySet<Provider>>> Save(Provider entity)
        {
            ReadStoreWriteOperation<EntitySet<Provider>> result = null;
            try
            {
                var entities = await _blobRepo.GetSetAsync<Provider>("*").ConfigureAwait(false);
                if (entities != null && entities.Entity != null && entities.Entity.Count > 0)
                {

                    var newEntities = entities.Entity.Items.Append(entity).ToArray();
                    result = await _blobRepo.PutSetAsync("*", new EntitySet<Provider>
                    {
                        Count = newEntities.Length,
                        Items = newEntities
                    });
                }
                else
                {
                    result = await _blobRepo.PutSetAsync("*", new EntitySet<Provider>
                    {
                        Count = 1,
                        Items = new Provider[] { entity }
                    });
                }
            }
            catch
            {
                return null;
            }
            return result;
        }

        public async Task<bool> SaveMultiple(Provider[] entities)
        {
            ReadStoreWriteOperation<EntitySet<Provider>> result = null;
            try
            {
                result = await _blobRepo.PutSetAsync("*", new EntitySet<Provider>
                {
                    Count = entities.Length,
                    Items = entities
                });
                if (result != null && result.HttpStatusCode == 200)
                {
                    return true;
                }

                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public async Task<Provider> Update(Provider providerRequest)
        {
            try
            {
                var providerList = await List().ConfigureAwait(false);
                if(providerList != null && providerList.Length > 0)
                {
                    var existingProvider = providerList.FirstOrDefault(t => t.Tag == providerRequest.Tag);
                    if(existingProvider != null)
                    {
                        existingProvider.Contact = providerRequest.Contact;
                        existingProvider.Name = providerRequest.Name;
                        existingProvider.PhoneNumber = providerRequest.PhoneNumber;
                        existingProvider.Email = providerRequest.Email;
                        existingProvider.ProviderId = providerRequest.ProviderId;
                        existingProvider.Tag = providerRequest.Tag;
                        existingProvider.Stage1Encode = providerRequest.Stage1Encode;
                        existingProvider.MediaPlatform = providerRequest.MediaPlatform;
                        existingProvider.JWPlayerSiteId = providerRequest.JWPlayerSiteId;
                        if (await SaveMultiple(providerList).ConfigureAwait(false))
                        {
                            return providerRequest;
                        }
                    }
                }

                return null;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task<Tuple<HttpStatusCode, Provider>> Create(PortalUser user)
        {
            try
            {
                if(user != null)
                {
                    var fireBaseUserCheckTask = await _firebaseClient.GetUserByEmail<UserInfo>(user.Email).ConfigureAwait(false);
                    if (fireBaseUserCheckTask != null)
                    {
                        return Tuple.Create(HttpStatusCode.Conflict, default(Provider));
                    }

                    UserRecordArgs userRecordArgs = new UserRecordArgs();
                    userRecordArgs.DisplayName = user.DisplayName;
                    userRecordArgs.Email = user.Email;
                    userRecordArgs.Password = user.Password;
                    userRecordArgs.PhotoUrl = user.PhotoUrl;
                    userRecordArgs.PhoneNumber = user.PhoneNumber;
                    userRecordArgs.Uid = user.UId;
                    var fireBaseUserCreationResponse = await _firebaseClient.CreateUserAsync<UserInfo>(userRecordArgs, user.UserRole).ConfigureAwait(false);

                    if(fireBaseUserCreationResponse != null)
                    {
                        string userId = string.Empty;

                        var claimsResponse = await _firebaseClient.SetClaims(fireBaseUserCreationResponse.UId,
                                                new Dictionary<string, object>() { { "role", Convert.ToInt32(user.UserRole) } }).ConfigureAwait(false);

                        if (claimsResponse)
                        {
                            user.UId = fireBaseUserCreationResponse.UId;
                            userId = await _userSignupService.CreatePortalUserIndexAsync(user, TenantId).ConfigureAwait(false);
                        }

                        if (!string.IsNullOrEmpty(userId))
                        {
                            Models.ContentPortal.Provider provider = new Models.ContentPortal.Provider();
                            provider.Contact = user.Contact;
                            provider.Tag = fireBaseUserCreationResponse.UId;
                            provider.PhoneNumber = user.PhoneNumber;
                            provider.Name = user.DisplayName;
                            provider.Email = user.Email;
                            provider.ProviderId = string.IsNullOrEmpty(user.ProviderId) ? fireBaseUserCreationResponse.UId : user.ProviderId;
                            provider.Stage1Encode = user.Stage1Encode.HasValue ? user.Stage1Encode.Value : true;
                            provider.IsTenantProvider = string.IsNullOrEmpty(user.TenantId) ? false : true;
                            provider.TenantId = user.TenantId;
                            provider.MediaPlatform = user.MediaPlatform;
                            provider.JWPlayerSiteId = user.JWPlayerSiteId;

                            var result = await Save(provider).ConfigureAwait(false);
                            if (result != null && result.Entity != null && result.Entity.Count > 0 && result.Entity.Items.Any(t => t.Tag == provider.Tag))
                            {
                                return Tuple.Create(HttpStatusCode.Created, result.Entity.Items.FirstOrDefault(t => t.Tag == provider.Tag));
                            }
                        }
                        else
                        {
                            // when user creation fails
                            var firebaseUserCleanup = await _firebaseClient.DeleteUserAsync(fireBaseUserCreationResponse.UId).ConfigureAwait(false);
                            if (firebaseUserCleanup)
                            {
                                return Tuple.Create(HttpStatusCode.InternalServerError, default(Provider));
                            }
                        }
                    }
                }
                return Tuple.Create(HttpStatusCode.BadRequest, default(Provider));
            }
            catch (Exception e)
            {
                _logger.Warn("ProviderService Create Exception", "warn", e.ToString());
                throw e;
            }
        }
    }
}
