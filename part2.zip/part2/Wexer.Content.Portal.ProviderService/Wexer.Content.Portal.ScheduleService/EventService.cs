﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.ScheduleEvents;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.UserService;

namespace Wexer.Content.Portal.EventService
{
    public class EventService : IEventService
    {
        private readonly ILogger _logger;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly IUserService _userService;
        private readonly ITitleService _titleService;
        private readonly ICommandBus _commandBus;

        public EventService(ILoggerFactory loggerFactory, ICmsStoreRepo cmsStore, IUserService userService, ITitleService titleService, ICommandBus commandBus)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _cmsStore = cmsStore;
            _userService = userService;
            _titleService = titleService;
            _commandBus = commandBus;
        }
        public async Task<ScheduleEvent> CreateEvent(ScheduleEventViewModel eventModel)
        {
            try
            {
                ScheduleEvent scheduleEvent = new ScheduleEvent();
                scheduleEvent.Event_Id = Guid.NewGuid().ToString();
                scheduleEvent.Title = CreateLocalisedText(eventModel.Title);
                scheduleEvent.Description = CreateLocalisedText(eventModel.Description);
                scheduleEvent.Active = false;
                scheduleEvent.Scheduled_Time = eventModel.Schedule_Time;
                scheduleEvent.Schedule = eventModel.Schedule;
                scheduleEvent.Type = eventModel.Type;
                scheduleEvent.TenantId = eventModel.TenantId;
                scheduleEvent.ImageUrl = eventModel.ImageUrl;
                scheduleEvent.CreationDate = DateTime.UtcNow;
                scheduleEvent.AllowAutoPublish = eventModel.AllowAutoPublish;
                scheduleEvent.EventStatus = EventStatus.Saved;
                var result = await _cmsStore.StoreAsync(scheduleEvent);
                if (result != null && result.IsSuccessStatusCode && result.Entity != null)
                {
                    return scheduleEvent;
                }
                return null;
            }
            catch (Exception e)
            {
                _logger.Warn("EventService CreateEvent exception", "warn", e.ToString());
                throw;
            }
        }

        public async Task<ScheduleEvent> UpdateEvent(ScheduleEventViewModel eventModel, ScheduleEvent existingEvent, string providerId, string lang = "en-GB")
        {
            try
            {
                if (existingEvent != null)
                {
                    if (existingEvent.Type == EventType.TrueLive && existingEvent.Video == null && eventModel.Video !=null)
                    {
                        existingEvent.Video = new VirtualClass();
                        existingEvent.Video.ClassName = eventModel.Video.ClassName;
                    }

                    if (eventModel.Video != null)
                    {
                        existingEvent.Video = await _titleService.ModifyTitle(eventModel.Video, existingEvent.Video, lang, "save", TitleSource.Event).ConfigureAwait(false);
                    }

                    var command = new AutoPublishTitleCommand();

                    command.Event_Id = existingEvent.Event_Id;
                    command.TenantId = existingEvent.TenantId;

                    var oldScheduleTime = existingEvent.Scheduled_Time.Date + existingEvent.Schedule.Daily_Time.TimeOfDay;
                    var newScheduleTime = eventModel.Schedule_Time.Date + eventModel.Schedule.Daily_Time.TimeOfDay;
                    if (existingEvent.Video != null)
                    {
                        if (existingEvent.Slot != null && !string.IsNullOrWhiteSpace(existingEvent.Slot.ScheduleMessageSequenceNumber))
                        {
                            if (DateTime.Compare(oldScheduleTime, newScheduleTime) != 0)
                            {
                                _logger.Info($"EventId:{existingEvent.Event_Id}, oldScheduleTime: {oldScheduleTime}, newScheduleTime: {newScheduleTime}");
                                _logger.Info($"Canceling scheduled auto publish for EventId:{existingEvent.Event_Id} StreamLink:{existingEvent.Video.StreamingLink}");
                                _logger.Info($"Canceling scheduled auto publish for EventId:{existingEvent.Event_Id} ScheduleMessageSequenceNumber:{existingEvent.Slot.ScheduleMessageSequenceNumber}");
                                _logger.Info($"Canceling scheduled auto publish for EventId:{existingEvent.Event_Id} long converted ScheduleMessageSequenceNumber:{long.Parse(existingEvent.Slot.ScheduleMessageSequenceNumber)}");
                                await _commandBus.CancelScheduleAsync(long.Parse(existingEvent.Slot.ScheduleMessageSequenceNumber)).ConfigureAwait(false);

                                _logger.Info($"Scheduling auto publish for EventId:{existingEvent.Event_Id}  StreamLink:{existingEvent.Video.StreamingLink}");
                                _logger.Info($"Scheduling auto publish for EventId:{existingEvent.Event_Id}  Next_Occurence_Time:{existingEvent.Schedule.Next_Occurence_Time}");
                                //var seq = await _commandBus.SendScheduledAsync(command, DateTime.SpecifyKind(DateTime.Parse(existingEvent.Schedule.Next_Occurence_Time), DateTimeKind.Utc).AddHours(3)); // for production
                                var seq = await _commandBus.SendScheduledAsync(command, DateTime.SpecifyKind(newScheduleTime, DateTimeKind.Utc).AddHours(24)); // for testing
                                _logger.Info($"auto publish for EventId:{existingEvent.Event_Id} new  ScheduleMessageSequenceNumber:{seq}");
                                existingEvent.Slot = new PublishingSlot()
                                {
                                    PublishedToTenant = false,
                                    Publish_Schedule_Time = DateTime.SpecifyKind(newScheduleTime, DateTimeKind.Utc).AddHours(24), // changed from AddHours to AddMinutes must revert before going live
                                    ScheduleMessageSequenceNumber = seq.ToString(),
                                    Video = existingEvent.Video
                                };
                            }
                        }
                    }



                    await UpdateLocalisedText(existingEvent.Title, eventModel.Title);
                    await UpdateLocalisedText(existingEvent.Description, eventModel.Description);
                    existingEvent.Active = eventModel.Active;
                    existingEvent.Scheduled_Time = eventModel.Schedule_Time;
                    existingEvent.Schedule = eventModel.Schedule;
                    existingEvent.Type = eventModel.Type;
                    existingEvent.ImageUrl = eventModel.ImageUrl;
                    existingEvent.AllowAutoPublish = eventModel.AllowAutoPublish;

                    if (existingEvent.Type == EventType.TrueLive && existingEvent.AllowAutoPublish)
                    {
                        if (existingEvent.Video == null || !IsMetadataExist(existingEvent.Video))
                        {
                            existingEvent.Video.Status = MediaProcessingStatus.Incomplete;
                            existingEvent.EventStatus = EventStatus.Saved;
                        }
                        else if (existingEvent.Video != null && IsMetadataExist(existingEvent.Video) && !existingEvent.Active)
                        {
                            existingEvent.Video.Status = MediaProcessingStatus.Complete;
                            existingEvent.EventStatus = EventStatus.Inactive;
                        }
                    }
                    else if (existingEvent.Type == EventType.TrueLive && !existingEvent.AllowAutoPublish)
                    {
                        if (!string.IsNullOrEmpty(existingEvent.EventKey) && !existingEvent.Active)
                        {
                            existingEvent.EventStatus = EventStatus.Inactive;
                        }
                    }

                    if (existingEvent.Type == EventType.FeelsLikeLive)
                    {
                        if(existingEvent.AllowAutoPublish)
                        {
                            if (existingEvent.Video == null || !IsMetadataExist(existingEvent.Video)) //Metadata not provided
                            {
                                existingEvent.Video.Status = MediaProcessingStatus.Incomplete;
                                existingEvent.EventStatus = EventStatus.Saved;
                            }
                            else if (existingEvent.Video != null && IsMetadataExist(existingEvent.Video)) //Metadata is provided
                            {
                                existingEvent.Video.Status = MediaProcessingStatus.Complete;
                                existingEvent.EventStatus = EventStatus.Inactive;
                            }
                        }
                        else if (!existingEvent.AllowAutoPublish && existingEvent.Video != null)
                        {
                            existingEvent.EventStatus = EventStatus.Inactive;
                        }
                    }
                    existingEvent.EventStatus = existingEvent.Active ? EventStatus.Active : existingEvent.EventStatus;

                    var result = await _cmsStore.StoreAsync(existingEvent).ConfigureAwait(false);
                    if (result != null && result.IsSuccessStatusCode && result.Entity != null)
                    {
                        return existingEvent;
                    }
                }
                return null;
            }
            catch (Exception e)
            {
                _logger.Warn("EventService UpdateEvent exception", "warn", e.ToString());
                throw;
            }
        }

        static LocalisedText CreateLocalisedText(string text, string ietfTag = "en-GB")
        {
            return new LocalisedText { InvariantText = text, LocalTexts = new[] { new LocalText { IETFTag = ietfTag, Text = text } } };
        }

        public async Task<IEnumerable<ScheduleEvent>> List(string tenant)
        {
            try
            {
                var result = await _cmsStore.GetListAsync<ScheduleEvent>(tenant).ConfigureAwait(false);
                var tenantInfo = await _userService.GetTenant(tenant).ConfigureAwait(false);
                var taskList = new List<Task>();
                var eventLockTaskList = new List<Task>();
                if (result != null && result.Count() > 0)
                {
                    if (tenantInfo != null && tenantInfo.TimeZoneInfo != null && !string.IsNullOrEmpty(tenantInfo.TimeZoneInfo.UtcOffset))
                    {
                        foreach (var item in result)
                        {
                            taskList.Add(item.SetNextOccurence());
                        }

                        await Task.WhenAll(taskList).ConfigureAwait(false);

                        foreach (var item in result)
                        {
                            eventLockTaskList.Add(item.GetEventLockStatus());
                        }

                        await Task.WhenAll(eventLockTaskList).ConfigureAwait(false);
                    }

                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception e)
            {
                _logger.Warn("EventService List exception", "warn", e.ToString());
                throw;
            }
        }

        public async Task<ScheduleEvent> GetEvent(string tenant, string tag)
        {
            try
            {
                var result = await _cmsStore.QueryAsync<ScheduleEvent>(tenant, tag).ConfigureAwait(false);
                var tenantInfo = await _userService.GetTenant(tenant).ConfigureAwait(false);
                if (result != null)
                {
                    if (tenantInfo != null && tenantInfo.TimeZoneInfo != null && !string.IsNullOrEmpty(tenantInfo.TimeZoneInfo.UtcOffset))
                    {
                        await Task.WhenAll(result.SetNextOccurence()).ConfigureAwait(false);
                        await result.GetEventLockStatus().ConfigureAwait(false);
                    }
                    return result;
                }

                return result;
            }
            catch (Exception e)
            {
                _logger.Warn("EventService GetEvent exception", "warn", e.ToString());
                throw;
            }
        }

        protected async static Task UpdateLocalisedText(LocalisedText localisedText, string changedText, string ietfTag = "en-GB")
        {
            if (localisedText != null)
            {
                if (localisedText.LocalTexts == null)
                {
                    localisedText.LocalTexts = new[] { new LocalText { Text = changedText, IETFTag = ietfTag } };
                }
                else
                {
                    var localTextList = localisedText.LocalTexts.ToList();
                    var currentCultureText = localTextList.FirstOrDefault(t => t.IETFTag == ietfTag);
                    if (currentCultureText != null)
                    {
                        currentCultureText.Text = changedText;
                    }
                    else
                    {
                        localTextList.Add(new LocalText { IETFTag = ietfTag, Text = changedText });
                    }
                    localisedText.LocalTexts = localTextList.ToArray();
                }
                if (ietfTag == "en-GB")
                {
                    localisedText.InvariantText = changedText;
                }
            }
        }

        public async Task<bool> DeleteEvent(string tenantId, string eventId)
        {
            try
            {
                var deleteEventResponse = await _cmsStore.DeleteAsync<ScheduleEvent>(tenantId, eventId).ConfigureAwait(false);

                return deleteEventResponse.IsSuccessStatusCode;

            }
            catch (Exception e)
            {
                _logger.Warn("EventService DeleteEvent exception", "warn", e.ToString());
                throw;
            }
        }

        static bool IsMetadataExist(VirtualClass virtualClass)
        {
            bool status = true;
            if (string.IsNullOrEmpty(virtualClass.ClassName) || string.IsNullOrEmpty(virtualClass.ClassName.InvariantText) || 
                string.IsNullOrEmpty(virtualClass.ClassDescription) || string.IsNullOrEmpty(virtualClass.ClassDescription.InvariantText) || 
                virtualClass.Skill <= 0 || virtualClass.ClassCategoryId == 0 || string.IsNullOrEmpty(virtualClass.ClassLanguageCode) ||
                virtualClass.Intensity == 0 || virtualClass.Equipments == null || string.IsNullOrEmpty(virtualClass.Equipments.InvariantText)
                )
            {
                status = false;
            }
            return status;
        }
    }
}
