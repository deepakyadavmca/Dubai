﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.ScheduleEvents;

namespace Wexer.Content.Portal.EventService
{
    public interface IEventService
    {
        Task<ScheduleEvent> GetEvent(string tenant, string tag);
        Task<IEnumerable<ScheduleEvent>> List(string tenant);
        Task<ScheduleEvent> CreateEvent(ScheduleEventViewModel eventModel);

        Task<ScheduleEvent> UpdateEvent(ScheduleEventViewModel eventModel, ScheduleEvent existingEvent, string providerId, string lang = "en-GB");

        Task<bool> DeleteEvent(string tenantId, string eventId);
    }
}
