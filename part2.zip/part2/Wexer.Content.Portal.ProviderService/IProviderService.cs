﻿using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using System;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.ReadStore;

namespace Wexer.Content.Portal.ProviderService
{
    public interface IProviderService
    {
        Task<Provider[]> List();
        Task<Provider> Get(string tag);
        Task<ReadStoreWriteOperation<EntitySet<Provider>>> Save(Provider entity);

        Task<HttpStatusCode> Delete(string tag);
        Task<bool> SaveMultiple(Provider[] entities);
        Task<Provider> Update(Provider providerRequest);
        Task<Tuple<HttpStatusCode, Provider>> Create(PortalUser user);
    }
}
