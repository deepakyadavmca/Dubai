﻿using RestSharp;
using System;
using System.Collections.Generic;
using Nancy.Json;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.RemoteService
{
    public class RemoteClient
    {
        private readonly string _uri;
        public Dictionary<string, string> headers;

        public void AddHeader(string key, string value)
        {
            headers.Add(key, value);
        }

        public RemoteClient(string uri, string apiSecret)
        {
            _uri = uri;
            headers = new Dictionary<string, string>();
            headers.Add("Authorization", "Bearer " + apiSecret);
        }

        public async Task<string> Get()
        {
            RestClient client = new RestClient(new Uri(_uri));
            client.AddDefaultHeaders(headers);

            var request = new RestRequest();
            request.Method = Method.GET;
            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            var response = await client.ExecuteAsync(request);
            return response.Content;
        }

        public async Task<string> Post(dynamic body)
        {
            RestClient client = new RestClient(new Uri(_uri));
            client.AddDefaultHeaders(headers);

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var jsonBody = serializer.Serialize(body);

            var request = new RestRequest();
            request.Method = Method.POST;
            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", jsonBody, ParameterType.RequestBody);

            var response = await client.ExecuteAsync(request);
            return response.Content;
        }

        public async Task<string> Patch(dynamic body)
        {
            RestClient client = new RestClient(new Uri(_uri));
            client.AddDefaultHeaders(headers);

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var jsonBody = serializer.Serialize(body);

            var request = new RestRequest();
            request.Method = Method.PATCH;
            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", jsonBody, ParameterType.RequestBody);

            var response = await client.ExecuteAsync(request);
            return response.Content;
        }

        public async Task<string> Put(dynamic body)
        {
            RestClient client = new RestClient(new Uri(_uri));
            client.AddDefaultHeaders(headers);

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            var jsonBody = serializer.Serialize(body);

            var request = new RestRequest();
            request.Method = Method.PUT;
            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", jsonBody, ParameterType.RequestBody);

            var response = await client.ExecuteAsync(request);
            return response.Content;
        }

        public async Task<string> Delete()
        {
            RestClient client = new RestClient(new Uri(_uri));
            client.AddDefaultHeaders(headers);

            var request = new RestRequest();
            request.Method = Method.DELETE;
            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();

            var response = await client.ExecuteAsync(request);
            return response.Content;
        }
    }
}
