﻿using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Controllers;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.EntityTransforms;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace Wexer.Content.Portal.UnitTests
{
    public class ChannelControllerTest: UnitTests.CustomMocks<Channel>
    {

        [Test]
        public async Task CreateChannelWithoutProvider_ShouldNotCreateChannel()
        {
            try
            {
                SetupChannelService();
                SetupProviderService();
                
                var controller = new ChannelsController(loggerFactory.Object, cache.Object, channelServiceMock.Object, providerServiceMock.Object, userServiceMock.Object, commandBus.Object);
                controller.ControllerContext.HttpContext = new DefaultHttpContext();
                controller.ControllerContext.HttpContext.Request.Headers.Add("Accept-Language", "en-GB");
                var execution = await controller.CreateChannel(new ChannelViewModel()
                {
                    Active = true,
                    Availability = new List<ChannelAvailability> { ChannelAvailability.AppAndWeb },
                    Name = "Test",
                    DisplayName = "Test",
                    Description = "Test Channel",
                    Provider = ""
                }).ConfigureAwait(false);

                var result = execution.Result as IStatusCodeActionResult;
                Assert.AreEqual(result.StatusCode, 400);
            }
            catch (Exception e)
            {
                throw e;
            }
        }



        [Test]
        public async Task CreateChannel_ShouldCreateChannel()
        {
            try
            {
                SetupChannelService();
                SetupProviderService();

                var controller = new ChannelsController(loggerFactory.Object, cache.Object, channelServiceMock.Object, providerServiceMock.Object, userServiceMock.Object, commandBus.Object);
                controller.ControllerContext.HttpContext = new DefaultHttpContext();
                controller.ControllerContext.HttpContext.Request.Headers.Add("Accept-Language", "en-GB");
                var execution = await controller.CreateChannel(new ChannelViewModel()
                {
                    Active = true,
                    Availability = new List<ChannelAvailability> { ChannelAvailability.AppAndWeb },
                    Description = "Test",
                    DisplayName = "Test1",
                    MediaSpaceImageUrl = "",
                    Name = "Test1",
                    ProfileImageUrl = "",
                    Provider = "adbvsdgw3234aed",
                    Tenants = new List<string>() { "wexer" }
                }).ConfigureAwait(false);

                var result = execution.Result as IStatusCodeActionResult;
                Assert.AreEqual(result.StatusCode, 201);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        
    }
}
