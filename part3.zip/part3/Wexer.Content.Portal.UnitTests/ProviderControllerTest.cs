using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.User;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Management.Media.Models;
using Microsoft.Extensions.Primitives;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Controllers;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.EntityTransforms;

namespace Wexer.Content.Portal.UnitTests
{

    public class ProviderControllerTest : CustomMocks<Models.ContentPortal.Provider>
    {
        

        [Test]
        public async Task CreateProvider_ShouldCreateProvider()
        {
            try
            {
                loggerFactory.Setup(v => v.GetLoggerForClass(this));
                SetupProviderService();
                var providerController = new ProviderController(loggerFactory.Object, cache.Object, providerServiceMock.Object, firebaseClient.Object, userSignupServiceMock.Object, userServiceMock.Object, channelServiceMock.Object);

                var execution = await providerController.CreateProvider(new PortalUser() { DisplayName = "B", Email = "b@b.com", Password = "123", UserRole = Roles.Provider }).ConfigureAwait(false);
                var result = execution.Result as CreatedAtActionResult;
                Assert.AreEqual(result.StatusCode, 201);
            }
            catch (Exception e)
            {
                throw e;
            }
            
        }

        [Test]
        public async Task CreateUser_ShouldNotCreateUser()
        {
            try
            {
                loggerFactory.Setup(v => v.GetLoggerForClass(this));
                SetupFirebaseClientForNegativeScenario();
                SetupProviderServiceForNegativeScenario();
                var providerController = new ProviderController(loggerFactory.Object, cache.Object, providerServiceMock.Object, firebaseClient.Object, userSignupServiceMock.Object, userServiceMock.Object, channelServiceMock.Object);

                var execution = await providerController.CreateProvider(new PortalUser() { DisplayName = "B", Email = "b@b.com", Password = "123", UserRole = Roles.Provider }).ConfigureAwait(false);
                var result = execution.Result as ObjectResult;
                Assert.AreEqual(result.StatusCode, 500);
            }
            catch (Exception e)
            {
                throw e;
            }
           
        }
    }
}