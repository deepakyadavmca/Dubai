﻿using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.User;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.EntityTransforms;
using Wexer.Content.Portal.UserService;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.UserService.SignupService;

namespace Wexer.Content.Portal.UnitTests
{
    public class CustomMocks<T> where T : class, new()
    {
        protected Mock<ILoggerFactory> loggerFactory;
        protected Mock<IFirebaseClient> firebaseClient;
        protected Mock<IUserBlobRepo> userBlobRepoMock;
        protected Mock<HttpRequest> request;
        protected Mock<IMemoryCache> cache;
        protected Mock<IBlobRepo> blobRepoMock;
        protected Mock<IModelTransformService> modelTransformServiceMock;
        protected Mock<IUserSignupService> userSignupServiceMock;
        protected Mock<IProviderService> providerServiceMock;
        protected Mock<IChannelService> channelServiceMock;
        protected Mock<IUserService> userServiceMock;
        protected Mock<ICommandBus> commandBus;

        [OneTimeSetUp]
        public void Setup()
        {
            loggerFactory = new Mock<ILoggerFactory>();
            firebaseClient = new Mock<IFirebaseClient>(MockBehavior.Strict);
            userBlobRepoMock = new Mock<IUserBlobRepo>(MockBehavior.Strict);
            request = new Mock<HttpRequest>(MockBehavior.Strict);
            cache = new Mock<IMemoryCache>(MockBehavior.Default);
            blobRepoMock = new Mock<IBlobRepo>(MockBehavior.Strict);
            modelTransformServiceMock = new Mock<IModelTransformService>();
            userSignupServiceMock = new Mock<IUserSignupService>();
            providerServiceMock = new Mock<IProviderService>(MockBehavior.Strict);
            channelServiceMock = new Mock<IChannelService>(MockBehavior.Strict);
            userServiceMock = new Mock<IUserService>();
            commandBus = new Mock<ICommandBus>();





            blobRepoMock.Setup(v => v.GetSetAsync<T>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>()))
                .Returns(Task.FromResult(new ReadStoreQueryOperation<EntitySet<T>>() { Entity = GetEntitySet(), HttpStatusCode = (int)HttpStatusCode.OK }));

            blobRepoMock.Setup(v => v.GetAsync<T>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>())).Returns(
                Task.FromResult(new ReadStoreQueryOperation<T>() { Entity = new T(), HttpStatusCode = (int)HttpStatusCode.OK }));

            blobRepoMock.Setup(v => v.GetDataAsync<T>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>()))
                .Returns(Task.FromResult(new ReadStoreQueryOperation<EntitySet<T>>() { Entity = GetEntitySet(), HttpStatusCode = 200 }));

            blobRepoMock.Setup(v => v.DeleteSetAsync<T>(It.IsAny<string>())).Returns(Task.FromResult(HttpStatusCode.OK));

            blobRepoMock.Setup(v => v.DeleteAsync<T>(It.IsAny<string>())).Returns(Task.FromResult(HttpStatusCode.OK));
            blobRepoMock.Setup(v => v.PutAsync(It.IsAny<string>(), It.IsAny<T>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>(), It.IsAny<bool>()))
                .Returns(Task.FromResult(new ReadStoreWriteOperation<T>() { Entity = new T(), HttpStatusCode = (int)HttpStatusCode.OK }));

            blobRepoMock.Setup(v => v.PutSetAsync(It.IsAny<string>(), It.IsAny<EntitySet<T>>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>(), It.IsAny<bool>()))
                        .Returns(Task.FromResult(new ReadStoreWriteOperation<EntitySet<T>>() { Entity = GetEntitySet(), HttpStatusCode = (int)HttpStatusCode.OK }));

            blobRepoMock.Setup(v => v.PutDataAsync(It.IsAny<string>(), It.IsAny<EntitySet<T>>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>(), It.IsAny<bool>()))
                .Returns(Task.FromResult(new ReadStoreWriteOperation<EntitySet<T>>() { Entity = GetEntitySet(), HttpStatusCode = (int)HttpStatusCode.OK }));

            blobRepoMock.Setup(v => v.ListBlobsFromContainer(It.IsAny<string>())).Returns(new List<string>());


            modelTransformServiceMock.Setup(v => v.ApplyEntityTransforms(It.IsAny<T>())).Returns(default(T));

            firebaseClient.Setup(v => v.SetClaims(It.IsAny<string>(), It.IsAny<Dictionary<string, object>>()))
                .Returns(Task.FromResult(true));
            firebaseClient.Setup(v => v.GetUserAsync<UserInfo>(It.IsAny<string>()))
                .Returns(Task.FromResult(new UserInfo() { DisplayName = "B", Email = "b@b.com" }));
            firebaseClient.Setup(v => v.CreateUserAsync<UserInfo>(It.IsAny<UserRecordArgs>(), It.IsAny<Roles>()))
                .Returns(Task.FromResult(GetMockFirebaseUser()));
            firebaseClient.Setup(v => v.GetUserByEmail<UserInfo>(It.IsAny<string>()))
                .Returns(Task.FromResult(default(UserInfo)));

            userSignupServiceMock.Setup(v => v.CreatePortalUserIndexAsync(It.IsAny<PortalUser>(), It.IsAny<string>()))
                    .Returns(Task.FromResult(Guid.NewGuid().ToString()));



        }


        private EntitySet<T> GetEntitySet()
        {
            return new EntitySet<T>
            {
                Count = 1,
                Items = new T[1] { new T() }
            };
        }

        private T[] GetListEntity()
        {
            return new T[1] { new T() };
        }

        private J[] GetListEntityFromGeneric<J>() where J : class, new()
        {
            J[] entity = null;
            if (typeof(J).Name.ToLowerInvariant() == "provider")
            {
                entity = GetMockListProviderObject() as J[];
            }
            if (typeof(J).Name.ToLowerInvariant() == "channel")
            {
                entity = GetMockListChannelObject() as J[];
            }
            return entity;
        }

        private EntitySet<J> GetEntitySetFromGeneric<J>() where J : class, new()
        {
            J entity = null;
            if (typeof(J).Name.ToLowerInvariant() == "provider")
            {
                entity = GetMockProviderObject() as J;
            }
            if (typeof(J).Name.ToLowerInvariant() == "channel")
            {
                entity = GetMockChannelObject() as J;
            }
            return new EntitySet<J>
            {
                Count = 1,
                Items = new J[1] { entity }
            };
        }

        protected void SetupProviderService()
        {
            providerServiceMock.Setup(v => v.Get(It.IsAny<string>()))
                .Returns(Task.FromResult(GetMockProviderObject()));
            providerServiceMock.Setup(v => v.List())
                .Returns(Task.FromResult(GetListEntityFromGeneric<Provider>()));
            providerServiceMock.Setup(v => v.Save(It.IsAny<Provider>()))
                .Returns(Task.FromResult(new ReadStoreWriteOperation<EntitySet<Provider>>() { Entity = GetEntitySetFromGeneric<Provider>(), HttpStatusCode = (int)HttpStatusCode.OK }));
            providerServiceMock.Setup(v => v.SaveMultiple(It.IsAny<Provider[]>()))
                .Returns(Task.FromResult(true));
            providerServiceMock.Setup(v => v.SaveMultiple(It.IsAny<Provider[]>()))
                .Returns(Task.FromResult(true));
            providerServiceMock.Setup(v => v.Create(It.IsAny<PortalUser>()))
                .Returns(Task.FromResult(Tuple.Create(HttpStatusCode.Created, GetMockProviderObject())));

        }

        protected void SetupProviderServiceForNegativeScenario()
        {
            providerServiceMock.Setup(v => v.Get(It.IsAny<string>())).Returns(Task.FromResult(default(Provider)));
            providerServiceMock.Setup(v => v.List()).Returns(Task.FromResult(default(Provider[])));
            providerServiceMock.Setup(v => v.Save(It.IsAny<Provider>()))
                .Returns(Task.FromResult(new ReadStoreWriteOperation<EntitySet<Provider>>() { Entity = null, HttpStatusCode = (int)HttpStatusCode.BadRequest }));
            providerServiceMock.Setup(v => v.SaveMultiple(It.IsAny<Provider[]>()))
               .Returns(Task.FromResult(false));
            providerServiceMock.Setup(v => v.SaveMultiple(It.IsAny<Provider[]>()))
                .Returns(Task.FromResult(false));
            providerServiceMock.Setup(v => v.Create(It.IsAny<PortalUser>()))
                .Returns(Task.FromResult(Tuple.Create(HttpStatusCode.InternalServerError, default(Provider))));
        }

        protected void SetupChannelService()
        {
            channelServiceMock.Setup(v => v.Get(It.IsAny<string>()))
                .Returns(Task.FromResult(GetMockChannelObject()));
            channelServiceMock.Setup(v => v.List())
                .Returns(Task.FromResult(GetListEntityFromGeneric<Channel>()));
            channelServiceMock.Setup(v => v.Save(It.IsAny<Channel>()))
                .Returns(Task.FromResult(new ReadStoreWriteOperation<EntitySet<Channel>>() { Entity = GetEntitySetFromGeneric<Channel>(), HttpStatusCode = (int)HttpStatusCode.OK }));
            channelServiceMock.Setup(v => v.SaveMultiple(It.IsAny<Channel[]>()))
                .Returns(Task.FromResult(true));
            channelServiceMock.Setup(v => v.Update(It.IsAny<Channel>(), It.IsAny<string>()))
                .Returns(Task.FromResult(HttpStatusCode.OK));
            channelServiceMock.Setup(v => v.Create(It.IsAny<ChannelViewModel>(), It.IsAny<string>()))
                .Returns(Task.FromResult(Tuple.Create(HttpStatusCode.Created, GetMockChannelObject())));
        }

        protected void SetupFirebaseClientForNegativeScenario()
        {
            firebaseClient.Setup(v => v.SetClaims(It.IsAny<string>(), It.IsAny<Dictionary<string, object>>()))
                .Returns(Task.FromResult(false));
            firebaseClient.Setup(v => v.GetUserAsync<UserInfo>(It.IsAny<string>()))
                .Returns(Task.FromResult(default(UserInfo)));
            firebaseClient.Setup(v => v.CreateUserAsync<UserInfo>(It.IsAny<UserRecordArgs>(), It.IsAny<Roles>()))
                .Returns(Task.FromResult(default(UserInfo)));
            firebaseClient.Setup(v => v.GetUserByEmail<UserInfo>(It.IsAny<string>()))
                .Returns(Task.FromResult(default(UserInfo)));
        }

        private Channel GetMockChannelObject()
        {
            return new Channel()
            {
                Active = true,
                Availability = new List<ChannelAvailability> { ChannelAvailability.AppAndWeb, ChannelAvailability.InClub },
                Description = "Test",
                DisplayName = "Test",
                MediaSpaceImageUrl = "",
                Name = "Test",
                ProfileImageUrl = "",
                Provider = "adbvsdgw3234aed",
                Tenants = new List<string>() { "wexer" },
                Tag = Guid.NewGuid().ToString()
            };
        }

        private Channel[] GetMockListChannelObject()
        {
            return new Channel[] {
                new Channel{
                    Active = true,
                    Availability = new List<ChannelAvailability> { ChannelAvailability.AppAndWeb, ChannelAvailability.InClub },
                    Description = "Test",
                    DisplayName = "Test",
                    MediaSpaceImageUrl = "",
                    Name = "Test",
                    ProfileImageUrl = "",
                    Provider = "adbvsdgw3234aed",
                    Tenants = new List<string>() { "wexer" },
                    Tag = Guid.NewGuid().ToString()
                }
            };
        }


        private Provider GetMockProviderObject()
        {
            return new Provider()
            {
                Tag = "adbvsdgw3234aed",
                Name = "Tester",
                Contact = "Abcd",
                Email = "tester@test.com",
                PhoneNumber = "123-345-5555"
            };
        }
        
        private Provider[] GetMockListProviderObject()
        {
            return new Provider[] {
                new Provider{
                    Tag = "adbvsdgw3234aed",
                    Name = "Tester",
                    Contact = "Abcd",
                    Email = "tester@test.com",
                    PhoneNumber = "123-345-5555"
                } 
            };
        }

        private UserInfo GetMockFirebaseUser()
        {
            return new UserInfo()
            {
                DisplayName = "B",
                Email = "b@b.com",
                UId = "adbvsdgw3234aed"
            };
        }
    }
}
