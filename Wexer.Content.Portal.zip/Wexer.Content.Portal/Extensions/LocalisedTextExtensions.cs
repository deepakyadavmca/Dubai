﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;

namespace Wexer.Content.Portal.Extensions
{
    public static class LocalisedTextExtensions
    {
        public static string FlattenByLanguage(this LocalisedText localisedText, string languageTag)
        {
            if (localisedText == null)
            {
                return string.Empty;
            }

            if (localisedText.LocalTexts == null)
            {
                return localisedText.InvariantText;
            }

            var matchingLanguageLocalText =
                localisedText.LocalTexts.FirstOrDefault(e => e.IETFTag == languageTag);

            if (matchingLanguageLocalText != null)
            {
                return matchingLanguageLocalText.Text;
            }

            matchingLanguageLocalText =
                localisedText.LocalTexts.FirstOrDefault(e => e.IETFTag == "en-GB");

            return matchingLanguageLocalText != null ? matchingLanguageLocalText.Text : localisedText.InvariantText;
        }


        /// <summary>
        /// Return string only if the localisedText found corresponding to particular languageTag else returns empty
        /// </summary>
        /// <param name="localisedText">LocalisedText</param>
        /// <param name="languageTag">languageTag</param>
        /// <returns></returns>
        public static string FlattenByLanguageStrict(this LocalisedText localisedText, string languageTag)
        {
            if (localisedText == null)
            {
                return string.Empty;
            }

            if (localisedText.LocalTexts == null)
            {
                return localisedText.InvariantText;
            }

            var matchingLanguageLocalText =
               localisedText.LocalTexts.FirstOrDefault(e => e.IETFTag == languageTag);

            if (matchingLanguageLocalText != null)
            {
                return matchingLanguageLocalText.Text;
            }
            else
            {
                return string.Empty;
            }
        }

        public static void UpdateLocalisedText(this LocalisedText localisedText, string changedText, string ietfTag = "en-GB")
        {
            if (localisedText != null)
            {
                if (localisedText.LocalTexts == null)
                {
                    localisedText.LocalTexts = new[] { new LocalText { Text = changedText, IETFTag = ietfTag } };
                }
                else
                {
                    var localTextList = localisedText.LocalTexts.ToList();
                    var currentCultureText = localTextList.FirstOrDefault(t => t.IETFTag == ietfTag);
                    if (currentCultureText != null)
                    {
                        currentCultureText.Text = changedText;
                    }
                    else
                    {
                        localTextList.Add(new LocalText { IETFTag = ietfTag, Text = changedText });
                    }
                    localisedText.LocalTexts = localTextList.ToArray();
                }
                if (ietfTag == "en-GB")
                {
                    localisedText.InvariantText = changedText;
                }
            }
        }
    }
}
