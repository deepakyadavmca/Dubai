﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wexer.Content.Portal
{
    public class AppSettings
    {
        public string LogglyAccountId { get; set; }
        public string LogglyUrl { get; set; }
        public string LogglyTags { get; set; }
        public string LogglyLevels { get; set; }
        public string BlobContentConnectionString { get; set; }
        public string BlobUserConnectionString { get; set; }
        public string TableConnectionString { get; set; }
        public string SqlTableContentConnectionString { get; set; }
        public string SqlTableUserConnectionString { get; set; }
        public string MediaBlobConnectionString { get; set; }
        public string FileStoreBlobConnectionString { get; set; }
        public string OnDemandMediaServicesCdnUrl { get; set; }
        public string FirebaseProjectId { get; set; }
        public string FirebaseClientId { get; set; }
        public string AzureMediaServiceTenantId { get; set; }
        public string AzureMediaServiceClientId { get; set; }
        public string AzureMediaServiceClientSecret { get; set; }
        public string AzureMediaServiceApiUrl { get; set; }
        public string ImageUrl { get; set; }
        public string VideoUrl { get; set; }

        public string ServiceBusConnectionString { get; set; }
        public string MediaServiceConnectionString { get; set; }
        public string CdnUrl { get; set; }
        public string AzureMediaServiceSubscriptionId { get; set; }
        public string AzureMediaServiceResourceGroup { get; set; }
        public string AzureMediaServiceAccountName { get; set; }
        public JWPlayerConfiguration JWPlayerConfiguration { get; set; }
    }

    public class JWPlayerConfiguration
    {
        public string BaseAddressV2 { get; set; }
        public string BaseAddressDelivery { get; set; }
        public bool IsSandbox { get; set; }
        public string SiteId { get; set; }
        public string APISecret { get; set; }
        public string WebhookId { get; set; }
        public string WebhookSecret { get; set; }
    }
}
