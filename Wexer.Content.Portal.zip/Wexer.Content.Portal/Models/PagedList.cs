﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wexer.Content.Portal.Models
{
    public class PagedList<T>
    {
        public int CurrentPage { get; private set; }
        public int PageSize { get; private set; }
        public int TotalPages { get; private set; }
        public int TotalRecords { get; set; }

        public static IEnumerable<T> Data { get; private set; }

        public static dynamic GetPagedResponse(IEnumerable<T> data, int page, int pageSize)
        {
            try
            {
                return new
                {
                    TotalRecords = data.Count(),
                    TotalPages = data.Count() > 0 ? Convert.ToInt32(Math.Ceiling(data.Count() / (double)pageSize)) : 0,
                    page,
                    Data = data.Skip((page - 1) * pageSize).Take(pageSize).ToList()
                };
            }
            catch (Exception e)
            {
                throw e;
            }
            
        }
    }
}
