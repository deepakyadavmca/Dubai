﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.Events;

namespace Wexer.Content.Portal.Models
{
    public class EventsActionModel
    {
        public string TrackingId { get; set; }
        public string Action { get; set; }
    }

    
}
