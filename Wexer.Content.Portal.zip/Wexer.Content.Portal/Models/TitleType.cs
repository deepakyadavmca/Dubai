﻿
namespace Wexer.Content.Portal.Models
{
    public enum TitleType
    {
        Trailer,
        Title
    }
}
