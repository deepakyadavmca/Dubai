﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore.Update;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Wexer.Content.Portal.Attributes
{
    public class HmacAuthorizeAttribute : Attribute, IAsyncAuthorizationFilter
    {
        private static Dictionary<string, string> allowedApps = new Dictionary<string, string>();
        private readonly UInt64 requestMaxAgeInSeconds = 300;
        private IMemoryCache _cache;
        public HmacAuthorizeAttribute()
        {
            if (allowedApps.Count == 0)
            {
                allowedApps.Add("4d53bce03ec34c0a911182d4c228ee6c", "A93reRTUJHsCuQSHR+L3GxqOJyDmQpCgps102ciuabc=");
            }
        }
        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var req = context.HttpContext.Request;
            _cache = context.HttpContext.RequestServices.GetRequiredService<IMemoryCache>();
            if (req.Headers.ContainsKey("Authorization"))
            {
                if(req.Headers.TryGetValue("Authorization", out StringValues hmacHeader))
                {
                    var headerValues = GetAuthHeaderValue(hmacHeader);

                    var APPId = headerValues[0];
                    var incomingBase64Signature = headerValues[1];
                    var nonce = headerValues[2];
                    var requestTimeStamp = headerValues[3];

                    var isValid = await IsValidRequest(req, APPId, incomingBase64Signature, nonce, requestTimeStamp);

                    if (isValid)
                    {
                        return;
                    }
                }
            }
            context.Result = new UnauthorizedResult();
        }

        private string[] GetAuthHeaderValue(StringValues headers)
        {
            var headerArray = headers.FirstOrDefault().Split(':');
            if(headerArray.Length == 4)
            {
                return headerArray;
            }

            return null;
        }

        private async Task<bool> IsValidRequest(HttpRequest req, string APPId, string incomingBase64Signature, string nonce, string requestTimeStamp)
        {
            string requestContentBase64String = "";
            string requestUri = HttpUtility.UrlEncode($"http://{req.Host}{req.Path}");
            string requestHttpMethod = req.Method;

            if (!allowedApps.ContainsKey(APPId))
            {
                return false;
            }

            var sharedKey = allowedApps[APPId];

            if (isReplayRequest(nonce, requestTimeStamp))
            {
                return false;
            }

            byte[] hash = await ComputeHash(req.Body);

            if (hash != null)
            {
                requestContentBase64String = Convert.ToBase64String(hash);
            }

            string data = String.Format("{0}{1}{2}{3}{4}{5}", APPId, requestHttpMethod, requestUri, requestTimeStamp, nonce, requestContentBase64String);

            var secretKeyBytes = Convert.FromBase64String(sharedKey);

            byte[] signature = Encoding.UTF8.GetBytes(data);

            using (HMACSHA256 hmac = new HMACSHA256(secretKeyBytes))
            {
                byte[] signatureBytes = hmac.ComputeHash(signature);

                return (incomingBase64Signature.Equals(Convert.ToBase64String(signatureBytes), StringComparison.Ordinal));
            }
        }

        private bool isReplayRequest(string nonce, string requestTimeStamp)
        {
            
            if (_cache.TryGetValue(nonce, out object localNonce))
            {
                return true;
            }

            DateTime epochStart = new DateTime(1970, 01, 01, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan currentTs = DateTime.UtcNow - epochStart;

            var serverTotalSeconds = Convert.ToUInt64(currentTs.TotalSeconds);
            var requestTotalSeconds = Convert.ToUInt64(requestTimeStamp);

            if ((serverTotalSeconds - requestTotalSeconds) > requestMaxAgeInSeconds)
            {
                return true;
            }

            _cache.Set(nonce, requestTimeStamp, DateTimeOffset.UtcNow.AddSeconds(requestMaxAgeInSeconds));

            return false;
        }

        private static async Task<byte[]> ComputeHash(Stream httpContent)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] hash = null;
                byte[] arr = null;
                using (var reader = new StreamReader(httpContent, Encoding.UTF8, true, 1024, true))
                {
                    var str = await reader.ReadToEndAsync();
                    arr = Encoding.UTF8.GetBytes(str);
                }
                //httpContent.Position = 0;
                
                if (arr.Length != 0)
                {
                    hash = md5.ComputeHash(arr);
                }
                return hash;
            }
        }
    }
}
