﻿using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Repositories.Blobs.Repo;

namespace Wexer.Content.Portal.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class APIAuthAttribute : AuthorizeAttribute, IAsyncAuthorizationFilter
    {
        private IBlobRepo _blobRepo;
        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            try
            {
                _blobRepo = context.HttpContext.RequestServices.GetRequiredService<IBlobRepo>();
                var authHeader = context.HttpContext.Request.Headers.Where(t => t.Key == "Authorization").Select(t => t.Value.ToString()).FirstOrDefault();
                if (!string.IsNullOrEmpty(authHeader))
                {
                    var token = authHeader.Split(" ")[1];
                    
                    var tokenparts = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(token)).Split(':');
                    if (tokenparts.Length == 2)
                    {
                        var key = tokenparts[0];
                        var secret = tokenparts[1];
                        
                        var apiKeys = await _blobRepo.GetSetAsync<ClientApplication>("*").ConfigureAwait(false);
                        var keyVals = apiKeys.Entity.Items.ToDictionary(x => x.AppKey, x => x.AppSecret);
                        if(keyVals.TryGetValue(key, out string dbKeySecret))
                        {
                            if(secret == dbKeySecret)
                            {
                                return;
                            }
                        }
                    }
                }
                context.Result = new StatusCodeResult(401);
            }
            catch (Exception e)
            {
                context.Result = new StatusCodeResult(401);
            }
        }
    }
}
