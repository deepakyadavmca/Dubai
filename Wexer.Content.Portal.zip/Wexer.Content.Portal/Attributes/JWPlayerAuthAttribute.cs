﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using Wexer.Content.Portal.Models.JWPlayer;

namespace Wexer.Content.Portal.Attributes
{
    public class JWPlayerAuthAttribute : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
            //throw new NotImplementedException();
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                var configService = (IConfiguration)context.HttpContext.RequestServices.GetService(typeof(IConfiguration));
                var settings = new AppSettings();
                configService.Bind(settings);

                var authHeader = context.HttpContext.Request.Headers.Where(t => t.Key == "Authorization").Select(t => t.Value.ToString()).FirstOrDefault();
                if (!string.IsNullOrEmpty(authHeader))
                {
                    var token = authHeader.Split(" ")[1];
                    var key = Encoding.ASCII.GetBytes(settings.JWPlayerConfiguration.WebhookSecret);
                    var handler = new JwtSecurityTokenHandler();

                    var validations = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(key),
                        ValidateIssuer = false,
                        ValidateAudience = false,
                        RequireExpirationTime = false
                    };
                    var jwtSecurityToken = handler.ReadJwtToken(token);
                    var claims = handler.ValidateToken(token, validations, out var tokenSecure);

                    var contextPayload = JsonConvert.DeserializeObject<MediaWebhookResponse>(context.ActionArguments.FirstOrDefault().Value.ToString());
                    var claimsList = claims.Claims.ToList().Select(x => x.ToString()).ToList();

                    if (
                        contextPayload.Event == claimsList.Where(x => x.Split(": ")[0] == "event").Select(x => x.Split(": ")[1]).FirstOrDefault() &&
                        contextPayload.MediaId == claimsList.Where(x => x.Split(": ")[0] == "media_id").Select(x => x.Split(": ")[1]).FirstOrDefault() &&
                        contextPayload.WebhookId == claimsList.Where(x => x.Split(": ")[0] == "webhook_id").Select(x => x.Split(": ")[1]).FirstOrDefault() &&
                        contextPayload.SiteId == claimsList.Where(x => x.Split(": ")[0] == "site_id").Select(x => x.Split(": ")[1]).FirstOrDefault() &&
                        Convert.ToDateTime(contextPayload.EventTime) == Convert.ToDateTime(claimsList.Where(x => x.Split(": ")[0] == "event_time").Select(x => x.Split(": ")[1]).FirstOrDefault().Replace(@"""", ""))
                    )
                        return;
                }
                context.Result = new StatusCodeResult(401);
            }
            catch (Exception e)
            {
                context.Result = new StatusCodeResult(401);
            }
        }
    }
}
