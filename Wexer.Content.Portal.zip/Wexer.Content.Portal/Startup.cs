using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using FirebaseAdmin;
using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models.ContentPortal;
using Google.Apis.Auth.OAuth2;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Repositories.Database.Models;
using Wexer.Content.Portal.Repositories.EntityTransforms;
using Wexer.Content.Portal.Repositories.MediaService;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.UserService;
using Wexer.Content.Portal.Command.Core;
using Microsoft.Azure.ServiceBus;
using Wexer.Content.Portal.TitleService;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Azure.Management.Media;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Rest.Azure.Authentication;
using UserInfo = Wexer.Content.Portal.Clients.UserInfo;
using Wexer.Content.Portal.UserService.SignupService;
using Wexer.Content.Portal.EventService;
using Wexer.Content.Portal.Repositories.JWPlayer;

namespace Wexer.Content.Portal
{
    public class Startup
    {
        const string QueueName = "contentportal-commands";
        const string BackgroundQueueName = "contentportal-background-commands";
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            var builder = new ConfigurationBuilder().SetBasePath(env.ContentRootPath).AddConfiguration(configuration)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            var firebaseApp = FirebaseApp.Create(new AppOptions()
            {
                Credential = GoogleCredential.FromFile($"firebase.{env.EnvironmentName}.json")
            });

            Configuration = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var settings = new AppSettings();
            Configuration.Bind(settings);
            ClientCredential creds = new ClientCredential(settings.AzureMediaServiceClientId, settings.AzureMediaServiceClientSecret);
            var serviceClientCredentials = ApplicationTokenProvider.LoginSilentAsync(settings.AzureMediaServiceTenantId, creds, ActiveDirectoryServiceSettings.Azure).Result;
            var mediaServiceClient = new AzureMediaServicesClient(serviceClientCredentials) { SubscriptionId = settings.AzureMediaServiceSubscriptionId };

            services.AddMemoryCache();
            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
                options.Providers.Add<GzipCompressionProvider>();
            });
            services.AddHttpClient();
            services.AddSingleton(settings);
            var loggerfactory = new LogglyLoggerFactory(settings.LogglyAccountId, settings.LogglyUrl, settings.LogglyTags, settings.LogglyLevels);
            var modelTransformService = new ModelTransformService();
            services.AddSingleton<Logging.ILoggerFactory>(loggerfactory);
            services.AddSingleton<IModelTransformService, ModelTransformService>();
            services.AddSingleton<IUserBlobRepo>(new UserBlobRepo(settings.BlobUserConnectionString, loggerfactory, modelTransformService));
            services.AddSingleton<IBlobRepo>(new BlobRepo(settings.BlobContentConnectionString, loggerfactory, modelTransformService));
            services.AddSingleton<ITableRepo>(new TableRepo(settings.TableConnectionString, loggerfactory, modelTransformService));
            services.AddDbContext<ContentWriteStoreContext>(o => o.UseSqlServer(settings.SqlTableContentConnectionString));
            services.AddScoped<IContentWriteStoreRepo, ContentWriteStoreRepo>();
            services.AddSingleton<IFirebaseClient, FirebaseClient>();
            services.AddSingleton<IUserSignupService, UserSignupService>();
            services.AddSingleton<IMediaServiceRepo>(new MediaServiceRepo(mediaServiceClient, settings.AzureMediaServiceResourceGroup,
                settings.AzureMediaServiceAccountName, loggerfactory, settings.CdnUrl, settings.MediaServiceConnectionString));
            services.AddSingleton<IFileStoreRepo>(new FileStoreRepo(settings.FileStoreBlobConnectionString, loggerfactory, Configuration));
            services.AddSingleton<IJWPlayerRepo>(new JWPlayerRepo(settings.JWPlayerConfiguration.IsSandbox, settings.JWPlayerConfiguration.SiteId, settings.JWPlayerConfiguration.APISecret, settings.JWPlayerConfiguration.BaseAddressV2, settings.JWPlayerConfiguration.BaseAddressDelivery, loggerfactory, new BlobRepo(settings.BlobContentConnectionString, loggerfactory, modelTransformService)));
            services.AddScoped<IProviderService, ProviderService.ProviderService>();
            services.AddScoped<IChannelService, ChannelService.ChannelService>();
            services.AddScoped<IUserService, UserService.UserService>();
            services.AddSingleton<ICmsStoreRepo>(new CmsStoreRepo(settings.BlobContentConnectionString, loggerfactory, modelTransformService));
            services.AddSingleton<ICommandBus>(new CommandBus(loggerfactory, new QueueClient(settings.ServiceBusConnectionString, QueueName), new QueueClient(settings.ServiceBusConnectionString, BackgroundQueueName)));
            services.AddScoped<ITitleService, TitleService.TitleService>();
            services.AddScoped<IEventService, EventService.EventService>();
            services.AddCors(o => o.AddPolicy("Default", options => options
                                                                .AllowAnyHeader()
                                                                .AllowAnyMethod()
                                                                .SetIsOriginAllowed((host) => true)
                                                                .AllowCredentials()));
            services.AddAuthorization(o =>
            {
                o.AddPolicy("Joint", policy => policy.RequireAssertion(c => c.User.HasClaim(claim => claim.Type == ClaimTypes.Role
                                                                                && (Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.Admin)
                                                                                    || Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.Provider)
                                                                                    || Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.ClientProvider)))));

                o.AddPolicy("Admin", policy => policy.RequireAuthenticatedUser().RequireAssertion(c => c.User.HasClaim(claim => claim.Type == ClaimTypes.Role && (Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.Admin)))));
                o.AddPolicy("Provider", policy => policy.RequireAuthenticatedUser()
                        .RequireAssertion(c => c.User.HasClaim(claim => claim.Type == ClaimTypes.Role
                            && (Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.Provider)))));
                o.AddPolicy("AdminClientProvider", policy => policy.RequireAssertion(c => c.User.HasClaim(claim => claim.Type == ClaimTypes.Role
                                                                                && (Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.Admin)
                                                                                    || Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.ClientProvider)))));
                o.AddPolicy("ProviderClientProvider", policy => policy.RequireAssertion(c => c.User.HasClaim(claim => claim.Type == ClaimTypes.Role
                                                                                && (Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.Provider)
                                                                                    || Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.ClientProvider)))));

                o.AddPolicy("ClientProvider", policy => policy.RequireAssertion(c => c.User.HasClaim(claim => claim.Type == ClaimTypes.Role
                                                                               && Convert.ToInt32(claim.Value) == Convert.ToInt32(Roles.ClientProvider))));
            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).
                AddJwtBearer(options =>
                {
                    //options.Authority = $"https://securetoken.google.com/{settings.FirebaseProjectId}";
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidIssuer = $"https://securetoken.google.com/{settings.FirebaseProjectId}",
                        ValidateAudience = false,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKeyResolver = (s, securityToken, identifier, parameters) =>
                        {
                            var json = new WebClient().DownloadString("https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com");
                            var keys = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                            return keys.Values.Select(CreateSecurityKeyFromPublicKey).ToArray();
                        }
                    };
                    options.Events = new JwtBearerEvents()
                    {
                        OnTokenValidated = context =>
                        {
                            var tableRepo = context.HttpContext.RequestServices.GetRequiredService<ITableRepo>();
                            var firebaseClient = context.HttpContext.RequestServices.GetRequiredService<IFirebaseClient>();
                            var userId = context.Principal.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
                            var role = context.Principal.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                            if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(role))
                            {
                                var firebaseUserCheck = firebaseClient.GetUserAsync<UserInfo>(userId).GetAwaiter().GetResult();
                                if (firebaseUserCheck != null)
                                {
                                    var userIndexCheck = tableRepo.GetAsync<PortalUserIndex>("wexer", userId).GetAwaiter().GetResult();
                                    if (userIndexCheck != null)
                                    {
                                        return Task.CompletedTask;
                                    }
                                }
                            }
                            context.Fail("Unauthorized");
                            return Task.CompletedTask;
                        }
                    };
                });
            services.AddControllers();
            services.AddSwaggerGen(x =>
            {
                x.SwaggerDoc("v1", new OpenApiInfo() { Title = "Wexer Content Portal", Version = "v1" });
                x.AddSecurityDefinition("jwt_auth", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using Bearer scheme",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer"
                });
                x.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Id = "jwt_auth",
                                Type = ReferenceType.SecurityScheme
                            }
                        },
                        new List<string>()
                    }
                });
                var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                x.IncludeXmlComments(xmlPath);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            var swaggerOptions = new SwaggerOptions();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.ConfigureCustomExceptionMiddleware();

            //app.UseHttpsRedirection();
            app.UseRouting();
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = string.Empty;
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
            });

            app.UseCors("Default");
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseResponseCompression();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        static SecurityKey CreateSecurityKeyFromPublicKey(string data)
        {
            return new X509SecurityKey(new X509Certificate2(Encoding.UTF8.GetBytes(data)));
        }

    }
}
