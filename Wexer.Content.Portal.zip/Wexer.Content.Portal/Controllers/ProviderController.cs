﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Policy;
using System.Threading.Tasks;
using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.User;
using Wexer.Content.Portal.Models.User.Profiles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Management.Media.Models;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.Attributes;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.UserService;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Command.Commands.Channel;
using Wexer.Content.Portal.UserService.SignupService;

namespace Wexer.Content.Portal.Controllers
{
    [Produces("application/json")]
    [ApiController]
    public class ProviderController : CommonController
    {
        private IMemoryCache _cache;
        private readonly IProviderService _providerService;
        private readonly IFirebaseClient _firebaseClient;
        private readonly ILogger _logger;
        private readonly IUserSignupService _userSignupService;
        private readonly IUserService _userService;
        private readonly IChannelService _channelService;

        public ProviderController(ILoggerFactory loggerFactory, IMemoryCache cache,
            IProviderService providerService, IFirebaseClient firebaseClient, IUserSignupService userSignupService,
            IUserService userService, IChannelService channelService)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _cache = cache;
            _providerService = providerService;
            _firebaseClient = firebaseClient;
            _userSignupService = userSignupService;
            _userService = userService;
            _channelService = channelService;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("staff/users")]
        public async Task<IActionResult> Get()
        {
            try
            {
                var providers = await _providerService.List().ConfigureAwait(false);
                var firebaseProvider = await _firebaseClient.GetUsersAsync(Roles.Provider).ConfigureAwait(false);
                var admin = await _firebaseClient.GetUsersAsync(Roles.Admin).ConfigureAwait(false);

                return Ok(
                    new
                    {
                        Providers = providers.Select(t => new
                        {
                            t.Email,
                            UserRole = 1,
                            t.ProviderId,
                            firebaseProvider.Where(x => x.Uid == t.Tag).FirstOrDefault().DisplayName,
                            Password = "RFdU7C8nME9@",
                            Uid = t.Tag
                        }),
                        Admins = admin.Select(x => new { x.Email, UserRole = 0, x.Uid, x.DisplayName })
                    });


            }
            catch (Exception e)
            {

                throw e;
            }
        }

        /// <summary>
        /// Creates a provider
        /// </summary>
        /// <param name="user"></param>
        /// <returns>A newly created provider user</returns>
        /// <response code="201">Returns a newly created provider user</response>
        /// <response code="500">Server error</response>
        /// <response code="400">If request had mising information</response>
        /// <response code="401">If token was invalid</response>
        /// <response code="403">If user not authorized</response>
        /// <response code="409">If user already exists</response>
        [Authorize(Policy = "Admin")]
        [HttpPost("api/v1/provider")]
        [ProducesResponseType(201, Type = typeof(Models.ContentPortal.Provider))]
        [ProducesResponseType(500, StatusCode = 500)]
        [ProducesResponseType(409, StatusCode = 409)]
        [ProducesResponseType(400, StatusCode = 400)]
        [ProducesResponseType(401, StatusCode = 401)]
        [ProducesResponseType(403, StatusCode = 403)]
        public async Task<ActionResult<HttpStatusCode>> CreateProvider([FromBody] PortalUser user)
        {
            try
            {
                if (user != null && !string.IsNullOrEmpty(user.DisplayName) && !string.IsNullOrEmpty(user.Password) && !string.IsNullOrEmpty(user.Email) && (user.UserRole == Roles.Provider || user.UserRole == Roles.ClientProvider))
                {
                    if (user.MediaPlatform == Models.Tenant.MediaPlatform.JWPlayer && string.IsNullOrEmpty(user.JWPlayerSiteId))
                    {
                        return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Site Id is required for JWPlayer media platform" });
                    }
                    else
                    {
                        var response = await _providerService.Create(user).ConfigureAwait(false);

                        if (response.Item1 == HttpStatusCode.Created && response.Item2 != null)
                        {
                            if (_cache.TryGetValue(CacheKeys.Providers, out Models.ContentPortal.Provider[] providers))
                            {
                                _cache.Remove(CacheKeys.Providers);
                            }

                            return CreatedAtAction("CreateProvider", response.Item2);
                        }
                        else
                        {
                            return StatusCode(500, new ErrorDetails { StatusCode = 500, Message = "User creation failed" });
                        }
                    }
                }
                return BadRequest("Request has invalid parameters");
            }
            catch (Exception e)
            {
                _logger.Error("CreateProvider exception", "error", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Joint")]
        [HttpGet("api/v1/providers")]
        public async Task<ActionResult> GetListProvider()
        {
            try
            {
                Models.ContentPortal.Provider[] providers = null;
                if (!_cache.TryGetValue(CacheKeys.Providers, out providers))
                {
                    var blobProviders = await _providerService.List().ConfigureAwait(false);
                    if (blobProviders != null && blobProviders.Length > 0)
                    {
                        _cache.Set(CacheKeys.Providers, blobProviders, DateTimeOffset.UtcNow.AddYears(1));
                        providers = blobProviders;
                    }
                }

                if (providers != null && providers.Length > 0)
                {
                    return Ok(providers);
                }

                return NotFound("No provider user found");
            }
            catch (Exception e)
            {
                _logger.Warn("GetListProvider failed", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [HttpGet("api/v1/provider/{uId}")]
        public async Task<ActionResult> GetProvider(string uId)
        {
            try
            {
                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                Models.ContentPortal.Provider[] providers = null;

                if (string.IsNullOrEmpty(uId))
                {
                    BadRequest("Provider Id cannot be empty");
                }
                uId = uId.Trim();
                if (!_cache.TryGetValue(CacheKeys.Providers, out providers))
                {
                    var blobProviders = await _providerService.List().ConfigureAwait(false);
                    _cache.Set(CacheKeys.Providers, blobProviders, DateTimeOffset.UtcNow.AddYears(1));
                    providers = blobProviders;
                }

                if (providers != null && providers.Length > 0 && providers.Any(t => t.Tag == uId))
                {
                    return Ok(providers.FirstOrDefault(t => t.Tag == uId));
                }

                return NotFound("No provider user found");
            }
            catch (Exception e)
            {
                _logger.Warn("GetProvider failed", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [HttpPost("api/v1/provider/forgotpassword")]
        public async Task<ActionResult<HttpStatusCode>> ForgetPassword([FromForm] string email)
        {
            try
            {
                if (!string.IsNullOrEmpty(email))
                {
                    var link = await _firebaseClient.GeneratePasswordReset(email).ConfigureAwait(false);
                    if (string.IsNullOrEmpty(link))
                    {
                        return Ok(link);
                    }
                    return NoContent();
                }

                return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.Warn("ForgetPassword failed", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Admin")]
        [HttpDelete("api/v1/providers")]
        public async Task<ActionResult<HttpStatusCode>> DeleteProvider([FromBody] List<string> users)
        {
            try
            {
                var successResults = new List<string>();
                if (users == null || users.Count == 0 || users.Any(g => string.IsNullOrEmpty(g)))
                {
                    return BadRequest();
                }
                for (var i = 0; i < users.Count; i++)
                {
                    var result = await _providerService.Delete(users[i]).ConfigureAwait(false);
                    if (result == HttpStatusCode.OK)
                    {
                        var removeFirebaseUser = await _firebaseClient.DeleteUserAsync(users[i]).ConfigureAwait(false);
                        if (removeFirebaseUser)
                        {
                            if (_cache.TryGetValue(CacheKeys.Providers, out Models.ContentPortal.Provider[] providers))
                            {
                                _cache.Remove(CacheKeys.Providers);
                            }
                            successResults.Add(users[i]);
                        }
                    }
                }
                return Ok(successResults);
            }
            catch (Exception e)
            {
                _logger.Warn("Deleteprovider failed", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Admin")]
        [HttpPut("api/v1/provider/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> UpdateProvider(string tag, [FromBody] Models.ContentPortal.Provider provider)
        {
            try
            {
                var existingProvider = await _providerService.Get(tag).ConfigureAwait(false);

                if (existingProvider == null)
                {
                    return NotFound();
                }

                if (_cache.TryGetValue(CacheKeys.Providers, out Models.ContentPortal.Provider[] providers) && providers != null)
                {
                    _cache.Remove(CacheKeys.Providers);
                }

                if (provider != null && existingProvider.Email.ToLowerInvariant() == provider.Email.ToLowerInvariant())
                {
                    if (existingProvider != null)
                    {
                        var updatedProvider = await _providerService.Update(provider).ConfigureAwait(false);

                        if (updatedProvider != null)
                        {
                            UserRecordArgs args = new UserRecordArgs();
                            args.Email = updatedProvider.Email;
                            args.Uid = updatedProvider.Tag;
                            args.DisplayName = updatedProvider.Name;
                            var updateFirebaseUser = await _firebaseClient.UpdateUserAsync<UserRecord>(args).ConfigureAwait(false);
                            if (updateFirebaseUser != null)
                            {
                                return Ok(updatedProvider);
                            }
                        }
                        return StatusCode(500);
                    }
                }

                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        [HttpPut("api/v1/resetpassword/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> ResetPassword(string tag, string password)
        {
            try
            {
                var userInfo = await _firebaseClient.GetUserAsync<UserInfo>(tag).ConfigureAwait(false);
                UserRecordArgs record = new UserRecordArgs();
                record.DisplayName = userInfo.DisplayName;
                record.Password = password;
                record.PhoneNumber = userInfo.PhoneNumber;
                record.Uid = userInfo.UId;
                var result = await _firebaseClient.UpdateUserAsync<UserRecord>(record).ConfigureAwait(false);
                if (result != null)
                {
                    return Ok(result);
                }
                return StatusCode(500);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [APIAuth]
        [HttpGet("private/api/v1/providers/{providerId?}")]
        public async Task<ActionResult<HttpStatusCode>> GetProviders(string providerId)
        {
            try
            {
                var providers = await _providerService.List().ConfigureAwait(false);
                var channels = await _channelService.List().ConfigureAwait(false);

                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                if (providers != null && providers.Length > 0 && channels != null && channels.Length > 0)
                {
                    if (!string.IsNullOrEmpty(providerId))
                    {
                        providers = providers.Where(t => t.Tag == providerId).ToArray();
                    }

                    var result = await ShapeForVirtual(providers, channels, lang).ConfigureAwait(false);
                    if (result != null && result.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(providerId))
                        {
                            return Ok(result.First());
                        }
                        return Ok(result);
                    }

                }

                return NotFound();

            }
            catch (Exception e)
            {
                _logger.Warn("GetProviders exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        private async Task<List<dynamic>> ShapeForVirtual(Models.ContentPortal.Provider[] providers, Channel[] channels, string lang = "en-GB")
        {
            try
            {
                var response = new List<dynamic>();
                foreach (var provider in providers)
                {
                    response.Add(new
                    {
                        provider.Tag,
                        provider.Name,
                        provider.PhoneNumber,
                        provider.ProviderId,
                        provider.Email,
                        provider.Contact,
                        Channels = channels.Where(x => x.Provider == provider.Tag).Select(x => ShapeChannelForVirtual(x, lang))
                    });
                }

                return response;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private object ShapeChannelForVirtual(Channel channel, string lang)
        {
            try
            {
                return new
                {
                    channel.Tag,
                    Name = channel.Name.FlattenByLanguage(lang),
                    DisplayName = channel.DisplayName.FlattenByLanguage(lang),
                    Description = channel.Description.FlattenByLanguage(lang),
                    channel.CreatedDate,
                    channel.Availability,
                    channel.Active,
                    channel.LastUpdatedDate,
                    channel.ProfileImageUrl,
                    channel.MediaSpaceImageUrl,
                    channel.Provider,
                    channel.Tenants
                };
            }
            catch (Exception e)
            {

                throw e;
            }
        }

    }
}
