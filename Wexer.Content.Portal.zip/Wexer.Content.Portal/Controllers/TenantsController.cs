﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.Tenant;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Repositories.Database.Models;
using Wexer.Content.Portal.Repositories.Database;
using System.Threading;
using Wexer.Content.Portal.ReadStore;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Command.Commands.Tenant;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Clients;
using FirebaseAdmin.Auth;
using System.IO;
using ClosedXML.Excel;

namespace Wexer.Content.Portal.Controllers
{
    [Authorize(Policy = "Admin")]
    [ApiController]
    public class TenantsController : CommonController
    {
        private readonly IBlobRepo _blobRepo;
        private readonly IContentWriteStoreRepo _db;
        private readonly IMemoryCache _cache;
        private readonly IChannelService _channelService;
        private readonly ICommandBus _commandBus;
        private readonly ILogger _logger;
        private readonly IProviderService _providerService;
        private readonly IFirebaseClient _firebaseClient;
        public TenantsController(IBlobRepo blobRepo, IContentWriteStoreRepo db, IMemoryCache memoryCache,
            IChannelService channelService, ICommandBus bus, ILoggerFactory loggerFactory, IProviderService providerService,
            IFirebaseClient firebaseClient)
        {
            _blobRepo = blobRepo;
            _db = db;
            _cache = memoryCache;
            _channelService = channelService;
            _commandBus = bus;
            _providerService = providerService;
            _logger = loggerFactory.GetLoggerForClass(this);
            _firebaseClient = firebaseClient;
        }

        [HttpGet("api/v1/tenant/{tenantId?}")]
        public async Task<ActionResult<HttpStatusCode>> Get(string tenantId, CancellationToken stoppingToken)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                if (!_cache.TryGetValue(CacheKeys.Channels, out Channel[] channels))
                {
                    channels = await _channelService.List().ConfigureAwait(false);
                    channels = channels ?? new Channel[0];
                }

                if (!_cache.TryGetValue(CacheKeys.Providers, out Provider[] providers))
                {
                    providers = await _providerService.List().ConfigureAwait(false);
                    providers = providers ?? new Provider[0];
                }

                if (!_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<TenantDetail> tenants))
                {
                    var entities = await Task.Run(() => _db.Read<TenantDetail>(), stoppingToken).ConfigureAwait(false);
                    if (entities != null && entities.Data != null && entities.Data.Count > 0)
                    {
                        _cache.Set(CacheKeys.Tenants, entities.Data.Select(t => t.Entity), new MemoryCacheEntryOptions
                        {
                            SlidingExpiration = TimeSpan.FromDays(1),
                            AbsoluteExpiration = DateTimeOffset.UtcNow.AddDays(356)
                        });

                        tenants = entities.Data.Select(x => x.Entity);
                    }
                    else
                    {
                        return NotFound();
                    }

                }

                tenants = tenants.Where(x => string.IsNullOrEmpty(tenantId) ? true : x.TenantID == tenantId.Trim());
                if (tenants == null || tenants.Count() == 0)
                {
                    return NotFound();
                }

                var tenantsResponse = tenants
                    .Select(x => new
                    {
                        Tenant = new
                        {
                            x.TenantID,
                            x.Name,
                            x.ApiKey,
                            x.ProviderId,
                            x.TimeZoneInfo,
                            ProviderEmail = providers.Where(f => f.Tag == x.ProviderId).Select(f => f.Email).FirstOrDefault(),
                            Active = x.IsProviderActive,
                            MediaPlatform = providers.Where(f => f.Tag == x.ProviderId).Select(f => f.MediaPlatform).FirstOrDefault(),
                            JwPlayerSiteId = providers.Where(f => f.Tag == x.ProviderId).Select(f => f.JWPlayerSiteId).FirstOrDefault(),
                            x.LanguageTag,
                            x.LanguageCodes
                        },
                        Channels = channels.Where(t => t.Tenants.Contains(x.TenantID)).Select(t => new
                        {
                            t.Tag,
                            Name = t.Name.FlattenByLanguage(lang),
                            DisplayName = t.DisplayName.FlattenByLanguage(lang),
                            ProviderId = t.Provider
                        })
                    });

                return Ok(tenantsResponse);

            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        [HttpPost("api/v1/tenant")]
        public async Task<ActionResult<HttpStatusCode>> CreateTenant([FromBody] TenantViewModel tenantRequest)
        {
            try
            {
                if (tenantRequest != null && tenantRequest.Tenant != null)
                {
                    var existingTenants = await Task.Run(() => _db.Read<TenantDetail>()).ConfigureAwait(false);
                    var existingProviders = await _providerService.List().ConfigureAwait(false);

                    if (existingTenants != null && existingTenants.Data.Count() > 0 && existingTenants.Data.Where(x => x.Entity.TenantID == tenantRequest.Tenant.TenantID).FirstOrDefault() != null)
                    {
                        return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Tenant already exists with tenantid : " + tenantRequest.Tenant.TenantID });
                    }
                    if (tenantRequest.Tenant.IsProviderActive && existingProviders != null && existingProviders.Count() > 0 && existingProviders.FirstOrDefault(x => x.Email == tenantRequest.Email) != null)
                    {
                        return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Provider already exists with email id : " + tenantRequest.Email });
                    }

                    if (_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<TenantDetail> tenants))
                    {
                        _cache.Remove(CacheKeys.Tenants);
                    }

                    if (tenantRequest.Tenant.IsProviderActive)
                    {
                        if (!string.IsNullOrEmpty(tenantRequest.Email) && !string.IsNullOrEmpty(tenantRequest.Password))
                        {
                            if (tenantRequest.MediaPlatform == MediaPlatform.JWPlayer && string.IsNullOrEmpty(tenantRequest.JWPlayerSiteId))
                            {
                                return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Site Id is required for JWPlayer media platform" });
                            }
                            else
                            {
                                var providerResult = await _providerService.Create(new PortalUser
                                {
                                    DisplayName = tenantRequest.Tenant.Name,
                                    Email = tenantRequest.Email,
                                    Password = tenantRequest.Password,
                                    UserRole = Roles.ClientProvider,
                                    TenantId = tenantRequest.Tenant.TenantID,
                                    Stage1Encode = false,
                                    MediaPlatform = tenantRequest.MediaPlatform,
                                    JWPlayerSiteId = tenantRequest.JWPlayerSiteId
                            }).ConfigureAwait(false);

                                if (providerResult.Item1 == HttpStatusCode.Created && providerResult.Item2 != null)
                                {
                                    if (_cache.TryGetValue(CacheKeys.Providers, out Provider[] provs))
                                    {
                                        _cache.Remove(CacheKeys.Providers);
                                    }

                                    var channel = await _channelService.Create(new ChannelViewModel
                                    {
                                        Name = tenantRequest.Tenant.Name,
                                        DisplayName = tenantRequest.Tenant.Name,
                                        Active = false,
                                        Availability = new List<ChannelAvailability> { ChannelAvailability.AppAndWeb },
                                        Description = $"Default Channel for {tenantRequest.Tenant.Name}",
                                        Provider = providerResult.Item2.Tag,
                                        Tenants = new List<string> { tenantRequest.Tenant.TenantID },
                                        IsTenantProviderChannel = true
                                    }).ConfigureAwait(false);

                                    if (channel != null)
                                    {
                                        if (_cache.TryGetValue(CacheKeys.Channels, out Channel[] channels))
                                        {
                                            _cache.Remove(CacheKeys.Channels);
                                        }

                                        tenantRequest.Tenant.ProviderId = providerResult.Item2.Tag;
                                    }
                                }
                            }
                        }
                        else
                        {
                            return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Email Id or password can't be blank" });
                        }
                    }

                    await Task.Run(() => _db.Create(tenantRequest.Tenant.TenantID, tenantRequest.Tenant, "*")).ConfigureAwait(false);

                    var result = await RewriteDocument().ConfigureAwait(false);
                    if (result.HttpStatusCode == (int)HttpStatusCode.OK)
                    {
                        return CreatedAtAction("CreateTenant", tenantRequest.Tenant);
                    }
                }
                return BadRequest("Invalid request");
            }
            catch (Exception e)
            {
                _logger.Warn("CreateTenant exception", "warn", e.ToString());
                return BadRequest(new { code = HttpStatusCode.InternalServerError, message = "Error while creating tenant" });
            }
        }

        [HttpPut("api/v1/tenant/{tenantId}")]
        public async Task<ActionResult<HttpStatusCode>> UpdateTenant(string tenantId, [FromBody] TenantViewModel model)
        {
            try
            {
                var channelName = string.IsNullOrEmpty(model.ChannelName) ? model.Tenant.Name : model.ChannelName;
                var providerName = string.IsNullOrEmpty(model.ProviderName) ? model.Tenant.Name : model.ProviderName;
                if (model != null && tenantId == model.Tenant.TenantID)
                {
                    if (model.MediaPlatform == MediaPlatform.JWPlayer && string.IsNullOrEmpty(model.JWPlayerSiteId))
                    {
                        return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Site Id is required for JWPlayer media platform" });
                    }

                    var existingTenants = await Task.Run(() => _db.Read<TenantDetail>()).ConfigureAwait(false);
                    if (existingTenants != null && existingTenants.Data != null && existingTenants.Data.Any(x => x.Entity.TenantID == tenantId))
                    {
                        var existingTenant = existingTenants.Data.FirstOrDefault(x => x.Entity.TenantID == tenantId);
                        model.Tenant = await UpdateTenantDetail(existingTenant.Entity, model.Tenant).ConfigureAwait(false);
                    }
                    else
                    {
                        return NotFound("Tenant not found");
                    }

                    if (_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<TenantDetail> tenants))
                    {
                        _cache.Remove(CacheKeys.Tenants);
                    }

                    if (!model.Tenant.IsProviderActive)
                    {
                        if (!string.IsNullOrEmpty(model.Tenant.ProviderId))
                        {
                            var disabledProvider = await _firebaseClient.UpdateUserAsync<UserRecord>(new UserRecordArgs
                            {
                                Uid = model.Tenant.ProviderId,
                                Disabled = true,
                            }).ConfigureAwait(false);

                            if (disabledProvider == null)
                            {
                                return StatusCode(500, "Provider could not be disabled");
                            }
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(model.Tenant.ProviderId))
                        {
                            if (!string.IsNullOrEmpty(channelName) && !string.IsNullOrEmpty(providerName))
                            {
                                var enabledProvider = await _firebaseClient.UpdateUserAsync<UserRecord>(new UserRecordArgs
                                {
                                    Uid = model.Tenant.ProviderId,
                                    Disabled = false,
                                    DisplayName = providerName
                                }).ConfigureAwait(false);

                                var provider = await _providerService.Get(model.Tenant.ProviderId).ConfigureAwait(false);
                                if (provider != null)
                                {
                                    provider.Name = providerName;
                                    provider.MediaPlatform = model.MediaPlatform;
                                    provider.JWPlayerSiteId = model.JWPlayerSiteId;
                                    await _providerService.Update(provider).ConfigureAwait(false);
                                    if (_cache.TryGetValue(CacheKeys.Providers, out Provider[] provs))
                                    {
                                        _cache.Remove(CacheKeys.Providers);
                                    }

                                    var channelList = await _channelService.List().ConfigureAwait(false);
                                    if (channelList != null && channelList.Any(x => x.Provider == provider.Tag))
                                    {
                                        var channel = channelList.FirstOrDefault(x => x.Provider == provider.Tag);
                                        channel.Name = channel.DisplayName = channelName;
                                        await _channelService.Update(channel, string.Empty).ConfigureAwait(false);
                                        if (_cache.TryGetValue(CacheKeys.Channels, out Provider[] channels))
                                        {
                                            _cache.Remove(CacheKeys.Channels);
                                        }
                                    }
                                }

                                if (enabledProvider == null)
                                {
                                    return StatusCode(500, "Provider could not be enabled");
                                }
                            }
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(model.Password) || string.IsNullOrEmpty(model.Email))
                            {
                                return BadRequest();
                            }
                            else
                            {
                                var providerResult = await _providerService.Create(new PortalUser
                                {
                                    DisplayName = providerName,
                                    Email = model.Email,
                                    Password = model.Password,
                                    UserRole = Roles.ClientProvider,
                                    TenantId = model.Tenant.TenantID,
                                    Stage1Encode = false,
                                    MediaPlatform = model.MediaPlatform,
                                    JWPlayerSiteId = model.JWPlayerSiteId
                                }).ConfigureAwait(false);

                                if (providerResult.Item1 == HttpStatusCode.Created && providerResult.Item2 != null)
                                {
                                    if (_cache.TryGetValue(CacheKeys.Providers, out Provider[] provs))
                                    {
                                        _cache.Remove(CacheKeys.Providers);
                                    }
                                    var channel = await _channelService.Create(new ChannelViewModel
                                    {
                                        Name = channelName,
                                        DisplayName = channelName,
                                        Active = false,
                                        Availability = new List<ChannelAvailability> { ChannelAvailability.AppAndWeb },
                                        Description = $"Default Channel for {model.Tenant.Name}",
                                        Provider = providerResult.Item2.Tag,
                                        Tenants = new List<string> { model.Tenant.TenantID },
                                        IsTenantProviderChannel = true
                                    }).ConfigureAwait(false);

                                    if (channel != null)
                                    {
                                        if (_cache.TryGetValue(CacheKeys.Channels, out Provider[] channels))
                                        {
                                            _cache.Remove(CacheKeys.Channels);
                                        }
                                        model.Tenant.ProviderId = providerResult.Item2.Tag;
                                    }
                                }
                                else
                                {
                                    return StatusCode((int)providerResult.Item1);
                                }
                            }
                        }

                    }

                    await Task.Run(() => _db.Update(tenantId, model.Tenant)).ConfigureAwait(false);

                    var result = await RewriteDocument().ConfigureAwait(false);
                    if (result.HttpStatusCode == (int)HttpStatusCode.OK)
                    {
                        return Ok(new { model.Tenant, model.MediaPlatform, model.JWPlayerSiteId});
                    }
                }
                return BadRequest("Invalid request");
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        [HttpDelete("api/v1/tenant/{tenantId}")]
        public async Task<ActionResult<HttpStatusCode>> DeleteTenant(string tenantId)
        {
            try
            {
                if (_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<TenantDetail> tenants))
                {
                    _cache.Remove(CacheKeys.Tenants);
                }

                await Task.Run(() => _db.Delete<TenantDetail>(tenantId)).ConfigureAwait(false);

                var result = await RewriteDocument().ConfigureAwait(false);
                if (result.HttpStatusCode == (int)HttpStatusCode.OK)
                {
                    return Ok();
                }

                return BadRequest("Invalid request");
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [NonAction]
        async Task<ReadStoreWriteOperation<EntitySet<TenantDetail>>> RewriteDocument(string tenant = "*")
        {
            try
            {
                var dataOperation = await Task.Run(() => _db.Read<TenantDetail>()).ConfigureAwait(false);
                if (tenant != "*")
                {
                    dataOperation = await Task.Run(() => _db.ReadTenantData<TenantDetail>(tenant)).ConfigureAwait(false);
                }

                if (dataOperation.Data != null)
                {
                    return await _blobRepo.PutSetAsync(tenant, new EntitySet<TenantDetail>
                    {
                        Count = dataOperation.Data.Count,
                        Items = dataOperation.Data.Select(x => x.Entity).ToArray()
                    }, createSnapshot: true);
                }
                return null;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        [HttpPut("api/v1/tenant/publish")]
        public async Task<ActionResult<HttpStatusCode>> PublishTenant([FromBody] TenantPublishViewModel tenantChannelRequest)
        {
            try
            {
                var tenant = GetTenantIDFromHeaders();
                if (tenantChannelRequest != null && !string.IsNullOrEmpty(tenant))
                {
                    if (tenantChannelRequest.ChannelIdsToPublish != null && tenantChannelRequest.ChannelIdsToPublish.Count > 0)
                    {
                        await _commandBus.SendAsync(new TenantPublishCommand
                        {
                            TenantId = tenant,
                            ChannelsToPublish = tenantChannelRequest.ChannelIdsToPublish,
                        }).ConfigureAwait(false);
                    }


                    if (tenantChannelRequest.ChannelIdsToUnPublish != null && tenantChannelRequest.ChannelIdsToUnPublish.Count > 0)
                    {
                        await _commandBus.SendAsync(new TenantUnPublishCommand
                        {
                            TenantId = tenant,
                            ChannelsToUnPublish = tenantChannelRequest.ChannelIdsToUnPublish,
                        }).ConfigureAwait(false);
                    }

                    return NoContent();
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("PublishTenant exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        async Task<TenantDetail> UpdateTenantDetail(TenantDetail existing, TenantDetail incoming)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(incoming.Name) && existing.Name != incoming.Name)
                {
                    existing.Name = incoming.Name;
                }

                if (!string.IsNullOrWhiteSpace(incoming.ApiKey) && existing.ApiKey != incoming.ApiKey)
                {
                    existing.ApiKey = incoming.ApiKey;
                }

                existing.IsProviderActive = incoming.IsProviderActive;
                existing.TimeZoneInfo = incoming.TimeZoneInfo;
                existing.ProviderId = incoming.ProviderId;
                existing.LanguageTag = incoming.LanguageTag;
                existing.LanguageCodes = incoming.LanguageCodes;


                //existing.AllowedAgreement = incoming.AllowedAgreement;
                //existing.AzureTenantID = incoming.AzureTenantID;
                //existing.BaseURL = incoming.BaseURL;
                //existing.ClientId = incoming.ClientId;
                //existing.ClientSecret = incoming.ClientSecret;
                //existing.Connect = incoming.Connect;
                //existing.ConnectSource = incoming.ConnectSource;
                //existing.ContactEmailAddress = incoming.ContactEmailAddress;
                //existing.ContactPersonName = incoming.ContactPersonName;
                //existing.CustomerNumber = incoming.CustomerNumber;
                //existing.DataSource = incoming.DataSource;
                //existing.EndpointKey = incoming.EndpointKey;
                //existing.EventCardSize = incoming.EventCardSize;
                //existing.ExtendedAttributes = incoming.ExtendedAttributes;
                //existing.IdentityProvider = incoming.IdentityProvider;
                //existing.IsAccessCodeMandatory = incoming.IsAccessCodeMandatory;
                //existing.IsAdestraEnabled = incoming.IsAdestraEnabled;
                //existing.IsMasterTenant = incoming.IsMasterTenant;
                //existing.LanguageTag = incoming.LanguageTag;
                //existing.LocalyticsKey = incoming.LocalyticsKey;
                //existing.MarketingDetail = incoming.MarketingDetail;
                //existing.NoReplyEmailAddress = incoming.NoReplyEmailAddress;
                //existing.ProductList = incoming.ProductList;
                //existing.ShowChannels = incoming.ShowChannels;
                //existing.ShowClassOfTheDay = incoming.ShowClassOfTheDay;
                //existing.ShowDiscountTextField = incoming.ShowDiscountTextField;
                //existing.ShowLiveConnect = incoming.ShowLiveConnect;
                //existing.ShowLiveEvent = incoming.ShowLiveEvent;
                //existing.SubscriptionKey = incoming.SubscriptionKey;
                //existing.TenantID = incoming.TenantID;
                //existing.TenantPaymenetProviderDetail = incoming.TenantPaymenetProviderDetail;
                //existing.Url = incoming.Url;
                //existing.VimeoFolderId = incoming.VimeoFolderId;
                //existing.VimeoToken = incoming.VimeoToken;

                return existing;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("api/v1/tenant/tenantdownloadreport")]
        public IActionResult DownloadTenantUploadReport(DateTime startDate, DateTime endDate, string type = "TU")
        {
            try
            {
                if (startDate != null && endDate != null)
                {
                    // BU - Billable User Report
                    // TU - Tenant Upload Report
                    if (type == "BU")
                    {
                        var entities = _db.FindAll<OnDemandUrlRequest>(x =>
                    (x.EventDate.Date >= startDate.Date && x.EventDate.Date <= endDate.Date)).ToList();

                        if (entities != null && entities.Count > 0)
                        {
                            string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            string fileName = "UserBillableReport-" + DateTime.UtcNow.ToString() + ".xlsx";

                            using (var workbook = new XLWorkbook())
                            {
                                IXLWorksheet worksheet = workbook.Worksheets.Add("Sheet 1");
                                worksheet = GetWorksheetForUserBillableReport(worksheet, entities);

                                using (var stream = new MemoryStream())
                                {
                                    workbook.SaveAs(stream);
                                    var content = stream.ToArray();
                                    _logger.Trace("File content set for file named :", fileName);
                                    return File(content, contentType, fileName);
                                }
                            }
                        }
                    }
                    else
                    {
                        var entities = _db.FindAll<OndemandTenantUploadTrackingEntity>(x =>
                        ((x.UploadedDate.Date >= startDate.Date && x.UploadedDate.Date <= endDate.Date)
                        || ((x.UploadedDate.Date == startDate.Date) && (x.UploadedDate.Date == endDate.Date)))).ToList();

                        if (entities != null && entities.Count > 0)
                        {
                            string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            string fileName = "TenantUploadReport-" + DateTime.UtcNow.ToString() + ".xlsx";

                            using (var workbook = new XLWorkbook())
                            {
                                IXLWorksheet worksheet = workbook.Worksheets.Add("Sheet 1");
                                worksheet = GetWorksheetWithData(worksheet, entities);

                                using (var stream = new MemoryStream())
                                {
                                    workbook.SaveAs(stream);
                                    var content = stream.ToArray();
                                    _logger.Trace("File content set for file named :", fileName);
                                    return File(content, contentType, fileName);
                                }
                            }
                        }

                    }
                }
                _logger.Trace("No data found for the provided dates");
                return BadRequest("No data found for the provided dates");
            }
            catch (Exception e)
            {
                _logger.Trace("Error while generating excel", e.ToString());
                return StatusCode(500);
            }
        }

        private IXLWorksheet GetWorksheetWithData(IXLWorksheet worksheet, List<OndemandTenantUploadTrackingEntity> entities)
        {
            worksheet.Cells("A1:Q1").Style.Fill.BackgroundColor = XLColor.FromArgb(1, 106, 168, 78);
            worksheet.Column(14).Style.NumberFormat.Format = "yyyy-MM-ddTHH:mm:ss.ms";
            worksheet.Column(15).Style.NumberFormat.Format = "yyyy-MM-ddTHH:mm:ss.ms";

            worksheet.Cell(1, 1).Value = "Id";
            worksheet.Cell(1, 2).Value = "TitleTag";
            worksheet.Cell(1, 3).Value = "Title";
            worksheet.Cell(1, 4).Value = "FileName";
            worksheet.Cell(1, 5).Value = "FileSize";
            worksheet.Cell(1, 6).Value = "TitleType";
            worksheet.Cell(1, 7).Value = "DurationSeconds";
            worksheet.Cell(1, 8).Value = "ProviderId";
            worksheet.Cell(1, 9).Value = "ProviderName";
            worksheet.Cell(1, 10).Value = "EncodedDurationMinute";
            worksheet.Cell(1, 11).Value = "EncodedDurationMultiplier";
            worksheet.Cell(1, 12).Value = "EventId";
            worksheet.Cell(1, 13).Value = "EventName";
            worksheet.Cell(1, 14).Value = "UploadedDate";
            worksheet.Cell(1, 15).Value = "EncodedDate";
            worksheet.Cell(1, 16).Value = "UploadedByUserEmail";
            worksheet.Cell(1, 17).Value = "UploadedByUserId";

            for (int i = 0; i < entities.Count; i++)
            {
                worksheet.Cell(i + 2, 1).Value = entities[i].Id;
                worksheet.Cell(i + 2, 2).Value = entities[i].TitleTag;
                worksheet.Cell(i + 2, 3).Value = entities[i].Title;
                worksheet.Cell(i + 2, 4).Value = entities[i].FileName;
                worksheet.Cell(i + 2, 5).Value = entities[i].FileSize;
                worksheet.Cell(i + 2, 6).Value = entities[i].TitleType == 1 ? "Title" : "Trailer";
                worksheet.Cell(i + 2, 7).Value = entities[i].DurationSecond;
                worksheet.Cell(i + 2, 8).Value = entities[i].ProviderId;
                worksheet.Cell(i + 2, 9).Value = entities[i].ProviderName;
                worksheet.Cell(i + 2, 10).Value = entities[i].EncodedDurationMinutes;
                worksheet.Cell(i + 2, 11).Value = entities[i].EncodedDurationMultiplier;
                worksheet.Cell(i + 2, 12).Value = entities[i].EventId;
                worksheet.Cell(i + 2, 13).Value = entities[i].EventName;
                worksheet.Cell(i + 2, 14).Value = entities[i].UploadedDate;
                worksheet.Cell(i + 2, 15).Value = entities[i].EncodedDate;
                worksheet.Cell(i + 2, 16).Value = entities[i].UploadedByUserEmail;
                worksheet.Cell(i + 2, 17).Value = entities[i].UploadedByUserId;
            }
            worksheet.Columns().AdjustToContents();
            _logger.Trace("Worksheet created");
            return worksheet;
        }
        private IXLWorksheet GetWorksheetForUserBillableReport(IXLWorksheet worksheet, List<OnDemandUrlRequest> entities)
        {
            worksheet.Cells("A1:H1").Style.Fill.BackgroundColor = XLColor.FromArgb(1, 106, 168, 78);
            worksheet.Cells("A1:H1").Style.Font.FontColor = XLColor.White;
            worksheet.Column(6).Style.NumberFormat.Format = "yyyy-MM-dd";
            worksheet.Column(4).SetDataType(XLDataType.Text);
            worksheet.Column(8).SetDataType(XLDataType.Text);

            worksheet.Cell(1, 1).Value = "Video Id";
            worksheet.Cell(1, 2).Value = "Provider Id";
            worksheet.Cell(1, 3).Value = "Provider Name";
            worksheet.Cell(1, 4).Value = "User Id";
            worksheet.Cell(1, 5).Value = "Video Duration (Secs)";
            worksheet.Cell(1, 6).Value = "Event Date";
            worksheet.Cell(1, 7).Value = "Client Id";
            worksheet.Cell(1, 8).Value = "Customer Number";

            for (int i = 0; i < entities.Count; i++)
            {
                worksheet.Cell(i + 2, 1).Value = entities[i].VideoId;
                worksheet.Cell(i + 2, 2).Value = entities[i].ProviderId;
                worksheet.Cell(i + 2, 3).Value = entities[i].ProviderName;
                worksheet.Cell(i + 2, 4).Value = "'" + entities[i].UserId;
                worksheet.Cell(i + 2, 5).Value = entities[i].VideoDurationSecond;
                worksheet.Cell(i + 2, 6).Value = entities[i].EventDate;
                worksheet.Cell(i + 2, 7).Value = entities[i].ClientId;
                worksheet.Cell(i + 2, 8).Value = "'" + entities[i].CustomerNumber;
            }
            worksheet.Columns().AdjustToContents();
            _logger.Trace("Worksheet created");
            return worksheet;
        }
    }

    public class TenantPublishViewModel
    {
        public List<string> ChannelIdsToPublish { get; set; }
        public List<string> ChannelIdsToUnPublish { get; set; }

    }
}
