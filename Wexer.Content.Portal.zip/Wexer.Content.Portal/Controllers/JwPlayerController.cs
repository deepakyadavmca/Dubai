﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Attributes;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.EventService;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.Models.JWPlayer.Request;
using Wexer.Content.Portal.Models.ScheduleEvents;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Repositories.JWPlayer;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class JwPlayerController : CommonController
    {
        private readonly ILogger _logger;
        private readonly IJWPlayerRepo _jwplayerRepo;
        private readonly ICmsStoreRepo _cmsStore;
        private IMemoryCache _cache;
        private readonly IProviderService _providerService;
        private readonly IEventService _eventService;
        private readonly ICommandBus _commandBus;
        private readonly IChannelService _channelService;

        public JwPlayerController(ILoggerFactory loggerFactory, IJWPlayerRepo jwplayerRepo, ICmsStoreRepo cmsStore,
                                    IMemoryCache cache, IProviderService providerService, IEventService eventService,
                                    ITitleService titleService, IConfiguration configuration, ICommandBus commandBus,
                                    IChannelService channelService)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _jwplayerRepo = jwplayerRepo;
            _cmsStore = cmsStore;
            _cache = cache;
            _providerService = providerService;
            _eventService = eventService;
            _commandBus = commandBus;
            _channelService = channelService;
        }

        /// <summary>
        /// Webhook to update status of title after encoding
        /// </summary>
        /// <param name="media">Media object received from JW Player</param>
        /// <returns></returns>
        [JWPlayerAuth]
        [HttpPost("api/v2/webhook")]
        public async Task<ActionResult<HttpStatusCode>> ManageJwplayerMediaStatus([FromBody] object media)
        {
            try
            {
                var response = JsonConvert.DeserializeObject<MediaWebhookResponse>(media.ToString());
                if (response != null)
                {
                    var mediaFeed = new DeliveryMediaResponse();
                    if (!string.IsNullOrEmpty(response.MediaId))
                    {
                        mediaFeed = await _jwplayerRepo.GetStreamingUrlById<DeliveryMediaResponse>(new MediaRequest { MediaId = response.MediaId });
                    }

                    try
                    {
                        var providers = await _providerService.List().ConfigureAwait(false);
                        var currentProvider = providers.FirstOrDefault(x => x.JWPlayerSiteId == response.SiteId);

                        if (response.Event == "media_available" && mediaFeed.Message == null)
                        {
                            var virtualClasses = await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);

                            if (virtualClasses != null)
                            {
                                var existingMedia = await _jwplayerRepo.GetMediaById<MediaResponse>(new MediaRequest { ProviderId = currentProvider != null ? currentProvider.ProviderId : string.Empty, MediaId = response.MediaId });
                                VirtualClass title = null;
                                title = virtualClasses.FirstOrDefault(x => x.Tag == existingMedia.External_id);
                                if (title != null)
                                {
                                    _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus ENDED at {0}", DateTime.UtcNow));
                                    await PublishMediaFile(title, mediaFeed);
                                }
                                else
                                {
                                    title = virtualClasses.FirstOrDefault(x => x.ExternalClassId == response.MediaId);
                                    if (title != null)
                                    {
                                        await PublishMediaFile(title, mediaFeed);
                                    }
                                    else
                                    {
                                        _logger.Error("JwPlayerController > ManageJwplayerMediaStatus > No record found for media id :" + response.MediaId);
                                    }
                                }
                            }
                        }

                        if (response.Event == "channel_idle")
                        {
                            _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > channel_idle section execution starts at {0}", DateTime.UtcNow));
                            var existingChannel = await _jwplayerRepo.GetChannelById<ChannelResponse>(new ChannelRequest
                            {
                                ProviderId = currentProvider != null ? currentProvider.ProviderId : string.Empty,
                                ChannelId = response.ChannelId
                            });
                            _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > JWPlayer Channel fetched at {0}", DateTime.UtcNow));
                            
                            if (existingChannel.Recent_events != null && existingChannel.Recent_events.Where(x => x.Status == "completed").Count() > 0)
                            {
                                _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > Channel with recent event found at {0}", DateTime.UtcNow));
                                string eventId = string.Empty;
                                eventId = existingChannel.Metadata.Custom_params.ContainsKey("EventId") ? existingChannel.Metadata.Custom_params["EventId"] : string.Empty;
                                var mediaToAdd = existingChannel.Recent_events.Where(x => x.Status == "completed").FirstOrDefault().MediaId;
                                var events = await _eventService.List(currentProvider.TenantId).ConfigureAwait(false);
                                ScheduleEvent currentEvent = new ScheduleEvent();
                                
                                if (!string.IsNullOrEmpty(eventId))
                                {
                                    currentEvent = events.Where(x => x.Event_Id == eventId).FirstOrDefault();
                                }
                                else
                                {
                                    currentEvent = events.Where(x => x.LiveChannelId == response.ChannelId).FirstOrDefault();
                                }

                                if (currentEvent != null && !string.IsNullOrEmpty(currentEvent.Event_Id) && currentEvent.AllowAutoPublish == true && !string.IsNullOrEmpty(mediaToAdd))
                                {
                                    _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > Event with event id : {0} found at {1}", currentEvent.Event_Id, DateTime.UtcNow));
                                    var channels = await _channelService.List().ConfigureAwait(false);
                                    var currentchannel = channels.Where(x => x.Provider == currentProvider.Tag).FirstOrDefault();
                                    var existingMedia = await _jwplayerRepo.GetMediaById<MediaResponse>(new MediaRequest
                                    {
                                        ProviderId = currentProvider != null ? currentProvider.Tag : string.Empty,
                                        MediaId = mediaToAdd
                                    });
                                    mediaFeed = await _jwplayerRepo.GetStreamingUrlById<DeliveryMediaResponse>(new MediaRequest { MediaId = mediaToAdd });

                                    VirtualClass title = currentEvent.Video;
                                    var titleTagInfo = new List<string>();
                                    if (title == null)
                                    {
                                        title = new VirtualClass();
                                    }
                                    else
                                    {
                                        titleTagInfo = GetMediaMetaData(title);
                                        existingMedia.Metadata.Tags = titleTagInfo.Where(x => x != "").ToList();
                                    }

                                    title.Tag = Guid.NewGuid().ToString();
                                    title.ExternalClassId = mediaToAdd;
                                    title.ChannelId = currentchannel.Tag;
                                    title.CreationDate = DateTime.UtcNow;
                                    title.ProviderID = currentProvider.Tag;
                                    title.Provider = currentProvider.Name;
                                    title.ProviderType = ProviderType.Tenant;
                                    title.Event_Id = currentEvent.Event_Id;
                                    title.DurationSecond = mediaFeed.Playlist[0].Duration;
                                    title.StreamingLink = mediaFeed.Playlist[0].Sources.OrderBy(x => x.Width).FirstOrDefault().File;
                                    title.AlternateLink = mediaFeed.Playlist[0].Link;
                                    title.PublishedDate = DateTime.UtcNow;
                                    currentEvent.Video = title;
                                    _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > Event title property updated at {0}", DateTime.UtcNow));

                                    if (existingMedia != null)
                                    {
                                        if (existingMedia.Metadata.Custom_params.ContainsKey("TitleTag"))
                                        {
                                            existingMedia.Metadata.Custom_params["TitleTag"] = title.Tag;
                                        }
                                        else
                                        {
                                            existingMedia.Metadata.Custom_params.Add("TitleTag", title.Tag);
                                        }

                                        await _jwplayerRepo.UpdateMediaMetadata<MediaResponse>(new MediaRequest
                                        {
                                            ProviderId = currentProvider != null ? currentProvider.Tag : string.Empty,
                                            MediaId = mediaToAdd,
                                            Metadata = new MediaMetadata
                                            {
                                                Title = title.ClassName,
                                                ExternalId = title.Tag,
                                                Tags = titleTagInfo,
                                                Publish_start_date = title.PublishedDate?.ToString("o"),
                                                Custom_params = existingMedia.Metadata.Custom_params
                                            }
                                        }).ConfigureAwait(false);
                                        _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > Existing media with MediaId : {0} updated at {1}", mediaToAdd, DateTime.UtcNow));
                                    }

                                    await UpdateEvent(currentProvider.Tag, currentEvent);
                                    _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > Event updated  EventID : {0} at {1}", currentEvent.Event_Id, DateTime.UtcNow));

                                    title.Status = MediaProcessingStatus.Published;
                                    await UpdateVirtualClass(title);
                                    _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > Title added to table with ID : {0} at {1}", title.Tag, DateTime.UtcNow));

                                    await _commandBus.SendAsync(new TitlePublishCommand
                                    {
                                        Tag = title.Tag,
                                        ChannelId = title.ChannelId,
                                        ProviderId = title.ProviderID
                                    }).ConfigureAwait(false);
                                    _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus > TitlePublishCommand intiated at {0}", DateTime.UtcNow));
                                }
                                else
                                {
                                    _logger.Warn("JwPlayerController > GetJwplayerMediaStatus => Event doesn't exists");
                                }
                            }
                        }
                        _logger.Info(string.Format("JwPlayerController > ManageJwplayerMediaStatus ENDED at {0}", DateTime.UtcNow));
                    }
                    catch (Exception e)
                    {
                        _logger.Error(string.Format("JwPlayerController > ManageJwplayerMediaStatus, Error in updating encoding status for media Id = {0}, msg={1}", response.MediaId, e.ToString()));
                    }
                    return Ok();
                }
                else
                {
                    _logger.Warn("JwPlayerController > GetJwplayerMediaStatus => Body doesn't have any data");
                    return BadRequest();
                }
            }
            catch (Exception e)
            {
                _logger.Error(string.Format("JwPlayerController > ManageJwplayerMediaStatus exception", "warn", e.ToString()));
                return StatusCode(500);
            }
        }

        private async Task PublishMediaFile(VirtualClass selectedVirtualClass, DeliveryMediaResponse deliveryMediaResponse)
        {
            _logger.Info(string.Format("JwPlayerController > PublishMediaFile started at {0}", DateTime.UtcNow));
            try
            {
                if (deliveryMediaResponse.Feed_instance_id != null)
                {
                    selectedVirtualClass.DurationSecond = deliveryMediaResponse.Playlist[0].Duration;
                    selectedVirtualClass.Status = MediaProcessingStatus.Incomplete;
                    selectedVirtualClass.AlternateLink = deliveryMediaResponse.Playlist[0].Link;
                    var url = deliveryMediaResponse.Playlist[0].Sources.OrderBy(x => x.Width).FirstOrDefault().File;
                    selectedVirtualClass.StreamingLink = url;
                    _logger.Info(string.Format("JwPlayerController > PublishMediaFile, StreamingLink : {0}", url));
                    _logger.Info(string.Format("JwPlayerController > PublishMediaFile, AlternateLink : {0}", deliveryMediaResponse.Playlist[0].Link));
                }
                else
                {
                    _logger.Error(string.Format("JwPlayerController > PublishMediaFile, Publishing failed for the class: {0}", selectedVirtualClass.Tag));
                    selectedVirtualClass.Status = MediaProcessingStatus.Error;
                    selectedVirtualClass.ErrorType = MediaProcessingError.PublishError;
                }

                await UpdateVirtualClass(selectedVirtualClass).ConfigureAwait(false);
                _logger.Info(string.Format("JwPlayerController > PublishMediaFile > Title updated at {0}", DateTime.UtcNow));
                if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
                {
                    _cache.Remove(CacheKeys.VirtualClass);
                }
                _logger.Info(string.Format("JwPlayerController > PublishMediaFile ended at {0}", DateTime.UtcNow));
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("JwPlayerController > PublishMediaFile, Publish Error > ", ex.ToString()));
                throw ex;
            }
        }

        private async Task UpdateVirtualClass(VirtualClass selectedVirtualClass)
        {
            await _cmsStore.StoreAsync(selectedVirtualClass.Tag, selectedVirtualClass, "", selectedVirtualClass.ProviderID).ConfigureAwait(false);
            _logger.Error(string.Format("JwPlayerController > UpdateVirtualClass > title Id >", selectedVirtualClass.ExternalClassId));
        }

        private List<string> GetMediaMetaData(VirtualClass title)
        {
            try
            {
                List<string> titleTagInfo = new List<string>();

                if (title.ClassCategories != null)
                    titleTagInfo.Add(title.ClassCategories.InvariantText);
                if (title.ClassSubCategory != null && title.ClassSubCategory.InvariantText != "")
                    titleTagInfo.Add(title.ClassSubCategory.InvariantText);
                if (title.Equipments != null && title.Equipments.InvariantText != "")
                    titleTagInfo.AddRange(title.Equipments.InvariantText.Split('|'));
                if (title.FocusArea != null && title.FocusArea.InvariantText != "")
                    titleTagInfo.AddRange(title.FocusArea.InvariantText.Split('|'));
                if (title.Labels != null)
                    titleTagInfo.AddRange(title.Labels);

                if (title.Skill >= 1 && title.Skill <= 4)
                    titleTagInfo.Add("low-skill");
                else if (title.Skill >= 5 && title.Skill <= 7)
                    titleTagInfo.Add("medium-skill");
                else if (title.Skill >= 8 && title.Skill <= 10)
                    titleTagInfo.Add("high-skill");

                if (title.Intensity >= 1 && title.Intensity <= 4)
                    titleTagInfo.Add("low-intensity");
                else if (title.Intensity >= 5 && title.Intensity <= 7)
                    titleTagInfo.Add("medium-intensity");
                else if (title.Intensity >= 8 && title.Intensity <= 10)
                    titleTagInfo.Add("high-intensity");

                return titleTagInfo;
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("JwPlayerController > ManageMediaMetaData > titleTag:{0} & Error:{1}", title.Tag, ex.ToString()));
                throw ex;
            }
        }

        private async Task UpdateEvent(string providerId, ScheduleEvent model)
        {
            var scheduleEventModel = new ScheduleEventViewModel()
            {
                Video = new VirtualClassViewModel
                {
                    Skill = model.Video.Skill,
                    Level = model.Video.Level,
                    ClassName = model.Video.ClassName,
                    ClassDescription = model.Video.ClassDescription,
                    ClassCategory = model.Video.ClassCategories,
                    ClassCategoryId = model.Video.ClassCategoryId,
                    ClassSubCategory = model.Video.ClassSubCategory,
                    Equipments = model.Video.Equipments?.InvariantText?.Split('|'),
                    ClassLanguageCode = model.Video.ClassLanguageCode,
                    ClassLanguage = model.Video.ClassLanguage,
                    Keywords = model.Video.Keywords,
                    FocusArea = model.Video.FocusArea?.InvariantText?.Split('|'),
                    Labels = model.Video.Labels,
                    Provider = model.Video.Provider,
                    ProviderID = model.Video.ProviderID,
                    ImageLink = model.Video.ImageLink,
                    StartDate = model.Video.StartDate,
                    EndDate = model.Video.EndDate,
                    ScheduleDate = model.Video.PublishedDate,
                    IsEquipment = model.Video.IsEquipment,
                    ChannelId = model.Video.ChannelId,
                    Instructor = model.Video.Instructor,
                    Intensity = model.Video.Intensity,
                    EquipmentTypeTags = model.Video.EquipmentTypeTags,
                    FocusAreaTags = model.Video.FocusAreaTags,
                },
                Event_Id = model.Event_Id,
                TenantId = model.TenantId,
                Title = model.Title,
                Description = model.Description,
                Active = model.Active,
                Schedule_Time = model.Scheduled_Time,
                Schedule = model.Schedule,
                Type = model.Type,
                ImageUrl = model.ImageUrl,
                AllowAutoPublish = model.AllowAutoPublish
            };
            await _eventService.UpdateEvent(scheduleEventModel, model, providerId).ConfigureAwait(false);
            _logger.Error(string.Format("JwPlayerController > UpdateEvent > event Id > ", model.Event_Id));
        }
    }
}