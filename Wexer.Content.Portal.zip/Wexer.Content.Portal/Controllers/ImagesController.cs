﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly IFileStoreRepo _fileStoreRepo;
        public ImagesController(IFileStoreRepo fileStoreRepo)
        {
            _fileStoreRepo = fileStoreRepo;
        }

        [ResponseCache(Duration = 31536000)]
        [HttpGet("media/image/{tag}")]
        public async Task<IActionResult> GetImage(string tag, int? width = null, int? height = null)
        {
            try
            {
                var ms = new MemoryStream();
                var result = await _fileStoreRepo.GetStreamAsync(ms, "images", tag).ConfigureAwait(false);
                ms.Seek(0L, SeekOrigin.Begin);
                Response.Headers.Add("Content-Type", result.MimeType);
                return Ok(ms);
            }
            catch (Exception e)
            {

                throw e;
            }
        }
    }
}
