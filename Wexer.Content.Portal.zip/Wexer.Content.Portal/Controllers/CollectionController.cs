﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.Logging;
using Microsoft.AspNetCore.Authorization;
using System.Net;
using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Models.OnDemandCollection;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.Models.User;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.ChannelService;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class CollectionController : CommonController
    {
        private const string Separator = "|";
        private readonly IBlobRepo _blobRepo;
        private readonly ITitleService _titleService;
        private IMemoryCache _cache;
        private readonly ICommandBus _commandBus;
        private readonly ILogger _logger;
        private readonly ITableRepo _tableRepo;
        private readonly IChannelService _channelService;
        private readonly ICmsStoreRepo _cmsStore;
        private const int minimum_titles_number = 6;
        public CollectionController(IBlobRepo blobRepo, ITitleService titleService, IMemoryCache cache,
            ICommandBus commandBus, ITableRepo tableRepo, IChannelService channelService,
            ILoggerFactory loggerFactory, ICmsStoreRepo cmsStore)
        {
            _blobRepo = blobRepo;
            _titleService = titleService;
            _cache = cache;
            _commandBus = commandBus;
            _logger = loggerFactory.GetLoggerForClass(this);
            _tableRepo = tableRepo;
            _channelService = channelService;
            _cmsStore = cmsStore;
        }

        #region APIv1
        /// <summary>
        /// API to get list of all collections by tenant id
        /// </summary>
        /// <param name="tenantid"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpGet("api/v1/tenants/{tenantid}/collections")]
        public async Task<ActionResult<HttpStatusCode>> GetCollections(string tenantid)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }
                List<object> responseList = new List<object>();
                var ondemandCollections = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                if (ondemandCollections != null && ondemandCollections.Entity != null && ondemandCollections.Entity.Items != null)
                {
                    if (ondemandCollections.Entity.Items.Count() > 0)
                    {
                        foreach (var collection in ondemandCollections.Entity.Items.OrderByDescending(x => x.CreationDate))
                        {
                            var responseItem = new
                            {
                                collectionType = collection.IsFeaturedCollection ? OnDemandCollectionType.Featured.ToLower() : collection.IsClassOfDayCollection ?
                                                                        OnDemandCollectionType.ClassOfTheDay.ToLower() : OnDemandCollectionType.Managed.ToLower(),
                                collectionTag = collection.Tag,
                                collectionName = collection.Name.FlattenByLanguage(lang),
                                collection.IsActive,
                                collection.CreationDate,
                                collection.Description,
                                collection.SequenceNumber,
                                collection.IsFeaturedCollection,
                                collection.IsClassOfDayCollection
                            };
                            responseList.Add(responseItem);
                        }
                        return Ok(new { results = responseList });
                    }
                    else
                    {
                        _logger.Info($"No ondemandcollections found for tenantid {tenantid}");
                        var error = new { code = 404, message = "No on demand collections found for tenantid: " + tenantid };
                        return BadRequest(new { HttpStatusCode.NotFound, error });
                    }
                }
                else
                {
                    _logger.Info($"No ondemandcollections found for tenantid {tenantid}");
                    var error = new { code = 404, message = "No on demand collections found for tenantid: " + tenantid };
                    return BadRequest(new { HttpStatusCode.NotFound, error });
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($"Get Collections list failed for tenant id:{tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to get details of collection by tenant id and collection id
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="collectionid"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpGet("api/v1/tenants/{tenantid}/collections/{collectionid}/{userId?}")]
        public async Task<ActionResult<HttpStatusCode>> GetCollectionDetailsByCollectionId(string tenantid, string collectionid, string userId = "")
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }
                IEnumerable<UserPreferredVirtualClass> userPreferredVirtualClasses = null;
                UserDetail userDetail = null;
                List<object> responseList = new List<object>();
                var dictionaryChannel = new Dictionary<string, string>();
                dictionaryChannel = await GetChannelListAsync(lang);
                if (!String.IsNullOrEmpty(userId))
                {
                    var userDetails = await _blobRepo.GetAsync<UserDetail>(userId);
                    if (userDetails == null || !userDetails.IsSuccessStatusCode || userDetails.Entity == null)
                    {
                        return NotFound("User Not found");
                    }
                    userDetail = userDetails.Entity;
                    userPreferredVirtualClasses = await _tableRepo.GetListAsync<UserPreferredVirtualClass>(userId).ConfigureAwait(false);
                }
                var ondemandCollections = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                var _ondemandCollection = ondemandCollections.Entity.Items.Where(x => x.Tag.Equals(collectionid)).FirstOrDefault();
                var tagList = _ondemandCollection != null ? _ondemandCollection.Section != null && _ondemandCollection.Section[0].Slot != null ? _ondemandCollection.Section[0].Slot.Select(x => x.OnDemandClassTag).ToList() : null : null;
                var virtualClassList = await _blobRepo.GetSetAsync<VirtualClass>(tenantid).ConfigureAwait(false);
                if (virtualClassList != null && virtualClassList.Entity != null && virtualClassList.Entity.Items.Count() > 0)
                {
                    if (_ondemandCollection != null && tagList != null && tagList.Count > 0)
                    {
                        var virtualClassItems = virtualClassList.Entity.Items.Where(x => tagList.Contains(x.Tag)).ToList();
                        if (virtualClassItems != null && virtualClassItems.Count() != 0)
                        {
                            var responseItem = ShapeOnDemandCollectionClasses(_ondemandCollection, virtualClassItems, userPreferredVirtualClasses, dictionaryChannel, userId, lang);
                            responseList.Add(responseItem);
                        }
                        return Ok(new { results = responseList });
                    }
                    else if (_ondemandCollection != null && tagList == null) //if collection dont have associated videos and collection id is not null
                    {
                        var responseItem = ShapeOnDemandCollectionClasses(_ondemandCollection, null, null, null, lang);
                        responseList.Add(responseItem);
                        return Ok(new { results = responseList });
                    }
                    else
                    {
                        _logger.Info($"No ondemandcollections found with videos for tenantid: {tenantid} ");
                        var error = new { code = 404, message = "No on demand collections with videos/classes found for tenant id " + tenantid + " and collection id: " + collectionid };
                        return BadRequest(new { HttpStatusCode.NotFound, error });
                    }
                }

                else if (virtualClassList.Entity == null)
                {
                    var responseItem = ShapeOnDemandCollectionClasses(_ondemandCollection, null, null, null, lang);
                    responseList.Add(responseItem);
                    return Ok(new { results = responseList });
                }
                else
                {

                    _logger.Info($"No collection found for tenantid: {tenantid} and collection id {collectionid}");
                    var error = new { code = 404, message = "No collection found for tenant id " + tenantid + " and collection id " + collectionid };
                    return BadRequest(new { HttpStatusCode.NotFound, error });
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($"Get Collections list failed for tenant id:{tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to create new Collection
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="collection"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpPost("api/v1/tenants/{tenantid}/collection")]
        public async Task<ActionResult<HttpStatusCode>> CreateCollection(string tenantid, [FromBody] OnDemandCollectionViewModel collection)
        {
            try
            {
                if (collection != null && !String.IsNullOrEmpty(collection.Name) && !String.IsNullOrEmpty(collection.Description))
                {
                    var lang = GetIETFTagFromHeaders();
                    if (string.IsNullOrEmpty(lang))
                    {
                        lang = "en-GB";
                    }

                    OnDemandCollection objCollection = new OnDemandCollection();
                    List<OnDemandCollection> listCollections = new List<OnDemandCollection>();
                    var collectionEntityList = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                    if (collectionEntityList != null && collectionEntityList.Entity != null && collectionEntityList.Entity.Items != null)
                    {
                        listCollections = collectionEntityList.Entity.Items.Count() > 0 ? collectionEntityList.Entity.Items.ToList() : listCollections;
                    }
                    objCollection.Tag = Guid.NewGuid().ToString();
                    objCollection.Name = await CreateLocalisedText(collection.Name).ConfigureAwait(false);
                    objCollection.InternalName = collection.Name;
                    objCollection.SequenceNumber = listCollections.Count() > 0 ? listCollections.Max(x => x.SequenceNumber) + 1 : 1;
                    objCollection.Description = collection.Description;
                    objCollection.IsActive = false;
                    objCollection.TenantId = tenantid;
                    objCollection.CreationDate = DateTime.UtcNow;
                    listCollections.Add(objCollection);
                    var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                    {
                        Count = listCollections.Count,
                        Items = listCollections.ToArray()
                    }, createSnapshot: true);
                    if (result != null && result.HttpStatusCode == 200)
                    {
                        var response = new { code = 201, message = "Created", collectionTag = result.Entity.Items.OrderByDescending(x => x.CreationDate).FirstOrDefault().Tag };
                        return Ok(new { result = response });
                    }
                    else
                    {
                        _logger.Info($"On Demand collection object cannot be empty: {collection} ");
                        var error = new { code = 500, message = "On Demand collections can not be empty" };
                        return StatusCode(500, error);
                    }
                }
                return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.Warn($"Create Collection failed for collection :{collection} & tenant id {tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to get a paged list of all published classes by tenant id
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="page"></param>
        /// <param name="take"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpGet("api/v1/tenants/{tenantid}/titles")]
        public async Task<ActionResult<HttpStatusCode>> GetPublishedClasses(string tenantid, int? page, int? take)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }
                var dictionaryChannel = new Dictionary<string, string>();
                dictionaryChannel = await GetChannelListAsync(lang);
                var virtualClassList = await _blobRepo.GetSetAsync<VirtualClass>(tenantid).ConfigureAwait(false);
                var virtualClassListTable = (List<VirtualClass>)await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);

                if (virtualClassList != null && virtualClassList.Entity != null && virtualClassList.Entity.Items.Count() > 0)
                {
                    var listVirtualClasses = virtualClassList.Entity.Items.Where(x => x.Status == MediaProcessingStatus.Published && x.ScheduleDate.HasValue).ToList();// get virtual classes with schedule date has value
                    var publishedClasses = listVirtualClasses != null ? listVirtualClasses.Where(x => x.ScheduleDate.Value.Date <= DateTime.Now.Date).ToList() : null;// check for schedule date with values not of future                    

                    if (publishedClasses != null && publishedClasses.Count > 0)
                    {
                        var publishedClassChannelIdList = publishedClasses.Where(x => x.ChannelId != null).Select(x => x.ChannelId).Distinct().ToList();
                        var publishedClassProviderList = publishedClasses.Where(x => x.Provider != null).Select(x => x.Provider).Distinct().ToList();
                        virtualClassListTable = publishedClasses.Where(x => x.ChannelId != null && x.ScheduleDate != null).ToList();// check if scheduled code is not null
                        var publishedVirtualClassListTable = virtualClassListTable.Where(x => publishedClassChannelIdList.Contains(x.ChannelId) && publishedClassProviderList.Contains(x.Provider) && x.ScheduleDate.Value.Date <= DateTime.Now.Date).ToList();
                        var shapedClasses = ShapeOnDemandCollectionVirtualClasses(publishedVirtualClassListTable.OrderByDescending(x => x.ScheduleDate).ToList(), null, dictionaryChannel, null, lang);
                        if (page != null && page.Value > 0 && take != null && take.Value > 0)
                        {
                            return Ok(new { results = PagedList<dynamic>.GetPagedResponse(shapedClasses, page.Value, take.Value) });
                        }
                        else
                        {
                            return Ok(new { results = shapedClasses });
                        }
                    }
                    else
                    {
                        _logger.Info($"No published virtual classes found for tenantid: {tenantid}");
                        var error = new { code = 404, message = "No  published virtual classes found for tenant id " + tenantid };
                        return BadRequest(new { HttpStatusCode.NotFound, error });
                    }
                }
                else
                {
                    _logger.Info($"No published virtual classes found for tenantid: {tenantid}");
                    var error = new { code = 404, message = "No virtual classes found for tenant id " + tenantid };
                    return BadRequest(new { HttpStatusCode.NotFound, error });
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($"Get published  virtual class list failed for tenant id:{tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to create classes
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="collectionid"></param>
        /// <param name="classList"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpPost("api/v1/tenant/{tenantid}/collections/{collectionid}/titles")]
        public async Task<ActionResult<HttpStatusCode>> AddCollectionClasses(string tenantid, string collectionid, List<string> classList)
        {
            try
            {
                if (classList != null)
                {
                    var lang = GetIETFTagFromHeaders();
                    if (string.IsNullOrEmpty(lang))
                    {
                        lang = "en-GB";
                    }
                    var onDemandCollectionList = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                    List<OnDemandCollection> listCollections = new List<OnDemandCollection>();
                    if (onDemandCollectionList != null && onDemandCollectionList.Entity != null && onDemandCollectionList.Entity.Items.Count() > 0)
                    {
                        listCollections = onDemandCollectionList.Entity.Items.ToList();
                    }
                    var onDemandCollection = listCollections.Where(d => d.Tag.Equals(collectionid, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                    if (onDemandCollection != null && onDemandCollection.Section == null)
                    {
                        onDemandCollection.Section = new[]{
                        new OnDemandCollectionSection{
                        SectionName="Main",
                        IsOptional = true,
                        OnDemandCollectionTag = collectionid
                            }
                        };
                    }
                    var section = onDemandCollection.Section[0];
                    if (section.Slot == null)
                    {
                        section.Slot = new OnDemandCollectionSectionSlot[] { };
                    }
                    var nextNumber = section.Slot != null ? section.Slot.Length + 1 : 1;
                    if (classList.Count > 0)
                    {
                        //remove duplicate on virtual classes 
                        var duplicateClassesItems = onDemandCollection.Section[0].Slot.Where(x => classList.Contains(x.OnDemandClassTag)).ToList();
                        var duplicateItemIds = duplicateClassesItems.Count != 0 ? duplicateClassesItems.Select(x => x.OnDemandClassTag).ToList() : new List<string>();
                        var filteredClassesList = classList.Except(duplicateItemIds).ToList();
                        if (filteredClassesList.Count() > 0)
                        {
                            for (int i = 0; i < filteredClassesList.Count(); i++)
                            {
                                var slot = new OnDemandCollectionSectionSlot { ItemNumber = nextNumber + i };
                                var item = classList.Where(x => x.Equals(filteredClassesList[i])).FirstOrDefault();
                                slot.OnDemandClassTag = item;
                                slot.Provider = null;
                                slot.Category = null;
                                slot.ScheduleDate = null;
                                section.Slot = section.Slot.Union(new[] { slot }).ToArray();
                            }
                        }
                        else
                        {
                            _logger.Info($"Duplicate classes can not be inserted: {string.Join(",", duplicateClassesItems.Select(x => x.OnDemandClassTag).ToList())} ");
                            var error = new { code = 500, message = "Duplicate classes can not be inserted:" + string.Join(",", duplicateClassesItems.Select(x => x.OnDemandClassTag).ToList()) };
                            return StatusCode(500, error);
                        }
                    }
                    onDemandCollection.LastModifiedDate = DateTime.UtcNow;
                    var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                    {
                        Count = listCollections.Count,
                        Items = listCollections.ToArray()
                    }, createSnapshot: true);
                    if (result != null && result.HttpStatusCode == 200)
                    {
                        var response = new { code = 201, message = "Created" };
                        return Ok(new { result = response });
                    }
                    else
                    {
                        _logger.Info($"virtual class list cannot be empty: {classList} ");
                        var error = new { code = 500, message = "virtual class list can not be empty" };
                        return StatusCode(500, error);
                    }
                }
                return BadRequest();
            }
            catch (Exception ex)
            {
                _logger.Warn($"Adding classes failed for collection :{classList} & tenant id {tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to update status of Collection by collection id
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="collectionid"></param>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpPut("api/v1/tenants/{tenantid}/collections/{collectionid}")]
        public async Task<ActionResult<HttpStatusCode>> UpdateCollectionStatus(string tenantid, string collectionid, [FromBody] OnDemandCollectionViewModel viewModel)
        {
            try
            {
                var onDemandCollectionList = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                List<OnDemandCollection> listCollections = new List<OnDemandCollection>();
                if (onDemandCollectionList != null && onDemandCollectionList.Entity != null && onDemandCollectionList.Entity.Items.Count() > 0)
                {
                    listCollections = onDemandCollectionList.Entity.Items.ToList();
                }
                var isCOTDCollectionExists = listCollections.Where(x => x.IsClassOfDayCollection).Count() > 0;
                var onDemandCollection = listCollections.Where(d => d.Tag.Equals(collectionid, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                if (onDemandCollection != null && !String.IsNullOrEmpty(viewModel.Name) && !String.IsNullOrEmpty(viewModel.Description))
                {
                    if (!isCOTDCollectionExists && viewModel.IsActive)
                    {
                        onDemandCollection.IsClassOfDayCollection = true;
                        onDemandCollection.StartDate = DateTime.UtcNow;
                    }
                    onDemandCollection.Name = await CreateLocalisedText(viewModel.Name).ConfigureAwait(false);
                    onDemandCollection.InternalName = viewModel.Name;
                    onDemandCollection.Description = viewModel.Description;
                    onDemandCollection.LastModifiedDate = DateTime.UtcNow;
                    var sequencenumberOfCurrentCollection = onDemandCollection.SequenceNumber;
                    if (onDemandCollection.IsFeaturedCollection == true && viewModel.IsActive == false)// check if collection being deactivated is not Featured
                    {
                        _logger.Info($"Featured Collection : {collectionid}  can not be deactivated");
                        var error = new { code = 500, message = "Featured collection with id : " + collectionid + " can not be deactivated" };
                        return StatusCode(500, error);
                    }
                    if (viewModel.IsActive == true && onDemandCollection.IsActive == false) //check if collection is being activated
                    {
                        if (onDemandCollection.Section[0].Slot.Length >= minimum_titles_number)// check if collection has 6 titles in it before activation
                        {
                            if (listCollections.Count() == 1) //if a collection is only collection and active then make it featured
                            {
                                onDemandCollection.IsFeaturedCollection = true;
                            }
                            onDemandCollection.SequenceNumber = 1;
                            foreach (var item in listCollections.Where(x => !x.Tag.Equals(collectionid) && x.SequenceNumber < sequencenumberOfCurrentCollection))// update sno. of only those collections whose sno is less than the collection's been activated sequence number
                            {
                                item.SequenceNumber = item.SequenceNumber + 1;
                            }
                        }
                        else
                        {
                            _logger.Info($"Collection activation failed for : {collectionid} as there are less than 6 titles in collection ");
                            var error = new
                            {
                                code = 501,
                                message = "Collection activation failed for : " + collectionid + " as there are less than 6 titles in collection "};
                            return StatusCode(501, error);//not implemented
                        }
                    }

                    onDemandCollection.IsActive = viewModel.IsActive;

                    var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                    {
                        Count = listCollections.Count,
                        Items = listCollections.ToArray()
                    }, createSnapshot: true);
                    if (result != null && result.HttpStatusCode == 200)
                    {
                        var response = new { code = 201, message = "Collection updated successfully" };
                        return Ok(new { result = response });
                    }
                    else
                    {
                        _logger.Info($"Collection update failed for : {collectionid} ");
                        var error = new { code = 500, message = "Collection update failed for : " + collectionid };
                        return StatusCode(500, error);
                    }
                }
                else
                {
                    _logger.Info($"Either Collection not found for id : {collectionid} or Collection name or Description is empty ");
                    var error = new { code = 404, message = "Either Collection not found for id : " + collectionid + " or Collection name or Description is empty" };
                    return NotFound(error);
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($" Collection update for collection id :{collectionid} & tenant id {tenantid} & collection name : {viewModel.Name} ", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to delete classes
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="collectionid"></param>
        /// <param name="classList"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpDelete("api/v1/tenants/{tenantid}/collections/{collectionid}/titles")]
        public async Task<ActionResult<HttpStatusCode>> RemoveCollectionItems(string tenantid, string collectionid, List<string> classList)
        {
            try
            {
                if (classList != null && classList.Count > 0)
                {

                    var onDemandCollectionList = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                    List<OnDemandCollection> listCollections = new List<OnDemandCollection>();
                    if (onDemandCollectionList != null && onDemandCollectionList.Entity != null && onDemandCollectionList.Entity.Items.Count() > 0)
                    {
                        listCollections = onDemandCollectionList.Entity.Items.ToList();
                    }
                    var onDemandCollection = listCollections.Where(d => d.Tag.Equals(collectionid, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                    int todeleteTitlesCount = classList.Count();
                    int currentCollectionTitleCounts = onDemandCollection != null && onDemandCollection.Section != null && onDemandCollection.Section[0].Slot != null ? onDemandCollection.Section[0].Slot.Length : 0;

                    if (onDemandCollection != null && onDemandCollection.IsActive == false)//allow delete simple if inactive collection
                    {
                        //var toDeleteClasses = onDemandCollection.Section[0].Slot.Where(x => listClasses.Contains(x.OnDemandClassTag)).ToList();
                        var slot = onDemandCollection.Section[0].Slot.ToList();
                        var slotlength = onDemandCollection.Section[0].Slot.Length;
                        foreach (var virtualClass in classList)
                        {
                            slot.RemoveAll(x => x.OnDemandClassTag.Equals(virtualClass));
                        }
                        onDemandCollection.Section[0].Slot = slot.ToArray();
                        onDemandCollection.IsActive = onDemandCollection.Section[0].Slot.Length == 0 ? false : onDemandCollection.IsActive;// if count 0 then mark inactive else leave as it is
                        onDemandCollection.LastModifiedDate = DateTime.UtcNow;
                        var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                        {
                            Count = listCollections.Count,
                            Items = listCollections.ToArray()
                        }, createSnapshot: true);
                        if (result != null && result.HttpStatusCode == 200)
                        {
                            var response = new { code = 201, message = "Virtual Classes with id " + string.Join(",", classList) + " removed successfully" };
                            return Ok(new { result = response });
                        }
                        else
                        {
                            _logger.Info($"Virtual Classes deletion failed for : {string.Join(",", classList)} ");
                            var error = new { code = 500, message = "Virtual Classes deletion failed for " + string.Join(",", classList) };
                            return StatusCode(500, error);
                        }
                    }
                    else if (onDemandCollection != null && onDemandCollection.IsActive == true && currentCollectionTitleCounts > 0 && currentCollectionTitleCounts - todeleteTitlesCount >= minimum_titles_number)// implement check on active collection for 6 min class count
                    {
                        var slot = onDemandCollection.Section[0].Slot.ToList();
                        var slotlength = onDemandCollection.Section[0].Slot.Length;
                        foreach (var virtualClass in classList)
                        {
                            slot.RemoveAll(x => x.OnDemandClassTag.Equals(virtualClass));
                        }
                        onDemandCollection.Section[0].Slot = slot.ToArray();
                        onDemandCollection.IsActive = onDemandCollection.Section[0].Slot.Length == 0 ? false : true;
                        onDemandCollection.LastModifiedDate = DateTime.UtcNow;
                        var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                        {
                            Count = listCollections.Count,
                            Items = listCollections.ToArray()
                        }, createSnapshot: true);
                        if (result != null && result.HttpStatusCode == 200)
                        {
                            var response = new { code = 201, message = "Virtual Classes with id " + string.Join(",", classList) + " removed successfully" };
                            return Ok(new { result = response });
                        }
                        else
                        {
                            _logger.Info($"Virtual Classes deletion failed for : {string.Join(",", classList)} ");
                            var error = new { code = 500, message = "Virtual Classes deletion failed for " + string.Join(",", classList) };
                            return StatusCode(500, error);
                        }
                    }
                    else
                    {
                        string strError = "";
                        if (onDemandCollection == null)
                        {
                            strError = $"Collection not found for id : {collectionid} ";
                            _logger.Info(strError);
                        }
                        else
                        {
                            strError = $"Collection items can not be deleted as current virtual class count is getting less than 6 for id : {collectionid} ";
                            _logger.Info(strError);
                        }
                        var error = new { code = 404, message = strError };
                        return NotFound(error);
                    }

                }
                else
                {
                    _logger.Info($"Can not perform delete operation on epmty classes for collection   : {collectionid} ");
                    var error = new { code = 404, message = "Can not perform delete operation on epmty classes for collection  id : " + collectionid };
                    return BadRequest(error);
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($" Delete classes failed for collection id :{collectionid} & tenant id {tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to delete collection
        /// </summary>
        /// <param name="tenantid"></param>        
        /// <param name="collectionids"></param> 
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpDelete("api/v1/tenants/{tenantid}/collections")]
        public async Task<ActionResult<HttpStatusCode>> RemoveCollection(string tenantid, List<string> collectionids)
        {
            try
            {
                if (collectionids.Count > 0 && !String.IsNullOrEmpty(tenantid))
                {

                    var onDemandCollectionList = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                    List<OnDemandCollection> listCollections = new List<OnDemandCollection>();
                    if (onDemandCollectionList != null && onDemandCollectionList.Entity != null && onDemandCollectionList.Entity.Items.Count() > 0)
                    {
                        listCollections = onDemandCollectionList.Entity.Items.ToList();
                    }                    
                    var featuredCollection = listCollections.Where(d => collectionids.Contains(d.Tag) && d.IsFeaturedCollection == true).FirstOrDefault();
                    if ((featuredCollection!=null))
                    {
                        if (collectionids.Contains(featuredCollection.Tag))
                        {
                            _logger.Info($"Can not perform delete operation on featured collection   : {featuredCollection.Name} ");
                            var error = new { code = 400, message = "Can not perform delete operation on featured collection : " + featuredCollection.Name };
                            return BadRequest(error);
                        }
                    }

                    var cotdCollections = listCollections.Where(d => collectionids.Contains(d.Tag) && d.IsClassOfDayCollection);
                    if (cotdCollections != null && cotdCollections.Count() > 0)
                    {
                        _logger.Info($"Can not perform delete operation on COTD collection : {cotdCollections.FirstOrDefault().Name} ");
                        return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Can not perform delete operation on COTD collection : " + cotdCollections.FirstOrDefault().Name });
                    }

                    var onDemandCollections = listCollections.Where(d => collectionids.Contains(d.Tag)).ToList();
                    if (onDemandCollections != null && onDemandCollections.Count > 0)
                    {
                        listCollections = listCollections.Except(onDemandCollections).ToList();
                        var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                        {
                            Count = listCollections.Count,
                            Items = listCollections.ToArray()
                        }, createSnapshot: true);
                        if (result != null && result.HttpStatusCode == 200)
                        {
                            var response = new { code = 201, message = "Collection deleted successfully" };
                            return Ok(new { result = response });
                        }
                        else
                        {
                            _logger.Info($"Collection deletion failed for : {string.Join(",", onDemandCollections.Select(x => x.Tag).ToList())} ");
                            var error = new { code = 500, message = "Collection deletion failed for : " + string.Join(",", onDemandCollections.Select(x => x.Tag).ToList()) };
                            return StatusCode(500, error);
                        }
                    }
                    else
                    {
                        _logger.Info($"Collection not found for id : {string.Join(",", collectionids)} or collection is featured");
                        var error = new { code = 404, message = "Collection not found for id : " + string.Join(",", collectionids)+ " or collection is featured" };
                        return NotFound(error);
                    }
                }
                else
                {
                    _logger.Info($"Can not perform delete operation collection   : {string.Join(",", collectionids)} ");
                    var error = new { code = 404, message = "Can not perform delete operation for collection  id : " + string.Join(",", string.Join(",", collectionids)) };
                    return BadRequest(error);
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($" Delete collection failed for collection id :{string.Join(",", collectionids)} & tenant id {tenantid}", "warn", ex.ToString());
                return StatusCode(500);
            }
        }

        /// <summary>
        /// API to make a collection featured
        /// </summary>
        /// <param name="tenantid"></param>
        /// <param name="collectionid"></param>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        [Authorize(Policy = "ClientProvider")]
        [HttpPatch("api/v1/tenants/{tenantid}/collections/{collectionid}")]
        public async Task<ActionResult<HttpStatusCode>> MarkCollectionFeatured(string tenantid, string collectionid, [FromBody] OnDemandCollectionViewModel viewModel)
        {
            try
            {
                var onDemandCollectionList = await _blobRepo.GetSetAsync<OnDemandCollection>(tenantid).ConfigureAwait(false);
                List<OnDemandCollection> listCollections = new List<OnDemandCollection>();
                if (onDemandCollectionList != null && onDemandCollectionList.Entity != null && onDemandCollectionList.Entity.Items.Count() > 0)
                {
                    listCollections = onDemandCollectionList.Entity.Items.ToList();
                }
                var onDemandCollection = listCollections.Where(d => d.Tag.Equals(collectionid, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                if (onDemandCollection != null && onDemandCollection.IsActive == true)
                {
                    if (viewModel.IsFeaturedCollection)
                    {
                        var existingFeaturedCollections = listCollections.Where(x => x.IsActive == true && x.IsFeaturedCollection == true && x.Tag != collectionid);
                        if (existingFeaturedCollections != null && existingFeaturedCollections.Count() > 0)
                        {
                            foreach (var featuredCollection in existingFeaturedCollections)
                            {
                                featuredCollection.IsFeaturedCollection = false;
                                featuredCollection.LastModifiedDate = DateTime.UtcNow;
                            }
                        }
                        onDemandCollection.IsFeaturedCollection = true;
                        onDemandCollection.LastModifiedDate = DateTime.UtcNow;
                    }
                    else if (viewModel.IsClassOfDayCollection)
                    {
                        var existingCOTDCollections = listCollections.Where(x => x.IsActive == true && x.IsClassOfDayCollection == true && x.Tag != collectionid);
                        if (existingCOTDCollections != null && existingCOTDCollections.Count() > 0)
                        {
                            foreach (var cotdCollection in existingCOTDCollections)
                            {
                                cotdCollection.IsClassOfDayCollection = false;
                                cotdCollection.LastModifiedDate = DateTime.UtcNow;
                            }
                        }
                        onDemandCollection.IsClassOfDayCollection = true;
                        onDemandCollection.StartDate = DateTime.UtcNow;
                        onDemandCollection.LastModifiedDate = DateTime.UtcNow;
                    }

                    var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                    {
                        Count = listCollections.Count,
                        Items = listCollections.ToArray()
                    }, createSnapshot: true);
                    if (result != null && result.HttpStatusCode == 200)
                    {
                        var response = new { code = 201, message = "Collection updated successfully" };
                        return Ok(new { result = response });
                    }
                    else
                    {
                        _logger.Info($"Collection update failed for : {collectionid} ");
                        var error = new { code = 500, message = "Collection update failed for : " + collectionid };
                        return StatusCode(500, error);
                    }
                }
                else
                {

                    _logger.Info($"Either Collection not found for id : {collectionid} or Collection is inactive ");
                    var error = new { code = 404, message = "Either Collection not found for id : " + collectionid + " or Collection is inactive" };
                    return NotFound(error);
                }
            }
            catch (Exception ex)
            {
                _logger.Warn($" Collection update for collection id :{collectionid} & tenant id {tenantid} & collection id : {collectionid} ", "warn", ex.ToString());
                return StatusCode(500);
            }
        }


        #endregion

        #region helper methods
        private dynamic ShapeOnDemandCollectionClasses(OnDemandCollection collection, List<VirtualClass> virtualClasses, IEnumerable<UserPreferredVirtualClass> userPreferredVirtualClassList, Dictionary<string, string> dictChannels, string userId = null, string lang = null)
        {
            return new
            {
                collectionType = collection.IsFeaturedCollection ? OnDemandCollectionType.Featured.ToLower() : collection.IsClassOfDayCollection ?
                                                                OnDemandCollectionType.ClassOfTheDay.ToLower() : OnDemandCollectionType.Managed.ToLower(),
                collectionTag = collection.Tag,
                collectionName = collection.Name.FlattenByLanguage(lang),
                itemCount = virtualClasses != null ? virtualClasses.Count() : 0,
                CollectionItems = virtualClasses != null ? ShapeOnDemandCollectionVirtualClasses(virtualClasses, userPreferredVirtualClassList, dictChannels, userId, lang) : new dynamic[0],
                collection.IsActive,
                collection.CreationDate,
                collection.Description,
                collection.IsFeaturedCollection
            };

        }

        private dynamic ShapeOnDemandCollectionVirtualClasses(List<VirtualClass> classes, IEnumerable<UserPreferredVirtualClass> userPreferredVirtualClassList, Dictionary<string, string> dictChannels, string userId = null, string lang = null)
        {
            List<dynamic> _list = new List<dynamic>();
            foreach (var classItem in classes)
            {
                _list.Add(new
                {
                    classItem.Tag,
                    ClassName = classItem.ClassName != null ? classItem.ClassName.FlattenByLanguage(lang) : null,
                    classItem.ClassLanguage,
                    classItem.ClassLanguageCode,
                    ClassCategory = classItem.ClassCategories != null ? classItem.ClassCategories.FlattenByLanguage(lang) : null,
                    ClassSubCategory = classItem.ClassSubCategory != null ? classItem.ClassSubCategory.FlattenByLanguage(lang) : null,
                    classItem.Intensity,
                    classItem.Skill,
                    classItem.Level,
                    Equipments = classItem.Equipments != null ? classItem.Equipments.FlattenByLanguage(lang) : null,
                    classItem.ScheduleDate,
                    classItem.TrailerLinkWeb,
                    classItem.TrailerLinkMobile,
                    classItem.isActive,
                    classItem.DurationSecond,
                    FocusArea = !string.IsNullOrEmpty(classItem.FocusArea) ? classItem.FocusArea.FlattenByLanguage(lang) : null,
                    classItem.ChannelId,
                    classItem.CreationDate,
                    classItem.EquipmentTypeTags,
                    classItem.FocusAreaTags,
                    classItem.PublishedDate,
                    ChannelName = GetChannelNameAsync(classItem.ChannelId, dictChannels, lang).Result
                });
            }
            return _list.OrderByDescending(x => x.CreationDate);
        }

        private static bool BindFavouriteData(IEnumerable<UserPreferredVirtualClass> userPreferredClasses, string virtualClassTag, string userId)
        {
            if (userPreferredClasses != null && userPreferredClasses.Count() > 0)
            {
                int count = userPreferredClasses.Where(x => x.VirtualClassTag == virtualClassTag && x.UserId == userId).ToList().Count();
                if (count != 0)
                {
                    return true;
                }
            }
            return false;
        }

        private async Task<string> GetChannelNameAsync(string channelid, Dictionary<string, string> channelDictionary, string lang)
        {
            if (!String.IsNullOrEmpty(channelid))
            {
                if (channelDictionary.TryGetValue(channelid, out string channelName))
                {
                    return channelName;
                }
                else
                {
                    return null;
                }
            }
            else
                return null;
        }
        private async Task<Dictionary<string, string>> GetChannelListAsync(string lang)
        {
            var channel = await _channelService.List().ConfigureAwait(false);
            var objDictionary = channel.Select(x => new { x.Tag, Name = x.Name.FlattenByLanguage(lang) }).ToDictionary(x => x.Tag, x => x.Name);
            return objDictionary;
        }
        #endregion

    }
}
