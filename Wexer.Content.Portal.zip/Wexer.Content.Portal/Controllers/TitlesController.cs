﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.Attributes;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Repositories.JWPlayer;
using Wexer.Content.Portal.TitleService;
using Channel = Wexer.Content.Portal.Models.ContentPortal.Channel;
using Wexer.Content.Portal.Models.JWPlayer.Request;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;
using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using System.Threading;
using Wexer.Content.Portal.Models.VirtualClassSearch;
using System.Net.Http;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class TitlesController : CommonController
    {
        private const string Separator = "|";
        private readonly IBlobRepo _blobRepo;
        private readonly ITitleService _titleService;
        private IMemoryCache _cache;
        private readonly IChannelService _channelService;
        private readonly IProviderService _providerService;
        private readonly ICommandBus _commandBus;
        private readonly ILogger _logger;
        private readonly IContentWriteStoreRepo _db;
        private readonly IJWPlayerRepo _jwplayerRepo;
        private readonly ICmsStoreRepo _cmsStore;

        public TitlesController(IBlobRepo blobRepo, ITitleService titleService, IMemoryCache cache,
            IChannelService channelService, IProviderService providerService, ICommandBus commandBus,
            ILoggerFactory loggerFactory, IContentWriteStoreRepo db, IJWPlayerRepo jwplayerRepo,
            ICmsStoreRepo cmsStore)
        {
            _blobRepo = blobRepo;
            _titleService = titleService;
            _cache = cache;
            _channelService = channelService;
            _providerService = providerService;
            _commandBus = commandBus;
            _logger = loggerFactory.GetLoggerForClass(this);
            _db = db;
            _jwplayerRepo = jwplayerRepo;
            _cmsStore = cmsStore;
        }

        [Authorize(Policy = "Joint")]
        [HttpGet("api/v1/titles")]
        public async Task<ActionResult<HttpStatusCode>> GetTitles(int page, int take, string provider, string channel)
        {
            try
            {
                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                if (string.IsNullOrEmpty(userRole))
                {
                    return BadRequest();
                }

                if (Convert.ToInt32(userRole) == Convert.ToInt32(Roles.Provider) || Convert.ToInt32(userRole) == Convert.ToInt32(Roles.ClientProvider))
                {
                    provider = userId;
                }

                if (!_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
                {
                    titles = await _titleService.List(userId, userRole).ConfigureAwait(false);

                    var cacheEntryOptions = new MemoryCacheEntryOptions()
                    {
                        SlidingExpiration = TimeSpan.FromDays(30),
                        AbsoluteExpiration = DateTimeOffset.UtcNow.AddYears(1)
                    };

                    _cache.Set(CacheKeys.VirtualClass, titles, cacheEntryOptions);
                }

                if (titles != null && titles.Count() > 0)
                {
                    if (take > 0 && page > 0)
                    {
                        if (Convert.ToInt32(userRole) == Convert.ToInt32(Roles.Admin))
                        {
                            titles = titles.Where(x => x.ProviderType == ProviderType.Regular);
                        }
                        var shapedResponse = await ShapeTitles(titles.ToArray(), provider, channel, lang, userRole).ConfigureAwait(false);
                        return Ok(PagedList<dynamic>.GetPagedResponse(shapedResponse, page, take));
                    }
                }

                return NotFound("No data");
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        [Authorize(Policy = "Joint")]
        [HttpGet("api/v1/titles/status")]
        public async Task<ActionResult<HttpStatusCode>> GetTitlesByProvider([FromBody] List<string> tags)
        {
            try
            {
                if (tags != null && tags.Count > 0)
                {

                    var titles = await _titleService.List(null, null).ConfigureAwait(false);

                    var cacheEntryOptions = new MemoryCacheEntryOptions()
                    {
                        SlidingExpiration = TimeSpan.FromDays(30),
                        AbsoluteExpiration = DateTimeOffset.UtcNow.AddYears(1)
                    };

                    if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> cachedTitles))
                    {
                        _cache.Remove(CacheKeys.VirtualClass);
                    }
                    _cache.Set(CacheKeys.VirtualClass, titles, cacheEntryOptions);


                    if (titles != null && titles.Count() > 0)
                    {
                        var data = titles.Where(x => tags.Any(t => t == x.Tag)).Select(x => new { x.Tag, x.Status }).ToArray();
                        if (data != null && data.Count() > 0)
                        {
                            return Ok(data);
                        }
                    }
                    return NotFound("Titles not found");
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        private async Task<dynamic> ShapeTitles(VirtualClass[] result, string provider, string channel, string lang, string role)
        {
            try
            {

                Func<VirtualClass, bool> filterByChannelProvider = x => (string.IsNullOrWhiteSpace(provider) ? true : x.ProviderID == provider) &&
                                                            (string.IsNullOrWhiteSpace(channel) ? true : x.ChannelId == channel);

                var shapedData = result
                    .Where(filterByChannelProvider)
                    .Select(x => new
                    {
                        x.Tag,
                        ClassName = x.ClassName != null ? x.ClassName.FlattenByLanguage(lang) : null,
                        ClassDescription = x.ClassDescription != null ? x.ClassDescription.FlattenByLanguage(lang) : null,
                        x.ClassLanguage,
                        x.ClassLanguageCode,
                        ClassCategory = x.ClassCategories != null ? x.ClassCategories.FlattenByLanguage(lang) : null,
                        x.ClassCategoryId,
                        ClassSubCategory = x.ClassSubCategory != null ? x.ClassSubCategory.FlattenByLanguage(lang) : null,
                        x.Intensity,
                        x.Skill,
                        x.RawVideoFileUrl,
                        x.StreamingLink,
                        x.AlternateLink,
                        x.ImageLink,
                        x.Status,
                        x.Instructor,
                        x.Level,
                        x.Labels,
                        Keywords = x.Keywords != null ? x.Keywords.FlattenByLanguage(lang) : null,
                        x.StartDate,
                        x.EndDate,
                        x.ProviderID,
                        x.Provider,
                        x.ProviderType,
                        Equipments = x.Equipments != null ? x.Equipments.FlattenByLanguage(lang) : null,
                        x.ScheduleDate,
                        x.TrailerLinkWeb,
                        x.TrailerLinkMobile,
                        x.TrailerName,
                        x.isComplete,
                        x.IsEquipment,
                        x.isActive,
                        x.DurationSecond,
                        x.ErrorType,
                        FocusArea = !string.IsNullOrEmpty(x.FocusArea) ? x.FocusArea.FlattenByLanguage(lang) : null,
                        x.ChannelId,
                        x.JobID,
                        x.CreationDate,
                        x.EquipmentTypeTags,
                        x.FocusAreaTags,
                        x.PublishedDate
                    }).OrderByDescending(x => x.CreationDate);

                return shapedData;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("private/api/v1/titles")]
        public async Task<ActionResult<HttpStatusCode>> GetAllTitles()
        {
            if (!_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
            {
                titles = await _titleService.List(null, null).ConfigureAwait(false);

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                {
                    SlidingExpiration = TimeSpan.FromDays(30),
                    AbsoluteExpiration = DateTimeOffset.UtcNow.AddYears(1)
                };

                _cache.Set(CacheKeys.VirtualClass, titles, cacheEntryOptions);
            }

            var lang = GetIETFTagFromHeaders();

            if (string.IsNullOrEmpty(lang))
            {
                lang = "en-GB";
            }

            if (titles != null && titles.Count() > 0)
            {
                var channels = await _channelService.List().ConfigureAwait(false);
                var shapedResponse = await ShapeAllTitles(titles.ToArray(), channels, lang).ConfigureAwait(false);
                return Ok(new { results = shapedResponse });
            }

            return NotFound("No data");
        }
        private async Task<dynamic> ShapeAllTitles(VirtualClass[] result, Channel[] channels, string lang)
        {
            try
            {
                var shapedData =
                    result.Where(x => x.Status == MediaProcessingStatus.Published)
                    .Select(x => new
                    {
                        x.Tag,
                        ClassName = x.ClassName != null ? x.ClassName.FlattenByLanguage(lang) : null,
                        ClassDescription = x.ClassDescription != null ? x.ClassDescription.FlattenByLanguage(lang) : null,
                        x.ClassLanguage,
                        x.ClassLanguageCode,
                        ClassCategory = x.ClassCategories != null ? x.ClassCategories.FlattenByLanguage(lang) : null,
                        ClassSubCategory = x.ClassSubCategory != null ? x.ClassSubCategory.FlattenByLanguage(lang) : null,
                        x.Intensity,
                        x.Skill,
                        x.RawVideoFileUrl,
                        encodedVideoUrl = x.Stage1EncodeVideoFileUrl,
                        //x.StreamingLink,
                        //x.AlternateLink,
                        x.ImageLink,
                        x.Status,
                        x.Instructor,
                        x.Level,
                        x.Labels,
                        //Keywords = x.Keywords != null ? x.Keywords.FlattenByLanguage(lang) : null,
                        //x.StartDate,
                        //x.EndDate,
                        x.ProviderID,
                        ProviderName = x.Provider,
                        Equipments = x.Equipments != null ? x.Equipments.FlattenByLanguage(lang).Split("|") : null,
                        //x.ScheduleDate,
                        x.TrailerLinkWeb,
                        //x.TrailerLinkMobile,
                        //x.TrailerName,
                        //x.isComplete,
                        x.IsEquipment,
                        x.isActive,
                        x.DurationSecond,
                        //x.ErrorType,
                        FocusAreas = !string.IsNullOrEmpty(x.FocusArea) ? x.FocusArea.FlattenByLanguage(lang).Split("|") : null,
                        x.ChannelId,
                        //x.JobID,
                        x.CreationDate,
                        x.PublishedDate,
                        x.LastModifiedDate,
                        x.ScheduleDate,
                        InClubAvailable = channels.Where(c => c.Tag == x.ChannelId && c.Availability.Contains(ChannelAvailability.InClub)).Count() > 0 ? "Yes" : "No"
                    });

                return shapedData;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [Authorize(Policy = "Joint")]
        [HttpPut("api/v1/title/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> Update(string tag, [FromBody] VirtualClassViewModel title)
        {
            try
            {
                if (title != null && title.Tag == tag && !string.IsNullOrEmpty(title.ProviderID) && !string.IsNullOrEmpty(title.Provider)
                    && title.Skill > 0 && !string.IsNullOrEmpty(title.ChannelId) && title.Intensity > 0
                    && !string.IsNullOrEmpty(title.ClassCategory) && (IsValidCategory(title.ClassCategoryId).Result == true) && title.EquipmentTypeTags != null
                    && !string.IsNullOrEmpty(title.ClassDescription) && !string.IsNullOrEmpty(title.ClassName))
                {

                    var lang = GetIETFTagFromHeaders();
                    if (string.IsNullOrEmpty(lang))
                    {
                        lang = "en-GB";
                    }

                    // Setting the Focus Area and Equipment Names based on Tags
                    if (title.EquipmentTypeTags != null && title.EquipmentTypeTags.Count() > 0
                        || title.FocusAreaTags != null && title.FocusAreaTags.Count() > 0)
                    {
                        var titlesMetadata = await GetTitlesMetaDataAsync(lang).ConfigureAwait(false);

                        if (titlesMetadata != null && titlesMetadata.Equipments != null && title.EquipmentTypeTags != null)
                            title.Equipments = (from eqp in titlesMetadata.Equipments
                                                join eqptag in title.EquipmentTypeTags
                                                on eqp.TypeTag equals eqptag
                                                select eqp.Name.FlattenByLanguage(lang)).ToArray();

                        if (titlesMetadata != null && titlesMetadata.FocusAreas != null && title.FocusAreaTags != null)
                            title.FocusArea = (from fa in titlesMetadata.FocusAreas
                                               join fat in title.FocusAreaTags
                                               on fa.Tag equals fat
                                               select fa.Name.FlattenByLanguage(lang)).ToArray();
                    }

                    if (title.IsMigrating)
                    {
                        if (!string.IsNullOrEmpty(title.SourceProviderId))
                        {
                            await _titleService.MigrateTitleProvider(title).ConfigureAwait(false);
                        }
                        else
                        {
                            return BadRequest();
                        }
                    }

                    var existingTitle = await _titleService.Get(title.ProviderID, tag).ConfigureAwait(false);

                    if (existingTitle != null)
                    {
                        if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
                        {
                            _cache.Remove(CacheKeys.VirtualClass);
                        }

                        var titleToUpdate = await _titleService.ModifyTitle(title, existingTitle, lang, "save").ConfigureAwait(false);
                        var titleUpdatedResult = await _titleService.Update(titleToUpdate).ConfigureAwait(false);
                        if (!string.IsNullOrEmpty(titleToUpdate.ExternalClassId))
                        {
                            await ManageMediaMetaData(title.ProviderID, titleToUpdate).ConfigureAwait(false);
                        }
                        return Ok(titleUpdatedResult);
                    }
                    return NotFound();
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        private async Task<TitlesMetadata> GetTitlesMetaDataAsync(string lang)
        {
            try
            {

                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                TitlesMetadata metadata = null;

                if (!_cache.TryGetValue(CacheKeys.Metadata, out metadata))
                {
                    var metadataTask = _blobRepo.GetAsync<TitlesMetadata>("*");
                    await Task.WhenAll(metadataTask).ConfigureAwait(false);

                    if (metadataTask.Result != null && metadataTask.Result.IsSuccessStatusCode)
                    {
                        _cache.Set(CacheKeys.Metadata, metadataTask.Result.Entity, DateTimeOffset.UtcNow.AddYears(1));
                        metadata = metadataTask.Result.Entity;
                    }
                }

                return metadata;
            }
            catch (Exception e)
            {
                _logger.Warn("Getmetadata exception", "warn", e.ToString());
            }
            return null;
        }


        [Authorize(Policy = "Admin")]
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpPost("api/v1/metadata")]
        public async Task<ActionResult<HttpStatusCode>> CreateMetadata([FromBody] ContentMetadataViewModel metadata)
        {
            try
            {
                if (metadata != null)
                {
                    var lang = GetIETFTagFromHeaders();
                    if (string.IsNullOrEmpty(lang))
                    {
                        lang = "en-GB";
                    }
                    TitlesMetadata titlesMetadata = new TitlesMetadata();

                    foreach (var item in metadata.Categories)
                    {
                        titlesMetadata.Categories.Add(
                            new Category
                            {
                                Id = item.Id,
                                Name = await CreateLocalisedText(item.Name, lang),
                                Subcategory = item.SubCategories.Select(x => CreateLocalisedText(x, lang).Result).ToList(),
                                Description = await CreateLocalisedText(item.Description, lang)
                            });
                    }

                    foreach (var item in metadata.FocusArea)
                    {
                        PortalMuscleGroup grp = new PortalMuscleGroup();
                        grp.Name = await CreateLocalisedText(item.Name.Trim(), lang);
                        grp.Tag = string.IsNullOrEmpty(item.Tag) ? item.Name.ToLowerInvariant().Trim().Replace(' ', '-') : item.Tag;
                        titlesMetadata.FocusAreas.Add(grp);
                    }

                    foreach (var item in metadata.Equipments)
                    {
                        PortalEquipmentType equipmentType = new PortalEquipmentType();
                        equipmentType.Name = await CreateLocalisedText(item.Name.Trim(), lang);
                        equipmentType.TypeTag = string.IsNullOrEmpty(item.TypeTag) ? item.Name.ToLowerInvariant().Trim().Replace(' ', '-') : item.TypeTag;
                        equipmentType.ImageUri = item.ImageUri;
                        titlesMetadata.Equipments.Add(equipmentType);
                    }

                    foreach (var item in metadata.Labels)
                    {
                        titlesMetadata.Labels.Add(await CreateLocalisedText(item, lang));
                    }

                    titlesMetadata.Language = metadata.Language;
                    titlesMetadata.Intensity = Enumerable.Range(1, 10).ToList();
                    titlesMetadata.SkillLevel = Enumerable.Range(1, 10).ToList();
                    var result = await _blobRepo.PutAsync("*", titlesMetadata).ConfigureAwait(false);
                    if (_cache.TryGetValue(CacheKeys.Metadata, out TitlesMetadata meta))
                    {
                        _cache.Remove(CacheKeys.Metadata);
                    }
                    if (result != null && result.HttpStatusCode == 200)
                    {
                        return Ok();
                    }
                    return StatusCode(500);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Joint")]
        [HttpGet("api/v1/metadata")]
        public async Task<ActionResult<HttpStatusCode>> GetMetadata()
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }
                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                TitlesMetadata metadata = null;
                Provider[] providers = null;
                Channel[] channels = null;

                if (!_cache.TryGetValue(CacheKeys.Metadata, out metadata) || !_cache.TryGetValue(CacheKeys.Providers, out providers)
                    || !_cache.TryGetValue(CacheKeys.Channels, out channels))
                {
                    var metadataTask = _blobRepo.GetAsync<TitlesMetadata>("*");
                    var channelsTask = _channelService.List();
                    var providersTask = _providerService.List();
                    await Task.WhenAll(metadataTask, channelsTask, providersTask).ConfigureAwait(false);

                    if (metadataTask.Result != null && metadataTask.Result.IsSuccessStatusCode)
                    {
                        _cache.Set(CacheKeys.Metadata, metadataTask.Result.Entity, DateTimeOffset.UtcNow.AddYears(1));
                        metadata = metadataTask.Result.Entity;
                    }
                    else
                    {
                        return NotFound("Metadata missing");
                    }
                    if (channelsTask.Result != null && channelsTask.Result.Length > 0)
                    {
                        _cache.Set(CacheKeys.Channels, channelsTask.Result, DateTimeOffset.UtcNow.AddYears(1));
                        channels = channelsTask.Result;
                    }
                    else
                    {
                        return NotFound("Channels missing");
                    }
                    if (providersTask.Result != null && providersTask.Result.Length > 0)
                    {
                        _cache.Set(CacheKeys.Providers, providersTask.Result, DateTimeOffset.UtcNow.AddYears(1));
                        providers = providersTask.Result;
                    }
                    else
                    {
                        return NotFound("Providers missing");
                    }
                }

                var response = await Shape(metadata, channels, providers, lang, userRole, userId).ConfigureAwait(false);
                return Ok(response);
            }
            catch (Exception e)
            {
                _logger.Warn("Getmetadata exception", "warn", e.ToString());
                throw e;
            }
        }

        [Authorize(Policy = "Joint")]
        [HttpPut("api/v1/title/publish/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> PublishTitle(string tag, [FromBody] VirtualClassViewModel title)
        {
            try
            {
                if (title != null && title.Tag == tag && !string.IsNullOrEmpty(title.ProviderID) && !string.IsNullOrEmpty(title.Provider)
                        && title.Skill > 0 && !string.IsNullOrEmpty(title.ChannelId) && title.Intensity > 0
                        && !string.IsNullOrEmpty(title.ClassCategory) && (IsValidCategory(title.ClassCategoryId).Result == true) && title.EquipmentTypeTags != null
                        && !string.IsNullOrEmpty(title.ClassDescription) && !string.IsNullOrEmpty(title.ClassName))
                {

                    var lang = GetIETFTagFromHeaders();
                    if (string.IsNullOrEmpty(lang))
                    {
                        lang = "en-GB";
                    }

                    // Setting the Focus Area and Equipment Names based on Tags
                    if (title.EquipmentTypeTags != null && title.EquipmentTypeTags.Count() > 0
                        || title.FocusAreaTags != null && title.FocusAreaTags.Count() > 0)
                    {
                        var titlesMetadata = await GetTitlesMetaDataAsync(lang).ConfigureAwait(false);

                        if (titlesMetadata != null && titlesMetadata.Equipments != null && title.EquipmentTypeTags != null)
                            title.Equipments = (from eqp in titlesMetadata.Equipments
                                                join eqptag in title.EquipmentTypeTags
                                                on eqp.TypeTag equals eqptag
                                                select eqp.Name.FlattenByLanguage(lang)).ToArray();

                        if (titlesMetadata != null && titlesMetadata.FocusAreas != null && title.FocusAreaTags != null)
                            title.FocusArea = (from fa in titlesMetadata.FocusAreas
                                               join fat in title.FocusAreaTags
                                               on fa.Tag equals fat
                                               select fa.Name.FlattenByLanguage(lang)).ToArray();
                    }


                    if (title.IsMigrating)
                    {
                        if (!string.IsNullOrEmpty(title.SourceProviderId))
                        {
                            await _titleService.MigrateTitleProvider(title).ConfigureAwait(false);
                        }
                        else
                        {
                            return BadRequest();
                        }
                    }

                    var existingTitle = await _titleService.Get(title.ProviderID, tag).ConfigureAwait(false);
                    if (existingTitle != null)
                    {
                        if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
                        {
                            _cache.Remove(CacheKeys.VirtualClass);
                        }

                        var channel = await _channelService.Get(title.ChannelId).ConfigureAwait(false);
                        if (channel != null && channel.Availability.Contains(ChannelAvailability.AppAndWeb))
                        {
                            var titleToUpdate = await _titleService.ModifyTitle(title, existingTitle, lang, "publish").ConfigureAwait(false);
                            if (titleToUpdate != null)
                            {
                                var titleUpdatedResult = await _titleService.Update(titleToUpdate).ConfigureAwait(false);
                                if (!string.IsNullOrEmpty(titleToUpdate.ExternalClassId))
                                {
                                    await ManageMediaMetaData(title.ProviderID, titleToUpdate).ConfigureAwait(false);
                                }
                                if (titleUpdatedResult != null)
                                {
                                    await _commandBus.SendAsync(new TitlePublishCommand
                                    {
                                        ChannelId = channel.Tag,
                                        Tag = existingTitle.Tag,
                                        ProviderId = existingTitle.ProviderID
                                    }).ConfigureAwait(false);

                                    return Ok(titleUpdatedResult);
                                }
                            }
                            return StatusCode(500);
                        }
                        return StatusCode(601);
                    }
                    return NotFound("No title");
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        [Authorize(Policy = "Admin")]
        [HttpDelete("api/v1/title")]
        public async Task<ActionResult<HttpStatusCode>> DeleteTitles([FromBody] List<DeleteTitle> titles)
        {
            try
            {
                if (titles != null && titles.Count > 0)
                {
                    var dictionaryOfTagAndProviderId = titles.ToDictionary(x => x.Tag, x => x.ProviderId);
                    await _commandBus.SendAsync(new TitleDeleteCommand
                    {
                        TitlesData = dictionaryOfTagAndProviderId
                    }).ConfigureAwait(false);

                    if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> cachedTitles))
                    {
                        _cache.Remove(CacheKeys.VirtualClass);
                    }
                    return NoContent();
                }

                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("DeleteTitles exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }


        [Authorize(Policy = "Joint")]
        [HttpDelete("api/v2/titles")]
        public async Task<ActionResult<HttpStatusCode>> RemoveTitles([FromBody] List<DeleteTitle> titles, CancellationToken stoppingToken)
        {
            try
            {
                if (titles != null && titles.Count > 0)
                {
                    List<VirtualClass> listVirtualClassesTables = new List<VirtualClass>();
                    List<OnDemandCollection> listOndemandCollection = new List<OnDemandCollection>();
                    List<OnDemandCollection> listOndemandCollectionBlobs = new List<OnDemandCollection>();
                    Dictionary<string, List<VirtualClass>> dicglobalVirtualClassesBlob = new Dictionary<string, List<VirtualClass>>();
                    var dictionaryOfTagAndProviderId = titles.ToDictionary(x => x.Tag, x => x.ProviderId);//Key =Tag, Value= ProviderId
                    var globallistVirtualClassesTables = (List<VirtualClass>)await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);
                    var listofModifiedTenantSpecificRecords = new List<string>();// tenantid

                    var tenantlist = GetAllTenantsID(stoppingToken).Result; //get list of all tenants
                    foreach (var item in tenantlist)
                    {
                        var OnDemandCollectionListbyTenantIDs = await _blobRepo.GetSetAsync<OnDemandCollection>(item.TenantID).ConfigureAwait(false);
                        if (OnDemandCollectionListbyTenantIDs != null && OnDemandCollectionListbyTenantIDs.Entity != null && OnDemandCollectionListbyTenantIDs.Entity.Items != null && OnDemandCollectionListbyTenantIDs.Entity.Items.Count() > 0)
                        {
                            listOndemandCollectionBlobs.AddRange(OnDemandCollectionListbyTenantIDs.Entity.Items.ToList());
                        }
                        var virtualClassListBlobs = await _blobRepo.GetSetAsync<VirtualClass>(item.TenantID).ConfigureAwait(false);
                        if (virtualClassListBlobs != null && virtualClassListBlobs.Entity != null && virtualClassListBlobs.Entity.Items != null)
                        {
                            dicglobalVirtualClassesBlob.Add(item.TenantID, virtualClassListBlobs.Entity.Items.ToList());
                        }
                    }

                    foreach (var item in dictionaryOfTagAndProviderId)
                    {
                        //get list of titles from Table Repo
                        var filteredVirtualClasses = globallistVirtualClassesTables != null && globallistVirtualClassesTables.Count() > 0 ? globallistVirtualClassesTables.Where(x => x.ProviderID.Equals(item.Value) && x.Tag.Equals(item.Key)).ToList() : null;//
                        if (filteredVirtualClasses != null && filteredVirtualClasses.Count() > 0)
                        {
                            listVirtualClassesTables.AddRange(filteredVirtualClasses);
                        }

                        //Get list of linked collections
                        var globalListOndemandCollections = listOndemandCollectionBlobs != null && listOndemandCollectionBlobs.Count() > 0 ? listOndemandCollectionBlobs.Where(x => x.Section != null && x.Section[0].Slot != null).ToList() : null;
                        var filteredOndemandCollections = globalListOndemandCollections != null && globalListOndemandCollections.Count() > 0 ? globalListOndemandCollections.Where(x => x.Section[0].Slot.Any(x => x.OnDemandClassTag.Equals(item.Key))).ToList() : null;

                        if (filteredOndemandCollections != null && filteredOndemandCollections.Count() > 0)
                        {
                            listOndemandCollection.AddRange(filteredOndemandCollections);
                        }
                    }

                    foreach (var title in listVirtualClassesTables)
                    {
                        title.IsDelete = true; // set IsDelete to true to mark it as deleted
                        title.LastModifiedDate = System.DateTime.UtcNow;
                    }

                    //remove titles from blob                    
                    int premodifiedcounts, postmodifiedcounts = 0;
                    foreach (var keyValuePair in dicglobalVirtualClassesBlob)
                    {
                        premodifiedcounts = keyValuePair.Value.Count();
                        keyValuePair.Value.RemoveAll(x => dictionaryOfTagAndProviderId.ContainsKey(x.Tag));
                        postmodifiedcounts = keyValuePair.Value.Count();
                        if (premodifiedcounts != postmodifiedcounts)// records have been deleted from blob
                        {
                            listofModifiedTenantSpecificRecords.Add(keyValuePair.Key);
                        }

                    }

                    //remove entries of titles from collections and update collections
                    for (int i = 0; i < dictionaryOfTagAndProviderId.Count(); i++)
                    {
                        var onDemandCollectionList = listOndemandCollection.Where(x => x.Section[0].Slot.Any(y => y.OnDemandClassTag == dictionaryOfTagAndProviderId.ElementAt(i).Key)).ToList();

                        if (onDemandCollectionList != null && onDemandCollectionList.Count() > 0)
                        {
                            for (int j = 0; j < onDemandCollectionList.Count(); j++)
                            {
                                var slot = onDemandCollectionList[j].Section[0].Slot.ToList();
                                var slotlength = onDemandCollectionList[j].Section[0].Slot.Length;
                                slot.RemoveAll(x => x.OnDemandClassTag.Equals(dictionaryOfTagAndProviderId.ElementAt(i).Key));
                                onDemandCollectionList[j].Section[0].Slot = slot.ToArray();
                            }
                        }
                    }

                    //update master table data
                    foreach (var title in listVirtualClassesTables)
                    {
                        try
                        {
                            await _cmsStore.StoreAsync(title.Tag, title, "", title.ProviderID).ConfigureAwait(false);// commented for testing
                            _logger.Info($"Delete Titles updated in table repo for tile id: {title.Tag}");
                        }
                        catch (Exception ex)
                        {
                            _logger.Warn("DeleteTitles exception for tile id: " + title.Tag, "warn", ex.ToString());
                        }
                    }

                    //update tenants specific blobs data and collections data
                    foreach (var tenantid in listofModifiedTenantSpecificRecords)//dicglobalVirtualClassesBlob
                    {
                        var tenantspecifictitles = dicglobalVirtualClassesBlob.Where(x => x.Key == tenantid).FirstOrDefault();
                        if (!string.IsNullOrEmpty(tenantspecifictitles.Key))
                        {
                            var status = await _blobRepo.PutSetAsync(tenantspecifictitles.Key,
                                new EntitySet<VirtualClass>
                                {
                                    Count = tenantspecifictitles.Value.Count,
                                    Items = tenantspecifictitles.Value.ToArray()
                                }).ConfigureAwait(false);
                            if (status != null && status.HttpStatusCode == 200)
                            {
                                _logger.Info($"Virtual Classes deleted succesfully from blob for tenant id : {tenantid }");
                            }
                            else
                            {
                                _logger.Info($"Virtual Classes deleted failed from blob for tenant id : {tenantid }");
                            }
                        }

                        //update collections
                        var collectionsToUpdate = listOndemandCollection.Where(x => x.TenantId == tenantid).ToList();
                        if (collectionsToUpdate != null && collectionsToUpdate.Count > 0)
                        {
                            var result = await _blobRepo.PutSetAsync(tenantid, new EntitySet<OnDemandCollection>
                            {
                                Count = collectionsToUpdate.Count,
                                Items = collectionsToUpdate.ToArray()
                            }, createSnapshot: true);
                            if (result != null && result.HttpStatusCode == 200)
                            {
                                _logger.Info($"Virtual Classes deleted succesfully for : {tenantid }");
                            }
                            else
                            {
                                _logger.Info($"Virtual Classes deletion failed for : {string.Join(",", tenantid)} ");
                            }
                        }
                    }

                    return Ok();
                }
                else
                    return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("DeleteTitles exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpDelete("api/v1/titles/cache/{key}")]
        public ActionResult<HttpStatusCode> RemoveTitlesChache(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                return BadRequest();
            }

            if (key == CacheKeys.Providers)
            {
                if (_cache.TryGetValue(CacheKeys.Providers, out IEnumerable<VirtualClass> providers))
                {
                    _cache.Remove(CacheKeys.Providers);
                    _logger.Info("Providers Caching removed");
                    return Ok();
                }
                return NoContent();
            }

            if (key == CacheKeys.Channels)
            {
                if (_cache.TryGetValue(CacheKeys.Channels, out IEnumerable<VirtualClass> channels))
                {
                    _cache.Remove(CacheKeys.Channels);
                    _logger.Info("Channels Caching removed");
                    return Ok();
                }
                return NoContent();
            }

            if (key == CacheKeys.Tenants)
            {
                if (_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<VirtualClass> tenants))
                {
                    _cache.Remove(CacheKeys.Tenants);
                    _logger.Info("Tenants Caching removed");
                    return Ok();
                }
                return NoContent();
            }

            if (key == CacheKeys.VirtualClass)
            {
                if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
                {
                    _cache.Remove(CacheKeys.VirtualClass);
                    _logger.Info("VirtualClass Caching removed");
                    return Ok();
                }
                return NoContent();
            }

            if (key == CacheKeys.Metadata)
            {
                if (_cache.TryGetValue(CacheKeys.Metadata, out IEnumerable<VirtualClass> metadata))
                {
                    _cache.Remove(CacheKeys.Metadata);
                    _logger.Info("Metadata Caching removed");
                    return Ok();
                }
                return NoContent();
            }

            return NoContent();
        }

        [Authorize(Policy = "Joint")]
        [HttpPut("api/v1/virtualclass/search")]
        public async Task<ActionResult<HttpStatusCode>> SearchTitles([FromBody] VirtualClassSearchCriteria criteria)
        {
            try
            {
                var tenant = GetTenantIDFromHeaders();

                if (string.IsNullOrEmpty(tenant))
                {
                    return BadRequest();
                }

                if (criteria == null)
                {
                    return BadRequest();
                }
                using (HttpClient client = new HttpClient())
                {
                    var environment= Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                    HttpResponseMessage response = await client.PutAsync(""/, criteria);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.Write("Success");
                    }
                    else
                    {
                        Console.Write("Failure");
                    }

                    return response;
                }
            }
            catch (Exception e)
            {
                _logger.Warn("DeleteTitles exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        private async Task<object> Shape(TitlesMetadata entity, Channel[] channels, Provider[] providers, string lang, string userRole, string userId)
        {
            try
            {
                List<object> categories = new List<object>();
                var virtualClassList = await _titleService.List(userId, userRole).ConfigureAwait(false);

                foreach (var item in entity.Categories)
                {
                    categories.Add(new
                    {
                        CategoryId = item.Id,
                        Category = item.Name.FlattenByLanguage(lang),
                        Description = item.Description.FlattenByLanguage(lang),
                        SubCategories = item.Subcategory.Select(x => x.FlattenByLanguage(lang))
                    });
                }

                var regularChannels = channels;
                var regularProviders = providers;
                if (userRole == Convert.ToInt32(Roles.Provider).ToString())
                {
                    regularChannels = regularChannels.Where(x => x.Provider == userId).ToArray();
                    regularProviders = regularProviders.Where(x => x.Tag == userId).ToArray();
                }
                else if (userRole == Convert.ToInt32(Roles.ClientProvider).ToString())
                {
                    var tenants = await Task.Run(() => _db.ReadList<TenantDetail>()).ConfigureAwait(false);
                    var existingTenant = tenants.Where(x => x.Data.Entity.ProviderId == userId).FirstOrDefault();
                    var tenantId = "";
                    if (existingTenant != null)
                        tenantId = existingTenant.Data.Key;
                    regularChannels = regularChannels.Where(x => (x.Provider == userId || x.Tenants.Contains(tenantId))).ToArray();
                    var channelProviders = regularChannels.Select(y => y.Provider);
                    regularProviders = regularProviders.Where(x => (x.Tag == userId || channelProviders.Contains(x.Tag))).ToArray();
                }

                return new
                {
                    categories,
                    Equipments = entity.Equipments.Select(x => new
                    {
                        x.TypeTag,
                        Name = x.Name.FlattenByLanguage(lang),
                        x.ImageUri,
                    }),
                    FocusAreas = entity.FocusAreas.Select(x => new
                    {
                        x.Tag,
                        Name = x.Name.FlattenByLanguage(lang),
                    }),
                    Channels = regularChannels
                    .Select(t => new
                    {
                        t.Tag,
                        Name = t.Name.FlattenByLanguage(lang),
                        DisplayName = t.DisplayName.FlattenByLanguage(lang),
                        ProviderId = t.Provider
                    }),
                    Providers = regularProviders
                    .Select(t => new
                    {
                        t.Tag,
                        t.Name
                    }),
                    Labels = entity.Labels.Select(t => t.FlattenByLanguage(lang)),
                    Languages = entity.Language,
                    SkillLevel = entity.SkillLevel != null && entity.SkillLevel.Count > 0 ? entity.SkillLevel : Enumerable.Range(1, 10).ToList(),
                    Intensity = entity.Intensity != null && entity.Intensity.Count > 0 ? entity.Intensity : Enumerable.Range(1, 10).ToList(),
                    DurationSecond = virtualClassList.Select(x => x.DurationSecond).Distinct().OrderBy(x => x),
                    DurationMinutes = virtualClassList.Select(x => string.Format("{2:D2}:{0:D2}:{1:D2}", TimeSpan.FromSeconds(x.DurationSecond).Minutes, TimeSpan.FromSeconds(x.DurationSecond).Seconds, TimeSpan.FromSeconds(x.DurationSecond).Hours)).Distinct().OrderBy(x => x),
                };
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        private async Task ManageMediaMetaData(string providerId, VirtualClass title)
        {
            try
            {
                var media = await _jwplayerRepo.GetMediaById<MediaResponse>(new MediaRequest { ProviderId = providerId, MediaId = title.ExternalClassId }).ConfigureAwait(false);
                if (media != null)
                {
                    var mediaRequest = new MediaRequest { ProviderId = providerId, MediaId = title.ExternalClassId, Metadata = new MediaMetadata() };
                    List<string> titleTagInfo = new List<string>();

                    if (title.ClassCategories != null)
                        titleTagInfo.Add(title.ClassCategories.InvariantText);
                    if (title.ClassSubCategory != null && title.ClassSubCategory.InvariantText != "")
                        titleTagInfo.Add(title.ClassSubCategory.InvariantText);
                    titleTagInfo.AddRange(title.Equipments.InvariantText.Split('|'));
                    if (title.FocusArea != null)
                        titleTagInfo.AddRange(title.FocusArea.InvariantText.Split('|'));
                    if (title.Labels != null)
                        titleTagInfo.AddRange(title.Labels);

                    if (title.Skill >= 1 && title.Skill <= 4)
                        titleTagInfo.Add("low-skill");
                    else if (title.Skill >= 5 && title.Skill <= 7)
                        titleTagInfo.Add("medium-skill");
                    else if (title.Skill >= 8 && title.Skill <= 10)
                        titleTagInfo.Add("high-skill");

                    if (title.Intensity >= 1 && title.Intensity <= 4)
                        titleTagInfo.Add("low-intensity");
                    else if (title.Intensity >= 5 && title.Intensity <= 7)
                        titleTagInfo.Add("medium-intensity");
                    else if (title.Intensity >= 8 && title.Intensity <= 10)
                        titleTagInfo.Add("high-intensity");

                    mediaRequest.Metadata.Title = title.ClassName;
                    mediaRequest.Metadata.Publish_start_date = title.ScheduleDate?.ToString("o");
                    mediaRequest.Metadata.Tags = titleTagInfo.Where(x => x != "").ToList();
                    mediaRequest.Metadata.Custom_params = media.Metadata.Custom_params;
                    await _jwplayerRepo.UpdateMediaMetadata<MediaResponse>(mediaRequest).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("TitlesController > ManageMediaMetaData > titleTag:{0} & Error:{1}", title.Tag, ex.ToString()));
                throw ex;
            }
        }
        private async Task<bool> IsValidCategory(int categoryid)
        {
            TitlesMetadata metadata = null;

            if (!_cache.TryGetValue(CacheKeys.Metadata, out metadata))
            {
                var metadataTask = _blobRepo.GetAsync<TitlesMetadata>("*");
                await Task.WhenAll(metadataTask).ConfigureAwait(false);

                if (metadataTask.Result != null && metadataTask.Result.IsSuccessStatusCode)
                {
                    _cache.Set(CacheKeys.Metadata, metadataTask.Result.Entity, DateTimeOffset.UtcNow.AddYears(1));
                    metadata = metadataTask.Result.Entity;
                }
            }
            var category = metadata.Categories.Where(x => x.Id == categoryid).FirstOrDefault();
            if (category != null)
            { return true; }
            else
                return false;
        }

        private async Task<List<TenantDetail>> GetAllTenantsID(CancellationToken stoppingToken)
        {
            var _TenantID = GetTenantIDFromHeaders();
            if (string.IsNullOrEmpty(_TenantID))
            {
                if (!_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<TenantDetail> tenants))
                {
                    var entities = await Task.Run(() => _db.Read<TenantDetail>(), stoppingToken).ConfigureAwait(false);
                    if (entities != null && entities.Data != null && entities.Data.Count > 0)
                    {
                        _cache.Set(CacheKeys.Tenants, entities.Data.Select(t => t.Entity), new MemoryCacheEntryOptions
                        {
                            SlidingExpiration = TimeSpan.FromDays(1),
                            AbsoluteExpiration = DateTimeOffset.UtcNow.AddDays(356)
                        });

                        tenants = entities.Data.Select(x => x.Entity);
                        return tenants.ToList();
                    }
                    else
                    {
                        return new List<TenantDetail>();
                    }

                }
            }
            else
            {
                var listTenantDetails = new List<TenantDetail>();
                listTenantDetails.Add(new TenantDetail
                {
                    TenantID = _TenantID
                });
                return listTenantDetails;
            }
            return new List<TenantDetail>();
        }
    }

    public class ContentMetadataViewModel
    {
        public List<Categories> Categories { get; set; }
        public List<PortalEquipmentTypeRawData> Equipments { get; set; }
        public List<PortalMuscleGroupRawData> FocusArea { get; set; }
        //public List<Subcategories> Subcategories { get; set; }
        public List<string> Labels { get; set; }
        public List<Language> Language { get; set; }
    }


    public class PortalMuscleGroupRawData
    {
        public string Tag { get; set; }
        public string Name { get; set; }
        public string Keywords { get; set; }
        public string IsHidden { get; set; }
    }

    public class PortalEquipmentTypeRawData
    {
        public string TypeTag { get; set; }
        public string Name { get; set; }
        public string ImageUri { get; set; }
        public string Keywords { get; set; }
        public bool CanTrackWeight { get; set; }
    }

    public class Categories
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<string> SubCategories { get; set; }
        public string Description { get; set; }
    }

    public class DeleteTitle
    {
        public string ProviderId { get; set; }
        public string Tag { get; set; }
    }
}
