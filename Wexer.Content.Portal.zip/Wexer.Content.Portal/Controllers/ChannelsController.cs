﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.Tenant;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.OData.Edm;
using Wexer.Content.Portal.Attributes;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.UserService;
using System.IO;
using System.Reflection;
using System.Text;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Command.Commands.Channel;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class ChannelsController : CommonController
    {
        private readonly ILogger _logger;
        private IMemoryCache _cache;
        private readonly IChannelService _channelService;
        private readonly IProviderService _providerService;
        private readonly IUserService _userService;
        private readonly ICommandBus _commandBus;

        public ChannelsController(ILoggerFactory loggerFactory, IMemoryCache memoryCache,
            IChannelService channelService, IProviderService providerService, IUserService userService, ICommandBus commandBus)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _cache = memoryCache;
            _channelService = channelService;
            _providerService = providerService;
            _userService = userService;
            _commandBus = commandBus;
        }


        [Authorize(Policy = "Admin")]
        [HttpPost("api/v1/channel")]
        public async Task<ActionResult<HttpStatusCode>> CreateChannel([FromBody] ChannelViewModel channel)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                if (channel != null)
                {
                    if (string.IsNullOrEmpty(channel.Provider))
                    {
                        return BadRequest();
                    }
                    if (_cache.TryGetValue(CacheKeys.Channels, out Channel[] channels))
                    {
                        _cache.Remove(CacheKeys.Channels);
                    }
                    
                    var result = await _channelService.Create(channel, lang).ConfigureAwait(false);

                    if(result.Item1 == HttpStatusCode.Conflict)
                    {
                        return Conflict();
                    }

                    if (result.Item1 == HttpStatusCode.Created && result.Item2 != null)
                    {
                        channel.Tag = result.Item2.Tag;
                        return CreatedAtAction("CreateChannel", channel);
                    }
                }

                return StatusCode(500);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [Authorize(Policy = "Joint")]
        [HttpGet("api/v1/channels")]
        public async Task<ActionResult<HttpStatusCode>> GetChannels()
        {
            try
            {

                Channel[] channels = null;
                Provider[] providers = null;
                TenantDetail[] tenants = null;

                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                if (string.IsNullOrEmpty(userRole) || string.IsNullOrEmpty(userId))
                {
                    return BadRequest();
                }

                if (_cache.TryGetValue(CacheKeys.Channels, out channels) && channels != null
                    && _cache.TryGetValue(CacheKeys.Providers, out providers) && providers != null
                    && _cache.TryGetValue(CacheKeys.Tenants, out tenants) && tenants != null)
                {
                    var result = await ShapeChannelsResponse(channels, providers, tenants, userRole, userId, lang).ConfigureAwait(false);
                    return result;
                }
                else
                {
                    var channelsTask = _channelService.List();
                    var providersTask = _providerService.List();
                    var tenantsTask = _userService.GetTenants();
                    await Task.WhenAll(channelsTask, providersTask, tenantsTask).ConfigureAwait(false);

                    if (tenantsTask.Result != null && tenantsTask.Result.Length > 0)
                    {
                        tenants = tenantsTask.Result;
                        _cache.Set(CacheKeys.Tenants, tenantsTask.Result, DateTimeOffset.UtcNow.AddYears(1));
                    }
                    if (channelsTask.Result != null && channelsTask.Result.Length > 0)
                    {
                        channels = channelsTask.Result;
                        _cache.Set(CacheKeys.Channels, channelsTask.Result, DateTimeOffset.UtcNow.AddYears(1));
                    }
                    if (providersTask.Result != null && providersTask.Result.Length > 0)
                    {
                        providers = providersTask.Result;
                        _cache.Set(CacheKeys.Providers, providersTask.Result, DateTimeOffset.UtcNow.AddYears(1));
                        var result = await ShapeChannelsResponse(channels, providers, tenants, userRole, userId, lang).ConfigureAwait(false);
                        return result;
                    }
                }
                return NotFound("No data");

            }
            catch (Exception e)
            {
                _logger.Warn("Create channel failed", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Joint")]
        [HttpPut("api/v1/channel")]
        public async Task<ActionResult<HttpStatusCode>> EditChannel([FromBody] ChannelViewModel channelRequest)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                if (channelRequest != null)
                {
                    if (string.IsNullOrEmpty(channelRequest.Provider))
                    {
                        return BadRequest();
                    }


                    var listChannels = await _channelService.List().ConfigureAwait(false);
                    var existingChannel = listChannels.FirstOrDefault(t => t.Tag == channelRequest.Tag);

                    if (existingChannel != null)
                    {
                        if (existingChannel.Name.InvariantText.ToLowerInvariant() != channelRequest.Name.ToLowerInvariant())
                        {
                            if (listChannels.Any(x => x.Name.InvariantText.ToLowerInvariant() == channelRequest.Name.ToLowerInvariant().Trim()))
                            {
                                return Conflict();
                            }
                        }
                        if (_cache.TryGetValue(CacheKeys.Channels, out Channel[] channels))
                        {
                            _cache.Remove(CacheKeys.Channels);
                        }

                        await UpdateLocalisedText(existingChannel.Name, channelRequest.Name, lang);
                        await UpdateLocalisedText(existingChannel.DisplayName, channelRequest.DisplayName, lang);
                        await UpdateLocalisedText(existingChannel.Description, channelRequest.Description, lang);
                        existingChannel.Active = channelRequest.Active;
                        existingChannel.Availability = channelRequest.Availability;
                        existingChannel.MediaSpaceImageUrl = channelRequest.MediaSpaceImageUrl;
                        existingChannel.ProfileImageUrl = channelRequest.ProfileImageUrl;
                        existingChannel.Tenants = channelRequest.Tenants.ToHashSet().ToList();
                        existingChannel.Provider = channelRequest.Provider;
                        existingChannel.LastUpdatedDate = DateTime.UtcNow;

                        var result = await _channelService.Update(existingChannel, lang).ConfigureAwait(false);
                        if (result == HttpStatusCode.OK)
                        {
                            return Ok(channelRequest);
                        }
                        return StatusCode((int)result);
                    }

                    return NotFound();
                }
                return BadRequest("Invalid request");
            }
            catch (Exception e)
            {
                _logger.Warn("Update channel failed", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Admin")]
        [HttpPut("api/v1/channel/{tag}/publish")]
        public async Task<ActionResult<HttpStatusCode>> Publish(string tag, [FromBody] ChannelPublishViewModel model)
        {
            try
            {
                if (model != null && !string.IsNullOrEmpty(tag))
                {
                    var channel = await _channelService.Get(tag).ConfigureAwait(false);
                    if(channel != null)
                    {
                        if(model.TenantIdsToPublish != null && model.TenantIdsToPublish.Count > 0)
                        {
                            await _commandBus.SendAsync(new ChannelPublishCommand
                            {
                                ChannelTag = tag,
                                TenantIdsToPublish = model.TenantIdsToPublish
                            }).ConfigureAwait(false);

                        }

                        if(model.TenantIdsToUnPublish != null && model.TenantIdsToUnPublish.Count > 0)
                        {
                            await _commandBus.SendAsync(new ChannelUnPublishCommand
                            {
                                ChannelTag = tag,
                                TenantIdsToUnPublish = model.TenantIdsToUnPublish
                            }).ConfigureAwait(false);
                        }

                        return NoContent();
                    }
                    else
                    {
                        return NotFound("Channel not found");
                    }
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [Authorize(Policy = "Admin")]
        [HttpDelete("staff/v1/channel")]
        public async Task<ActionResult<HttpStatusCode>> Delete([FromBody] List<string> channelIds)
        {
            try
            {
                List<string> removed = new List<string>();
                if (_cache.TryGetValue(CacheKeys.Channels, out Channel[] channels))
                {
                    _cache.Remove(CacheKeys.Channels);
                }
                foreach (var channelId in channelIds)
                {
                    var result = await _channelService.Delete(channelId).ConfigureAwait(false);
                    if (result == HttpStatusCode.OK)
                    {
                        removed.Add(channelId);
                    }
                }

                return Ok(removed);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [Authorize(Policy = "Admin")]
        [HttpPut("api/v1/channels/bulk")]
        public async Task<ActionResult<HttpStatusCode>> BulkUpdateChannel([FromBody] List<ChannelViewModel> channels)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                if (channels != null && channels.Count > 0)
                {
                    var listChannels = await _channelService.List().ConfigureAwait(false);

                    if (listChannels != null && listChannels.Length > 0)
                    {
                        foreach (var channel in channels)
                        {
                            var existingChannel = listChannels.FirstOrDefault(t => t.Tag == channel.Tag);

                            if (existingChannel != null)
                            {
                                if (existingChannel.Name.InvariantText.ToLowerInvariant() != channel.Name.ToLowerInvariant())
                                {
                                    if (listChannels.Any(x => x.Name.InvariantText.ToLowerInvariant() == channel.Name.ToLowerInvariant().Trim()))
                                    {
                                        return Conflict();
                                    }
                                }
                                
                                await UpdateLocalisedText(existingChannel.Name, channel.Name, lang);
                                await UpdateLocalisedText(existingChannel.DisplayName, channel.DisplayName, lang);
                                await UpdateLocalisedText(existingChannel.Description, channel.Description, lang);
                                existingChannel.Active = channel.Active;
                                existingChannel.Availability = channel.Availability;
                                existingChannel.MediaSpaceImageUrl = channel.MediaSpaceImageUrl;
                                existingChannel.ProfileImageUrl = channel.ProfileImageUrl;
                                existingChannel.Tenants = channel.Tenants.ToHashSet().ToList();
                                existingChannel.Provider = channel.Provider;
                                existingChannel.LastUpdatedDate = DateTime.UtcNow;
                            }
                            else
                            {
                                return NotFound($"No channel with Tag:{channel.Tag}");
                            }
                        }

                        if (_cache.TryGetValue(CacheKeys.Channels, out Channel[] channelsCache))
                        {
                            _cache.Remove(CacheKeys.Channels);
                        }

                        var result = await _channelService.SaveMultiple(listChannels).ConfigureAwait(false);
                        if (result)
                        {
                            return Ok();
                        }
                        return StatusCode(500);
                    }
                    else
                    {
                        return NotFound("No channels");
                    }
                }

                return BadRequest();

            }
            catch (Exception e)
            {
                _logger.Warn("BulkUpdateChannel exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [Authorize(Policy = "Admin")]
        [HttpGet("api/v1/channel/export")]
        public async Task<ActionResult<HttpStatusCode>> BulkChannelExport()
        {
            try
            {
                var channels = await _channelService.List().ConfigureAwait(false);
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }
                if(channels != null && channels.Length > 0)
                {
                    var listChannels = channels.Select(x => new ChannelViewModel
                    {
                        Name = x.Name.FlattenByLanguage(lang),
                        Description = x.Description.FlattenByLanguage(lang),
                        Active = x.Active,
                        Availability = x.Availability,
                        DisplayName = x.DisplayName.FlattenByLanguage(lang),
                        MediaSpaceImageUrl = x.MediaSpaceImageUrl,
                        ProfileImageUrl = x.ProfileImageUrl,
                        Provider = x.Provider,
                        Tag = x.Tag,
                        Tenants = x.Tenants
                    });

                    if(listChannels != null && listChannels.Count() > 0)
                    {
                        return Ok(listChannels);
                    }
                }

                return NotFound("No channels found");
            }
            catch (Exception e)
            {

                return StatusCode(500);
            }
        }

        private async Task<ObjectResult> ShapeChannelsResponse(Channel[] channels, Provider[] providers, TenantDetail[] tenants, string role, string userId, string lang)
        {
            try
            {
                List<dynamic> result = new List<dynamic>();

                if ((channels != null && channels.Length > 0) && (providers != null && providers.Length > 0))
                {
                    if (Convert.ToInt32(role) == Convert.ToInt32(Roles.Provider) || Convert.ToInt32(role) == Convert.ToInt32(Roles.ClientProvider))
                    {
                        channels = channels.Where(t => t.Provider == userId).ToArray();
                        providers = providers.Where(t => t.Tag == userId).ToArray();
                    }
                    if(Convert.ToInt32(role) == Convert.ToInt32(Roles.Admin))
                    {
                        channels = channels.Where(t => !t.IsTenantProviderChannel).ToArray();
                        providers = providers.Where(t => !t.IsTenantProvider).ToArray();
                    }
                    foreach (var item in channels)
                    {
                        result.Add(new
                        {
                            item.Tag,
                            Name = item.Name.FlattenByLanguage(lang),
                            DisplayName = item.DisplayName.FlattenByLanguage(lang),
                            Description = item.Description.FlattenByLanguage(lang),
                            item.Active,
                            item.Availability,
                            item.MediaSpaceImageUrl,
                            item.ProfileImageUrl,
                            Provider = providers.FirstOrDefault(t => item.Provider == t.Tag),
                            item.Tenants
                        });
                    }
                }

                return Ok(
                    new
                    {
                        Channels = result,
                        Providers = providers != null && providers.Length > 0 ? providers : new Provider[0],
                        Tenants = tenants.Select(t => new { Id = t.TenantID, t.Name, t.TimeZoneInfo, t.IsProviderActive, t.Url })
                    });

            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }

    public class ChannelPublishViewModel
    {
        public List<string> TenantIdsToPublish { get; set; }
        public List<string> TenantIdsToUnPublish { get; set; }

    }
}
