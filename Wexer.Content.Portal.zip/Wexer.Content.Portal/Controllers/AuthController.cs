﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.FitnessTracking;
using Wexer.Content.Portal.Models.User;
using Wexer.Content.Portal.Models.User.Profiles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.MediaService;
using Wexer.Content.Portal.UserService.SignupService;

namespace Wexer.Content.Portal.Controllers
{
    public class AuthController : CommonController
    {
        private readonly ILogger _logger;
        private readonly IFirebaseClient _firebaseClient;
        private readonly IUserBlobRepo _userBlobRepo;
        private readonly IUserSignupService _userSignupService;
        private readonly IBlobRepo _blobRepo;
        //private readonly IMediaServiceRepo _mediaService;
        public AuthController(ILoggerFactory loggerFactory, IFirebaseClient firebaseClient, IUserBlobRepo userBlobRepo,
            IUserSignupService userSignupService, IBlobRepo blobRepo)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _firebaseClient = firebaseClient;
            _userBlobRepo = userBlobRepo;
            _userSignupService = userSignupService;
            _blobRepo = blobRepo;
        }




        [HttpPost("api/v1/verify")]
        public async Task<ActionResult> Login([FromBody] FirebaseModel model)
        {
            try
            {
                var app = FirebaseAuth.DefaultInstance;
                var tokenDecoded = await app.VerifyIdTokenAsync(model.Token);
                return Ok(new
                {
                    tokenDecoded.Audience,
                    tokenDecoded.ExpirationTimeSeconds,
                    tokenDecoded.Issuer,
                    claims = tokenDecoded.Claims.Where(t => t.Key.ToLowerInvariant() != "firebase").Select(t => new { t.Key, t.Value })
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    public class FirebaseModel
    {
        public string Token { get; set; }
    }
}