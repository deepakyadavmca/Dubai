﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.EventService;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.JWPlayer;
using Wexer.Content.Portal.Models.JWPlayer.Request;
using Wexer.Content.Portal.Models.ScheduleEvents;
using Wexer.Content.Portal.ProviderService;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.JWPlayer;
using Wexer.Content.Portal.Repositories.JWPlayer.Models;
using Wexer.Content.Portal.UserService;

namespace Wexer.Content.Portal.Controllers
{
    [Route("connect")]
    [ApiController]
    public class ConnectController : CommonController
    {
        private readonly ILogger _logger;
        private readonly IEventService _eventService;
        private readonly IUserService _userService;
        private readonly IProviderService _providerService;
        private readonly IBlobRepo _blobRepo;
        private IMemoryCache _cache;
        private readonly IJWPlayerRepo _jwplayerRepo;

        public ConnectController(ILoggerFactory loggerFactory, IEventService eventService, IUserService userService, IProviderService providerService
            , IBlobRepo blobRepo, IMemoryCache cache, IJWPlayerRepo jwplayerRepo)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _eventService = eventService;
            _userService = userService;
            _providerService = providerService;
            _blobRepo = blobRepo;
            _cache = cache;
            _jwplayerRepo = jwplayerRepo;
        }

        [Authorize(Policy = "AdminClientProvider")]
        [HttpGet("events/{tenantId?}")]
        public async Task<ActionResult<HttpStatusCode>> GetEvent(string tenantId)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();

                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                if (Convert.ToInt32(userRole) == Convert.ToInt32(Roles.Admin) && string.IsNullOrWhiteSpace(tenantId))
                {
                    return BadRequest("TenantId required");
                }
                if (string.IsNullOrEmpty(tenantId) && Convert.ToInt32(userRole) == Convert.ToInt32(Roles.ClientProvider))
                {
                    var provider = await _providerService.Get(userId).ConfigureAwait(false);
                    if (provider != null && provider.IsTenantProvider && !string.IsNullOrEmpty(provider.TenantId))
                    {
                        tenantId = provider.TenantId;
                    }
                    else
                    {
                        return BadRequest("Provider information missing");
                    }
                }


                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }
                var events = await _eventService.List(tenantId).ConfigureAwait(false);
                if (events != null && events.Count() > 0)
                {
                    return Ok(Shape(events, lang));
                }
                return NotFound();
            }
            catch (Exception e)
            {
                _logger.Warn("GetEvent exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        private dynamic Shape(IEnumerable<ScheduleEvent> events, string lang = "en-GB")
        {
            try
            {
                return events.Select(t => new
                {
                    t.Event_Id,
                    Title = t.Title.FlattenByLanguage(lang),
                    Description = t.Description.FlattenByLanguage(lang),
                    t.ImageUrl,
                    t.Scheduled_Time,
                    t.Active,
                    t.Type,
                    t.Schedule,
                    t.TenantId,
                    t.IsLocked,
                    t.AllowAutoPublish,
                    t.EventStatus,
                    EventKey = t.Type == EventType.TrueLive ? t.EventKey : null,
                    Video = t.Video != null ? new
                    {
                        t.Video.Tag,
                        ClassName = t.Video.ClassName != null ? t.Video.ClassName.FlattenByLanguage(lang) : null,
                        ClassDescription = t.Video.ClassDescription != null ? t.Video.ClassDescription.FlattenByLanguage(lang) : null,
                        t.Video.ClassLanguage,
                        t.Video.ClassLanguageCode,
                        ClassCategory = t.Video.ClassCategories != null ? t.Video.ClassCategories.FlattenByLanguage(lang) : null,
                        t.Video.ClassCategoryId,
                        ClassSubCategory = t.Video.ClassSubCategory != null ? t.Video.ClassSubCategory.FlattenByLanguage(lang) : null,
                        t.Video.Intensity,
                        t.Video.Skill,
                        t.Video.RawVideoFileUrl,
                        t.Video.StreamingLink,
                        t.Video.AlternateLink,
                        t.Video.ImageLink,
                        t.Video.Status,
                        t.Video.Instructor,
                        t.Video.Level,
                        t.Video.Labels,
                        Keywords = t.Video.Keywords != null ? t.Video.Keywords.FlattenByLanguage(lang) : null,
                        t.Video.StartDate,
                        t.Video.EndDate,
                        t.Video.ProviderID,
                        t.Video.Provider,
                        Equipments = t.Video.Equipments != null ? t.Video.Equipments.FlattenByLanguage(lang) : null,
                        t.Video.ScheduleDate,
                        t.Video.TrailerLinkWeb,
                        t.Video.TrailerLinkMobile,
                        t.Video.TrailerName,
                        t.Video.isComplete,
                        t.Video.IsEquipment,
                        t.Video.isActive,
                        t.Video.DurationSecond,
                        t.Video.ErrorType,
                        FocusArea = !string.IsNullOrEmpty(t.Video.FocusArea) ? t.Video.FocusArea.FlattenByLanguage(lang) : null,
                        t.Video.ChannelId,
                        t.Video.JobID,
                        t.Video.CreationDate,
                        t.Video.EquipmentTypeTags,
                        t.Video.FocusAreaTags,
                        t.Video.PublishedDate
                    } : null
                }).OrderBy(t => DateTime.Parse(t.Schedule.Next_Occurence_Time).Date).ThenBy(t => DateTime.Parse(t.Schedule.Next_Occurence_Time).TimeOfDay);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [Authorize(Policy = "AdminClientProvider")]
        [HttpPost("event")]
        public async Task<ActionResult<HttpStatusCode>> CreateEvent(ScheduleEventViewModel model)
        {
            try
            {
                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                if (model != null && !string.IsNullOrEmpty(model.Title) && !string.IsNullOrEmpty(model.Description) && model.Schedule_Time > DateTime.MinValue && model.Schedule != null
                    && model.Schedule.Daily_Time > DateTime.MinValue && model.Schedule.Weekdays != null && model.Schedule.Weekdays.Length > 0 && !string.IsNullOrEmpty(model.ImageUrl)
                    && ((Convert.ToInt32(userRole) == Convert.ToInt32(Roles.Admin) && !string.IsNullOrWhiteSpace(model.TenantId)) || Convert.ToInt32(userRole) == Convert.ToInt32(Roles.ClientProvider)))
                {
                    if (Convert.ToInt32(userRole) == Convert.ToInt32(Roles.ClientProvider))
                    {
                        var provider = await _providerService.Get(userId).ConfigureAwait(false);
                        if (provider != null)
                        {
                            model.TenantId = provider.TenantId;
                        }
                    }
                    var result = await _eventService.CreateEvent(model).ConfigureAwait(false);
                    if (result != null)
                    {
                        model.Event_Id = result.Event_Id;
                        return CreatedAtAction("CreateEvent", model);
                    }
                    else
                    {
                        return StatusCode(500);
                    }
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("CreateEvent exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "AdminClientProvider")]
        [HttpPut("event/{eventId}")]
        public async Task<ActionResult<HttpStatusCode>> UpdateEvent(string eventId, [FromBody] ScheduleEventViewModel model)
        {
            try
            {
                if (model != null && !string.IsNullOrEmpty(model.Title) && !string.IsNullOrEmpty(model.Description) && model.Schedule_Time > DateTime.MinValue && model.Schedule != null
                    && model.Schedule.Daily_Time > DateTime.MinValue && model.Schedule.Weekdays != null && model.Schedule.Weekdays.Length > 0 && !string.IsNullOrEmpty(model.ImageUrl))
                {
                    var lang = GetIETFTagFromHeaders();
                    if (string.IsNullOrEmpty(lang))
                    {
                        lang = "en-GB";
                    }
                    var tenantInfo = await _userService.GetTenant(model.TenantId).ConfigureAwait(false);
                    var existingEvent = await _eventService.GetEvent(model.TenantId, model.Event_Id).ConfigureAwait(false);
                    if (existingEvent != null)
                    {
                        if (model.Video != null && (IsValidCategory(model.Video.ClassCategoryId).Result == false))
                        {
                            return StatusCode((int)HttpStatusCode.BadRequest, "Invalid Class Category");
                        }
                        if (!string.IsNullOrEmpty(existingEvent.Schedule.Next_Occurence_Time))
                        {
                            if (existingEvent.Active && existingEvent.IsLocked)
                            {
                                return StatusCode((int)HttpStatusCode.Locked, "Event locked");
                            }
                            else
                            {

                                // Setting the Focus Area and Equipment Names based on Tags
                                if (model.Video != null &&
                                    ((model.Video.EquipmentTypeTags != null && model.Video.EquipmentTypeTags.Count() > 0)
                                    || (model.Video.FocusAreaTags != null && model.Video.FocusAreaTags.Count() > 0)))
                                {
                                    var titlesMetadata = await GetTitlesMetaDataAsync(lang).ConfigureAwait(false);

                                    if (titlesMetadata != null && titlesMetadata.Equipments != null && model.Video.EquipmentTypeTags != null)
                                        model.Video.Equipments = (from eqp in titlesMetadata.Equipments
                                                                  join eqptag in model.Video.EquipmentTypeTags
                                                                  on eqp.TypeTag equals eqptag
                                                                  select eqp.Name.FlattenByLanguage(lang)).ToArray();

                                    if (titlesMetadata != null && titlesMetadata.FocusAreas != null && model.Video.FocusAreaTags != null)
                                        model.Video.FocusArea = (from fa in titlesMetadata.FocusAreas
                                                                 join fat in model.Video.FocusAreaTags
                                                                 on fa.Tag equals fat
                                                                 select fa.Name.FlattenByLanguage(lang)).ToArray();
                                }

                                var result = await _eventService.UpdateEvent(model, existingEvent, tenantInfo.ProviderId, lang).ConfigureAwait(false);
                                if (result != null)
                                {
                                    return Ok();
                                }
                                else
                                {
                                    return StatusCode((int)HttpStatusCode.InternalServerError);
                                }
                            }
                        }
                        else
                        {
                            return BadRequest("Tenant info missing");
                        }
                    }
                    else
                    {
                        return NotFound("No event");
                    }
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("UpdateEvent exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }


        private async Task<TitlesMetadata> GetTitlesMetaDataAsync(string lang)
        {
            try
            {

                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                TitlesMetadata metadata = null;

                if (!_cache.TryGetValue(CacheKeys.Metadata, out metadata))
                {
                    var metadataTask = _blobRepo.GetAsync<TitlesMetadata>("*");
                    await Task.WhenAll(metadataTask).ConfigureAwait(false);

                    if (metadataTask.Result != null && metadataTask.Result.IsSuccessStatusCode)
                    {
                        _cache.Set(CacheKeys.Metadata, metadataTask.Result.Entity, DateTimeOffset.UtcNow.AddYears(1));
                        metadata = metadataTask.Result.Entity;
                    }
                }

                return metadata;
            }
            catch (Exception e)
            {
                _logger.Warn("Getmetadata exception", "warn", e.ToString());
            }
            return null;
        }

        [Authorize(Policy = "AdminClientProvider")]
        [HttpDelete("events")]
        public async Task<ActionResult<HttpStatusCode>> DeleteEvent(List<string> eventIds)
        {
            try
            {
                var tenant = GetTenantIDFromHeaders();
                if (string.IsNullOrWhiteSpace(tenant))
                {
                    return BadRequest();
                }
                List<Tuple<string, int>> deletedEvents = new List<Tuple<string, int>>();
                foreach (var eventId in eventIds)
                {
                    var existingEvent = await _eventService.GetEvent(tenant, eventId).ConfigureAwait(false);

                    if (existingEvent != null)
                    {
                        if (existingEvent.Active)
                        {
                            if (existingEvent.IsLocked)
                            {
                                deletedEvents.Add(Tuple.Create(eventId, (int)HttpStatusCode.Locked));
                                continue;
                            }
                        }
                        var respone = await _eventService.DeleteEvent(tenant, eventId).ConfigureAwait(false);
                        if (respone)
                        {
                            deletedEvents.Add(Tuple.Create(eventId, (int)HttpStatusCode.OK));
                        }
                    }
                    else
                    {
                        deletedEvents.Add(Tuple.Create(eventId, (int)HttpStatusCode.NotFound));
                    }
                }

                return Ok(deletedEvents);
            }
            catch (Exception e)
            {
                _logger.Warn("DeleteEvent exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        private async Task<bool> IsValidCategory(int categoryid)
        {
            TitlesMetadata metadata = null;

            if (!_cache.TryGetValue(CacheKeys.Metadata, out metadata))
            {
                var metadataTask = _blobRepo.GetAsync<TitlesMetadata>("*");
                await Task.WhenAll(metadataTask).ConfigureAwait(false);

                if (metadataTask.Result != null && metadataTask.Result.IsSuccessStatusCode)
                {
                    _cache.Set(CacheKeys.Metadata, metadataTask.Result.Entity, DateTimeOffset.UtcNow.AddYears(1));
                    metadata = metadataTask.Result.Entity;
                }
            }
            var category = metadata.Categories.Where(x => x.Id == categoryid).FirstOrDefault();
            if (category != null)
            { return true; }
            else
                return false;
        }

        [Authorize(Policy = "AdminClientProvider")]
        [HttpPost("event/live/key")]
        public async Task<ActionResult<HttpStatusCode>> GenerateLiveEventKey(ScheduleEventViewModel model)
        {
            try
            {
                var lang = GetIETFTagFromHeaders();
                if (string.IsNullOrEmpty(lang))
                {
                    lang = "en-GB";
                }

                string userRole = User.Claims.Where(t => t.Type == ClaimTypes.Role).Select(t => t.Value).FirstOrDefault();
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
                if (Convert.ToInt32(userRole) == Convert.ToInt32(Roles.ClientProvider))
                {
                    var provider = await _providerService.Get(userId).ConfigureAwait(false);
                    if (provider != null)
                    {
                        model.TenantId = provider.TenantId;
                    }
                }

                if (!string.IsNullOrEmpty(model.Event_Id))
                {
                    var existingEvent = await _eventService.GetEvent(model.TenantId, model.Event_Id).ConfigureAwait(false);
                    if(string.IsNullOrEmpty(existingEvent.EventKey) && existingEvent.Type == EventType.TrueLive)
                    {
                        var liveChannel = await _jwplayerRepo.InsertChannel<ChannelResponse>(new ChannelRequest { ProviderId = userId, Metadata = new ChannelMetadata { Title = existingEvent.Title, EnableDvr = true, CustomParameters = new Dictionary<string, string> { { "EventId", existingEvent.Event_Id } } } }).ConfigureAwait(false);
                        existingEvent.EventKey = liveChannel.Stream_key;
                        existingEvent.LiveChannelId = liveChannel.Id;
                        var result = await _eventService.UpdateEvent(model, existingEvent, userId, lang).ConfigureAwait(false);
                    }
                    return Ok(new { EventId = existingEvent.Event_Id, existingEvent.EventKey});
                }
                else
                {
                    return BadRequest(new { code = HttpStatusCode.BadRequest, message = "Event id is required" });
                }
            }
            catch (Exception e)
            {
                _logger.Warn("Generate Event key exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }
    }
}
