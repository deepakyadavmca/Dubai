﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Repositories.Blobs.Repo;

namespace Wexer.Content.Portal.Controllers
{

    [ApiController]
    public class LanguagesController : CommonController
    {

        private readonly ILogger _logger;
        private readonly IBlobRepo _blobRepo;

        public LanguagesController(ILoggerFactory loggerFactory, IBlobRepo blobRepo)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _blobRepo = blobRepo;
        }


        [HttpGet("api/v1/languages")]
        public async Task<ActionResult<HttpStatusCode>> GetLanguages()
        {
            try
            {
                _logger.Info("Fetching the languages");

                var mLanguages = await _blobRepo.GetSetAsync<Language>("*").ConfigureAwait(false);
                if (mLanguages == null || mLanguages.Entity == null || mLanguages.Entity.Items == null)
                {
                    return NoContent();
                }
                else
                {

                    return Ok(mLanguages.Entity.Items);
                }
            }
            catch (Exception e)
            {
                _logger.Warn("Add Language exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }



        [HttpPost("api/v1/language")]
        public async Task<ActionResult<HttpStatusCode>> AddLanguage([FromBody] Language model)
        {
            try
            {
                _logger.Info("Appending the language");

                if (model == null || string.IsNullOrEmpty(model.IETFTag) || string.IsNullOrEmpty(model.DisplayName))
                {
                    return BadRequest();
                }

                var mLanguages = await _blobRepo.GetSetAsync<Language>("*").ConfigureAwait(false);
                if (mLanguages == null || mLanguages.Entity == null || mLanguages.Entity.Items == null)
                {
                    var languages = new List<Language>();
                    languages.Add(model);

                    await _blobRepo.PutSetAsync("*", new EntitySet<Language>() { Count = 1, Items = languages.ToArray() }).ConfigureAwait(false);
                }
                else
                {
                    var existingLanguages = mLanguages.Entity.Items.ToList();
                    existingLanguages.Add(model);

                    await _blobRepo.PutSetAsync("*", new EntitySet<Language>() { Count = existingLanguages.Count, Items = existingLanguages.ToArray() }).ConfigureAwait(false);
                }
                return Ok();
            }
            catch (Exception e)
            {
                _logger.Warn("Add Language exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }


    }
}
