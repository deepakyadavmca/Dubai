﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Wexer.Content.Portal.Command.Commands.Events;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Models.BackgroundTasks;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.Events;
using Wexer.Content.Portal.Models.Tenant;
using Wexer.Content.Portal.ReadStore;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Repositories.Tables.Repo;

namespace Wexer.Content.Portal.Controllers
{

    [Authorize(Policy = "Admin")]
    [ApiController]
    public class EventsController : CommonController
    {
        private readonly ILogger _logger;
        protected readonly ICommandBus _commandBus;
        private readonly IMemoryCache _cache;
        private readonly IContentWriteStoreRepo _contentWriteRepo;
        private readonly IFileStoreRepo _fileStoreRepo;
        private readonly ICmsStoreRepo _cmsStoreRepo;

        public EventsController(ICommandBus commandBus, ILoggerFactory loggerFactory, IMemoryCache memoryCache, IContentWriteStoreRepo contentWriteRepo
            , IFileStoreRepo fileStoreRepo, ICmsStoreRepo cmsStoreRepo)
        {
            _commandBus = commandBus;
            _logger = loggerFactory.GetLoggerForClass(this);
            _cache = memoryCache;
            _contentWriteRepo = contentWriteRepo;
            _fileStoreRepo = fileStoreRepo;
            _cmsStoreRepo = cmsStoreRepo;
        }


        [HttpPost("api/v1/events/ondemand/playback/upload")]
        public async Task<ActionResult<HttpStatusCode>> PostEvents([FromForm] IFormFile eventsfile)
        {
            try
            {
                if (eventsfile == null || eventsfile.Length <= 0)
                {
                    _logger.Info("EventsController > Post, entities are null or empty.");
                    return BadRequest("Empty request");
                }

                // Read file and load to object
                var eventsData = LoadJsonFile(eventsfile);

                if (eventsData == null || eventsData.Events == null || eventsData.Events.Count <= 0)
                {
                    _logger.Info("EventsController > Post, playback events are empty.");
                    return BadRequest("Invalid file format. Please correct the file and try again.");
                }

                if (string.IsNullOrEmpty(eventsData.TenantId))
                {
                    _logger.Info("EventsController > Post, tenant id is empty");
                    return BadRequest("Tenant Id should not empty.");
                }

                // convert string to stream
                byte[] byteArray = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(eventsData));
                // Generating the tracking Id
                string trackingId = Hash.Create(byteArray);

                var existingBackgroundTasks = _cmsStoreRepo.GetList<BackgroundTaskStatus>(trackingId);
                if (existingBackgroundTasks != null && existingBackgroundTasks.Count() > 0)
                {
                    var processbgTask = existingBackgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsProcess.ToString()).FirstOrDefault();
                    if (processbgTask != null && processbgTask.Status == ProcessTaskStatus.FileProcessed.ToString())
                    {
                        _logger.Info("EventsController > Post, File already uploaded, please try another file.");
                        return BadRequest("File already uploaded, please try another file.");
                    }
                    else
                    {
                        // If we allowed initiate again for same tracking id then we delete existing records
                        await _cmsStoreRepo.DeleteAllAsync<BackgroundTaskStatus>(trackingId).ConfigureAwait(false);
                    }
                }

                var tenantId = eventsData.TenantId;

                // Check the tenantId is valid or not
                var tenantDetail = await IsTenantValidAsync(tenantId).ConfigureAwait(false);

                if (tenantDetail == null)
                {
                    _logger.Info("EventsController > Post, invalid tenant.");
                    return BadRequest("Tenant Id is invalid.");
                }

                // I have used the default c# hashing, I will check and changed with MD5
                var fileNameHashCode = DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "_" + Math.Abs(eventsfile.FileName.ToLower().GetHashCode()).ToString();

                //byte[] byteArray = Encoding.ASCII.GetBytes(contents);
                MemoryStream stream = new MemoryStream(byteArray);

                await _fileStoreRepo.PutStreamAsync("ondemandevents", fileNameHashCode, stream, eventsfile.ContentType).ConfigureAwait(false);

                var backgroundTaskStatus = new BackgroundTaskStatus
                {
                    TaskId = trackingId,
                    Name = BackgroundTaskType.Validate.ToString(),
                    Handler = BackgroundTaskHandlerType.EventsValidate.ToString(),
                    Status = ValidateTaskStatus.Validating.ToString(),
                    TenantId = tenantId,
                    StartedDateTimeUtc = DateTime.UtcNow,
                    FileBlobName = fileNameHashCode
                };

                // Adding the BackgroundTaskStatus for 
                await _cmsStoreRepo.StoreAsync(backgroundTaskStatus).ConfigureAwait(false);

                await _commandBus.SendAsync(new EventsValidateCommand
                {
                    TaskId = trackingId
                }).ConfigureAwait(false);

                return Ok(new { TrackingId = trackingId });
            }
            catch (InvalidDataException e)
            {
                _logger.Warn("EventsController > Post, Missing Information", e.Message.ToString());
                return StatusCode(406, "Invalid data exception");
            }
            catch (Exception ex)
            {
                _logger.Warn("EventsController > Post, Error while logging OnDemand Tracking Data", ex.Message.ToString());
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("api/v1/events/ondemand/playback/upload")]
        public async Task<ActionResult<HttpStatusCode>> PutEvents([FromBody] EventsActionModel eventsAction)
        {
            try
            {
                if (eventsAction == null || string.IsNullOrEmpty(eventsAction.TrackingId) ||
                    string.IsNullOrEmpty(eventsAction.Action))
                {
                    _logger.Info("EventsController > Put, required info missing.");
                    return BadRequest("Please send required info to activate/ cancel the event.");
                }

                var backgroundTasks = _cmsStoreRepo.GetList<BackgroundTaskStatus>(eventsAction.TrackingId);

                var processbgTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsProcess.ToString()).FirstOrDefault();
                if (processbgTask != null)
                {
                    if (processbgTask.Status == ProcessTaskStatus.FileProcessing.ToString())
                    {
                        _logger.Info("EventsController > Put, Task already in processing for this Tracking Id.");
                        return BadRequest("Process already in processing for this Tracking Id.");
                    }
                    else if (processbgTask.Status == ProcessTaskStatus.FileProcessing.ToString())
                    {
                        _logger.Info("EventsController > Put, Task already processed for this Tracking Id.");
                        return BadRequest("Process already completed for this Tracking Id.");
                    }
                    else if (processbgTask.Status == ProcessTaskStatus.Cancelled.ToString())
                    {
                        _logger.Info("EventsController > Put, Task cancelled of this Tracking Id.");
                        return BadRequest("Process cancelled of this Tracking Id.");
                    }
                    else if (processbgTask.Status == ProcessTaskStatus.Failed.ToString())
                    {
                        _logger.Info("EventsController > Put, Task failed for this Tracking Id. ");
                        return BadRequest("Process failed for this Tracking Id.");
                    }
                }

                var validatebgTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsValidate.ToString()).FirstOrDefault();
                var backgroundTaskStatus = new BackgroundTaskStatus
                {
                    TaskId = eventsAction.TrackingId,
                    Name = BackgroundTaskType.Process.ToString(),
                    Handler = BackgroundTaskHandlerType.EventsProcess.ToString(),
                    Status = ProcessTaskStatus.FileProcessing.ToString(),
                    TenantId = validatebgTask.TenantId,
                    StartedDateTimeUtc = DateTime.UtcNow,
                    FileBlobName = validatebgTask.FileBlobName
                };

                // Adding the BackgroundTaskStatus for 
                await _cmsStoreRepo.StoreAsync(backgroundTaskStatus).ConfigureAwait(false);

                await _commandBus.SendAsync(new EventsUploadCommand
                {
                    TaskId = eventsAction.TrackingId,
                    Action = eventsAction.Action
                }).ConfigureAwait(false);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.Warn("EventsController > Put, Error while logging OnDemand Tracking Data", ex.Message.ToString());
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("api/v1/events/ondemand/playback/upload/{trackingid}")]
        public ActionResult<HttpStatusCode> GetStatus(string trackingid)
        {
            try
            {
                if (string.IsNullOrEmpty(trackingid))
                    return BadRequest("Tracking id is empty.");

                var backgroundTasks = _cmsStoreRepo.GetList<BackgroundTaskStatus>(trackingid);

                if (backgroundTasks == null || backgroundTasks.Count() <= 0)
                    return BadRequest("Invalid Tracking Id");

                var processbgTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsProcess.ToString()).FirstOrDefault();
                if (processbgTask != null)
                    return Ok(new { processbgTask.TaskId, processbgTask.Status, events = !string.IsNullOrEmpty(processbgTask.Result) ? JsonSerializer.Deserialize<BackgroundTaskProcessResult>(processbgTask.Result) : null, processbgTask.ErrorCode, processbgTask.ErrorItems, processbgTask.ErrorMessage });
                else
                {
                    var validatebgTask = backgroundTasks.Where(x => x.Handler == BackgroundTaskHandlerType.EventsValidate.ToString()).FirstOrDefault();
                    return Ok(new { validatebgTask.TaskId, validatebgTask.Status, events = !string.IsNullOrEmpty(validatebgTask.Result) ? JsonSerializer.Deserialize<BackgroundTaskResult>(validatebgTask.Result) : null, validatebgTask.ErrorCode, validatebgTask.ErrorItems, validatebgTask.ErrorMessage });
                }

            }
            catch (Exception ex)
            {
                _logger.Warn("EventsController > Put, Error while logging OnDemand Tracking Data", ex.Message.ToString());
                return StatusCode(500, "Internal server error");
            }
        }


        /// <summary>
        /// Load Json file to Object
        /// </summary>
        /// <param name="eventsFile"></param>
        /// <returns></returns>
        private OnDemandEventData LoadJsonFile(IFormFile eventsFile)
        {
            _logger.Info("EventsController: Loading the json file to object");

            // Read the file content
            string eventsData = ReadFileContent(eventsFile);

            if (string.IsNullOrEmpty(eventsData))
                return null;

            try
            {
                return JsonSerializer.Deserialize<OnDemandEventData>(eventsData, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            }
            catch (Exception ex)
            {
                _logger.Error("EventController>LoadJsonFile error: " + ex.StackTrace);
            }
            return null;
        }

        /// <summary>
        /// Read string content from IFormFile object
        /// </summary>
        /// <param name="eventsFile"></param>
        /// <returns></returns>
        private string ReadFileContent(IFormFile eventsFile)
        {
            if (eventsFile.Length > 0)
            {
                using (var ms = new MemoryStream())
                {
                    eventsFile.CopyTo(ms);
                    var fileBytes = ms.ToArray();
                    string s = Encoding.UTF8.GetString(fileBytes);
                    return s;
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Validate the tenant and fetch the details of tenant
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        private async Task<TenantDetail> IsTenantValidAsync(string tenantId)
        {
            if (string.IsNullOrEmpty(tenantId))
                return null;

            if (!_cache.TryGetValue(CacheKeys.Tenants, out IEnumerable<TenantDetail> tenants))
            {
                var entities = await Task.Run(() => _contentWriteRepo.Read<TenantDetail>()).ConfigureAwait(false);
                if (entities != null && entities.Data != null && entities.Data.Count > 0)
                {
                    _cache.Set(CacheKeys.Tenants, entities.Data.Select(t => t.Entity), new MemoryCacheEntryOptions
                    {
                        SlidingExpiration = TimeSpan.FromDays(1),
                        AbsoluteExpiration = DateTimeOffset.UtcNow.AddDays(356)
                    });

                    tenants = entities.Data.Select(x => x.Entity);
                }
                else
                {
                    return null;
                }
            }

            var tenant = tenants.Where(x => string.IsNullOrEmpty(tenantId) ? true : x.TenantID == tenantId.Trim()).FirstOrDefault();
            if (tenant != null)
                return tenant;

            return null;
        }

    }
}
