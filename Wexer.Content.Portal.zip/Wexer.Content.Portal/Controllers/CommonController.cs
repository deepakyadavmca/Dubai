﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Wexer.Content.Portal.Models;

namespace Wexer.Content.Portal.Controllers
{
    public abstract class CommonController : ControllerBase
    {
        protected string GetTenantIDFromHeaders()
        {
            StringValues keys;
            if (!Request.Headers.TryGetValue("TenantID", out keys))
                return null;
            return keys.First();
        }

        protected string GetUserAgentFromRequest()
        {
            StringValues keys;
            if (!Request.Headers.TryGetValue("UserAgent", out keys))
            {
                return null;
            }
            return keys.First();
        }

        protected string GetIETFTagFromHeaders()
        {
            StringValues keys;
            if (!Request.Headers.TryGetValue("Accept-Language", out keys))
            {
                return string.Empty;
            }

            return keys.First();
        }

        protected async static Task<LocalisedText> CreateLocalisedText(string text, string ietfTag = "en-GB")
        {
            return new LocalisedText { InvariantText = text, LocalTexts = new[] { new LocalText { IETFTag = ietfTag, Text = text } } };
        }

        protected async static Task UpdateLocalisedText(LocalisedText localisedText, string changedText, string ietfTag = "en-GB")
        {
            if (localisedText != null)
            {
                if (localisedText.LocalTexts == null)
                {
                    localisedText.LocalTexts = new[] { new LocalText { Text = changedText, IETFTag = ietfTag } };
                }
                else
                {
                    var localTextList = localisedText.LocalTexts.ToList();
                    var currentCultureText = localTextList.FirstOrDefault(t => t.IETFTag == ietfTag);
                    if (currentCultureText != null)
                    {
                        currentCultureText.Text = changedText;
                    }
                    else
                    {
                        localTextList.Add(new LocalText { IETFTag = ietfTag, Text = changedText });
                    }
                    localisedText.LocalTexts = localTextList.ToArray();
                }
                if (ietfTag == "en-GB")
                {
                    localisedText.InvariantText = changedText;
                }
            }
        }
    }
}
