﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Wexer.Content.Portal.Command.Commands.Media;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.VirtualClasses;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using Wexer.Content.Portal.ChannelService;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.Models.ScheduleEvents;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Controllers
{
    public class MediaServiceController : CommonController
    {
        private readonly ICommandBus _commandBus;
        private readonly ILogger _logger;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly IBlobRepo _blobRepo;
        private readonly IChannelService _channelService;
        private IMemoryCache _cache;

        public MediaServiceController(ILoggerFactory loggerFactory, ICommandBus commandBus,
            ICmsStoreRepo cmsStore, IBlobRepo blobRepo, IChannelService channelService, IMemoryCache cache)
        {
            _logger = loggerFactory.GetLoggerForClass(this);
            _commandBus = commandBus;
            _cmsStore = cmsStore;
            _blobRepo = blobRepo;
            _channelService = channelService;
            _cache = cache;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/video/getTitle")]
        public async Task<ActionResult> GetTitleDetails()
        {
            var selectedVirtualClass = await _cmsStore.GetAsync<VirtualClass>("l4MICbPk4sPtA4dqudX46PW3Is42", "d0119229-052a-43df-93c8-1849e66c1a04").ConfigureAwait(false);
            return Ok(selectedVirtualClass);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/video/encodeVideosWithStage1Ecoding")]
        public async Task<ActionResult> EncodeVideosWithStage1Ecoding()
        {
            await _commandBus.SendAsync(new EncodeMediaCommand
            {
                ClassTag = "d0119229-052a-43df-93c8-1849e66c1a04",
                AssetName = "6291456-YOGESH_V_.mp4",
                IsTrailerFile = false,
                ProviderId = "l4MICbPk4sPtA4dqudX46PW3Is42",
                AssetUrl = "https://cfltestfilestore.blob.core.windows.net/portal-raw-videos/6291456-YOGESH_V_.mp4?sv=2019-07-07&sr=b&sig=%2FjM56THILtQaieX5VkIsjxTNZrHBwPOYxdaLOzgmaHU%3D&st=2020-12-04T11%3A05%3A57Z&se=2030-12-04T11%3A05%3A57Z&sp=r",
                Stage1Encode = true
            });
            return Ok();
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/video/encodeVideos")]
        public async Task<ActionResult> EncodeVideos()
        {

            await _commandBus.SendAsync(new EncodeMediaCommand
            {
                ClassTag = "fb3b19e8-ea4a-4c64-829d-2efc9e047c6f",
                AssetName = "2097152-Squirrel_Monkey_on_B.mp4",
                IsTrailerFile = false,
                ProviderId = "qKl8xu6bT8ORJURjVQrfQRgkozz2",
                AssetUrl = "https://cfltestfilestore.blob.core.windows.net/portal-raw-videos/2097152-Squirrel_Monkey_on_B.mp4?sv=2019-07-07&sr=b&sig=gBZ%2BYtjUgHmFn7Zme3Xrr6uizTXMjMNjTIOkkU89CZ8%3D&st=2020-11-20T07%3A46%3A56Z&se=2030-11-20T07%3A46%3A56Z&sp=r",
                Stage1Encode = false
            });
            return Ok();
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/video/encodeTrailers")]
        public async Task<ActionResult> EncodeTrailers()
        {

            await _commandBus.SendAsync(new EncodeMediaCommand
            {
                ClassTag = "49f9025b-6714-490b-8274-b3732537de7a",
                AssetName = "2097152-Squirrel_Monkey_on_B.mp4",
                IsTrailerFile = true,
                ProviderId = "l4MICbPk4sPtA4dqudX46PW3Is42",
                AssetUrl = "https://cfltestfilestore.blob.core.windows.net/portal-raw-videos/2097152-Squirrel_Monkey_on_B.mp4?sv=2019-07-07&sr=b&sig=gBZ%2BYtjUgHmFn7Zme3Xrr6uizTXMjMNjTIOkkU89CZ8%3D&st=2020-11-20T07%3A46%3A56Z&se=2030-11-20T07%3A46%3A56Z&sp=r",
                Stage1Encode = false
            });
            return Ok();
        }


        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpPut("api/v1/update/mastertitles")]
        public async Task<ActionResult> UpdateMasterClassses()
        {
            var masterTitles = await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);

            var invalidTitles = masterTitles.Where(x => x.ClassCategoryId == 0).ToList();

            var masterMetadata = await _blobRepo.GetAsync<TitlesMetadata>("*").ConfigureAwait(false);

            foreach (var item in masterTitles)
            {
                if (item.ClassCategories != null && item.ClassCategories.InvariantText != null)
                {
                    item.ClassCategoryId = masterMetadata.Entity.Categories.Where(t => t.Name.InvariantText == item.ClassCategories.InvariantText) != null
                        && masterMetadata.Entity.Categories.Where(t => t.Name.InvariantText == item.ClassCategories.InvariantText).Count() > 0
                        ? masterMetadata.Entity.Categories.Where(t => t.Name.InvariantText == item.ClassCategories.InvariantText).Select(t => t.Id).FirstOrDefault() : 0;

                    await _cmsStore.StoreAsync(item.Tag, item, "", item.ProviderID).ConfigureAwait(false);
                }

            }
            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
            {
                _cache.Remove(CacheKeys.VirtualClass);
            }
            return Ok(masterTitles);
        }


        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/master/titles")]
        public async Task<ActionResult> GetTitles()
        {
            var lang = GetIETFTagFromHeaders();
            //if (string.IsNullOrEmpty(lang))
            //{
            //    lang = "en-GB";
            //}
            var titles = await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);

            var channelsTask = await _channelService.List().ConfigureAwait(false);

            var metadataTask = await _blobRepo.GetAsync<TitlesMetadata>("*").ConfigureAwait(false);

            var categories = metadataTask.Entity.Categories.ToArray().Select(x => x.Name.InvariantText);

            var classes = titles.Where(x => x.ClassCategories != null && !categories.Contains(x.ClassCategories.InvariantText));
            return Ok(
                   new
                   {
                       count = classes.Count(),
                       items = classes.Select(t => new
                       {
                           ClassId = t.Tag,
                           ClassName = t.ClassName.InvariantText,
                           CategoryName = t.ClassCategories != null ? t.ClassCategories.InvariantText : "",
                           language = t.ClassLanguage,
                           channel = channelsTask.Where(x => x.Tag == t.ChannelId).Select(x => x.Name.InvariantText),
                           status = Enum.GetName(typeof(Models.MediaProcessingStatus), t.Status)
                       })
                   }
                );
        }


        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/master/blanktitles")]
        public async Task<ActionResult> GetBlankTitles()
        {
            var masterTitles = await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);
            var invalidTitles = masterTitles.Where(x => x.ClassCategoryId == 0).ToList();
            var channelsTask = await _channelService.List().ConfigureAwait(false);

            return Ok(
                  new
                  {
                      count = invalidTitles.Count(),
                      items = invalidTitles.Select(t => new
                      {
                          ClassId = t.Tag,
                          ClassName = t.ClassName.InvariantText,
                          CategoryId = t.ClassCategoryId,
                          CategoryName = t.ClassCategories != null ? t.ClassCategories.InvariantText : "",
                          language = t.ClassLanguage,
                          channel = channelsTask.Where(x => x.Tag == t.ChannelId).Select(x => x.Name.InvariantText),
                          status = Enum.GetName(typeof(Models.MediaProcessingStatus), t.Status)
                      })
                  }
               );
        }

        /// <summary>
        /// Get invalid events with blank video category id
        /// </summary>
        /// <returns></returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/master/blankevents")]
        public async Task<ActionResult> GetBlankEvents()
        {
            var masterEvents = await _cmsStore.GetListAsync<ScheduleEvent>().ConfigureAwait(false);
            var invalidEvents = masterEvents.Where(x => x.Video != null && x.Video.ClassCategoryId == 0).ToList();
            var channelsTask = await _channelService.List().ConfigureAwait(false);

            return Ok(
                  new
                  {
                      count = invalidEvents.Count(),
                      items = invalidEvents.Select(t => new
                      {
                          ClassId = t.Video.Tag,
                          ClassName = t.Video.ClassName.InvariantText,
                          CategoryId = t.Video.ClassCategoryId,
                          CategoryName = t.Video.ClassCategories != null ? t.Video.ClassCategories.InvariantText : "",
                          language = t.Video.ClassLanguage,
                          channel = channelsTask.Where(x => x.Tag == t.Video.ChannelId).Select(x => x.Name.InvariantText),
                          status = Enum.GetName(typeof(Models.MediaProcessingStatus), t.Video.Status),
                          creationDate = t.Video.CreationDate
                      })
                  }
               );
        }

        /// <summary>
        /// Update master events' class category Id
        /// </summary>
        /// <returns>Updated master events</returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpPut("api/v1/update/masterevents")]
        public async Task<ActionResult> UpdateMasterEvents()
        {
            var masterEvents = await _cmsStore.GetListAsync<ScheduleEvent>().ConfigureAwait(false);
            var invalidEvents = masterEvents.Where(x => x.Video != null && x.Video.ClassCategoryId == 0).ToList();
            var masterMetadata = await _blobRepo.GetAsync<TitlesMetadata>("*").ConfigureAwait(false);

            foreach (var item in invalidEvents)
            {
                if (item.Video.ClassCategories != null && item.Video.ClassCategories.InvariantText != null)
                {
                    item.Video.ClassCategoryId = masterMetadata.Entity.Categories.Where(t => t.Name.InvariantText == item.Video.ClassCategories.InvariantText) != null
                        && masterMetadata.Entity.Categories.Where(t => t.Name.InvariantText == item.Video.ClassCategories.InvariantText).Count() > 0
                        ? masterMetadata.Entity.Categories.Where(t => t.Name.InvariantText == item.Video.ClassCategories.InvariantText).Select(t => t.Id).FirstOrDefault() : 0;

                    await _cmsStore.StoreAsync(item).ConfigureAwait(false);
                }
            }
            return Ok(invalidEvents);
        }

        /// <summary>
        /// Get blank categories from tenant blob
        /// </summary>
        /// <param name="tenantId">tenant id</param>
        /// <returns>Invalid blob set</returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpGet("api/v1/gettenant/blankcategory/{tenantId}")]
        public async Task<ActionResult> GetTenantBlankCategories(string tenantId)
        {
            var tenantBlobSet = await _blobRepo.GetSetAsync<VirtualClass>(tenantId).ConfigureAwait(false);
            var invalidBlobSet = tenantBlobSet.Entity.Items.Where(x => x.ClassCategoryId == 0).ToList();

            return Ok(invalidBlobSet);
        }

        /// <summary>
        /// Update event status to Complete which have status Published
        /// </summary>
        /// <returns></returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpPut("api/v1/update/publishedmasterevents")]
        public async Task<ActionResult> UpdateMasterEventsWithPublishedStatus()
        {
            var masterEvents = await _cmsStore.GetListAsync<ScheduleEvent>().ConfigureAwait(false);
            var invalidEvents = masterEvents.Where(x => x.Active && x.Video != null &&
                                    x.Video.Status == Models.MediaProcessingStatus.Published
                                    && x.Scheduled_Time < DateTime.UtcNow.AddHours(-24)).ToList();

            if (invalidEvents != null && invalidEvents.Count() > 0)
            {
                foreach (var item in invalidEvents)
                {
                    item.Video.Status = Models.MediaProcessingStatus.Complete;
                    await _cmsStore.StoreAsync(item).ConfigureAwait(false);
                }
            }
            return Ok(new { count = invalidEvents.Count(), data = invalidEvents });
        }

        /// <summary>
        /// Find and Correct Auto-Published classes which exist in tenant's blob but not in master table
        /// </summary>
        /// <returns></returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [APIAuth]
        [AllowAnonymous]
        [HttpPut("api/v1/autopublishclasses/create")]
        public async Task<ActionResult> CreateAutoPublishedClasses()
        {

            var events = await _cmsStore.GetListAsync<ScheduleEvent>().ConfigureAwait(false);
            var publishedEvents = events.Where(x => x.Active && x.Video != null &&
                                    (x.Video.Status == Models.MediaProcessingStatus.Complete
                                    || x.Video.Status == Models.MediaProcessingStatus.Published)
                                    && x.Scheduled_Time < DateTime.UtcNow.AddHours(-24)).ToList();

            var masterTitles = await _cmsStore.GetBulk<VirtualClass>().ConfigureAwait(false);
            var publishedMasterClasses = masterTitles.ToList();

            List<ScheduleEvent> missingEvents = new List<ScheduleEvent>();
            if (publishedMasterClasses != null && publishedMasterClasses.Count() > 0 &&
                publishedEvents != null && publishedEvents.Count() > 0)
            {
                List<string> publishedMaterClassesTag = publishedMasterClasses.Select(x => x.Tag).ToList();
                var tenants = await _blobRepo.GetSetAsync<TenantDetail>("*");

                foreach (var item in publishedEvents)
                {
                    var tenant = tenants.Entity.Items.Where(x => x.TenantID == item.TenantId).FirstOrDefault();

                    if (!publishedMaterClassesTag.Exists(x => x == item.Video.Tag) && tenant != null)
                    {
                        publishedMaterClassesTag.Add(item.Video.Tag);
                        missingEvents.Add(item);
                        await _cmsStore.StoreAsync(item.Video.Tag, item.Video, "", tenant.ProviderId).ConfigureAwait(false);
                    }
                }

            }
            return Ok(new { count = missingEvents.Count(), data = missingEvents });
        }
    }
}
