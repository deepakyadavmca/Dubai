﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FirebaseAdmin;
using FirebaseAdmin.Auth;
using Wexer.Content.Portal.Models.ContentPortal;
using Wexer.Content.Portal.Models.User;
using Wexer.Content.Portal.Models.User.Profiles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wexer.Content.Portal.Clients;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.UserService;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.UserService.SignupService;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IFirebaseClient _firebaseClient;
        private readonly IUserSignupService _userSignupService;
        private readonly IUserService _userService;
        private IMemoryCache _cache;
        public AdminController(IFirebaseClient firebaseClient, IUserSignupService userSignupService, IUserService userService, IMemoryCache cache)
        {
            _firebaseClient = firebaseClient;
            _userSignupService = userSignupService;
            _userService = userService;
            _cache = cache;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        //[Attributes.HmacAuthorize]
        [HttpPost("admin/api/v1/users")]
        public async Task<ActionResult<HttpStatusCode>> CreateAdmin([FromBody] PortalUser user)
        {
            try
            {
                var tenant = "wexer";
                if (!string.IsNullOrEmpty(user.DisplayName) && !string.IsNullOrEmpty(user.Password) && !string.IsNullOrEmpty(user.Email) && user.UserRole == Roles.Admin)
                {
                    var fireBaseUserCheckTask = _firebaseClient.GetUserByEmail<UserInfo>(user.Email);
                    var userLookupInTableTask = _userService.CheckUserEmailIndexTenantIdAsync(user.Email, tenant);
                    await Task.WhenAll(fireBaseUserCheckTask, userLookupInTableTask).ConfigureAwait(false);

                    if (fireBaseUserCheckTask.Result == null && userLookupInTableTask.Result == null)
                    {
                        UserRecordArgs userRecordArgs = new UserRecordArgs();
                        userRecordArgs.DisplayName = user.DisplayName;
                        userRecordArgs.Email = user.Email;
                        userRecordArgs.Password = user.Password;
                        userRecordArgs.PhotoUrl = user.PhotoUrl;
                        userRecordArgs.PhoneNumber = user.PhoneNumber;
                        userRecordArgs.Uid = user.UId;

                        var fireBaseUserCreationResponse = await _firebaseClient.CreateUserAsync<UserInfo>(userRecordArgs, user.UserRole).ConfigureAwait(false);

                        if (fireBaseUserCreationResponse != null)
                        {
                            string userId = String.Empty;

                            var claimsResponse = await _firebaseClient.SetClaims(fireBaseUserCreationResponse.UId,
                                                    new Dictionary<string, object>() { { "role", Convert.ToInt32(user.UserRole) } }).ConfigureAwait(false);

                            if (claimsResponse)
                            {
                                user.UId = fireBaseUserCreationResponse.UId;
                                userId = await _userSignupService.CreatePortalUserIndexAsync(user, tenant).ConfigureAwait(false);
                            }


                            if (!string.IsNullOrEmpty(userId))
                            {
                                return CreatedAtAction("CreateAdmin", user);
                            }
                            else
                            {
                                // when user creation fails
                                var firebaseUserCleanup = await _firebaseClient.DeleteUserAsync(fireBaseUserCreationResponse.UId).ConfigureAwait(false);
                                if (firebaseUserCleanup)
                                {
                                    return StatusCode(500, new ErrorDetails { StatusCode = 500, Message = "Failed" });
                                }
                            }
                        }
                        else
                        {
                            return StatusCode(500, String.Empty);
                        }
                    }
                    else
                    {
                        return Conflict();
                    }

                }
                return BadRequest("Request has invalid parameters");
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("staff/bustcache")]
        public async Task<ActionResult<HttpStatusCode>> BustCache()
        {
            try
            {
                _cache.Remove(CacheKeys.Channels);
                _cache.Remove(CacheKeys.Metadata);
                _cache.Remove(CacheKeys.Tenants);
                _cache.Remove(CacheKeys.Providers);
                _cache.Remove(CacheKeys.VirtualClass);
                return Ok();
            }
            catch (Exception e)
            {

                return StatusCode(500);
            }
        }
    }
}
