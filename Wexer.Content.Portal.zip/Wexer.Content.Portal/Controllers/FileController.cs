﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Wexer.Content.Portal.Models.ContentPortal;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wexer.Content.Portal.Models;
using Wexer.Content.Portal.Repositories.Blobs.Repo;
using Wexer.Content.Portal.Repositories.Blobs.Repo.FileStore;
using Wexer.Content.Portal.Repositories.Tables.Repo;
using Wexer.Content.Portal.TitleService;
using Wexer.Content.Portal.Repositories.MediaService;
using Wexer.Content.Portal.Models.VirtualClasses;
using Microsoft.Extensions.Caching.Memory;
using Wexer.Content.Portal.Command.Core;
using Wexer.Content.Portal.Command.Commands.Media;
using Wexer.Content.Portal.ProviderService;
using System.Security.Claims;
using Wexer.Content.Portal.Logging;
using Wexer.Content.Portal.EventService;
using Wexer.Content.Portal.Models.ScheduleEvents;
using Wexer.Content.Portal.Repositories.Database.Models;
using Wexer.Content.Portal.Repositories.Database;
using Wexer.Content.Portal.Extensions;
using Wexer.Content.Portal.Command.Commands.Titles;
using Wexer.Content.Portal.Models.Tenant;

namespace Wexer.Content.Portal.Controllers
{
    [ApiController]
    public class FileController : CommonController
    {
        private readonly IFileStoreRepo _fileStoreRepo;
        private readonly IBlobRepo _blobRepo;
        private readonly ITableRepo _tableRepo;
        private readonly ICmsStoreRepo _cmsStore;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _config;
        private readonly ITitleService _titleService;
        private readonly IMediaServiceRepo _mediaServiceRepo;
        private IMemoryCache _cache;
        private readonly ICommandBus _commandBus;
        private readonly IProviderService _providerService;
        private readonly ILogger _logger;
        private readonly IEventService _eventService;
        private readonly IContentWriteStoreRepo _contentWriteStoreRepo;

        private SemaphoreSlim _sem = new SemaphoreSlim(1);
        public FileController(IFileStoreRepo fileStoreRepo, IBlobRepo blobRepo, ITableRepo tableRepo,
            ICmsStoreRepo cmsStore, Microsoft.Extensions.Configuration.IConfiguration config, ITitleService titleService,
            IMediaServiceRepo mediaServiceRepo, IMemoryCache cache, ICommandBus commandBus, IProviderService providerService,
            ILoggerFactory loggerFactory, IEventService eventService, IContentWriteStoreRepo contentWriteStoreRepo)
        {
            _fileStoreRepo = fileStoreRepo;
            _blobRepo = blobRepo;
            _tableRepo = tableRepo;
            _cmsStore = cmsStore;
            _config = config;
            _titleService = titleService;
            _mediaServiceRepo = mediaServiceRepo;
            _cache = cache;
            _commandBus = commandBus;
            _providerService = providerService;
            _logger = loggerFactory.GetLoggerForClass(this);
            _eventService = eventService;
            _contentWriteStoreRepo = contentWriteStoreRepo;
        }


        [Authorize(Policy = "Joint")]
        [HttpPost("images")]
        public async Task<ActionResult<HttpStatusCode>> UploadIndividualImage([FromForm] IFormFile img, CancellationToken stoppingToken)
        {
            try
            {
                if (img != null && img.Length > 0)
                {
                    var ms = img.OpenReadStream();
                    var result = await _fileStoreRepo.PutStreamAsync("images", img.FileName, ms, img.ContentType).ConfigureAwait(false);

                    if (result != null && result.HttpStatusCode == 200)
                    {
                        return CreatedAtAction("UploadIndividualImage", string.Format("{0}/{1}", _config["ImageUrl"], img.FileName));
                    }

                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }


        [Authorize(Policy = "ProviderClientProvider")]
        [HttpPost("api/v1/videos")]
        public async Task<ActionResult<HttpStatusCode>> UploadVideo([FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-videos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
                                        var tenantDetail = await _blobRepo.GetSetAsync<TenantDetail>("*").ConfigureAwait(false);

                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-videos",
                                                        result.Item2.FileIdentifier, stoppingToken, false, provider.MediaPlatform).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            if (provider != null)
                                            {
                                                VirtualClass title = new VirtualClass();
                                                title.ClassName = await CreateLocalisedText(fileChunk.ResumableFilename.Split('.')[0], lang).ConfigureAwait(false);
                                                title.FileName = result.Item2.FileIdentifier;
                                                title.Tag = Guid.NewGuid().ToString();
                                                title.CreationDate = DateTime.UtcNow;
                                                title.RawVideoFileUrl = uri;
                                                title.ProviderID = provider.Tag;
                                                title.Provider = provider.Name;
                                                title.Status = MediaProcessingStatus.EncodingQueued;
                                                title.ProviderType = provider.IsTenantProvider ? ProviderType.Tenant : ProviderType.Regular;
                                                title.ExternalClassId = string.Empty;
                                                title.MediaPlatform = provider.MediaPlatform;

                                                await _cmsStore.StoreAsync(title.Tag, title, "", title.ProviderID).ConfigureAwait(false);

                                                #region Logic to add TenantUpload record without encoding data
                                                var uploadTrackEntity = await GetNewUploadTrackEntity(title, null, userId, false, fileChunk.ResumableTotalSize, lang);
                                                uploadTrackEntity = await _contentWriteStoreRepo.UpsertAndReturnEntity(0, uploadTrackEntity);
                                                #endregion

                                                await _commandBus.SendAsync(new EncodeMediaCommand
                                                {
                                                    AssetName = title.FileName,
                                                    ClassTag = title.Tag,
                                                    ProviderId = title.ProviderID,
                                                    IsTrailerFile = false,
                                                    AssetUrl = title.RawVideoFileUrl,
                                                    Stage1Encode = provider.Stage1Encode,
                                                    TenantUploadReportTrackingId = uploadTrackEntity.Id
                                                }).ConfigureAwait(false);
                                            }

                                            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
                                            {
                                                _cache.Remove(CacheKeys.VirtualClass);
                                            }
                                            return CreatedAtAction("UploadVideo", uri);
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("UploadVideo exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "ClientProvider")]
        [HttpPost("api/v1/videos/event/{eventId}")]
        public async Task<ActionResult<HttpStatusCode>> UploadEventVideo(string eventId, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                var tenantId = GetTenantIDFromHeaders();
                if (string.IsNullOrWhiteSpace(tenantId))
                {
                    return BadRequest("Invalid tenant Id");
                }

                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-videos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-videos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);

                                            var scheduleEvent = await _eventService.GetEvent(tenantId, eventId).ConfigureAwait(false);

                                            if (scheduleEvent != null && provider != null)
                                            {
                                                VirtualClass title = new VirtualClass();
                                                title.ClassName = await CreateLocalisedText(fileChunk.ResumableFilename.Split('.')[0], lang).ConfigureAwait(false);
                                                title.FileName = result.Item2.FileIdentifier;
                                                title.Tag = Guid.NewGuid().ToString();
                                                title.CreationDate = DateTime.UtcNow;
                                                title.RawVideoFileUrl = uri;
                                                title.ProviderID = provider.Tag;
                                                title.Provider = provider.Name;
                                                title.Status = MediaProcessingStatus.EncodingQueued;
                                                title.ProviderType = ProviderType.Tenant;
                                                title.Event_Id = scheduleEvent.Event_Id;
                                                scheduleEvent.Video = title;

                                                //var scheduleExec = DateTime.SpecifyKind(DateTime.Parse(scheduleEvent.Schedule.Next_Occurence_Time), DateTimeKind.Utc).AddHours(3); // for prod
                                                var scheduleExec = DateTime.SpecifyKind(DateTime.Parse(scheduleEvent.Schedule.Next_Occurence_Time), DateTimeKind.Utc).AddHours(24); // for testing
                                                var autopublishCommand = new AutoPublishTitleCommand
                                                {
                                                    Event_Id = scheduleEvent.Event_Id,
                                                    OldStreamingUrl = scheduleEvent.Video.StreamingLink,
                                                    NewStreamingUrl = scheduleEvent.Video.StreamingLink,
                                                    TenantId = tenantId,
                                                };

                                                var schedResult = await _commandBus.SendScheduledAsync(autopublishCommand, scheduleExec).ConfigureAwait(false);

                                                scheduleEvent.Slot = new PublishingSlot
                                                {
                                                    ScheduleMessageSequenceNumber = schedResult.ToString()
                                                };
                                                await _cmsStore.StoreAsync(scheduleEvent).ConfigureAwait(false);


                                                #region Logic to add Tenant Event Upload record without encoding data
                                                var uploadTrackEntity = await GetNewUploadTrackEntity(title, scheduleEvent, userId, false, fileChunk.ResumableTotalSize, lang);
                                                uploadTrackEntity = await _contentWriteStoreRepo.UpsertAndReturnEntity(0, uploadTrackEntity);
                                                #endregion

                                                await _commandBus.SendAsync(new EncodeEventMediaCommand
                                                {
                                                    EventId = scheduleEvent.Event_Id,
                                                    Tenant = scheduleEvent.TenantId,
                                                    AssetName = title.FileName,
                                                    AssetUrl = title.RawVideoFileUrl,
                                                    ClassTag = title.Tag,
                                                    IsTrailerFile = false,
                                                    ProviderId = title.ProviderID,
                                                    Stage1Encode = provider.Stage1Encode,
                                                    TenantUploadReportTrackingId = uploadTrackEntity.Id
                                                }).ConfigureAwait(false);
                                            }

                                            return CreatedAtAction("UploadEventVideo", uri);
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();

            }
            catch (Exception)
            {

                throw;
            }
        }


        [Authorize(Policy = "ClientProvider")]
        [HttpPost("api/v1/trailer/event/{eventId}")]
        public async Task<ActionResult<HttpStatusCode>> UploadEventTrailer(string eventId, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                var tenantId = GetTenantIDFromHeaders();
                if (string.IsNullOrWhiteSpace(tenantId))
                {
                    return BadRequest("Invalid tenant Id");
                }

                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-trailervideos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-trailervideos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);

                                            var scheduleEvent = await _eventService.GetEvent(tenantId, eventId).ConfigureAwait(false);

                                            if (scheduleEvent != null && provider != null)
                                            {
                                                scheduleEvent.Video.TrailerName = result.Item2.FileIdentifier;
                                                scheduleEvent.Video.TrailerLinkWeb = uri;
                                                scheduleEvent.Video.Status = scheduleEvent.Video.Status == MediaProcessingStatus.Published ? MediaProcessingStatus.Unpublished : scheduleEvent.Video.Status;
                                                scheduleEvent.Video.ProviderType = ProviderType.Tenant;
                                                scheduleEvent.Video.Event_Id = scheduleEvent.Event_Id;
                                                await _cmsStore.StoreAsync(scheduleEvent).ConfigureAwait(false);

                                                await _commandBus.SendAsync(new EncodeEventMediaCommand
                                                {
                                                    AssetName = scheduleEvent.Video.TrailerName,
                                                    ClassTag = scheduleEvent.Video.Tag,
                                                    ProviderId = scheduleEvent.Video.ProviderID,
                                                    IsTrailerFile = true,
                                                    Stage1Encode = false,
                                                    AssetUrl = scheduleEvent.Video.TrailerLinkWeb,
                                                    EventId = scheduleEvent.Event_Id,
                                                    Tenant = scheduleEvent.TenantId
                                                }).ConfigureAwait(false);
                                            }

                                            return CreatedAtAction("UploadEventTrailer", uri);
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();

            }
            catch (Exception)
            {

                throw;
            }
        }

        [Authorize(Policy = "ProviderClientProvider")]
        [HttpPost("api/v1/trailer/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> UploadTrailer(string tag, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-trailervideos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-trailervideos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            VirtualClass virtualClass = await _titleService.Get(userId, tag).ConfigureAwait(false);

                                            if (virtualClass != null)
                                            {
                                                virtualClass.TrailerName = result.Item2.FileIdentifier;
                                                virtualClass.TrailerLinkWeb = uri;
                                                virtualClass.Status = virtualClass.Status == MediaProcessingStatus.Published ? MediaProcessingStatus.Unpublished : virtualClass.Status;


                                                await _cmsStore.StoreAsync(virtualClass.Tag, virtualClass, "", virtualClass.ProviderID).ConfigureAwait(false);

                                                await _commandBus.SendAsync(new EncodeMediaCommand
                                                {
                                                    AssetName = virtualClass.TrailerName,
                                                    ClassTag = virtualClass.Tag,
                                                    ProviderId = virtualClass.ProviderID,
                                                    IsTrailerFile = true,
                                                    Stage1Encode = false,
                                                    AssetUrl = virtualClass.TrailerLinkWeb
                                                }).ConfigureAwait(false);

                                                if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
                                                {
                                                    _cache.Remove(CacheKeys.VirtualClass);
                                                }

                                                return CreatedAtAction("UploadTrailer", uri);
                                            }
                                            else
                                            {
                                                return NotFound("Title not found");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("UploadTrailer exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "Provider")]
        [HttpPost("api/v1/encodevideo/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> EncodeVideo(string tag)
        {
            string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
            VirtualClass virtualClass = await _titleService.Get(userId, tag).ConfigureAwait(false);

            if (virtualClass != null)
            {
                await _commandBus.SendAsync(new EncodeMediaCommand
                {
                    AssetName = virtualClass.FileName,
                    ClassTag = virtualClass.Tag,
                    ProviderId = virtualClass.ProviderID,
                    IsTrailerFile = false,
                    AssetUrl = virtualClass.RawVideoFileUrl,
                    Stage1Encode = provider.Stage1Encode
                }).ConfigureAwait(false);

                virtualClass.Status = MediaProcessingStatus.EncodingQueued;

                await _cmsStore.StoreAsync(virtualClass.Tag, virtualClass, "", virtualClass.ProviderID).ConfigureAwait(false);
            }

            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
            {
                _cache.Remove(CacheKeys.VirtualClass);
            }

            return Ok();
        }


        [Authorize(Policy = "ClientProvider")]
        [HttpPost("api/v1/event/encodevideo/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> EncodeEventVideo(string tag)
        {
            var tenant = GetTenantIDFromHeaders();
            if (string.IsNullOrWhiteSpace(tenant))
            {
                return BadRequest();
            }
            string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
            ScheduleEvent @event = await _eventService.GetEvent(tenant, tag).ConfigureAwait(false);

            if (@event != null && @event.Video != null)
            {
                await _commandBus.SendAsync(new EncodeEventMediaCommand
                {
                    EventId = @event.Event_Id,
                    Tenant = tenant,
                    AssetName = @event.Video.FileName,
                    ClassTag = @event.Video.Tag,
                    ProviderId = @event.Video.ProviderID,
                    IsTrailerFile = false,
                    AssetUrl = @event.Video.RawVideoFileUrl,
                    Stage1Encode = provider.Stage1Encode
                }).ConfigureAwait(false);

                @event.Video.Status = MediaProcessingStatus.EncodingQueued;

                await _cmsStore.StoreAsync(@event).ConfigureAwait(false);
            }

            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
            {
                _cache.Remove(CacheKeys.VirtualClass);
            }

            return Ok();
        }


        [Authorize(Policy = "Provider")]
        [HttpPost("api/v1/encodetrailer/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> EncodeTrailer(string tag)
        {
            string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

            Provider provider = null;
            if (!_cache.TryGetValue(CacheKeys.Providers, out Provider[] providers))
            {
                provider = await _providerService.Get(userId).ConfigureAwait(false);
            }
            else
            {
                provider = providers.FirstOrDefault(t => t.Tag == userId);
            }

            VirtualClass virtualClass = null;
            if (!_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> titles))
            {
                virtualClass = await _titleService.Get(userId, tag).ConfigureAwait(false);
            }
            else
            {
                virtualClass = titles.FirstOrDefault(x => x.Tag == tag);
                _cache.Remove(CacheKeys.VirtualClass);
            }

            if (virtualClass != null)
            {
                await _commandBus.SendAsync(new EncodeMediaCommand
                {
                    AssetName = virtualClass.TrailerName,
                    ClassTag = virtualClass.Tag,
                    ProviderId = virtualClass.ProviderID,
                    IsTrailerFile = true,
                    Stage1Encode = false,
                    AssetUrl = virtualClass.TrailerLinkWeb
                }).ConfigureAwait(false);

                virtualClass.Status = MediaProcessingStatus.EncodingQueued;

                await _cmsStore.StoreAsync(virtualClass.Tag, virtualClass, "", virtualClass.ProviderID).ConfigureAwait(false);
            }

            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
            {
                _cache.Remove(CacheKeys.VirtualClass);
            }

            return Ok();
        }


        [Authorize(Policy = "ClientProvider")]
        [HttpPost("api/v1/event/encodetrailer/{tag}")]
        public async Task<ActionResult<HttpStatusCode>> EncodeEventTrailer(string tag)
        {
            var tenant = GetTenantIDFromHeaders();
            if (string.IsNullOrWhiteSpace(tenant))
            {
                return BadRequest();
            }

            string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
            ScheduleEvent @event = await _eventService.GetEvent(tenant, tag).ConfigureAwait(false);

            if (@event != null)
            {
                await _commandBus.SendAsync(new EncodeEventMediaCommand
                {
                    AssetName = @event.Video.TrailerName,
                    ClassTag = @event.Video.Tag,
                    ProviderId = @event.Video.ProviderID,
                    IsTrailerFile = true,
                    Stage1Encode = false,
                    AssetUrl = @event.Video.TrailerLinkWeb,
                    EventId = @event.Event_Id,
                    Tenant = @event.TenantId
                }).ConfigureAwait(false);

                @event.Video.Status = MediaProcessingStatus.EncodingQueued;

                await _cmsStore.StoreAsync(@event).ConfigureAwait(false);
            }

            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
            {
                _cache.Remove(CacheKeys.VirtualClass);
            }

            return Ok();
        }

        [Authorize(Policy = "ProviderClientProvider")]
        [HttpPut("api/v1/videos/{titleTag}")]
        public async Task<ActionResult<HttpStatusCode>> ReplaceTitleVideo(string titleTag, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-videos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-videos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
                                            VirtualClass virtualClass = await _titleService.Get(userId, titleTag).ConfigureAwait(false);

                                            if (virtualClass != null)
                                            {
                                                virtualClass.RawVideoFileUrl = uri;
                                                virtualClass.Status = MediaProcessingStatus.EncodingQueued;
                                                virtualClass.LastModifiedDate = DateTime.UtcNow;
                                                virtualClass.FileName = result.Item2.FileIdentifier;
                                            }

                                            await _cmsStore.StoreAsync(virtualClass.Tag, virtualClass, "", virtualClass.ProviderID).ConfigureAwait(false);

                                            #region Logic to add TenantUpload record without encoding data
                                            var uploadTrackEntity = await GetNewUploadTrackEntity(virtualClass, null, userId, false, fileChunk.ResumableTotalSize, lang);
                                            uploadTrackEntity = await _contentWriteStoreRepo.UpsertAndReturnEntity(0, uploadTrackEntity);
                                            #endregion

                                            await _commandBus.SendAsync(new EncodeMediaCommand
                                            {
                                                AssetName = virtualClass.FileName,
                                                ClassTag = virtualClass.Tag,
                                                ProviderId = virtualClass.ProviderID,
                                                IsTrailerFile = false,
                                                AssetUrl = virtualClass.RawVideoFileUrl,
                                                Stage1Encode = provider.Stage1Encode,
                                                TenantUploadReportTrackingId = uploadTrackEntity.Id
                                            }).ConfigureAwait(false);

                                            if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
                                            {
                                                _cache.Remove(CacheKeys.VirtualClass);
                                            }

                                            return CreatedAtAction("UploadVideo", uri);
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("ReplaceTitleVideo exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "ProviderClientProvider")]
        [HttpPut("api/v1/trailer/{titleTag}")]
        public async Task<ActionResult<HttpStatusCode>> ReplaceTrailer(string titleTag, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();
                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-trailervideos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-trailervideos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            VirtualClass virtualClass = virtualClass = await _titleService.Get(userId, titleTag).ConfigureAwait(false);

                                            if (virtualClass != null)
                                            {
                                                virtualClass.TrailerName = result.Item2.FileIdentifier;
                                                virtualClass.TrailerLinkWeb = uri;
                                                virtualClass.Status = virtualClass.Status == MediaProcessingStatus.Published ? MediaProcessingStatus.Unpublished : virtualClass.Status;


                                                await _cmsStore.StoreAsync(virtualClass.Tag, virtualClass, "", virtualClass.ProviderID).ConfigureAwait(false);

                                                await _commandBus.SendAsync(new EncodeMediaCommand
                                                {
                                                    AssetName = virtualClass.TrailerName,
                                                    ClassTag = virtualClass.Tag,
                                                    ProviderId = virtualClass.ProviderID,
                                                    IsTrailerFile = true,
                                                    Stage1Encode = false,
                                                    AssetUrl = virtualClass.TrailerLinkWeb
                                                }).ConfigureAwait(false);

                                                if (_cache.TryGetValue(CacheKeys.VirtualClass, out IEnumerable<VirtualClass> classes))
                                                {
                                                    _cache.Remove(CacheKeys.VirtualClass);
                                                }

                                                return CreatedAtAction("UploadTrailer", uri);
                                            }
                                            else
                                            {
                                                return NotFound("Title not found");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("ReplaceTrailer exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        [Authorize(Policy = "ClientProvider")]
        [HttpPut("api/v1/videos/event/{eventId}")]
        public async Task<ActionResult<HttpStatusCode>> ReplaceEventVideo(string eventId, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                var tenantId = GetTenantIDFromHeaders();
                if (string.IsNullOrWhiteSpace(tenantId))
                {
                    return BadRequest("Invalid tenant Id");
                }

                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-videos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-videos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
                                            var scheduleEvent = await _eventService.GetEvent(tenantId, eventId).ConfigureAwait(false);

                                            if (provider != null && scheduleEvent != null)
                                            {

                                                if (!scheduleEvent.Video.RawVideoFileUrl.Equals(uri))
                                                {
                                                    if (scheduleEvent.Slot != null)
                                                    {
                                                        await _commandBus.CancelScheduleAsync(Convert.ToInt64(scheduleEvent.Slot.ScheduleMessageSequenceNumber)).ConfigureAwait(false);
                                                    }
                                                }
                                                //var scheduleExec = DateTime.SpecifyKind(DateTime.Parse(scheduleEvent.Schedule.Next_Occurence_Time), DateTimeKind.Utc).AddHours(3) // for prod
                                                var scheduleExec = DateTime.SpecifyKind(DateTime.Parse(scheduleEvent.Schedule.Next_Occurence_Time), DateTimeKind.Utc).AddHours(24); // for testing
                                                var autopublishCommand = new AutoPublishTitleCommand
                                                {
                                                    Event_Id = scheduleEvent.Event_Id,
                                                    OldStreamingUrl = scheduleEvent.Video.RawVideoFileUrl,
                                                    TenantId = tenantId,
                                                };


                                                scheduleEvent.Video.RawVideoFileUrl = uri;
                                                scheduleEvent.Video.Status = MediaProcessingStatus.EncodingQueued;
                                                scheduleEvent.Video.LastModifiedDate = DateTime.UtcNow;
                                                scheduleEvent.Video.FileName = result.Item2.FileIdentifier;
                                                scheduleEvent.Video.Event_Id = scheduleEvent.Event_Id;

                                                autopublishCommand.NewStreamingUrl = uri;

                                                var schedResult = await _commandBus.SendScheduledAsync(autopublishCommand, scheduleExec).ConfigureAwait(false);

                                                scheduleEvent.Slot = new PublishingSlot
                                                {
                                                    Publish_Schedule_Time = scheduleExec,
                                                    ScheduleMessageSequenceNumber = schedResult.ToString(),
                                                };


                                                await _cmsStore.StoreAsync(scheduleEvent).ConfigureAwait(false);

                                                #region Logic to add Tenant Event Upload record without encoding data
                                                var uploadTrackEntity = await GetNewUploadTrackEntity(scheduleEvent.Video, scheduleEvent, userId, false, fileChunk.ResumableTotalSize, lang);
                                                uploadTrackEntity = await _contentWriteStoreRepo.UpsertAndReturnEntity(0, uploadTrackEntity);
                                                #endregion

                                                await _commandBus.SendAsync(new EncodeEventMediaCommand
                                                {
                                                    EventId = scheduleEvent.Event_Id,
                                                    Tenant = scheduleEvent.TenantId,
                                                    AssetName = scheduleEvent.Video.FileName,
                                                    AssetUrl = scheduleEvent.Video.RawVideoFileUrl,
                                                    ClassTag = scheduleEvent.Video.Tag,
                                                    IsTrailerFile = false,
                                                    ProviderId = scheduleEvent.Video.ProviderID,
                                                    Stage1Encode = provider.Stage1Encode,
                                                    TenantUploadReportTrackingId = uploadTrackEntity.Id
                                                }).ConfigureAwait(false);
                                            }

                                            return CreatedAtAction("ReplaceEventVideo", uri);
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("ReplaceEventVideo exception", "warn", e.ToString());
                return StatusCode(500);
            }
            finally
            {
                //_sem.Release();
            }
        }

        [Authorize(Policy = "ClientProvider")]
        [HttpPut("api/v1/trailer/event/{eventId}")]
        public async Task<ActionResult<HttpStatusCode>> ReplaceEventTrailer(string eventId, [FromForm] FileChunkMetadata fileChunk, CancellationToken stoppingToken)
        {
            try
            {
                string userId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault();

                var tenantId = GetTenantIDFromHeaders();
                if (string.IsNullOrWhiteSpace(tenantId))
                {
                    return BadRequest("Invalid tenant Id");
                }

                if (fileChunk != null && fileChunk.ResumableChunkSize > 0)
                {
                    fileChunk.SetByteArray();
                    fileChunk.GetByteArray();

                    var result = await _fileStoreRepo.PutInBlocksAsync(fileChunk, "portal-raw-trailervideos", stoppingToken).ConfigureAwait(false);
                    if (result.Item1 == HttpStatusCode.NoContent)
                    {
                        var tableResult = await _cmsStore.StoreAsync(result.Item2).ConfigureAwait(false);
                        if (tableResult != null && tableResult.IsSuccessStatusCode)
                        {
                            if (fileChunk.ResumableChunkNumber == fileChunk.ResumableTotalChunks)
                            {
                                var blocks = await _cmsStore.QueryAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                if (blocks != null && blocks.Count() > 0)
                                {
                                    if (blocks.All(x => x.Status == PortalMediaStatus.Complete))
                                    {
                                        var uri = await _fileStoreRepo.CommitBlocks(blocks.OrderBy(t => t.ChunkNumber).Select(t => t.BlockId), "portal-raw-trailervideos",
                                                        result.Item2.FileIdentifier, stoppingToken).ConfigureAwait(false);

                                        var clearTable = await _cmsStore.DeleteAllAsync<PortalMedia>(result.Item2.PartitionKey).ConfigureAwait(false);
                                        if (!string.IsNullOrEmpty(uri))
                                        {
                                            var lang = GetIETFTagFromHeaders();
                                            if (string.IsNullOrEmpty(lang))
                                            {
                                                lang = "en-GB";
                                            }

                                            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
                                            var scheduleEvent = await _eventService.GetEvent(tenantId, eventId).ConfigureAwait(false);

                                            if (provider != null && scheduleEvent != null)
                                            {
                                                scheduleEvent.Video.TrailerName = result.Item2.FileIdentifier;
                                                scheduleEvent.Video.TrailerLinkWeb = uri;
                                                scheduleEvent.Video.Status = scheduleEvent.Video.Status == MediaProcessingStatus.Published ? MediaProcessingStatus.Unpublished : scheduleEvent.Video.Status;
                                                scheduleEvent.Video.Event_Id = scheduleEvent.Event_Id;
                                                await _cmsStore.StoreAsync(scheduleEvent).ConfigureAwait(false);

                                                await _commandBus.SendAsync(new EncodeEventMediaCommand
                                                {
                                                    EventId = scheduleEvent.Event_Id,
                                                    Tenant = scheduleEvent.TenantId,
                                                    AssetName = scheduleEvent.Video.FileName,
                                                    AssetUrl = scheduleEvent.Video.RawVideoFileUrl,
                                                    ClassTag = scheduleEvent.Video.Tag,
                                                    IsTrailerFile = true,
                                                    ProviderId = scheduleEvent.Video.ProviderID,
                                                    Stage1Encode = false
                                                }).ConfigureAwait(false);
                                            }

                                            return CreatedAtAction("ReplaceEventTrailer", uri);
                                        }
                                    }
                                    else
                                    {
                                        return StatusCode(500);
                                    }
                                }
                            }
                            return Ok();
                        }
                        return StatusCode(tableResult.HttpStatusCode);
                    }
                    return StatusCode((int)result.Item1);
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                _logger.Warn("RepalceEventTrailer exception", "warn", e.ToString());
                return StatusCode(500);
            }
        }

        private async Task<OndemandTenantUploadTrackingEntity> GetNewUploadTrackEntity(VirtualClass title,
            ScheduleEvent eventDetail, string userId, bool isTrailerFile, long fileSize, string lang = "en-GB")
        {
            Provider provider = await _providerService.Get(userId).ConfigureAwait(false);
            return new OndemandTenantUploadTrackingEntity
            {
                TitleTag = title.Tag,
                Title = title.ClassName,
                FileName = title.FileName,
                FileSize = fileSize.ToString(),
                TitleType = Convert.ToInt32(isTrailerFile ? TitleType.Trailer : TitleType.Title),
                DurationSecond = title.DurationSecond,
                ProviderId = provider.ProviderId,
                ProviderName = provider.Name,
                EncodedDurationMinutes = 0,
                EncodedDurationMultiplier = 0,
                EventId = eventDetail != null ? eventDetail.Event_Id : null,
                EventName = eventDetail != null ? eventDetail.Title.FlattenByLanguage(lang) : null,
                UploadedDate = DateTime.UtcNow,
                EncodedDate = null,
                UploadedByUserEmail = User.Claims.Where(t => t.Type == ClaimTypes.Email).Select(t => t.Value).FirstOrDefault(),
                UploadedByUserId = User.Claims.Where(t => t.Type == ClaimTypes.NameIdentifier).Select(t => t.Value).FirstOrDefault()
            };
        }
    }
}
